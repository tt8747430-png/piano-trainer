// L = left hand, R = right hand. Canonical location for this type — the hand
// engine (utils/handAssignment.ts) and metadata round-trip (utils/handMetadata.ts)
// both import it from here rather than declaring their own.
export type Hand = 'L' | 'R'

// Canonical location for the note-hit visual effect pattern — the store and
// components/PianoRoll/HitEffects.ts both import it from here.
export type HitEffectPattern =
  | 'glowBloom' | 'rippleRing' | 'particleBurst'
  | 'smokePlume' | 'colorAura' | 'starburstNova' | 'cometTrail'

// Downloadable extra SF2/SF3 sound libraries (Samples engine). 'generaluser-gs'
// is the always-bundled default and is never downloaded/deleted. User-imported
// soundfonts get a dynamic 'custom:<filename>' id, so this is a plain string
// rather than a fixed union.
export type SoundfontId = string

export interface SoundfontInfo {
  id: SoundfontId
  name: string
  sizeMB: number
  downloaded: boolean
  custom?: boolean
}

export interface ParsedNote {
  midi: number
  time: number
  duration: number
  velocity: number
  trackIndex: number
  // ── Hand-assignment sidecar — authoritative in-memory source of truth ──────
  // Set either by utils/handAssignment.ts (assignHands()) or restored from an
  // exported hint on reimport (utils/handMetadata.ts). Absent until one of
  // those has run; absence is not itself meaningful (not yet decided, not "no hand").
  hand?: Hand
  // 0..1, present only alongside `hand`. Sidecar-only — never written to the
  // exported MIDI file. Re-derivable from the algorithm, not authoritative
  // once a human has accepted a split, so there's no case for spending an
  // SMF meta-event slot on it.
  handConfidence?: number
  // ── 'computed' = algorithm decided this (default once `hand` is set).
  // 'manual' = a human confirmed it via Note Editor's Assign LH/RH — from
  // then on authoritative: assignHands()/auto-tag-on-load must never
  // overwrite it, and Split partitions it by tag instead of recomputing.
  // Absent has the same meaning as 'computed' for any note that predates
  // this field (old hints, notes assigned before this existed). ────────────
  handSource?: 'computed' | 'manual'
}

export interface SustainEvent {
  time: number   // seconds, at the file's own tempo
  down: boolean  // true = pedal pressed (CC64 ≥ 64)
}

export interface ControlEvent {
  time: number   // seconds, at the file's own tempo
  value: number  // 0–1
}

export interface ParsedTrack {
  index: number
  name: string
  gmName: string
  program: number
  group: string
  isDrum: boolean
  color: string
  notes: ParsedNote[]
  channel: number
  // ── Sustain-pedal (CC64) transitions on this track's channel, time-ordered,
  // consecutive duplicates collapsed. The Samples engine replays these to
  // spessasynth so pedalled passages ring; the GM engine gets pedal for free
  // (it streams the raw MIDI). Absent when the file has no CC64 data. ────────
  sustainEvents?: SustainEvent[]
  // ── The song's own volume (CC7) and expression (CC11) as it moves: fades,
  // swells, a part brought up for its solo. Both engines play them on top of
  // the Console fader (src/audio/songVolume.ts). Absent when the file has none.
  volumeEvents?: ControlEvent[]
  expressionEvents?: ControlEvent[]
}

export interface TempoEvent {
  bpm: number
  time: number
}

export interface ParsedMidi {
  fileName: string
  duration: number
  bpm: number
  timeSignatureNumerator: number
  timeSignatureDenominator: number
  tracks: ParsedTrack[]
  noteCount: number
  _tempoMap?: TempoEvent[]
  _barTimes?: number[]
  _beatTimes?: number[]
  // ── The bytes this song plays from (GM streams them as they are)
  _raw?: ArrayBuffer
  // ── Skip empty bars at the start (utils/prepareSong.ts): the file's own
  // bytes (song identity, reloading, saving with the lead-in kept) and where
  // the song was cut — 0 when it wasn't. Set once a song has been prepared.
  _origRaw?: ArrayBuffer
  _leadTick?: number
  _leadSec?: number
}

export type PlaybackState = 'stopped' | 'playing' | 'paused'

export interface TrackState {
  index: number
  name: string
  gmName: string
  trackName: string  // user-visible label; defaults to gmName, editable in MIDI Playback Editor
  program: number
  group: string
  isDrum: boolean
  color: string
  colorSource: 'default' | 'palette' | 'custom'
  muted: boolean
  solo: boolean
  visible: boolean
  showOnKeyboard: boolean
  volume: number
  pan: number
  chorus: number
  reverb: number
}

export type KeyboardSize = 61 | 73 | 88
export type KeyboardMode = 'docked' | 'floating'
export type NoteNaming = 'english' | 'central-european' | 'solfege' | 'hidden'
export type Accidentals = 'flat' | 'sharp'
// ── Chord *type/quality* naming — orthogonal to NoteNaming (which governs
// root-letter spelling). 'abbreviation' = "Bb(b5)", 'symbol' = "Bb(♭5)". ────
export type ChordNamingStyle = 'abbreviation' | 'symbol'

export type ChordTrackingMode = 'auto' | 'harmony' | 'follow'
export type ChordFollowSubMode = 'group' | 'track'
export type ChordReadingMode = 'safe' | 'progressive'

export interface MidiFileResult {
  fileName: string
  filePath: string
  base64: string
}

export interface LibraryFile {
  name: string
  path: string
}

export interface ChordEvent {
  time: number
  name: string
  // ── Raw pitch-class spelling of the chord (root-position, tonal's default
  // accidentals) — NOT display-localized to the user's noteNaming/accidentals.
  // No consumer reads this today; localize at the call site if one ever does.
  notes: string[]
  // ── The exact real MIDI notes (with real octave) actually sounding at
  // this event — already transpose-adjusted. "Show on keyboard" uses these
  // directly so the locked chord shows up in the SAME register it was
  // actually playing in, instead of buildChordMidi()'s canonical-octave
  // reconstruction (which is deliberately register-agnostic — right for
  // "Open in Chord Explorer", wrong for "Show on keyboard"). ────────────────
  realMidi: number[]
  // ── Root-position identity for this chord — null when structured detection
  // fails even though basic detection succeeded (rare). Lets consumers (the
  // playback chord-display context menu) reconstruct a canonical voicing via
  // buildChordMidi() without re-parsing the localized display name. ─────────
  structured: { rootPitchClass: number; intervals: string[]; rawRootName: string } | null
  // ── Beat-aligned time the display should switch at. Equals `time` for the
  // sequence builder (its windows already start on beats); a distinct field
  // so consumers never assume time === display. ─────────────────────────
  displayTime: number
  // ── Segment shorter than one bar — the prompter renders runs of these
  // compressed instead of one-per-slot. ────────────────────────────────
  short: boolean
}

export interface TranscriptEntry {
  midiPath: string
  transcriptPath: string
  date: string
}

declare global {
  interface Window {
    electronAPI: {
      openMidiFile:        () => Promise<MidiFileResult | null>
      getPrefs:            () => Promise<Record<string, any>>
      setPrefs:            (data: Record<string, any>) => Promise<void>
      openFolder:          () => Promise<string | null>
      scanMidiFolder:      (path: string) => Promise<LibraryFile[]>
      getDemoFolder:       () => Promise<string | null>
      loadMidiFromPath:    (path: string) => Promise<MidiFileResult | null>
      // Export to audio: writes to <library>/Orfeo/Exports, returns the saved path
      saveExport:          (songPath: string, libraryFolder: string | null, fileName: string, bytes: Uint8Array) => Promise<string>
      statFiles:           (paths: string[]) => Promise<{ path: string; size: number; mtime: number }[]>
      windowMinimize:      () => Promise<void>
      windowMaximize:      () => Promise<void>
      windowClose:         () => Promise<void>
      transcriptGenerate:  (midiPath: string, noteNaming: string, accidentals: string) => Promise<{ success: boolean; path?: string; error?: string }>
      saveFileDialog:      (opts: { defaultPath: string; filters: { name: string; extensions: string[] }[] }) => Promise<string | null>
      saveMidiEditor:      (payload: { filePath: string; outputPath: string; includedTracks: { index: number; newProgram: number; name?: string; color?: string; splitHand?: 'L' | 'R'; visible?: boolean; showOnKeyboard?: boolean }[]; mergeGroups: number[][]; rhMaxFingers?: number; lhMaxFingers?: number; bpmRatio?: number; transposeSemitones?: number; finalKey?: { semitone: number; isMinor: boolean } }) => Promise<{ ok: boolean; message: string; filePath?: string; fileName?: string; base64?: string }>
      saveMixerChannels:   (payload: { filePath: string; channels: { index: number; volume: number; pan: number; chorus: number; reverb: number }[] }) => Promise<{ ok: boolean; message?: string; filePath?: string; fileName?: string; base64?: string }>
      saveNoteEditor:      (payload: { filePath: string; base64: string; summary?: string }) => Promise<{ ok: boolean; message?: string; filePath?: string; fileName?: string; base64?: string }>
      saveTempoKey:        (payload: { filePath: string; bpmRatio: number; transposeSemitones: number; summary: string; finalKey?: { semitone: number; isMinor: boolean } }) => Promise<{ ok: boolean; message?: string; filePath?: string; fileName?: string; base64?: string }>
      showMessageBox:      (opts: { type?: string; buttons: string[]; defaultId?: number; cancelId?: number; message: string; detail?: string }) => Promise<{ response: number }>
      confirmClose:        () => Promise<void>
      setFullScreen:       (value: boolean) => Promise<void>
      onSaveBeforeClose:   (fn: () => void) => void
      offSaveBeforeClose:  () => void
      openExternal:        (url: string) => Promise<void>
      openFolderInExplorer: (folderPath: string) => Promise<string>
      showItemInFolder:    (filePath: string) => Promise<void>
      // Library folder management — create/rename/delete/move, scoped to libraryFolder
      listLibraryFolders:  (libraryFolder: string) => Promise<string[]>
      createLibraryFolder: (libraryFolder: string, name: string) => Promise<string>
      renameLibraryFolder: (libraryFolder: string, oldName: string, newName: string) => Promise<{ ok: boolean; reason?: string; name?: string; pairs?: { oldPath: string; newPath: string }[] }>
      deleteLibraryFolder: (libraryFolder: string, name: string) => Promise<{ ok: boolean; reason?: string }>
      renameLibraryFile: (filePath: string, newName: string) => Promise<{ ok: boolean; reason?: string; newPath?: string }>
      getFileLog:  (filePath: string) => Promise<{ type: string; timestamp: number; summary: string }[]>
      logFileEvent: (filePath: string, type: string, summary: string) => Promise<void>
      listFileVersions: (filePath: string) => Promise<{ name: string; path: string; version: number; mtime: number }[]>
      moveLibraryFiles:    (filePaths: string[], libraryFolder: string, destFolderName: string | null) => Promise<{ oldPath: string; newPath: string }[]>
      // Downloadable extra soundfonts (Samples engine)
      listSoundfonts:      () => Promise<SoundfontInfo[]>
      downloadSoundfont:   (id: SoundfontId) => Promise<{ ok: boolean; error?: string }>
      deleteSoundfont:     (id: SoundfontId) => Promise<void>
      readSoundfont:       (id: SoundfontId) => Promise<ArrayBuffer | null>
      // Native audio engine (beta) — see src/audio/nativeClient.ts
      connectNativeAudio:    () => Promise<{ ok: boolean; reason?: string }>
      nativeSoundfontPaths:  (extraId: string | null) => Promise<string[]>
      onNativeAudioHostExit: (fn: (code: number) => void) => void
      importSoundfont:     () => Promise<SoundfontId | null>
      onSoundfontProgress: (fn: (data: { id: SoundfontId; progress: number }) => void) => void
      offSoundfontProgress: () => void
      // Drag-and-drop file import
      getPathForFile:      (file: File) => string
      copyMidiToLibrary:   (sourcePath: string, libraryFolder: string) => Promise<string>
      // Foreign format import cache
      getCachedImport:     (sourcePath: string, cachePath: string) => Promise<string | null>
      writeCachedImport:   (destPath: string, base64: string) => Promise<void>
      // Auto-update (GitHub Releases)
      getUpdateInfo:       () => Promise<UpdateInfo>
      checkForUpdates:     () => Promise<void>
      installUpdate:       () => Promise<void>
      onUpdateStatus:      (fn: (data: UpdateStatus) => void) => void
      offUpdateStatus:     () => void
      // "Enjoying Orfeo?" note + Rate Orfeo (Store build)
      getSupportNoteInfo:  () => Promise<SupportNoteInfo>
      requestReview:       () => Promise<'succeeded' | 'canceled' | 'network-error' | 'error'>
      neverShowSupportNote: () => Promise<void>
      snoozeSupportNote:   () => Promise<void>
      // App zoom (Ctrl +/−/0)
      getZoom:             () => Promise<{ percent: number; steps: number[]; max: number }>
      setZoom:             (percent: number) => Promise<{ percent: number; capped: boolean } | null>
      onZoomChanged:       (fn: (data: { percent: number; capped: boolean }) => void) => void
      offZoomChanged:      (fn: (data: { percent: number; capped: boolean }) => void) => void
    }
  }
}

// ── How the "check for updates" button behaves for this build, decided once
// in electron/main.ts and read by SettingsPanel on mount:
//   'auto'   — installed Windows build: electron-updater does check→download→install.
//   'store'  — Microsoft Store build: the Store updates it; the button opens the Store.
//   'manual' — portable / macOS / Linux / dev: the button just opens downloadUrl (orfeo.cc/download).
export type UpdateInfo = {
  mode: 'auto' | 'store' | 'manual'
  downloadUrl: string
}

// ── "Enjoying Orfeo?" note — decided in electron/main.ts: `store` = the
// Microsoft Store build (its note and star offer the Store's review window);
// `prompt` = show the note this launch (every 5th, unless paused or done)
export type SupportNoteInfo = { store: boolean; prompt: boolean }

export type UpdateStatus = {
  state: 'idle' | 'checking' | 'up-to-date' | 'downloading' | 'ready' | 'error' | 'unavailable'
  version?: string
  percent?: number
  reason?: string
  message?: string
}

// ── Tap Tempo session — see utils/tapTempoSession.ts. Session-only state,
// never persisted. ──────────────────────────────────────────────────────────
export interface TapSession {
  phase: 'armed' | 'tapping' | 'preview'
  start: number              // song seconds — where the correction will take over
  taps: number[]             // heard song time of each tap
  segment: import('../utils/tempoCorrection').TempoSegment | null  // the preview segment
  prevMetronome: boolean     // metronome on/off before the session, restored at the end
  message: string | null     // e.g. "Need at least 4 taps"
  lastTapAt: number          // performance.now() of the last tap
  editIndex?: number | null  // adjusting an already-kept tempo (index into the song's segments)
  listenMetronome?: boolean  // metronome on while listening back (panel switch)
  snapped?: boolean          // grid was lined up with the song's notes
  fileMatch?: number | null  // taps sit on the file's own beats at this ratio (1, 2, 0.5)
  freeSegment?: import('../utils/tempoCorrection').TempoSegment | null  // grid from the taps
  nearOriginal?: boolean     // tapped tempo is within ±3% of the file's own (offer "Original is fine")
}

// ── Settings window / Quick Settings group ids — same keys the drawer's
// fold state (settingsGroupsCollapsed) already uses. ─────────────────────
export type SettingsGroupId =
  // 'playback-editing' is the Playback group (its id kept so saved choices still apply)
  | 'audio' | 'midi-files-library' | 'playback-editing' | 'practice' | 'editing'
  | 'notation' | 'keyboard' | 'piano-roll' | 'appearance' | 'midi'
