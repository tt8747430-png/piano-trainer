import { AudioLines, Timer, TriangleAlert, ListOrdered, Hand, Repeat, Focus, Pause, SkipForward } from 'lucide-react'
import { useStore } from '../../../store'
import { t } from '../../../utils/i18n'
import { Switch, OptionBtn, FingerStepper, InlineIcon, SubLabel, HelpText } from '../controls'
import type { SettingDef } from '../types'
import { applySkipEmptyBarsChange } from '../../../utils/reloadOpenSong'

function TapTempoExtra() {
  const on = useStore(s => s.tapTempoPadEnabled)
  const mode = useStore(s => s.tapTempoMode)
  const setMode = useStore(s => s.setTapTempoMode)
  if (!on) return null
  return (
    <>
      <SubLabel>{t`Tap Tempo counting`}</SubLabel>
      <div style={{ display: 'flex', gap: 'var(--space-1)' }}>
        <OptionBtn active={mode === 'beat'} onClick={() => setMode('beat')}>{t`Every beat`}</OptionBtn>
        <OptionBtn active={mode === 'bar'} onClick={() => setMode('bar')}>{t`Only the 1`}</OptionBtn>
      </div>
      <HelpText>
        {mode === 'beat'
          ? t`Tap 1, 2, 3, 4 — like tapping your foot. Your first tap is the 1.`
          : t`Tap only the first beat of each bar. Every tap is a 1.`}
      </HelpText>
    </>
  )
}

function TempoWarningsExtra() {
  const on = useStore(s => s.tempoWarningsEnabled)
  const dismissedCount = useStore(s => Object.keys(s.tempoWarningDismissed).length)
  if (!on || dismissedCount === 0) return null
  return (
    <>
      <SubLabel>{t`Dismissed tempo warnings`}</SubLabel>
      <OptionBtn active={false} onClick={useStore.getState().clearTempoWarningDismissals}>
        {dismissedCount === 1 ? t`Show the warning for 1 dismissed song again` : t`Show warnings for ${dismissedCount} dismissed songs again`}
      </OptionBtn>
    </>
  )
}

function CountInExtra() {
  const on = useStore(s => s.countInEnabled)
  const bars = useStore(s => s.countInBars)
  const setBars = useStore(s => s.setCountInBars)
  if (!on) return null
  return (
    <>
      <SubLabel>{t`Count-in bars`}</SubLabel>
      <div style={{ display: 'flex', gap: 'var(--space-1)' }}>
        {[1, 2, 3, 4].map(n => <OptionBtn key={n} active={bars === n} onClick={() => setBars(n)}>{String(n)}</OptionBtn>)}
      </div>
    </>
  )
}

// Keep drum count-ins — under the main switch, only while it's on
function SkipEmptyBarsExtra() {
  const on = useStore(s => s.skipEmptyBars)
  const keep = useStore(s => s.keepDrumCountIn)
  if (!on) return null
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) auto', alignItems: 'center', columnGap: 8, minHeight: 22,
      fontSize: 'var(--text-xs)', fontFamily: 'var(--font-ui)', color: 'var(--text-default)' }}>
      <span>{t`Keep drum count-ins`}</span>
      <Switch value={keep} onChange={v => { useStore.getState().setKeepDrumCountIn(v); void applySkipEmptyBarsChange() }} label={t`Keep drum count-ins`} />
    </div>
  )
}

// Max fingers per hand — a real hand-split parameter (handAssignment.ts)
function HandAssignmentExtra() {
  const on = useStore(s => s.showHandLabels)
  const lh = useStore(s => s.lhMaxFingers)
  const rh = useStore(s => s.rhMaxFingers)
  if (!on) return null
  return (
    <>
      <SubLabel>{t`Max Fingers`}</SubLabel>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 10, color: 'var(--text-default)', fontFamily: 'var(--font-ui)', whiteSpace: 'nowrap' }}>{t`Left hand`}</span>
          <FingerStepper value={lh} onChange={useStore.getState().setLhMaxFingers} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 10, color: 'var(--text-default)', fontFamily: 'var(--font-ui)', whiteSpace: 'nowrap' }}>{t`Right hand`}</span>
          <FingerStepper value={rh} onChange={useStore.getState().setRhMaxFingers} />
        </div>
      </div>
      <HelpText>{t`How many notes of a wide chord each hand can take before the rest is absorbed by the other — left counts from the bottom of the chord, right from the top.`}</HelpText>
    </>
  )
}

// Link to Settings › Appearance › Hand colours — in the card's description
// and under the Setup row; opens the Settings window on Appearance
function HandColoursLink() {
  return (
    <button onClick={() => useStore.getState().openSettingsWindow('appearance')}
      style={{ padding: 0, border: 'none', background: 'none', cursor: 'pointer', font: 'inherit', fontStyle: 'normal', color: 'var(--text-amber)', textDecoration: 'underline', textUnderlineOffset: 2 }}>
      {t`Set your own hand colours`}
    </button>
  )
}

export const PLAYBACK_DEFS: SettingDef[] = [
  {
    id: 'noteEditor', icon: AudioLines, kind: 'switch',
    Control: () => { const v = useStore(s => s.noteEditorEnabled); return <Switch value={v} onChange={useStore.getState().setNoteEditorEnabled} label={t`MIDI Note Editor`} /> },
    Description: () => <>{t`Shows`} <InlineIcon><AudioLines size={11} /></InlineIcon> {t`icon in the Tracks panel. Enables MIDI note-editing mode directly on the piano roll.`}</>,
  },
  {
    id: 'tapTempo', icon: Timer, kind: 'switch', Extra: TapTempoExtra,
    Control: () => { const v = useStore(s => s.tapTempoPadEnabled); return <Switch value={v} onChange={useStore.getState().setTapTempoPadEnabled} label={t`Tap Tempo`} /> },
  },
  {
    id: 'tempoWarnings', icon: TriangleAlert, kind: 'switch', Extra: TempoWarningsExtra,
    Description: () => <>
      {t`Marks songs whose bar lines and metronome don't match the music's steady beat — the ones Tap Tempo can fix.`}
      <br /><br />
      {t`Shown`} <span aria-hidden style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: 'var(--text-amber)', verticalAlign: '1px', margin: '0 2px' }} /> {t`next to Key in the top bar and in the Library.`}
    </>,
    Control: () => { const v = useStore(s => s.tempoWarningsEnabled); return <Switch value={v} onChange={useStore.getState().setTempoWarningsEnabled} label={t`Tempo warnings`} /> },
  },
  {
    id: 'countIn', icon: ListOrdered, kind: 'switch', Extra: CountInExtra,
    Control: () => { const v = useStore(s => s.countInEnabled); return <Switch value={v} onChange={useStore.getState().setCountInEnabled} label={t`Count-in`} /> },
  },
  {
    id: 'skipEmptyBars', icon: SkipForward, kind: 'switch', Extra: SkipEmptyBarsExtra,
    Description: () => <>
      {t`Songs that begin with silent bars open with the music on bar 1: the piano roll, bar numbers, playback, loops and step-through all start there. Your files are never changed — switch it off to see a song exactly as written. Switching this on switches off Chord Transcription, whose charts number the bars as the file has them.`}
      <br /><br />
      {t`Keep drum count-ins keeps one or two bars of plain drum clicks before the music.`}
    </>,
    Control: () => { const v = useStore(s => s.skipEmptyBars); return <Switch value={v} onChange={x => { useStore.getState().setSkipEmptyBars(x); void applySkipEmptyBarsChange() }} label={t`Skip empty bars at the start`} /> },
  },
  {
    id: 'handAssignment', icon: Hand, kind: 'switch', Extra: HandAssignmentExtra,
    Control: () => { const v = useStore(s => s.showHandLabels); return <Switch value={v} onChange={useStore.getState().setShowHandLabels} label={t`Hand Assignment`} /> },
    Description: () => <>
      {t`Automated hand assignment for piano that colors each note by the hand that plays it. A guideline, not a verified transcript!`}
      <br /><br />
      {t`For a perfectly accurate split use MIDI note editor and click the`} <InlineIcon><Hand size={11} /></InlineIcon> {t`icon to manually assign notes to left and right hand.`}
      <br /><br />
      <HandColoursLink />
    </>,
    SummaryEnd: HandColoursLink,
  },
  {
    id: 'loopRegion', icon: Repeat, kind: 'switch',
    Control: () => { const v = useStore(s => s.loopRegionEnabled); return <Switch value={v} onChange={useStore.getState().setLoopRegionEnabled} label={t`Loop region`} /> },
    Description: () => <>{t`Shows a strip to select and loop-play a section. Alt+Click & drag to select. Click`} <InlineIcon><Repeat size={11} /></InlineIcon> {t`icon to loop.`}</>,
  },
  {
    id: 'explorerPause', icon: Pause, kind: 'switch',
    Control: () => { const v = useStore(s => s.explorerPausesPlayback); return <Switch value={v} onChange={useStore.getState().setExplorerPausesPlayback} label={t`Explorers pause playback`} /> },
  },
  {
    id: 'focusMode', icon: Focus, kind: 'switch',
    Control: () => { const v = useStore(s => s.autoMuteNonKeyboard); return <Switch value={v} onChange={useStore.getState().setAutoMuteNonKeyboard} label={t`Focus mode`} /> },
  },
]
