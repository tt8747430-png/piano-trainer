import React, { useEffect, useRef, useState } from 'react'
import { Application, Graphics } from 'pixi.js'
import type { Track } from '@tonejs/midi'
import { useStore } from '../../store'
import { isBlackKey } from '../../utils/midiParser'
import { buildKeyLayout, PIANO_RANGES as RANGES, type KeyLayout } from '../../utils/keyLayout'
import { NES } from '../../utils/noteEditorState'
import {
  cmdAddNote, cmdRemoveNotes, cmdSetRangeVelocity, midiToEditableCopy, copyHandTagsOntoEditBuffer,
  type ToneNote,
} from '../../utils/noteEditorCommands'
import { getNoteLabel } from '../../utils/noteNames'
import { PENCIL_CURSOR } from '../../utils/cursors'
import type { Hand } from '../../types'
import { HAND_LH_CSS, HAND_RH_CSS } from '../../utils/handColors'
import { HitEffectsRenderer } from './HitEffects'
import { drainHitEffects } from '../../utils/hitEffectQueue'
import { isShown } from '../../utils/trackShown'
import { t } from '../../utils/i18n'

const VISIBLE_SECONDS  = 6
const NOTE_RADIUS      = 3
const MIN_NOTE_H       = 4
const PLAYHEAD_RATIO   = 0.80
const RESIZE_ZONE_PX   = 6
const DRAG_THRESHOLD   = 4
// ── Velocity lane (edit mode, toggled on demand) — one thin bar per note of
// whichever track is currently soloed for edit, aligned to the same X/pitch
// position as the falling notes and keyboard (one continuous vertical line
// through keyboard key → note → velocity bar). Height is computed live each
// frame as the piano-roll canvas height minus the playhead Y — it covers the
// whole area below the playhead, not a fixed strip; that's the area that's
// visually "spent" once a note has fallen through anyway, and playback is
// paused while editing regardless. Bars only reflect whatever's in the same
// live time-window the falling view already computes — no independent pan/
// zoom to browse the rest of a soloed track's notes while paused; a real
// secondary time-axis mini-editor (closer to Signal/Ableton/Logic's lane)
// is the flagged upgrade if that's ever wanted. ───────────────────────────
const VELOCITY_BAR_W   = 5
const VELOCITY_LANE_HEIGHT_BOOST = 60   // extra px on top of the playhead-derived height

// ── Canvas/PixiJS colors + fonts resolved from CSS custom properties ─────────
// PixiJS Graphics.fill({color}) needs a numeric 0xRRGGBB and Canvas2D ctx.fillStyle
// needs a literal color string — neither can resolve a var() string directly, so
// these are resolved once from index.css tokens via getComputedStyle (see
// resolvePianoRollColorsFromCSS, called on mount) — index.css stays the single
// source of truth; these are just its canvas-usable cache. Defaults here only
// cover the sliver of first render before the mount effect runs. Same pattern as
// ChannelStrip.tsx / MasterStrip.tsx. FONT_UI_STR/FONT_MONO_STR exist for the
// same reason — ctx.font can't resolve var(--font-ui)/var(--font-mono) either.
let HAND_LH_COLOR       = 0x6270a5   // --hand-lh
let HAND_RH_COLOR       = 0xcb636c   // --hand-rh
let SEL_NOTE_COLOR       = 0xffffff   // --note-select-outline — selected/dragged/edited/new notes
let SEL_MARQUEE_COLOR    = 0x7788aa   // --note-marquee-blue — drag-select rectangle
let KEY_ROW_COLOR        = 0x171720   // --pianoroll-key-row — white-key row shading
let KEY_ROW_DARK_COLOR   = 0x0d0d10   // --bg-modal-header (near-match snap) — black-key row shading
let OCTAVE_DIVIDER_COLOR = 0x2e2e48   // --pianoroll-octave-divider
let PLAYHEAD_COLOR       = 0xc6c8c8   // --text-default
let NOTE_HIGHLIGHT_COLOR = 0xffffff   // --text-white (near-match snap) — note top-edge highlight strip
let CANVAS_BG_COLOR      = 0x0f0f12   // --bg-modal-header (near-match snap) — non-warm PixiJS floor
let CANVAS_BG_WARM_COLOR = 0x12100e   // --bg-warm — warm-theme PixiJS floor

let FONT_UI_STR                = "'Inter', sans-serif"           // --font-ui
let FONT_MONO_STR              = "'IBM Plex Mono', monospace"   // --font-mono
let HAND_AMBER_HEX_STR         = '#e8a027'   // --text-amber (string form, for Canvas2D fillStyle)
let BARLINE_COLOR             = '#1e1e38'   // --pianoroll-barline
let BAR_PILL_BG_COLOR         = '#0d0d18'   // --bg-row (near-match snap)
let BAR_PILL_TEXT_DARK_COLOR  = '#0f0f12'   // --bg-modal-header (near-match snap)
let NOTE_LABEL_COLOR          = 'rgba(255,255,255,0.85)'   // --text-canvas-label
let VELOCITY_BAR_HEX_STR      = '#8080cc'   // --merge-badge-text (same blue as MidiEditor's Undo-merge icon)

function hexVarToNumber(raw: string, fallback: number): number {
  const h = raw.trim().replace('#', '')
  if (h.length !== 6 && h.length !== 3) return fallback
  const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h
  const n = parseInt(full, 16)
  return Number.isNaN(n) ? fallback : n
}

function resolvePianoRollColorsFromCSS() {
  const cs = getComputedStyle(document.documentElement)
  const readNum = (name: string, fallback: number) => {
    const raw = cs.getPropertyValue(name).trim()
    return raw ? hexVarToNumber(raw, fallback) : fallback
  }
  const readStr = (name: string, fallback: string) => cs.getPropertyValue(name).trim() || fallback

  HAND_LH_COLOR        = readNum('--hand-lh', HAND_LH_COLOR)
  HAND_RH_COLOR        = readNum('--hand-rh', HAND_RH_COLOR)
  SEL_NOTE_COLOR       = readNum('--note-select-outline', SEL_NOTE_COLOR)
  SEL_MARQUEE_COLOR    = readNum('--note-marquee-blue', SEL_MARQUEE_COLOR)
  KEY_ROW_COLOR        = readNum('--pianoroll-key-row', KEY_ROW_COLOR)
  KEY_ROW_DARK_COLOR   = readNum('--bg-modal-header', KEY_ROW_DARK_COLOR)
  OCTAVE_DIVIDER_COLOR = readNum('--pianoroll-octave-divider', OCTAVE_DIVIDER_COLOR)
  PLAYHEAD_COLOR       = readNum('--text-default', PLAYHEAD_COLOR)
  NOTE_HIGHLIGHT_COLOR = readNum('--text-white', NOTE_HIGHLIGHT_COLOR)
  CANVAS_BG_COLOR      = readNum('--bg-modal-header', CANVAS_BG_COLOR)
  CANVAS_BG_WARM_COLOR = readNum('--bg-warm', CANVAS_BG_WARM_COLOR)

  FONT_UI_STR              = readStr('--font-ui', FONT_UI_STR)
  FONT_MONO_STR            = readStr('--font-mono', FONT_MONO_STR)
  HAND_AMBER_HEX_STR       = readStr('--text-amber', HAND_AMBER_HEX_STR)
  BARLINE_COLOR            = readStr('--pianoroll-barline', BARLINE_COLOR)
  BAR_PILL_BG_COLOR        = readStr('--bg-row', BAR_PILL_BG_COLOR)
  BAR_PILL_TEXT_DARK_COLOR = readStr('--bg-modal-header', BAR_PILL_TEXT_DARK_COLOR)
  NOTE_LABEL_COLOR         = readStr('--text-canvas-label', NOTE_LABEL_COLOR)
  VELOCITY_BAR_HEX_STR     = readStr('--merge-badge-text', VELOCITY_BAR_HEX_STR)
}

// ── FlatNote — used for the main render O(log N) binary search ────────────────
// noteRef — only populated during edit mode's rebuild (see below), so the
// base fill loop can check editNewNotes.has(ef.noteRef) and skip filling a
// brand-new, not-yet-saved note (outline-only, drawn by the edit overlay).
interface FlatNote { midi: number; time: number; duration: number; trackIndex: number; hand?: Hand; noteRef?: ToneNote }

// ── EditFlatNote — actual @tonejs/midi Note references for edit hit-testing ───
interface EditFlatNote {
  note:       ToneNote
  track:      Track
  key:        KeyLayout
  topY:       number   // screen Y of the note's visual top (= note END time)
  botY:       number   // screen Y of the note's visual bottom (= note START time)
  noteH:      number   // clamped height
  trackIndex: number
  color:      number   // track color as hex int
}

// ── EditDragState ─────────────────────────────────────────────────────────────
interface EditDragState {
  mode:              'note-move' | 'note-resize-end' | 'note-resize-start' | 'selection-move'
  note:              ToneNote
  track:             Track
  trackIndex:        number   // parsedTrack.index — for per-channel audio preview
  origTime:          number
  origDuration:      number
  origTicks:         number
  origDurationTicks: number
  origMidi:          number
  origNoteX:         number
  startClientX:      number
  startClientY:      number
  axis:              'time' | 'pitch' | null
  selectionSnapshot?: Array<{ note: ToneNote; origTime: number; origTicks: number; origMidi: number }>
  // Set true only once real drag distance is exceeded (see the jitter gate
  // in onEditMove). A note whose raw tick isn't already grid-aligned (any
  // realistic, humanized performance) would otherwise get silently
  // re-snapped by onEditUp's snapTick(note.time) even on an untouched
  // click — snapping is only meaningful once something was actually dragged.
  moved?:            boolean
}

interface EditMarqueeState {
  startX: number; startY: number; endX: number; endY: number; additive: boolean
}

// ── Lasso — paint-select: a note is added the instant the drag path
// crosses it, not only if fully enclosed (unlike marquee). Points kept only
// for the visible trail; hit-testing happens per-segment as the pointer moves. ──
interface EditLassoState {
  points: { x: number; y: number }[]
  additive: boolean
}

interface EditPanState {
  startClientX: number
  startClientY: number
  startTime:    number
}

export interface ContextMenuOption {
  label: string
  onClick: () => void
  destructive?: boolean
  disabled?: boolean
  swatchColor?: string   // small colored square before the label — LH/RH assign entries
}

export interface ContextMenuState {
  x: number
  y: number
  options: ContextMenuOption[]
}

function lowerBound(notes: FlatNote[], target: number): number {
  let lo = 0, hi = notes.length
  while (lo < hi) {
    const mid = (lo + hi) >> 1
    if (notes[mid].time < target) lo = mid + 1
    else hi = mid
  }
  return lo
}

// ── xToMidi — screen X → MIDI pitch via key layout ───────────────────────────
function xToMidi(x: number, layout: KeyLayout[], midiMin: number, midiMax: number): number {
  for (let m = midiMax; m >= midiMin; m--) {
    if (!isBlackKey(m)) continue
    const k = layout[m - midiMin]
    if (k && x >= k.x && x < k.x + k.width) return m
  }
  for (let m = midiMin; m <= midiMax; m++) {
    if (isBlackKey(m)) continue
    const k = layout[m - midiMin]
    if (k && x >= k.x && x < k.x + k.width) return m
  }
  return midiMin
}

// ── LoopOverlay — amber band + draggable boundary lines over the waterfall ────
function LoopOverlay() {
  const loopStart          = useStore(s => s.loopStart)
  const loopEnd            = useStore(s => s.loopEnd)
  const loopRegionActive   = useStore(s => s.loopRegionActive)
  const currentTime        = useStore(s => s.currentTime)
  const zoomLevel          = useStore(s => s.zoomLevel)
  const noteEditorActive   = useStore(s => s.noteEditorActive)
  const midi               = useStore(s => s.midi)

  const overlayRef  = useRef<HTMLDivElement>(null)
  const draggingRef = useRef<'start' | 'end' | null>(null)
  const newDragRef  = useRef<{ anchorTime: number } | null>(null)
  const [mousePos,  setMousePos]  = useState<{ x: number; y: number } | null>(null)

  // ── Global mouse handlers — drag logic + cursor tooltip tracking ──────────
  useEffect(() => {
    const yToTime = (clientY: number): number => {
      const el = overlayRef.current
      if (!el) return 0
      const rect = el.getBoundingClientRect()
      const pct  = Math.max(0, Math.min(100, (clientY - rect.top) / rect.height * 100))
      const s    = useStore.getState()
      const vs   = VISIBLE_SECONDS / (s.zoomLevel ?? 1)
      return s.currentTime + vs * (1 - pct / (PLAYHEAD_RATIO * 100))
    }
    const onMove = (e: MouseEvent) => {
      const st  = useStore.getState()
      const dur = st.midi?.duration ?? Infinity
      const which = draggingRef.current
      if (which) {
        const t  = Math.max(0, Math.min(dur, yToTime(e.clientY)))
        const ls = st.loopStart ?? 0
        const le = st.loopEnd   ?? 0
        if (which === 'end') st.setLoopRegion(ls, Math.max(t, ls + 0.01))
        else                 st.setLoopRegion(Math.min(t, le - 0.01), le)
        return
      }
      const nd = newDragRef.current
      if (nd) {
        const t     = Math.max(0, Math.min(dur, yToTime(e.clientY)))
        const start = Math.min(nd.anchorTime, t)
        const end   = Math.max(nd.anchorTime, t)
        if (end - start > 0.01) st.setLoopRegion(start, end)
        return
      }
      // Track position for cursor tooltip (only when inside overlay bounds)
      const el = overlayRef.current
      if (el) {
        const rect = el.getBoundingClientRect()
        if (e.clientX >= rect.left && e.clientX <= rect.right &&
            e.clientY >= rect.top  && e.clientY <= rect.bottom) {
          setMousePos({ x: e.clientX, y: e.clientY })
        } else {
          setMousePos(null)
        }
      }
    }
    const onUp = () => { draggingRef.current = null; newDragRef.current = null }
    // Right-click anywhere over the overlay clears the loop region
    const onContextMenu = (e: MouseEvent) => {
      const el = overlayRef.current
      if (!el) return
      const rect = el.getBoundingClientRect()
      if (e.clientX >= rect.left && e.clientX <= rect.right &&
          e.clientY >= rect.top  && e.clientY <= rect.bottom) {
        e.preventDefault()
        useStore.getState().clearLoopRegion()
      }
    }
    window.addEventListener('mousemove',   onMove)
    window.addEventListener('mouseup',     onUp)
    window.addEventListener('contextmenu', onContextMenu)
    return () => {
      window.removeEventListener('mousemove',   onMove)
      window.removeEventListener('mouseup',     onUp)
      window.removeEventListener('contextmenu', onContextMenu)
    }
  }, [])

  const handleOverlayMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!e.altKey) return   // plain click/drag is reserved for other roll interactions
    e.preventDefault()
    const el = overlayRef.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const pct  = Math.max(0, Math.min(100, (e.clientY - rect.top) / rect.height * 100))
    const s    = useStore.getState()
    const vs   = VISIBLE_SECONDS / (s.zoomLevel ?? 1)
    newDragRef.current = { anchorTime: s.currentTime + vs * (1 - pct / (PLAYHEAD_RATIO * 100)) }
  }

  const handleWrap = (pct: number): React.CSSProperties => ({
    position: 'absolute', left: 0, right: 0,
    top: `${pct}%`, height: 12,
    transform: 'translateY(-6px)',
    cursor: 'ns-resize', pointerEvents: 'auto',
    display: 'flex', alignItems: 'center',
  })

  const hasSelection = loopStart !== null && loopEnd !== null
  const visibleSecs  = VISIBLE_SECONDS / (zoomLevel ?? 1)
  const timeToPct    = (t: number) =>
    PLAYHEAD_RATIO * 100 - ((t - currentTime) / visibleSecs) * (PLAYHEAD_RATIO * 100)

  const topPct    = hasSelection ? Math.max(0, Math.min(100, timeToPct(loopEnd!)))   : 0
  const botPct    = hasSelection ? Math.max(0, Math.min(100, timeToPct(loopStart!))) : 0
  const heightPct = botPct - topPct

  const amber     = loopRegionActive ? 'var(--accent-amber-loop-border)' : 'var(--accent-amber-loop-border-dim)'
  const amberFill = loopRegionActive ? 'var(--accent-amber-active-bg)'   : 'var(--accent-amber-loop-fill-dim)'

  // Tooltip visibility: only while a region is actively selected — showing
  // it on every hover over the roll (even with nothing selected yet) read
  // as a permanent, naggy tooltip.
  // (a hint, so it follows Settings › Appearance › Tooltips; this redraws on every mouse move anyway)
  const showTooltip = !!midi && !noteEditorActive && hasSelection && mousePos !== null && useStore.getState().tooltipsEnabled

  // Edit mode disables loop overlay pointer events to pass them to PixiJS
  if (noteEditorActive) return null

  return (
    <div
      ref={overlayRef}
      onMouseDown={handleOverlayMouseDown}
      onDoubleClick={() => useStore.getState().clearLoopRegion()}
      style={{
        position: 'absolute', inset: 0, overflow: 'hidden',
        pointerEvents: 'auto',
        cursor: 'crosshair',
      }}
    >
      {hasSelection && heightPct > 0 && (<>
        <div style={{
          position: 'absolute', left: 0, right: 0,
          top: `${topPct}%`, height: `${heightPct}%`,
          background: amberFill, pointerEvents: 'none',
        }} />
        <div
          onMouseDown={e => { e.preventDefault(); e.stopPropagation(); draggingRef.current = 'end' }}
          onDoubleClick={e => { e.stopPropagation(); useStore.getState().clearLoopRegion() }}
          style={handleWrap(topPct)}
        >
          <div style={{ width: '100%', height: 2, background: amber }} />
        </div>
        <div
          onMouseDown={e => { e.preventDefault(); e.stopPropagation(); draggingRef.current = 'start' }}
          onDoubleClick={e => { e.stopPropagation(); useStore.getState().clearLoopRegion() }}
          style={handleWrap(botPct)}
        >
          <div style={{ width: '100%', height: 2, background: amber }} />
        </div>
      </>)}

      {/* ── Cursor tooltip — hints drag and right-click ── */}
      {showTooltip && mousePos && (
        <div style={{
          position: 'fixed',
          left: mousePos.x + 14,
          top:  mousePos.y + 14,
          pointerEvents: 'none',
          zIndex: 99999,
          background: 'var(--bg-tooltip)',
          border: '1px solid var(--accent-amber-strong)',
          borderRadius: 4,
          padding: '4px 8px',
          display: 'flex', flexDirection: 'column', gap: 2,
          whiteSpace: 'nowrap',
        }}>
          <span style={{
            fontFamily: 'var(--font-ui)', fontSize: 9, fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.08em',
            color: 'var(--accent-amber-tooltip-text)',
          }}>
            {t`Loop region set`}
          </span>
          <span style={{ fontFamily: 'var(--font-ui)', fontSize: 10, color: 'var(--text-tooltip-secondary)' }}>
            {t`Drag to reorder, right-click to clear`}
          </span>
        </div>
      )}
    </div>
  )
}

export default function PianoRoll() {
  const containerRef      = useRef<HTMLDivElement>(null)
  const appRef            = useRef<Application | null>(null)
  const gridRef           = useRef<Graphics | null>(null)
  const notesRef          = useRef<Graphics | null>(null)
  const playheadRef       = useRef<Graphics | null>(null)
  const overlayCanvasRef  = useRef<HTMLCanvasElement | null>(null)
  const overlayCtxRef     = useRef<CanvasRenderingContext2D | null>(null)
  const velocityCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const velocityCtxRef    = useRef<CanvasRenderingContext2D | null>(null)
  const keyLayoutRef      = useRef<KeyLayout[]>([])
  const hitEffectsRef     = useRef<HitEffectsRenderer | null>(null)
  const storeRef          = useRef(useStore.getState())
  // ── Redraw gating — the ticker below only pays for a full drawFrame() when
  // something drawFrame actually reads has changed, instead of unconditionally
  // every tick. Starts true so the first tick performs the initial draw.
  const dirtyRef          = useRef(true)
  const lastKeySizeRef    = useRef<number>(0)
  const lastMidiRef       = useRef<any>(null)
  const flatNotesRef      = useRef<FlatNote[]>([])
  // ── Tracks whose notes are ALL the same hand — i.e. a genuine "split into
  // two tracks" output (Piano LH / Piano RH). These always render in the
  // fixed hand colors regardless of the Left/Right Hand setting; a single
  // mixed-hand track only does that when the setting is on. ─────────────────
  const homogeneousHandTracksRef = useRef<Set<number>>(new Set())
  const barStartsRef      = useRef<number[]>([])
  // ── Shared between wheel-handler effect and PixiJS-closure drag handlers ──────
  const editDragActiveRef = useRef(false)

  // ── Note-name tooltip for notes too small to show inline text ────────────────
  const [editTooltip, setEditTooltip] = useState<{ x: number; y: number; label: string } | null>(null)

  // ── Unified right-click context menu — replaces instant-delete. Options
  // depend on tool/selection at click time (see onEditContext). ────────────
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null)
  const contextMenuRef = useRef<ContextMenuState | null>(null)
  useEffect(() => { contextMenuRef.current = contextMenu }, [contextMenu])
  useEffect(() => {
    if (!contextMenu) return
    const close = () => setContextMenu(null)
    window.addEventListener('mousedown', close)
    return () => window.removeEventListener('mousedown', close)
  }, [contextMenu])

  useEffect(() => useStore.subscribe((s) => {
    const prev = storeRef.current
    storeRef.current = s
    // Hand colours (Settings › Appearance): refresh the canvas cache, redraw
    if (s.handColorLH !== prev.handColorLH || s.handColorRH !== prev.handColorRH) {
      HAND_LH_COLOR = hexVarToNumber(s.handColorLH, HAND_LH_COLOR)
      HAND_RH_COLOR = hexVarToNumber(s.handColorRH, HAND_RH_COLOR)
      dirtyRef.current = true
    }
    // Mirrors the fields drawFrame() destructures from the store (below), plus
    // currentTime — needed so a paused scrub/seek still redraws even though the
    // ticker's playbackState check alone wouldn't catch it (during actual
    // playback currentTime changes every tick too, but that's harmless since
    // the playbackState check already forces a redraw every tick then).
    if (
      s.midi !== prev.midi ||
      s.currentTime !== prev.currentTime ||
      s.tracks !== prev.tracks ||
      s.detectedKey !== prev.detectedKey ||
      s.zoomLevel !== prev.zoomLevel ||
      s.appTheme !== prev.appTheme ||
      s.keyboardSize !== prev.keyboardSize ||
      s.showBarNumbers !== prev.showBarNumbers ||
      s.barStarts !== prev.barStarts ||
      s.noteEditorActive !== prev.noteEditorActive ||
      s.showHandLabels !== prev.showHandLabels ||
      s.playbarVisible !== prev.playbarVisible ||
      s.keyboardTopY !== prev.keyboardTopY ||
      s.hitEffectsEnabled !== prev.hitEffectsEnabled ||
      s.hitEffectPattern !== prev.hitEffectPattern ||
      s.hitEffectBloomThreshold !== prev.hitEffectBloomThreshold ||
      s.hitEffectBloomIntensity !== prev.hitEffectBloomIntensity ||
      s.hitEffectBloomSpread !== prev.hitEffectBloomSpread ||
      s.hitEffectColor !== prev.hitEffectColor ||
      s.playbackState !== prev.playbackState
    ) dirtyRef.current = true
  }), [])

  // ── Wheel to scrub — disabled in edit mode ───────────────────────────────────
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const onWheel = (e: WheelEvent) => {
      e.preventDefault()
      if (editDragActiveRef.current) return
      const { midi, currentTime, playbackState } = useStore.getState()
      if (!midi) return
      // Shift = fine control (small step), plain wheel = coarse (unchanged).
      // Was inverted (shift = 10s, bigger) — fine scrubbing had no way in.
      // 0.15s was still too coarse to land inside a single note in a dense
      // passage — narrowed to 0.03s so each tick is a small nudge, not a jump.
      const step  = e.shiftKey ? 0.03 : 2
      const delta = e.deltaY > 0 ? -step : step
      const newTime = Math.max(0, Math.min(midi.duration, currentTime + delta))
      if (playbackState === 'playing') {
        useStore.setState({ playbackState: 'paused' })
        setTimeout(() => useStore.setState({ currentTime: newTime, playbackState: 'playing' }), 20)
      } else {
        useStore.setState({ currentTime: newTime })
      }
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  }, [])

  // ── PixiJS canvas init ───────────────────────────────────────────────────────
  useEffect(() => {
    resolvePianoRollColorsFromCSS()
    if (!containerRef.current) return
    const el = containerRef.current
    const app = new Application()
    let roInstance: ResizeObserver
    let dprQuery: MediaQueryList | null = null
    let onDprChangeHandler: (() => void) | null = null
    // Set by the cleanup. app.init is async: in development React runs this
    // effect, its cleanup, and the effect again — the first init finishing
    // after its cleanup used to build a second, invisible piano roll that
    // drew into the same velocity lane and handled every key a second time
    let disposed = false
    let offEditKey: (() => void) | null = null

    app.init({
      background: CANVAS_BG_COLOR,
      width:  el.clientWidth  || 800,
      height: el.clientHeight || 600,
      antialias:   true,
      resolution:  window.devicePixelRatio || 1,
      autoDensity: true,
    }).then(() => {
      if (disposed || !containerRef.current) { app.destroy(false); return }
      el.appendChild(app.canvas)
      appRef.current = app

      // ── Canvas2D overlay for bar number labels ────────────────────────────
      const overlay = document.createElement('canvas')
      overlay.style.cssText = 'position:absolute;top:0;left:0;pointer-events:none'
      overlay.width  = el.clientWidth  || 800
      overlay.height = el.clientHeight || 600
      el.appendChild(overlay)
      overlayCanvasRef.current = overlay
      overlayCtxRef.current    = overlay.getContext('2d')

      // ── Canvas2D velocity lane — edit-mode only, hidden otherwise ─────────
      const velCanvas = document.createElement('canvas')
      velCanvas.style.cssText = 'position:absolute;left:0;bottom:0;display:none'
      velCanvas.width  = el.clientWidth || 800
      velCanvas.height = Math.round((el.clientHeight || 600) * (1 - PLAYHEAD_RATIO)) + VELOCITY_LANE_HEIGHT_BOOST
      el.appendChild(velCanvas)
      velocityCanvasRef.current = velCanvas
      velocityCtxRef.current    = velCanvas.getContext('2d')

      const grid     = new Graphics()
      const barLines = new Graphics()   // bar dividers — behind notes, above key grid
      const notes    = new Graphics()
      const playhead = new Graphics()
      const editG    = new Graphics()   // edit overlay — must be last (on top)
      app.stage.addChild(grid)
      app.stage.addChild(barLines)
      app.stage.addChild(notes)
      app.stage.addChild(playhead)
      const hitEffects = new HitEffectsRenderer(app.stage)   // above playhead, below edit overlay
      hitEffectsRef.current = hitEffects
      app.stage.addChild(editG)
      gridRef.current     = grid
      notesRef.current    = notes
      playheadRef.current = playhead

      // ── Edit mode state — lives in closure, shared by drawFrame + pointer handlers ──
      let editFlatNotes:        EditFlatNote[]  = []
      let editSelectedNotes:    Set<ToneNote>   = new Set()
      let editNewNotes:         Set<ToneNote>   = NES.newNotes   // reference to singleton set
      let editDrag:             EditDragState | null   = null
      let editMarquee:          EditMarqueeState | null = null
      let editLasso:            EditLassoState | null   = null
      let editPan:              EditPanState | null      = null
      let lastGlissandoMidi:    number | null   = null
      let prevNoteEditorActive: boolean         = false

      // ── Velocity lane state — bars rebuilt each draw from the current
      // selection; drag state tracks which note (if any) is being adjusted. ──
      let velBars: { note: ToneNote; x: number; w: number }[] = []
      let velDragNote:      ToneNote | null = null
      let velHoverNote:     ToneNote | null = null   // bar under the cursor (brighter + value label)
      let velDragStartY     = 0
      let velDragStartVel   = 0
      // ── Group velocity drag — dragging any bar that's part of a multi-note
      // selection shifts every selected note's velocity by the same delta,
      // instead of just the one bar under the pointer. Preserves whatever
      // relative shape the selection already has (a crescendo stays a
      // crescendo, just moved up/down as a block) rather than flattening it
      // to one value — for that, see the "Flatten Velocity" context-menu
      // action below, which uses cmdSetRangeVelocity instead. null outside
      // a group drag (plain single-note drag, unchanged from before). ──────
      let velDragGroup: Map<ToneNote, number> | null = null

      // ── snapTick — quantize a tick value to the grid ──────────────────────
      const snapTick = (tick: number): number => {
        if (!NES.snapRef.current) return Math.max(0, tick)
        const ppq  = (NES.editMidi as any)?.header?.ppq ?? 480
        const unit = ppq / (NES.quantizeDivisorRef.current ?? 8)
        return Math.max(0, Math.round(tick / unit) * unit)
      }

      // ── syncNoteTimes — update note.time and note.duration from ticks ─────
      // @tonejs/midi does NOT auto-sync these; we must update them explicitly.
      // Uses NES.editMidi.header (not ParsedMidi which has no header).
      const syncNoteTimes = (note: ToneNote) => {
        const header = (NES.editMidi as any)?.header
        if (!header) return
        note.time     = header.ticksToSeconds(note.ticks)
        note.duration = header.ticksToSeconds(note.ticks + note.durationTicks) - note.time
      }

      // ── buildEditFlatNotes — rebuild hit-testable note list from NES.editMidi ──
      // Uses NES.editMidi (real @tonejs/midi Tracks/Notes) for edit operations.
      // Position-based mapping: NES.editMidi.tracks[i] ↔ parsedMidi.tracks[i].
      const buildEditFlatNotes = (
        py: number, pps: number, currentTime: number,
        midiMin: number, midiMax: number, transpose: number,
      ) => {
        editFlatNotes = []
        const editMidi = NES.editMidi as any
        if (!editMidi) return

        const { tracks } = storeRef.current
        const parsedMidi = storeRef.current.midi as any
        const trackMap = new Map<number, { visible: boolean; muted: boolean; solo: boolean; color: string }>()
        for (const t of tracks) trackMap.set(t.index, t)
        const hasSolo = tracks.some((t: any) => t.solo)

        const visStart  = currentTime - (VISIBLE_SECONDS / (storeRef.current.zoomLevel ?? 1)) * (1 - PLAYHEAD_RATIO)
        const visEnd    = currentTime + (VISIBLE_SECONDS / (storeRef.current.zoomLevel ?? 1)) * PLAYHEAD_RATIO
        const totalKeys = midiMax - midiMin + 1

        // Mirror parseMidiBuffer's empty-track filter so position-based index mapping stays in sync
        const nonEmptyEditTracks = (editMidi.tracks as any[]).filter((t: any) => t.notes.length > 0)
        for (let i = 0; i < nonEmptyEditTracks.length; i++) {
          const track    = nonEmptyEditTracks[i]
          const parsedIdx = parsedMidi?.tracks?.[i]?.index ?? i
          const ts = trackMap.get(parsedIdx)
          if (!ts || !isShown(ts, hasSolo)) continue   // same gate as drawFrame (trackShown.ts)
          const color = parseInt((ts.color ?? '#e8a027').replace('#', ''), 16)

          for (const note of track.notes) {
            if (note.time + note.duration < visStart) continue
            if (note.time > visEnd) break

            const idx = (note.midi + transpose) - midiMin
            if (idx < 0 || idx >= totalKeys) continue
            const key = keyLayoutRef.current[idx]
            if (!key) continue

            const topY  = py - (note.time + note.duration - currentTime) * pps
            const botY  = py - (note.time - currentTime) * pps
            const noteH = Math.max(botY - topY, MIN_NOTE_H)

            // Prune stale newNotes entries (e.g. after undo of add)
            if (!track.notes.includes(note)) editNewNotes.delete(note)

            editFlatNotes.push({ note, track, key, topY, botY, noteH, trackIndex: parsedIdx, color })
          }
        }
      }

      // ── editHitTest — find top-most note under pointer ────────────────────
      const editHitTest = (cx: number, cy: number): EditFlatNote | null => {
        for (let i = editFlatNotes.length - 1; i >= 0; i--) {
          const ef = editFlatNotes[i]
          const { key, topY, botY, noteH } = ef
          const actualBot = topY + noteH
          if (cx >= key.x - 2 && cx < key.x + key.width + 2 &&
              cy >= topY - 2 && cy < actualBot + 2) return ef
        }
        return null
      }

      // ── drawEditOverlay — selection highlights + new-note blink ──────────
      const drawEditOverlay = (
        py: number, pps: number, currentTime: number,
        midiMin: number, midiMax: number, transpose: number,
      ) => {
        editG.clear()
        if (!storeRef.current.noteEditorActive || !NES.editMidi) return

        // Rebuild flat notes every frame — ensures drag-move preview is always current.
        buildEditFlatNotes(py, pps, currentTime, midiMin, midiMax, transpose)

        // Pulsate selected-note border via sine wave — driven purely by wall-clock time,
        // no extra state needed since drawFrame already runs on rAF every frame.
        const pulse = 0.55 + 0.30 * Math.sin(Date.now() / 250)
        // Hard on/off square wave, not a smooth fade — new/unsaved notes need
        // to read as "unsaved" at a glance, distinct from the selection
        // pulse's smooth glow. Replaces the old dashed-border treatment,
        // which wasn't visible enough at small note sizes.
        const blinkOn = Math.floor(Date.now() / 400) % 2 === 0

        for (const ef of editFlatNotes) {
          const { note, key, topY, noteH } = ef
          const isSelected = editSelectedNotes.has(note)
          const isNew      = editNewNotes.has(note)
          const isEdited   = !isNew && NES.editedNotes.has(note)
          const isDragged  = note === editDrag?.note

          // Selected/dragged/edited all pulse the same white outline, with a
          // 3px gap from the note itself (was 1px, flush against the note —
          // hard to see at small note heights). New notes are drawn
          // outline-only here (the base fill loop skips them entirely) so
          // "unsaved" reads as a fully empty note, not just a colored one
          // with a border on top.
          if (isSelected || isDragged || isEdited) {
            editG.roundRect(key.x - 2, topY - 3, key.width + 4, noteH + 6, NOTE_RADIUS)
            editG.stroke({ color: SEL_NOTE_COLOR, width: 2, alpha: pulse })
          }
          if (isNew && blinkOn) {
            editG.roundRect(key.x + 1, topY, Math.max(key.width - 2, 1), noteH, NOTE_RADIUS)
            editG.stroke({ color: SEL_NOTE_COLOR, width: 2.5, alpha: 0.9 })
          }
        }

        // ── Marquee selection rectangle ──────────────────────────────────────
        if (editMarquee) {
          const mx = Math.min(editMarquee.startX, editMarquee.endX)
          const my = Math.min(editMarquee.startY, editMarquee.endY)
          const mw = Math.abs(editMarquee.endX - editMarquee.startX)
          const mh = Math.abs(editMarquee.endY - editMarquee.startY)
          editG.rect(mx, my, mw, mh)
          editG.fill({ color: SEL_MARQUEE_COLOR, alpha: 0.07 })
          editG.rect(mx, my, mw, mh)
          editG.stroke({ color: SEL_MARQUEE_COLOR, width: 1, alpha: 0.45 })
        }

        // ── Lasso paint-select trail ──────────────────────────────────────────
        if (editLasso && editLasso.points.length > 1) {
          editG.moveTo(editLasso.points[0].x, editLasso.points[0].y)
          for (let i = 1; i < editLasso.points.length; i++) {
            editG.lineTo(editLasso.points[i].x, editLasso.points[i].y)
          }
          editG.stroke({ color: SEL_MARQUEE_COLOR, width: 2, alpha: 0.6 })
        }
      }

      // ── Static grid: black key shading + octave dividers ──────────────────
      const drawGrid = (W: number, H: number, midiMin: number, midiMax: number) => {
        grid.clear()
        keyLayoutRef.current = buildKeyLayout(W, midiMin, midiMax)
        const kl = keyLayoutRef.current

        for (let m = midiMin; m <= midiMax; m++) {
          if (isBlackKey(m)) continue
          const key = kl[m - midiMin]
          if (!key) continue
          grid.rect(key.x, 0, key.width, H)
          grid.fill({ color: KEY_ROW_COLOR, alpha: 1 })
        }
        for (let m = midiMin; m <= midiMax; m++) {
          if (!isBlackKey(m)) continue
          const key = kl[m - midiMin]
          if (!key) continue
          grid.rect(Math.round(key.x), 0, Math.round(key.width), H)
          grid.fill({ color: KEY_ROW_DARK_COLOR, alpha: 1 })
        }
        for (let m = midiMin; m <= midiMax; m++) {
          if (m % 12 !== 0) continue
          const key = kl[m - midiMin]
          if (!key) continue
          grid.rect(Math.round(key.x), 0, 1, H)
          grid.fill({ color: OCTAVE_DIVIDER_COLOR, alpha: 1 })
        }
      }

      // ── Shared resize path — CSS size + device pixel ratio ─────────────────
      // Tracks the CSS width/height/DPR we last resized TO, not Pixi's own
      // app.screen.* — PixiJS's TextureSource.resize() rounds to a whole
      // device pixel and reports back width = roundedPixels / resolution,
      // which at a fractional DPR (Windows scaling at 125%/150%/175%)
      // essentially never matches the raw CSS size exactly. The old code
      // compared against app.screen.* directly, so it looked "resized" on
      // literally every tick and bailed out before ever drawing a note —
      // that's the piano-roll freeze this fixes. Comparing against what WE
      // last asked for instead is an exact match once nothing has actually
      // changed. Also keeps the bar-number overlay and velocity-lane 2D
      // canvases in step: their backing store is sized in real device
      // pixels (`Math.round(cssSize * dpr)`) while their CSS size stays the
      // same, with a matching ctx.setTransform so the existing drawing code
      // keeps working entirely in CSS px — otherwise both look soft at any
      // scaling above 100%. ───────────────────────────────────────────────
      let lastSizeW = -1, lastSizeH = -1, lastSizeDpr = 0

      const applyResize = (cw: number, ch: number, dpr: number) => {
        app.renderer.resize(cw, ch, dpr)
        lastSizeW = cw; lastSizeH = ch; lastSizeDpr = dpr

        const { keyboardSize: ks } = storeRef.current
        const { min: syncMin, max: syncMax } = RANGES[ks] ?? RANGES[88]
        drawGrid(cw, ch, syncMin, syncMax)

        if (overlayCanvasRef.current) {
          const oc = overlayCanvasRef.current
          oc.width  = Math.round(cw * dpr)
          oc.height = Math.round(ch * dpr)
          oc.style.width  = cw + 'px'
          oc.style.height = ch + 'px'
          overlayCtxRef.current?.setTransform(dpr, 0, 0, dpr, 0, 0)
        }
        if (velocityCanvasRef.current) {
          const vc = velocityCanvasRef.current
          const cssVelH = Math.round(ch * (1 - PLAYHEAD_RATIO)) + VELOCITY_LANE_HEIGHT_BOOST
          vc.width  = Math.round(cw * dpr)
          vc.height = Math.round(cssVelH * dpr)
          vc.style.width  = cw + 'px'
          vc.style.height = cssVelH + 'px'
          velocityCtxRef.current?.setTransform(dpr, 0, 0, dpr, 0, 0)
        }
        dirtyRef.current = true
      }

      // ── Live Windows-scaling / DPR change ───────────────────────────────
      // `resolution` is fixed at app.init() time — without this, changing
      // Windows display scaling while Orfeo is already open would leave the
      // roll drawn at the old ratio until something else forces a resize
      // (previously: a restart). A matchMedia resolution query only ever
      // matches once for a given dppx value, so it's re-armed after every
      // fire rather than being a persistent listener. ────────────────────
      const armDprWatch = () => {
        dprQuery = window.matchMedia(`(resolution: ${window.devicePixelRatio || 1}dppx)`)
        onDprChangeHandler = onDprChange
        dprQuery.addEventListener('change', onDprChangeHandler, { once: true })
      }
      const onDprChange = () => {
        const cw = el.clientWidth, ch = el.clientHeight
        if (cw > 0 && ch > 0) applyResize(cw, ch, window.devicePixelRatio || 1)
        armDprWatch()
      }
      armDprWatch()

      // ── Main render loop ──────────────────────────────────────────────────
      const drawFrame = () => {
        const cw = el.clientWidth, ch = el.clientHeight
        const dpr = window.devicePixelRatio || 1
        if (cw > 0 && ch > 0 && (cw !== lastSizeW || ch !== lastSizeH || dpr !== lastSizeDpr)) {
          applyResize(cw, ch, dpr)
        }

        const { midi, currentTime, tracks, detectedKey, zoomLevel, appTheme, keyboardSize, showBarNumbers, barStarts: storeBars, noteEditorActive, showHandLabels, playbarVisible, keyboardTopY, hitEffectsEnabled, hitEffectPattern, hitEffectBloomThreshold, hitEffectBloomIntensity, hitEffectBloomSpread, hitEffectColor } = storeRef.current
        const transpose   = (detectedKey as any)?.transpose ?? 0
        const W = app.screen.width, H = app.screen.height
        // ── Hit-line Y position — fixed 80% line by default (unchanged), or the
        // live keyboard top edge when the playbar is hidden. `pps` (pixels per
        // second, i.e. how fast/compressed notes fall) always derives from the
        // FIXED ratio regardless — only where the line/notes visually land
        // moves, per the feature's own scope ("only where the trigger
        // threshold is read from", not how notes are drawn or fall).
        const staticPy    = H * PLAYHEAD_RATIO
        const visibleSecs = VISIBLE_SECONDS / (zoomLevel ?? 1)
        const pps         = staticPy / visibleSecs
        let py = staticPy
        if (!playbarVisible && keyboardTopY !== null) {
          const rect = el.getBoundingClientRect()
          py = Math.max(20, Math.min(H - 4, keyboardTopY - rect.top))
        }
        const { min: midiMin, max: midiMax } = RANGES[keyboardSize] ?? RANGES[88]
        const totalKeys   = midiMax - midiMin + 1

        if (keyboardSize !== lastKeySizeRef.current) {
          lastKeySizeRef.current = keyboardSize
          drawGrid(W, H, midiMin, midiMax)
        }

        // ── Note-hit visual effects (Phase 2) — spawn from the same trigger as
        // the key glow (drained queue, see utils/hitEffectQueue.ts), positioned
        // at the hit note's key X and the CURRENT hit line's Y (playbar or
        // keyboard-derived, per Phase 1 above) — so the effect always lands
        // exactly where the glow itself is. Skipped entirely when the setting
        // is off. Each spawned effect drives its own lifecycle via GSAP from
        // here on — nothing to poll per-frame from this loop.
        if (hitEffectsEnabled) {
          hitEffects.setBloomParams({ threshold: hitEffectBloomThreshold, intensity: hitEffectBloomIntensity, spread: hitEffectBloomSpread })
          const hits = drainHitEffects()
          // hitEffectColor overrides the particle color only — leaves the queued
          // per-track color (and the key glow, a separate render path) untouched.
          const overrideHex = hitEffectColor ? parseInt(hitEffectColor.replace('#', ''), 16) : null
          for (const hit of hits) {
            const idx = hit.midi - midiMin
            if (idx < 0 || idx >= totalKeys) continue
            const key = keyLayoutRef.current[idx]
            if (!key) continue
            const colorHex = overrideHex ?? parseInt(hit.color.replace('#', ''), 16)
            hitEffects.spawn(hitEffectPattern, key.x + key.width / 2, py, colorHex)
          }
        }

        // ── Edit mode enter/exit — create or destroy NES.editMidi ────────────
        if (noteEditorActive && !prevNoteEditorActive) {
          const rawBuffer = (midi as any)?._raw
          if (rawBuffer && !NES.editMidi) {
            NES.editMidi = midiToEditableCopy(rawBuffer)
            copyHandTagsOntoEditBuffer(midi, NES.editMidi)
          }
          NES.needsFlatRebuild = true
          // Prime GM channel programs via a silent SMF player so notes preview
          // on the correct instrument before the user presses Play for the first time.
          ;(window as any).__orfeoWarmupEditChannels?.()
        }
        if (!noteEditorActive && prevNoteEditorActive) {
          NES.editMidi = null
          lastMidiRef.current = null   // force rebuild from ParsedMidi on exit
          app.canvas.style.cursor = 'default'
        }
        prevNoteEditorActive = noteEditorActive

        // ── After edit commands: rebuild flatNotesRef from NES.editMidi ──────
        if (noteEditorActive && NES.needsFlatRebuild) {
          NES.needsFlatRebuild = false
          if (NES.editMidi) {
            const parsedMidi = storeRef.current.midi as any
            const flat: FlatNote[] = []
            const homogeneous = new Set<number>()
            // Mirror parseMidiBuffer's empty-track filter so position-based index mapping stays in sync
            const nonEmpty = ((NES.editMidi as any).tracks as any[]).filter((t: any) => t.notes.length > 0)
            for (let i = 0; i < nonEmpty.length; i++) {
              const et = nonEmpty[i]
              const parsedIdx = parsedMidi?.tracks?.[i]?.index ?? i
              let allSameHand: Hand | null | undefined = undefined
              for (const note of et.notes) {
                // .hand must travel here — omitting it (as this rebuild did
                // before) silently falls every note back to the track's
                // default color while editing, hiding any hand-coloring
                // (algorithm's or a manual Assign LH/RH) for the whole
                // session, even though NES.editMidi's notes carry it fine. ──
                flat.push({ midi: note.midi, time: note.time, duration: note.duration, trackIndex: parsedIdx, hand: note.hand, noteRef: note })
                if (allSameHand === null) continue
                if (!note.hand) { allSameHand = null; continue }
                if (allSameHand === undefined) allSameHand = note.hand
                else if (allSameHand !== note.hand) allSameHand = null
              }
              if (et.notes.length > 0 && allSameHand) homogeneous.add(parsedIdx)
            }
            flat.sort((a, b) => a.time - b.time)
            flatNotesRef.current = flat
            homogeneousHandTracksRef.current = homogeneous
          } else {
            lastMidiRef.current = null   // fallback: let the normal path rebuild
          }
        }

        app.renderer.background.color = appTheme === 'warm' ? CANVAS_BG_WARM_COLOR : CANVAS_BG_COLOR

        playhead.clear()
        if (playbarVisible) {
          playhead.rect(0, py, W + 1, 2)
          playhead.fill({ color: PLAYHEAD_COLOR, alpha: 0.90 })
        }

        notes.clear()

        const ctx = overlayCtxRef.current
        const ov  = overlayCanvasRef.current
        if (ctx && ov) ctx.clearRect(0, 0, ov.width, ov.height)

        if (!midi) { editG.clear(); return }

        const visStart = currentTime - visibleSecs * (1 - PLAYHEAD_RATIO)
        const visEnd   = currentTime + visibleSecs * PLAYHEAD_RATIO

        // ── Rebuild flat note array once per MIDI file load (or after edit) ──
        // Skipped entirely while actively editing — the edit-mode rebuild
        // above already owns flatNotesRef then, built from NES.editMidi
        // (which carries in-progress edits the store's midi doesn't have
        // yet). Without this guard, a Save & Reload mid-session replaces
        // the store's midi object, which flips this condition true and
        // silently overwrites the correct just-edited colors with whatever
        // the freshly reloaded file's own tags say — even one frame of that
        // is visible as edits "reverting" right after save. lastMidiRef is
        // reset to null on edit-mode exit (see above), so this still
        // rebuilds fresh the moment editing actually ends. ────────────────
        if (midi !== lastMidiRef.current && !noteEditorActive) {
          lastMidiRef.current = midi
          const flat: FlatNote[] = []
          const homogeneous = new Set<number>()
          for (const track of midi.tracks) {
            let allSameHand: Hand | null | undefined = undefined
            for (const note of track.notes) {
              flat.push({ midi: note.midi, time: note.time, duration: note.duration, trackIndex: track.index, hand: note.hand })
              if (allSameHand === null) continue
              if (!note.hand) { allSameHand = null; continue }
              if (allSameHand === undefined) allSameHand = note.hand
              else if (allSameHand !== note.hand) allSameHand = null
            }
            if (track.notes.length > 0 && allSameHand) homogeneous.add(track.index)
          }
          flat.sort((a, b) => a.time - b.time)
          flatNotesRef.current = flat
          homogeneousHandTracksRef.current = homogeneous
        }

        barStartsRef.current = storeBars

        const trackMap = new Map<number, { visible: boolean; muted: boolean; solo: boolean; color: string }>()
        for (const t of tracks) trackMap.set(t.index, t)
        const hasSolo = tracks.some((t: any) => t.solo)

        const flat     = flatNotesRef.current
        const startIdx = lowerBound(flat, visStart - visibleSecs)
        for (let i = startIdx; i < flat.length; i++) {
          const note = flat[i]
          if (note.time > visEnd) break
          if (note.time + note.duration < visStart) continue

          const ts = trackMap.get(note.trackIndex)
          if (ts && !isShown(ts, hasSolo)) continue   // what shows: eye, mute and solo (trackShown.ts)

          const idx = (note.midi + transpose) - midiMin
          if (idx < 0 || idx >= totalKeys) continue
          const key = keyLayoutRef.current[idx]
          if (!key) continue

          // ── Hand coloring — fixed LH/RH tokens, not per-track palette. A track
          // that's a genuine split output (every note same hand — Piano LH/RH)
          // always renders in these colors. A single mixed-hand track only does
          // when Left/Right Hand mode is on; off, it falls back to the track's
          // own color — same contract as resolveHandAwareColor() (handColors.ts),
          // which Keyboard.tsx calls directly; this is a numeric-color PixiJS
          // reimplementation of the same rule, not an independent one. Non-piano
          // notes (no hand tag) keep their normal per-track palette color throughout.
          const isSplitTrack = homogeneousHandTracksRef.current.has(note.trackIndex)
          const trackColorNum = parseInt((ts?.color ?? '#e8a027').replace('#', ''), 16)
          // Global Settings LH/RH toggle stays authoritative for whether
          // hand colors SHOW — opening the Note Editor must never itself
          // change what's on screen. The editor's own Reassign-hands toggle
          // only ADDS to that (lets you preview hand colors even with the
          // global toggle off, and gates Assign LH/RH availability); it
          // never takes display away from what was already showing. ───────
          const handColoringOn = showHandLabels || (noteEditorActive && NES.reassignHandsMode)
          const color = !note.hand
            ? trackColorNum
            : (isSplitTrack || handColoringOn)
              ? (note.hand === 'L' ? HAND_LH_COLOR : HAND_RH_COLOR)
              : trackColorNum
          const topY   = py - (note.time + note.duration - currentTime) * pps
          const botY   = py - (note.time - currentTime) * pps
          const noteH  = Math.max(botY - topY, MIN_NOTE_H)

          // New, not-yet-saved notes get no fill here — the edit overlay
          // draws them outline-only instead, so "unsaved" reads at a
          // glance without needing to check color/blink state too.
          if (noteEditorActive && note.noteRef && NES.newNotes.has(note.noteRef)) continue

          const drawW = Math.max(key.width - 2, 1)
          notes.roundRect(key.x + 1, topY, drawW, noteH, NOTE_RADIUS)
          notes.fill({ color, alpha: 0.9 })
          notes.rect(key.x + 1, topY, drawW, 2)
          notes.fill({ color: NOTE_HIGHLIGHT_COLOR, alpha: 0.25 })

          // ── Non-color hand signal — a thin edge accent (left = LH, right =
          // RH), not a hue, so a colorblind user keeps the hand cue during
          // normal playback (previously hand was color-only here). ─────────
          if (note.hand && (isSplitTrack || handColoringOn)) {
            const edgeW = Math.min(2, drawW)
            const edgeX = note.hand === 'L' ? key.x + 1 : key.x + 1 + drawW - edgeW
            notes.rect(edgeX, topY, edgeW, noteH)
            notes.fill({ color: 0xffffff, alpha: 0.55 })
          }
        }

        // ── Edit overlay (drawn after notes so it renders on top) ─────────────
        drawEditOverlay(py, pps, currentTime, midiMin, midiMax, transpose)

        // ── Note names in edit mode (Canvas2D over the PixiJS canvas) ───────
        if (noteEditorActive && NES.showNoteNamesRef.current && ctx && ov) {
          const { noteNaming, accidentals } = storeRef.current
          ctx.save()
          ctx.font = `9px ${FONT_MONO_STR}`
          ctx.textAlign = 'center'
          ctx.textBaseline = 'middle'
          ctx.fillStyle = NOTE_LABEL_COLOR
          for (const ef of editFlatNotes) {
            if (ef.noteH < 14) continue
            const label = getNoteLabel(ef.note.midi, noteNaming, accidentals).replace(/\d+$/, '')
            if (!label) continue
            ctx.fillText(label, ef.key.x + ef.key.width / 2, ef.topY + ef.noteH / 2)
          }
          ctx.restore()
        }

        // ── Bar lines + bar number labels ─────────────────────────────────────
        // The line itself is drawn in Pixi (barLines, behind the notes layer) —
        // it used to be drawn on the 2D overlay canvas, which sits visually
        // above the whole Pixi canvas, so it always rendered on top of falling
        // notes (looked like a dark line splitting notes in two). Number pills
        // stay on the overlay — small text drawn on the overlay canvas needing
        // font metrics, and not the thing that was actually reported as broken.
        barLines.clear()
        if (!showBarNumbers || !ctx) return
        const bStarts = barStartsRef.current
        if (bStarts.length === 0) return

        let currentBarIdx = 0
        for (let i = 0; i < bStarts.length; i++) {
          if (bStarts[i] <= currentTime) currentBarIdx = i
        }

        ctx.font = `bold 11px ${FONT_MONO_STR}`
        ctx.textBaseline = 'alphabetic'

        for (let bi = 0; bi < bStarts.length; bi++) {
          const barY = py - (bStarts[bi] - currentTime) * pps
          if (barY > H + 20) continue
          if (barY < -20) break

          barLines.rect(0, Math.round(barY), W, 1)
          barLines.fill({ color: BARLINE_COLOR, alpha: 0.5 })

          const isCurrent = bi === currentBarIdx
          const label = String(bi + 1)
          const tw = ctx.measureText(label).width
          const pillX = 4, pillY = Math.round(barY) - 18, pillW = tw + 8, pillH = 16

          ctx.globalAlpha = isCurrent ? 1 : 0.8
          ctx.fillStyle = isCurrent ? HAND_AMBER_HEX_STR : BAR_PILL_BG_COLOR
          ctx.beginPath()
          if ((ctx as any).roundRect) { ;(ctx as any).roundRect(pillX, pillY, pillW, pillH, 3) }
          else { ctx.rect(pillX, pillY, pillW, pillH) }
          ctx.fill()

          ctx.globalAlpha = 1
          ctx.fillStyle = isCurrent ? BAR_PILL_TEXT_DARK_COLOR : HAND_AMBER_HEX_STR
          ctx.fillText(label, pillX + 4, Math.round(barY) - 5)
        }

        ctx.globalAlpha = 1
      }

      // ── Edit pointer handlers ─────────────────────────────────────────────
      // Checked via storeRef.current.noteEditorActive — only active in edit mode.

      const toCanvas = (clientX: number, clientY: number) => {
        const r = app.canvas.getBoundingClientRect()
        return { cx: clientX - r.left, cy: clientY - r.top }
      }

      const getViewParams = () => {
        const { currentTime, zoomLevel, keyboardSize, detectedKey } = storeRef.current
        const H = app.screen.height
        const py = H * PLAYHEAD_RATIO
        const visibleSecs = VISIBLE_SECONDS / (zoomLevel ?? 1)
        const pps = py / visibleSecs
        const { min: midiMin, max: midiMax } = RANGES[keyboardSize] ?? RANGES[88]
        const transpose = (detectedKey as any)?.transpose ?? 0
        return { currentTime, py, pps, midiMin, midiMax, transpose }
      }

      // ── getNoteColorHex — same rule the notes-fill loop below uses (and
      // resolveHandAwareColor's contract), so the click-preview key-light on
      // the DOM Keyboard matches the note's actual on-screen piano-roll
      // color instead of always defaulting to amber. ───────────────────────
      const getNoteColorHex = (note: any, trackIndex: number): string => {
        const { tracks: stTracks, noteEditorActive: neActive, showHandLabels: shl } = storeRef.current
        const ts = stTracks.find((t: any) => t.index === trackIndex)
        const trackColorHex = ts?.color ?? '#e8a027'
        if (!note.hand) return trackColorHex
        const isSplitTrack   = homogeneousHandTracksRef.current.has(trackIndex)
        const handColoringOn = shl || (neActive && NES.reassignHandsMode)
        if (isSplitTrack || handColoringOn) return note.hand === 'L' ? HAND_LH_CSS : HAND_RH_CSS
        return trackColorHex
      }

      // ── updateHoverState — cursor + hint text, tool-isolated ──────────────
      // Each tool owns exactly one cursor/behavior story: 'select' resizes/
      // moves notes and grabs+pans empty space; 'pen' only adds/marks notes
      // for delete; 'marquee'/'lasso' only select. No tool reads another
      // tool's affordance (e.g. Pen no longer drag-selects).
      const updateHoverState = (cx: number, cy: number, ef: EditFlatNote | null, clientX?: number, clientY?: number) => {
        if (!storeRef.current.noteEditorActive) { app.canvas.style.cursor = 'default'; setEditTooltip(null); return }
        const tool = NES.activeTool
        let hint: string

        if (ef) {
          if (tool === 'select') {
            const canResize = ef.noteH >= RESIZE_ZONE_PX * 2
            const atEnd   = canResize && cy <= ef.topY + RESIZE_ZONE_PX
            const atStart = canResize && cy >= ef.topY + ef.noteH - RESIZE_ZONE_PX
            if (atEnd || atStart) {
              app.canvas.style.cursor = 'ns-resize'
              hint = t`Drag to resize`
              setEditTooltip(null)
            } else {
              app.canvas.style.cursor = 'move'
              hint = t`Drag to move · Shift+click to add to selection`
              if (NES.showNoteNamesRef.current && ef.noteH < 14 && clientX !== undefined && clientY !== undefined) {
                const { noteNaming, accidentals } = storeRef.current
                const naming = noteNaming === 'hidden' ? 'english' : noteNaming
                const label  = getNoteLabel(ef.note.midi, naming, accidentals).replace(/\d+$/, '')
                setEditTooltip({ x: clientX, y: clientY, label })
              } else {
                setEditTooltip(null)
              }
            }
          } else if (tool === 'pen') {
            app.canvas.style.cursor = PENCIL_CURSOR
            hint = t`Click to mark for delete · Right-click for options`
            setEditTooltip(null)
          } else {
            app.canvas.style.cursor = 'crosshair'
            hint = t`Click to select · Right-click for options`
            setEditTooltip(null)
          }
        } else {
          if (tool === 'select') {
            app.canvas.style.cursor = 'grab'
            hint = t`Drag to pan · Shift+wheel to scrub finely`
          } else if (tool === 'pen') {
            app.canvas.style.cursor = PENCIL_CURSOR
            hint = t`Alt+click to add a note`
          } else if (tool === 'marquee') {
            app.canvas.style.cursor = 'crosshair'
            hint = t`Drag to select a cluster`
          } else {
            app.canvas.style.cursor = 'crosshair'
            hint = t`Drag through notes to select them`
          }
          setEditTooltip(null)
        }
        if (NES.hoverHint !== hint) {
          NES.hoverHint = hint
          NES.onHintChange?.()
        }
      }

      // ── updateMarqueeSelection ────────────────────────────────────────────
      const updateMarqueeSelection = () => {
        if (!editMarquee) return
        const x1 = Math.min(editMarquee.startX, editMarquee.endX)
        const x2 = Math.max(editMarquee.startX, editMarquee.endX)
        const y1 = Math.min(editMarquee.startY, editMarquee.endY)
        const y2 = Math.max(editMarquee.startY, editMarquee.endY)
        if (!editMarquee.additive) editSelectedNotes.clear()
        for (const ef of editFlatNotes) {
          const { note, key, topY, noteH } = ef
          const botY = topY + noteH
          if (key.x + key.width > x1 && key.x < x2 && botY > y1 && topY < y2) {
            editSelectedNotes.add(note)
          }
        }
      }

      // ── updateLassoSelection — paint-select: a note is added the instant
      // the latest path segment crosses its rect, not on release, and never
      // removed by a later segment missing it (unlike marquee, which
      // recomputes from scratch every move). Only the newest segment is
      // tested each call — already-tested segments can't un-select anything. ──
      const updateLassoSelection = (fromX: number, fromY: number, toX: number, toY: number) => {
        if (!editLasso) return
        const segMinX = Math.min(fromX, toX), segMaxX = Math.max(fromX, toX)
        const segMinY = Math.min(fromY, toY), segMaxY = Math.max(fromY, toY)
        for (const ef of editFlatNotes) {
          if (editSelectedNotes.has(ef.note)) continue
          const { key, topY, noteH } = ef
          const botY = topY + noteH
          if (key.x + key.width > segMinX - 2 && key.x < segMaxX + 2 && botY > segMinY - 2 && topY < segMaxY + 2) {
            editSelectedNotes.add(ef.note)
          }
        }
      }

      // ── getTrackChannel — MIDI channel for a parsedTrack.index, for audio preview ──
      const getTrackChannel = (parsedIdx: number): number | undefined => {
        const parsedMidi = storeRef.current.midi as any
        return parsedMidi?.tracks?.find((t: any) => t.index === parsedIdx)?.channel
      }

      // ── deleteSelectedNotes — shared by Delete key and context menu ───────
      const deleteSelectedNotes = () => {
        if (editSelectedNotes.size === 0) return
        const notesToDel = [...editSelectedNotes]
        const byTrack = new Map<Track, ToneNote[]>()
        for (const ef of editFlatNotes) {
          if (editSelectedNotes.has(ef.note)) {
            const arr = byTrack.get(ef.track) ?? []
            arr.push(ef.note)
            byTrack.set(ef.track, arr)
          }
        }
        for (const [t, ns] of byTrack) {
          const cmd = cmdRemoveNotes(t, ns)
          cmd.apply()
          NES.history.push(cmd)
        }
        for (const n of notesToDel) { editSelectedNotes.delete(n); editNewNotes.delete(n) }
        NES.dirty            = true
        NES.needsFlatRebuild = true
        NES.onHistoryChange?.()
      }

      // ── flattenSelectedVelocity — sets every selected note to the same
      // velocity (their own average) as one undoable step, via the shared
      // Set-Velocity-on-a-range command. For nudging a selection up/down
      // while keeping its existing shape, drag any selected note's
      // velocity-lane bar instead (see velDragGroup above) — this is for
      // the opposite case, making an already-similar passage perfectly
      // steady instead of just shifting it. ─────────────────────────────
      const flattenSelectedVelocity = () => {
        if (editSelectedNotes.size < 2) return
        const notes = [...editSelectedNotes]
        const avg = notes.reduce((sum, n) => sum + n.velocity, 0) / notes.length
        const cmd = cmdSetRangeVelocity(notes, avg)
        cmd.apply()
        cmd.touched = notes
        history_push(cmd)
      }

      const onEditDown = (e: PointerEvent) => {
        if (!storeRef.current.noteEditorActive) return
        if (e.button !== 0) return
        setEditTooltip(null)
        setContextMenu(null)
        const { cx, cy } = toCanvas(e.clientX, e.clientY)
        const { py, pps, midiMin, midiMax, currentTime } = getViewParams()
        const ef = editHitTest(cx, cy)
        const tool = NES.activeTool

        if (ef) {
          const { note, track, key, topY, noteH } = ef
          ;(window as any).__orfeoPlayNote?.(note.midi, 90, 500, getTrackChannel(ef.trackIndex), true, getNoteColorHex(note, ef.trackIndex))

          if (tool !== 'select') {
            // ── Pen/Marquee/Lasso on a note: select only, never drag/resize —
            // each tool does exactly one thing, isolated from the others. ────
            if (e.shiftKey) {
              if (editSelectedNotes.has(note)) editSelectedNotes.delete(note)
              else editSelectedNotes.add(note)
            } else {
              editSelectedNotes.clear()
              editSelectedNotes.add(note)
            }
            return
          }

          // ── Select tool: existing resize/move/multi-select drag, unchanged ──
          const canResize = noteH >= RESIZE_ZONE_PX * 2
          const atEnd   = canResize && cy <= topY + RESIZE_ZONE_PX
          const atStart = canResize && cy >= topY + noteH - RESIZE_ZONE_PX

          if (atEnd || atStart) {
            const mode: EditDragState['mode'] = atEnd ? 'note-resize-end' : 'note-resize-start'
            editDrag = {
              mode, note, track, trackIndex: ef.trackIndex,
              origTime: note.time, origDuration: note.duration,
              origTicks: note.ticks, origDurationTicks: note.durationTicks,
              origMidi: note.midi,
              origNoteX: key.x + key.width / 2,
              startClientX: e.clientX, startClientY: e.clientY,
              axis: null,
            }
            editDragActiveRef.current = true
            app.canvas.setPointerCapture(e.pointerId)
            app.canvas.style.cursor = 'ns-resize'
          } else if (e.shiftKey) {
            if (editSelectedNotes.has(note)) editSelectedNotes.delete(note)
            else editSelectedNotes.add(note)
          } else if (editSelectedNotes.has(note) && editSelectedNotes.size > 1) {
            editDrag = {
              mode: 'selection-move', note, track, trackIndex: ef.trackIndex,
              origTime: note.time, origDuration: note.duration,
              origTicks: note.ticks, origDurationTicks: note.durationTicks,
              origMidi: note.midi,
              origNoteX: key.x + key.width / 2,
              startClientX: e.clientX, startClientY: e.clientY,
              axis: null,
              selectionSnapshot: [...editSelectedNotes].map(n => ({ note: n, origTime: n.time, origTicks: n.ticks, origMidi: n.midi })),
            }
            editDragActiveRef.current = true
            app.canvas.setPointerCapture(e.pointerId)
            app.canvas.style.cursor = 'move'
          } else {
            editSelectedNotes.clear()
            editSelectedNotes.add(note)
            editDrag = {
              mode: 'note-move', note, track, trackIndex: ef.trackIndex,
              origTime: note.time, origDuration: note.duration,
              origTicks: note.ticks, origDurationTicks: note.durationTicks,
              origMidi: note.midi,
              origNoteX: key.x + key.width / 2,
              startClientX: e.clientX, startClientY: e.clientY,
              axis: null,
            }
            editDragActiveRef.current = true
            app.canvas.setPointerCapture(e.pointerId)
            app.canvas.style.cursor = 'move'
          }
          return
        }

        // ── Empty space — behavior fully isolated per tool ──────────────────
        if (tool === 'pen') {
          if (!e.altKey) return   // Pen only adds on Alt+click; plain click on empty is a no-op
          // ── Alt+click empty: add a new note to NES.editMidi ──────────────
          const editMidi = NES.editMidi as any
          if (!editMidi) return
          const clickTime = currentTime + (py - cy) / pps
          const header    = editMidi.header
          const rawTick   = Math.round(header.secondsToTicks(Math.max(0, clickTime)))
          const startTick = snapTick(rawTick)
          const ppq       = header.ppq ?? 480
          const dur       = ppq

          // Find the first editable track (visible, not muted) in editMidi.
          // Must filter to non-empty tracks first — same as buildEditFlatNotes — so
          // position-based index mapping stays in sync with parsedMidi.tracks[i].
          const { tracks } = storeRef.current
          const parsedMidi = storeRef.current.midi as any
          const trackMap   = new Map(tracks.map((t: any) => [t.index, t]))
          const nonEmptyForAdd = (editMidi.tracks as any[]).filter((t: any) => t.notes.length > 0)
          const editTrack  = nonEmptyForAdd.find((_t: any, i: number) => {
            const parsedIdx = parsedMidi?.tracks?.[i]?.index ?? i
            const ts = trackMap.get(parsedIdx)
            return ts && ts.visible && !ts.muted
          })
          if (!editTrack) return

          const midiNum = xToMidi(cx, keyLayoutRef.current, midiMin, midiMax)
          ;(window as any).__orfeoPlayNote?.(midiNum)

          const beforeSet = new Set(editTrack.notes)
          const cmd = cmdAddNote(editTrack as any, { midi: midiNum, ticks: startTick, durationTicks: dur, velocity: 0.8 })
          cmd.apply()
          const addedNote = editTrack.notes.find((n: ToneNote) => !beforeSet.has(n)) as ToneNote | undefined
          if (addedNote) {
            syncNoteTimes(addedNote)
            editNewNotes.add(addedNote)
          }
          NES.history.push(cmd)
          NES.dirty              = true
          NES.needsFlatRebuild   = true
          NES.onHistoryChange?.()
        } else if (tool === 'marquee') {
          editMarquee = { startX: cx, startY: cy, endX: cx, endY: cy, additive: e.shiftKey }
          if (!e.shiftKey) editSelectedNotes.clear()
        } else if (tool === 'lasso') {
          editLasso = { points: [{ x: cx, y: cy }], additive: e.shiftKey }
          if (!e.shiftKey) editSelectedNotes.clear()
        } else {
          // ── Select tool, empty space: pan the view, not marquee-select ────
          editPan = { startClientX: e.clientX, startClientY: e.clientY, startTime: currentTime }
          app.canvas.style.cursor = 'grabbing'
        }
      }

      const onEditMove = (e: PointerEvent) => {
        if (!storeRef.current.noteEditorActive) return
        const { cx, cy } = toCanvas(e.clientX, e.clientY)
        const { py, pps } = getViewParams()

        if (!editDrag && !editMarquee && !editLasso && !editPan) {
          const ef = editHitTest(cx, cy)
          updateHoverState(cx, cy, ef, e.clientX, e.clientY)
          return
        }

        if (editMarquee) {
          editMarquee = { ...editMarquee, endX: cx, endY: cy }
          updateMarqueeSelection()
          return
        }

        if (editLasso) {
          const last = editLasso.points[editLasso.points.length - 1]
          updateLassoSelection(last.x, last.y, cx, cy)
          editLasso.points.push({ x: cx, y: cy })
          return
        }

        if (editPan) {
          // Time is the VERTICAL axis here (notes fall top-to-bottom), same
          // as note-move's dy-based time formula above — panning read dx
          // (horizontal) instead, so a natural vertical drag barely moved
          // the view (only its horizontal jitter counted) and could easily
          // read as either sign. Matches note-move: drag down (dy>0) = earlier.
          const dy = e.clientY - editPan.startClientY
          const newTime = Math.max(0, editPan.startTime - dy / pps)
          useStore.setState({ currentTime: newTime })
          return
        }

        if (!editDrag) return

        // ── Ignore sub-threshold jitter — a plain click still fires a few
        // pointermove events between down and up with 1-2px of incidental
        // movement, which previously got applied straight through and
        // silently nudged the note by a tick/semitone: marked the file
        // dirty and logged a phantom "Moved note" in the changelog even
        // though nothing was intentionally dragged. Note fields stay
        // untouched (still exactly original) until real drag distance is
        // exceeded, so onEditUp's timeChanged/pitchChanged checks below
        // correctly see no change for a plain click. ─────────────────────
        if (Math.hypot(e.clientX - editDrag.startClientX, e.clientY - editDrag.startClientY) < 3) return
        editDrag.moved = true

        // ── In PianoRoll, Y increases downward; moving a note DOWN = earlier (smaller time) ──
        const dy = e.clientY - editDrag.startClientY
        const dx = e.clientX - editDrag.startClientX

        if (editDrag.mode === 'note-resize-end') {
          // Top edge of note = note END time. Moving up (dy<0) = later end = longer duration.
          const newDuration = Math.max(0.02, editDrag.origDuration + (-dy / pps))
          editDrag.note.duration      = newDuration
          editDrag.note.durationTicks = Math.max(1, Math.round(
            (storeRef.current.midi as any)?.header?.secondsToTicks(newDuration) ?? newDuration * 480
          ))
          return
        }

        if (editDrag.mode === 'note-resize-start') {
          // Bottom edge of note = note START time. Moving down (dy>0) = earlier start.
          const origEnd     = editDrag.origTime + editDrag.origDuration
          const newTime     = Math.max(0, editDrag.origTime + (-dy / pps))
          const newDuration = Math.max(0.02, origEnd - newTime)
          editDrag.note.time     = newTime
          editDrag.note.duration = newDuration
          return
        }

        if (editDrag.mode === 'note-move') {
          // Update both pitch and time simultaneously — no axis lock
          const { midiMin, midiMax } = getViewParams()
          editDrag.note.time = Math.max(0, editDrag.origTime + (-dy / pps))
          const newMidi = Math.max(midiMin, Math.min(midiMax,
            xToMidi(editDrag.origNoteX + dx, keyLayoutRef.current, midiMin, midiMax)))
          if (newMidi !== lastGlissandoMidi) {
            ;(window as any).__orfeoPlayNote?.(newMidi, 90, 500, getTrackChannel(editDrag.trackIndex), true, getNoteColorHex(editDrag.note, editDrag.trackIndex))
            lastGlissandoMidi = newMidi
          }
          editDrag.note.midi = newMidi
        }

        if (editDrag.mode === 'selection-move') {
          const { midiMin, midiMax } = getViewParams()
          for (const snap of editDrag.selectionSnapshot!) {
            snap.note.time = Math.max(0, snap.origTime + (-dy / pps))
          }
          const newPrimaryMidi = Math.max(midiMin, Math.min(midiMax,
            xToMidi(editDrag.origNoteX + dx, keyLayoutRef.current, midiMin, midiMax)))
          const deltaMidi = newPrimaryMidi - editDrag.origMidi
          if (deltaMidi !== 0) {
            for (const snap of editDrag.selectionSnapshot!) {
              snap.note.midi = Math.max(midiMin, Math.min(midiMax, snap.origMidi + deltaMidi))
            }
          }
        }
      }

      const onEditUp = (e: PointerEvent) => {
        if (!storeRef.current.noteEditorActive) return

        if (editMarquee) {
          updateMarqueeSelection()
          editMarquee = null
          return
        }

        if (editLasso) {
          editLasso = null
          return
        }

        if (editPan) {
          // A plain click (no real drag) on empty space deselects — same
          // convention marquee/lasso already have on mousedown. Distance
          // threshold so a genuine pan-drag never accidentally clears.
          const dist = Math.hypot(e.clientX - editPan.startClientX, e.clientY - editPan.startClientY)
          editPan = null
          app.canvas.style.cursor = 'grab'
          if (dist < 4) editSelectedNotes.clear()
          return
        }

        if (!editDrag) return
        const { note, track } = editDrag
        // Use NES.editMidi.header — ParsedMidi has no header property
        const header = (NES.editMidi as any)?.header

        // ── Convert live note.time back to snapped ticks ───────────────────
        const timeToSnappedTick = (t: number) => {
          if (!header) return snapTick(Math.round(t * 480))
          return snapTick(Math.round(header.secondsToTicks(Math.max(0, t))))
        }
        const durToTicks = (dur: number, startTick: number) => {
          if (!header) return Math.max(1, Math.round(dur * 480))
          return Math.max(1, Math.round(header.secondsToTicks(note.time + dur) - startTick))
        }

        // ── A plain click creates a 'note-move' editDrag same as a real
        // drag would, but onEditMove's jitter gate never touched any note
        // field for it — `editDrag.moved` stays false. Skip the whole
        // snap-and-compare dance below entirely for that case: snapTick()
        // rounds to the nearest grid line unconditionally, so even calling
        // it against an untouched, off-grid (humanized/unquantized) note's
        // original time would read as "moved" purely from the rounding,
        // not from anything the click actually did. ──────────────────────
        if (editDrag.moved) {
        if (editDrag.mode === 'note-resize-end') {
          const fDur   = note.durationTicks
          const oDur   = editDrag.origDurationTicks
          if (fDur !== oDur) {
            note.durationTicks = Math.max(1, snapTick(fDur) || fDur)
            const fSnapped = note.durationTicks
            history_push({ note, track,
              apply()  { note.durationTicks = fSnapped; syncNoteTimes(note) },
              revert() { note.durationTicks = oDur;     syncNoteTimes(note) },
              description: `Resize end midi=${note.midi}`,
            })
          } else {
            note.durationTicks = oDur
          }
          syncNoteTimes(note)
        }

        else if (editDrag.mode === 'note-resize-start') {
          const origEnd    = editDrag.origTicks + editDrag.origDurationTicks
          const newTick    = timeToSnappedTick(note.time)
          const newDurTick = Math.max(1, origEnd - newTick)
          const oTicks     = editDrag.origTicks
          const oDur       = editDrag.origDurationTicks
          if (newTick !== oTicks) {
            note.ticks = newTick; note.durationTicks = newDurTick
            syncNoteTimes(note)
            history_push({ note, track,
              apply()  { note.ticks = newTick;  note.durationTicks = newDurTick;  syncNoteTimes(note); track.notes.sort((a: any, b: any) => a.ticks - b.ticks) },
              revert() { note.ticks = oTicks;   note.durationTicks = oDur;         syncNoteTimes(note); track.notes.sort((a: any, b: any) => a.ticks - b.ticks) },
              description: `Resize start midi=${note.midi}`,
            })
          } else {
            note.ticks = oTicks; note.durationTicks = oDur; syncNoteTimes(note)
          }
        }

        else if (editDrag.mode === 'note-move') {
          const newTick      = timeToSnappedTick(note.time)
          const origTick     = editDrag.origTicks
          const origMidi     = editDrag.origMidi
          const newMidi      = note.midi
          const timeChanged  = newTick !== origTick
          const pitchChanged = newMidi !== origMidi
          if (timeChanged || pitchChanged) {
            note.ticks = timeChanged ? newTick : origTick
            syncNoteTimes(note)
            if (timeChanged) track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
            history_push({ note, track,
              apply()  {
                note.ticks = timeChanged  ? newTick  : origTick
                note.midi  = pitchChanged ? newMidi  : origMidi
                syncNoteTimes(note)
                if (timeChanged) track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
              },
              revert() {
                note.ticks = origTick
                note.midi  = origMidi
                syncNoteTimes(note)
                if (timeChanged) track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
              },
              description: `Move note midi=${origMidi}→${newMidi} tick=${origTick}→${newTick}`,
            })
          } else {
            note.ticks = origTick
            note.midi  = origMidi
            syncNoteTimes(note)
          }
        }

        else if (editDrag.mode === 'selection-move') {
          const snapshot    = editDrag.selectionSnapshot!
          const finalTicks  = snapshot.map(s => timeToSnappedTick(s.note.time))
          const finalMidis  = snapshot.map(s => s.note.midi)
          const anyTimeMoved  = finalTicks.some((t, i) => t !== snapshot[i].origTicks)
          const anyPitchMoved = finalMidis.some((m, i) => m !== snapshot[i].origMidi)
          if (anyTimeMoved || anyPitchMoved) {
            snapshot.forEach((s, i) => { s.note.ticks = finalTicks[i]; s.note.midi = finalMidis[i]; syncNoteTimes(s.note) })
            track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
            history_push({ note, track, touched: snapshot.map(s => s.note),
              apply()  {
                snapshot.forEach((s, i) => { s.note.ticks = finalTicks[i]; s.note.midi = finalMidis[i]; syncNoteTimes(s.note) })
                track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
              },
              revert() {
                snapshot.forEach(s => { s.note.ticks = s.origTicks; s.note.midi = s.origMidi; syncNoteTimes(s.note) })
                track.notes.sort((a: any, b: any) => a.ticks - b.ticks)
              },
              description: `Move ${snapshot.length} notes`,
            })
          } else {
            snapshot.forEach(s => { s.note.time = s.origTime; s.note.midi = s.origMidi })
          }
        }
        } // if (editDrag.moved)

        app.canvas.releasePointerCapture(e.pointerId)
        // Recompute the real cursor for wherever the pointer ended up,
        // instead of hardcoding the pen cursor — this ran unconditionally
        // even for the Select tool's note-move/resize drags (which fire on
        // every plain click, since a click still creates a 'note-move'
        // editDrag), so clicking a single note in Select left the cursor
        // stuck as the pencil icon until the mouse left and re-entered.
        {
          const { cx: upCx, cy: upCy } = toCanvas(e.clientX, e.clientY)
          updateHoverState(upCx, upCy, editHitTest(upCx, upCy), e.clientX, e.clientY)
        }
        editDrag                  = null
        editDragActiveRef.current = false
        lastGlissandoMidi         = null
        NES.needsFlatRebuild      = true
      }

      // ── onEditContext — unified right-click menu, replaces instant-delete.
      // Always opens a menu; options depend on what's selected. Right-
      // clicking a note not already selected selects it first (so "Delete"/
      // "Assign LH/RH" act on the note you clicked, not a stale selection). ──
      const onEditContext = (e: MouseEvent) => {
        if (!storeRef.current.noteEditorActive) return
        e.preventDefault()
        const { cx, cy } = toCanvas(e.clientX, e.clientY)
        const ef = editHitTest(cx, cy)

        if (ef && !editSelectedNotes.has(ef.note)) {
          if (!e.shiftKey) editSelectedNotes.clear()
          editSelectedNotes.add(ef.note)
        }

        const hasSelection = editSelectedNotes.size > 0
        const options: ContextMenuOption[] = []

        if (hasSelection) {
          if (NES.reassignHandsMode) {
            options.push({
              label: t`Assign to Left Hand`,
              swatchColor: 'var(--hand-lh)',
              onClick: () => { assignSelectedHand('L'); setContextMenu(null) },
            })
            options.push({
              label: t`Assign to Right Hand`,
              swatchColor: 'var(--hand-rh)',
              onClick: () => { assignSelectedHand('R'); setContextMenu(null) },
            })
          }
          if (editSelectedNotes.size >= 2) {
            options.push({
              label: `Flatten Velocity (${editSelectedNotes.size} notes)`,
              onClick: () => { flattenSelectedVelocity(); setContextMenu(null) },
            })
          }
          options.push({
            label: t`Deselect`,
            onClick: () => { editSelectedNotes.clear(); setContextMenu(null) },
          })
        }
        options.push({ label: t`Undo`, disabled: !NES.history.canUndo, onClick: () => { doHistoryUndo(); setContextMenu(null) } })
        options.push({ label: t`Redo`, disabled: !NES.history.canRedo, onClick: () => { doHistoryRedo(); setContextMenu(null) } })
        // Delete always last — destructive action shouldn't be the first
        // thing a right-click reaches for.
        if (hasSelection) {
          options.push({
            label: editSelectedNotes.size === 1 ? 'Delete note' : `Delete ${editSelectedNotes.size} notes`,
            destructive: true,
            onClick: () => { deleteSelectedNotes(); setContextMenu(null) },
          })
        }

        setContextMenu({ x: e.clientX, y: e.clientY, options })
      }

      const doHistoryUndo = () => { if (NES.history.undo()) { NES.syncEditedNotes(); NES.needsFlatRebuild = true; NES.onHistoryChange?.() } }
      const doHistoryRedo = () => { if (NES.history.redo()) { NES.syncEditedNotes(); NES.needsFlatRebuild = true; NES.onHistoryChange?.() } }

      // ── assignSelectedHand — sets hand + handSource:'manual' on every
      // selected note, undoable via the normal Ctrl+Z stack (the only way
      // back to the algorithm's guess, per plan §10 — no separate "reset to
      // auto" affordance). 'manual' is what makes the correction stick: a
      // later Split (Phase 4) partitions manual notes by tag instead of
      // recomputing them, and no future assignHands() run can silently
      // overwrite them (auto-tag-on-load only ever touches notes with
      // hand === undefined). Only reachable when NES.reassignHandsMode is on
      // (menu entries above are hidden otherwise). Visual only — never
      // touches audio scheduling. ───────────────────────────────────────────
      const assignSelectedHand = (hand: Hand) => {
        if (editSelectedNotes.size === 0) return
        const before = [...editSelectedNotes].map(n => ({
          note: n,
          hand: (n as any).hand,
          handConfidence: (n as any).handConfidence,
          handSource: (n as any).handSource,
        }))
        const count = before.length
        const cmd = {
          description: count === 1 ? `Assign ${hand === 'L' ? 'left' : 'right'} hand` : `Assign ${hand === 'L' ? 'left' : 'right'} hand to ${count} notes`,
          apply() {
            for (const b of before) {
              ;(b.note as any).hand = hand
              ;(b.note as any).handConfidence = 1
              ;(b.note as any).handSource = 'manual'
            }
          },
          revert() {
            for (const b of before) {
              ;(b.note as any).hand = b.hand
              ;(b.note as any).handConfidence = b.handConfidence
              ;(b.note as any).handSource = b.handSource
            }
          },
        }
        cmd.apply()
        NES.history.push(cmd)
        NES.dirty            = true
        NES.needsFlatRebuild = true
        NES.onHistoryChange?.()
      }

      // ── onEditKey — Ctrl+Z/Y undo/redo, Delete to remove ─────────────────
      const onEditKey = (e: KeyboardEvent) => {
        if (!storeRef.current.noteEditorActive) return
        if (e.target instanceof HTMLInputElement) return
        // never undo/delete notes behind the Settings window
        if (useStore.getState().settingsWindowOpen) return

        if (e.ctrlKey && !e.shiftKey && e.key === 'z') {
          e.preventDefault()
          doHistoryUndo()
        } else if (e.ctrlKey && (e.key === 'y' || (e.shiftKey && e.key === 'Z'))) {
          e.preventDefault()
          doHistoryRedo()
        } else if (e.key === 'Escape') {
          setContextMenu(null)
        } else if ((e.key === 'Delete' || e.key === 'Backspace') && editSelectedNotes.size > 0) {
          e.preventDefault()
          deleteSelectedNotes()
        }
      }

      // ── history_push helper (avoids repeating boilerplate) ────────────────
      const history_push = (cmd: { apply(): void; revert(): void; description: string; note?: ToneNote; track?: Track; touched?: object[] }) => {
        // A single-note edit marks its own note; group edits pass touched
        cmd.touched ??= cmd.note ? [cmd.note] : []
        NES.history.push(cmd)
        NES.syncEditedNotes()
        NES.dirty            = true
        NES.needsFlatRebuild = true
        NES.onHistoryChange?.()
      }

      // ── Velocity lane — advanced technique, toggled on demand (toolbar icon),
      // only meaningful while a track is soloed for edit. Bars align to the
      // SAME pitch/X position as the falling notes and keyboard above/below —
      // one continuous vertical line through keyboard key → note → velocity
      // bar, matching this roll's vertical (Y=time, X=pitch) orientation
      // rather than porting a horizontal-DAW-style time-axis lane. Scoped to
      // one soloed track at a time — with large files (many tracks, thousands
      // of notes) editing velocity across everything at once isn't
      // practically usable anyway. Notes shown are whatever's in the same
      // visible time-window the falling view already computes (editFlatNotes)
      // — bars scroll/update live with playback; there's no independent
      // pan/zoom to browse the rest of the track while paused (that's the
      // flagged upgrade — a real secondary time-axis mini-editor, closer to
      // Signal/Ableton/Logic's lane, if ever wanted). ───────────────────────
      const drawVelocityLane = () => {
        const canvas = velocityCanvasRef.current
        const ctx    = velocityCtxRef.current
        if (!canvas || !ctx) return
        const { noteEditorActive, velocityPanelOpen, noteEditorSoloTrackIndex } = storeRef.current
        const visible = noteEditorActive && velocityPanelOpen
        canvas.style.display = visible ? 'block' : 'none'
        if (!visible) { velBars = []; return }

        const W = canvas.width, H = canvas.height
        ctx.clearRect(0, 0, W, H)
        ctx.fillStyle = BAR_PILL_BG_COLOR
        ctx.fillRect(0, 0, W, H)
        ctx.strokeStyle = BARLINE_COLOR
        ctx.beginPath(); ctx.moveTo(0, 0.5); ctx.lineTo(W, 0.5); ctx.stroke()

        // ── Label — top center, amber caps, no icon. Bigger top/bottom
        // padding + larger type than the rest of the roll's canvas labels —
        // this header needs to read at a glance, not blend into background
        // chrome like the bar-number labels do. ────────────────────────────
        const HEADER_H = 34
        ctx.fillStyle = HAND_AMBER_HEX_STR
        ctx.font = `bold 12px ${FONT_UI_STR}`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'alphabetic'
        ctx.save()
        ctx.letterSpacing = '0.1em' as any
        ctx.fillText('VELOCITY EDITOR', W / 2, HEADER_H / 2 + 4)
        ctx.restore()

        if (noteEditorSoloTrackIndex === null) {
          velBars = []
          ctx.fillStyle = NOTE_LABEL_COLOR
          ctx.globalAlpha = 0.6
          ctx.font = `11px ${FONT_MONO_STR}`
          ctx.textAlign = 'center'
          ctx.textBaseline = 'middle'
          ctx.fillText('Solo a track to edit its velocity in the Tracks panel on the right', W / 2, H / 2)
          ctx.globalAlpha = 1
          return
        }

        velBars = []
        // trackTop starts below the taller header row so the guideline grid
        // never overlaps it.
        const trackTop = HEADER_H, trackH = H - trackTop - 6

        // ── Guideline gridlines — 0/32/64/96/127, barely-visible horizontal
        // lines + value markers on both edges, same idea as the main roll's
        // bar-number lines but much subtler (this is a background reference,
        // not a primary UI element). ────────────────────────────────────────
        ctx.font = `8px ${FONT_MONO_STR}`
        ctx.textBaseline = 'middle'
        for (const v of [0, 32, 64, 96, 127]) {
          const gy = trackTop + trackH - (v / 127) * trackH
          ctx.globalAlpha = 0.25
          ctx.strokeStyle = BARLINE_COLOR
          ctx.beginPath(); ctx.moveTo(0, Math.round(gy) + 0.5); ctx.lineTo(W, Math.round(gy) + 0.5); ctx.stroke()
          ctx.globalAlpha = 0.4
          ctx.fillStyle = NOTE_LABEL_COLOR
          ctx.textAlign = 'left'
          ctx.fillText(String(v), 4, gy)
          ctx.textAlign = 'right'
          ctx.fillText(String(v), W - 4, gy)
        }
        ctx.globalAlpha = 1

        // ── Pitch range → horizontal position, centered ───────────────────
        // Previously bars sat at the note's actual keyboard X — for a track
        // using only a narrow slice of the keyboard (e.g. a bass or lead
        // line), all its bars crowded into one edge of the lane and
        // overlapped instead of using the available width. Remapping the
        // soloed track's own min–max pitch span to the full lane width
        // (centered, with side padding) spreads them out regardless of
        // where on the actual keyboard the notes sit. Computed from the
        // FULL track (not just the currently-visible falling notes), so the
        // layout stays stable and doesn't shift as different notes scroll
        // into view. ─────────────────────────────────────────────────────
        const soloedParsedTrack = storeRef.current.midi?.tracks.find((t: any) => t.index === noteEditorSoloTrackIndex)
        const soloedNotes = soloedParsedTrack?.notes ?? []
        let minMidi = Infinity, maxMidi = -Infinity
        for (const n of soloedNotes) {
          if (n.midi < minMidi) minMidi = n.midi
          if (n.midi > maxMidi) maxMidi = n.midi
        }
        const rawSpan  = maxMidi >= minMidi ? maxMidi - minMidi : 0
        const LANE_PAD = 20
        const usableW  = Math.max(1, W - LANE_PAD * 2)

        // ── Same-pitch repeats within the visible window — nudge sideways ──
        // Two passes: count how many visible notes share each pitch, then
        // (below) spread that many bars symmetrically around the pitch's
        // base X instead of stacking them exactly on top of each other. ────
        const pitchTotal = new Map<number, number>()
        for (const ef of editFlatNotes) pitchTotal.set(ef.note.midi, (pitchTotal.get(ef.note.midi) ?? 0) + 1)
        const pitchSeen = new Map<number, number>()

        // editFlatNotes already excludes every track except the soloed one —
        // soloTrackForEdit hides all others (ts.visible=false), and
        // buildEditFlatNotes gates on ts.visible the same way the main
        // falling view does. No extra track filtering needed here.
        for (const ef of editFlatNotes) {
          const note = ef.note
          const vel  = Math.max(0, Math.min(1, note.velocity))
          const barW = VELOCITY_BAR_W
          const norm = rawSpan > 0 ? (note.midi - minMidi) / rawSpan : 0.5
          const total = pitchTotal.get(note.midi) ?? 1
          const seen  = pitchSeen.get(note.midi) ?? 0
          pitchSeen.set(note.midi, seen + 1)
          const nudge = total > 1 ? (seen - (total - 1) / 2) * (barW + 2) : 0
          const x    = LANE_PAD + norm * usableW - barW / 2 + nudge
          const barH = Math.max(2, Math.round(vel * trackH))
          const y    = trackTop + (trackH - barH)
          const isDragging = note === velDragNote

          // The value isn't printed on the bars (close bars made the numbers
          // overlap): it's in the hover label, which follows a drag live
          // A note selected on the roll lights its bar in amber, so in a dense
          // passage you can see which bar belongs to the note you clicked
          const isHovered = note === velHoverNote
          ctx.fillStyle = editSelectedNotes.has(note) ? HAND_AMBER_HEX_STR
            : isDragging || isHovered ? VELOCITY_BAR_HEX_STR : `${VELOCITY_BAR_HEX_STR}bb`
          ctx.fillRect(x, y, barW, barH)

          velBars.push({ note, x, w: barW })
        }
      }

      const onVelPointerDown = (e: PointerEvent) => {
        if (!storeRef.current.noteEditorActive) return
        const canvas = velocityCanvasRef.current
        if (!canvas) return
        const r  = canvas.getBoundingClientRect()
        const cx = e.clientX - r.left
        // Last match wins (matches draw order — later entries render on top).
        let hit: { note: ToneNote; x: number; w: number } | undefined
        for (const b of velBars) { if (cx >= b.x && cx <= b.x + b.w) hit = b }
        if (!hit) return
        velDragNote    = hit.note
        velDragStartY  = e.clientY
        velDragStartVel = hit.note.velocity
        // Dragging a bar that's part of a real multi-selection shifts the
        // whole selection together — see velDragGroup's declaration above.
        if (editSelectedNotes.has(hit.note) && editSelectedNotes.size > 1) {
          velDragGroup = new Map()
          for (const n of editSelectedNotes) velDragGroup.set(n, n.velocity)
        } else {
          velDragGroup = null
        }
        canvas.style.cursor = 'grabbing'
        canvas.setPointerCapture(e.pointerId)
      }
      // ── Hover/drag label — "Velocity 96" next to the cursor (same label the
      // main roll uses for notes); a group drag shows the grabbed bar's value
      const velLabel = (n: ToneNote) => `Velocity ${Math.round(Math.max(0, Math.min(1, n.velocity)) * 127)}`
      const onVelPointerMove = (e: PointerEvent) => {
        const canvas = velocityCanvasRef.current
        if (!canvas) return
        if (!velDragNote) {
          // Not dragging — hover cursor (grab over a bar) and the value label
          const r  = canvas.getBoundingClientRect()
          const cx = e.clientX - r.left
          let hit: ToneNote | null = null
          for (const b of velBars) { if (cx >= b.x && cx <= b.x + b.w) hit = b.note }
          canvas.style.cursor = hit ? 'grab' : 'default'
          if (hit !== velHoverNote) { velHoverNote = hit; dirtyRef.current = true }
          setEditTooltip(hit ? { x: e.clientX, y: e.clientY, label: velLabel(hit) } : null)
          return
        }
        const trackH = canvas.height - 20 - 6
        const delta  = (velDragStartY - e.clientY) / trackH
        if (velDragGroup) {
          for (const [n, startVel] of velDragGroup) n.velocity = Math.max(0, Math.min(1, startVel + delta))
        } else {
          velDragNote.velocity = Math.max(0, Math.min(1, velDragStartVel + delta))
        }
        setEditTooltip({ x: e.clientX, y: e.clientY, label: velLabel(velDragNote) })
      }
      const onVelPointerLeave = () => {
        if (velDragNote) return   // pointer capture keeps a drag going outside
        if (velHoverNote) { velHoverNote = null; dirtyRef.current = true }
        setEditTooltip(null)
      }
      const onVelPointerUp = (e: PointerEvent) => {
        if (!velDragNote) return
        const note        = velDragNote
        const originalVel = velDragStartVel
        const finalVel    = note.velocity
        const group       = velDragGroup
        velDragNote  = null
        velDragGroup = null
        if (velocityCanvasRef.current) velocityCanvasRef.current.style.cursor = 'default'
        try { velocityCanvasRef.current?.releasePointerCapture(e.pointerId) } catch {}
        if (group) {
          const originals = group
          const finals = new Map([...group.keys()].map(n => [n, n.velocity] as const))
          const changed = [...originals].some(([n, v]) => Math.abs((finals.get(n) ?? v) - v) >= 0.001)
          if (!changed) return
          history_push({
            touched: [...originals.keys()],
            description: `Velocity shift on ${originals.size} notes`,
            apply()  { for (const [n, v] of finals) n.velocity = v },
            revert() { for (const [n, v] of originals) n.velocity = v },
          })
          return
        }
        if (Math.abs(finalVel - originalVel) < 0.001) return
        history_push({
          note,
          description: `Velocity note midi=${note.midi}: ${originalVel.toFixed(2)} → ${finalVel.toFixed(2)}`,
          apply()  { note.velocity = finalVel },
          revert() { note.velocity = originalVel },
        })
      }

      // ── Register reset handler — toolbar Reset button rebuilds editMidi from _raw ──
      NES.onResetRequest = () => {
        const raw = (storeRef.current.midi as any)?._raw as ArrayBuffer | undefined
        if (!raw) return
        NES.editMidi         = midiToEditableCopy(raw)
        copyHandTagsOntoEditBuffer(storeRef.current.midi, NES.editMidi)
        NES.history.clear()
        NES.dirty            = false
        NES.newNotes.clear()
        NES.editedNotes.clear()
        NES.needsFlatRebuild = true
        NES.hoverHint        = NES.defaultHint
        NES.onHistoryChange?.()
        NES.onHintChange?.()
      }

      // ── Reset hint when cursor leaves the canvas — selection-aware, so
      // "nothing selected" doesn't lie about an active selection just
      // because the mouse moved back onto the toolbar itself. ─────────────
      const onCanvasLeave = () => {
        if (!storeRef.current.noteEditorActive) return
        setEditTooltip(null)
        const n = editSelectedNotes.size
        const hint = n > 0 ? `${n} note${n === 1 ? '' : 's'} selected · Right-click for options` : NES.defaultHint
        if (NES.hoverHint !== hint) {
          NES.hoverHint = hint
          NES.onHintChange?.()
        }
      }

      // ── Register edit handlers ────────────────────────────────────────────
      app.canvas.addEventListener('pointerdown',   onEditDown)
      app.canvas.addEventListener('pointermove',   onEditMove)
      app.canvas.addEventListener('pointerup',     onEditUp)
      app.canvas.addEventListener('pointercancel', onEditUp)
      app.canvas.addEventListener('contextmenu',   onEditContext)
      app.canvas.addEventListener('mouseleave',    onCanvasLeave)
      window.addEventListener('keydown', onEditKey, { capture: true })
      offEditKey = () => window.removeEventListener('keydown', onEditKey, { capture: true })
      velCanvas.addEventListener('pointerdown',   onVelPointerDown)
      velCanvas.addEventListener('pointermove',   onVelPointerMove)
      velCanvas.addEventListener('pointerup',     onVelPointerUp)
      velCanvas.addEventListener('pointercancel', onVelPointerUp)
      velCanvas.addEventListener('pointerleave',  onVelPointerLeave)

      // ── Initial draw ──────────────────────────────────────────────────────
      const { keyboardSize } = useStore.getState()
      lastKeySizeRef.current = keyboardSize
      applyResize(el.clientWidth || 800, el.clientHeight || 600, window.devicePixelRatio || 1)
      // Redraw every tick during playback or note editing (both need continuous
      // animation — scrolling playhead, drag previews, selection pulse). Otherwise
      // only redraw when dirtyRef was flagged by an actual relevant change, so an
      // idle piano roll doesn't burn a full core recomputing an unchanged frame
      // 60x/second.
      app.ticker.add(() => {
        const { playbackState, noteEditorActive } = storeRef.current
        if (playbackState !== 'playing' && !noteEditorActive && !dirtyRef.current) return
        dirtyRef.current = false
        drawFrame()
        drawVelocityLane()
      })

      // ── Real window/layout resizes — routed through the same applyResize +
      // last-requested-size check as drawFrame's own per-tick guard, so the
      // two paths can't fight each other (e.g. both resizing the same frame
      // to two different DPR readings taken a moment apart). ───────────────
      roInstance = new ResizeObserver(() => {
        if (!appRef.current) return
        const w = el.clientWidth, h = el.clientHeight
        const dpr = window.devicePixelRatio || 1
        if (w <= 0 || h <= 0) return
        if (w === lastSizeW && h === lastSizeH && dpr === lastSizeDpr) return
        applyResize(w, h, dpr)
      })
      roInstance.observe(el)
    })

    return () => {
      disposed = true
      offEditKey?.()
      roInstance?.disconnect()
      if (dprQuery && onDprChangeHandler) dprQuery.removeEventListener('change', onDprChangeHandler)
      NES.onResetRequest = null
      if (overlayCanvasRef.current) {
        try { overlayCanvasRef.current.remove() } catch {}
        overlayCanvasRef.current = null
        overlayCtxRef.current    = null
      }
      if (velocityCanvasRef.current) {
        try { velocityCanvasRef.current.remove() } catch {}
        velocityCanvasRef.current = null
        velocityCtxRef.current    = null
      }
      try { hitEffectsRef.current?.destroy() } catch {}
      hitEffectsRef.current = null
      if (appRef.current) {
        try { appRef.current.canvas.remove() } catch {}
        try { appRef.current.destroy(false) } catch {}
        appRef.current = null
      }
    }
  }, [])

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: '100%', background: 'var(--bg)', overflow: 'hidden', position: 'relative' }}
    >
      <LoopOverlay />
      {/* ── Note-name tooltip — shown in edit mode when note is too small for inline text ── */}
      {editTooltip && (
        <div style={{
          position: 'fixed',
          left: editTooltip.x + 14,
          top:  editTooltip.y - 28,
          zIndex: 9500,
          background: 'var(--pianoroll-tooltip-bg)',
          border: '1px solid var(--state-hover-border)',
          borderRadius: 'var(--radius-sm)',
          padding: '2px 8px',
          fontSize: 'var(--text-xs)',
          fontFamily: 'var(--font-mono)',
          color: 'var(--text-default)',
          pointerEvents: 'none',
          userSelect: 'none',
          whiteSpace: 'nowrap',
          boxShadow: '0 2px 8px rgba(0,0,0,0.5)',
        }}>
          {editTooltip.label}
        </div>
      )}

      {contextMenu && (
        <div
          role="menu"
          aria-label={t`Note actions`}
          onMouseDown={e => e.stopPropagation()}
          style={{
            position: 'fixed',
            left: contextMenu.x, top: contextMenu.y,
            zIndex: 9800,
            background: 'var(--panel)',
            border: '1px solid var(--state-hover-border)',
            borderRadius: 'var(--radius-sm)',
            padding: '4px 0',
            minWidth: 160,
            boxShadow: '0 4px 16px rgba(0,0,0,0.55)',
            fontFamily: 'var(--font-ui)',
            fontSize: 12,
          }}
        >
          {contextMenu.options.map((opt, i) => (
            <div
              key={i}
              role="menuitem"
              aria-disabled={opt.disabled}
              onClick={() => { if (!opt.disabled) opt.onClick() }}
              style={{
                padding: '6px 14px',
                display: 'flex', alignItems: 'center', gap: 8,
                cursor: opt.disabled ? 'default' : 'pointer',
                color: opt.disabled ? 'var(--text-disabled-icon)' : opt.destructive ? 'var(--status-error)' : 'var(--text-default)',
                opacity: opt.disabled ? 0.5 : 1,
              }}
              onMouseEnter={e => { if (!opt.disabled) (e.currentTarget as HTMLElement).style.background = 'var(--state-hover-overlay-white)' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'transparent' }}
            >
              {opt.swatchColor && (
                <span style={{ width: 9, height: 9, borderRadius: 2, background: opt.swatchColor, flexShrink: 0 }} />
              )}
              {opt.label}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
