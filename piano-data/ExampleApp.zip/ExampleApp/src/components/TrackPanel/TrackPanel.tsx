import { useMemo, useState, useRef, useEffect } from 'react'
import { ChevronRight, Eye, Volume2, VolumeX, ChevronDown, AudioLines, ListTree, SlidersVertical, GripVertical, Sparkles } from 'lucide-react'
import { useStore } from '../../store'
import { t } from '../../utils/i18n'
import { GM_GROUPS } from '../../utils/gmInstruments'
import type { TrackState } from '../../types'
import { MarqueeText } from '../MarqueeText'
import { usePlayback } from '../../hooks/usePlayback'
import { NES } from '../../utils/noteEditorState'
import Tooltip from '../Tooltip'
import PianoKeysIcon from '../PianoKeysIcon'

const GROUP_ORDER = [
  'piano', 'chromatic', 'organ', 'guitar', 'bass',
  'strings', 'ensemble', 'brass', 'reed', 'pipe',
  'synth_lead', 'synth_pad', 'synth_fx', 'ethnic',
  'percussive', 'sfx', 'drums',
]

// Groups that show on keyboard by default
const KEYBOARD_GROUPS = new Set(['piano', 'chromatic', 'organ'])

// ── EyeClosed — custom icon replacing lucide EyeOff ──────────────────────────
function EyeClosed({ size = 24, strokeWidth = 2 }: { size?: number; strokeWidth?: number }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24"
      fill="none" stroke="currentColor" strokeWidth={strokeWidth}
      strokeLinecap="round" strokeLinejoin="round">
      <path d="m15 18-.722-3.25"/>
      <path d="M2 8a10.645 10.645 0 0 0 20 0"/>
      <path d="m20 15-1.726-2.05"/>
      <path d="m4 15 1.726-2.05"/>
      <path d="m9 18 .722-3.25"/>
    </svg>
  )
}

// ── PencilSparkles icon — open MIDI Playback Editor (not in installed lucide-react v0.503.0, inlined) ──
function PencilSparklesIcon({ size = 16 }: { size?: number }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10 3H8"/><path d="m15.007 5.008 3.987 3.986"/><path d="M20 15v4"/><path d="M21.174 6.813a2.82 2.82 0 0 0-3.986-3.987L3.842 16.175a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="M22 17h-4"/><path d="M4 5v4"/><path d="M6 7H2"/><path d="M9 2v2"/>
    </svg>
  )
}

// ── Track panel — collapsible right drawer with instrument group list and track controls
export default function TrackPanel() {
  // ── Lightweight track display-signature — NOT the live `tracks` array. Same
  // root cause as MixerConsole.tsx/ChannelStrip.tsx/MasterStrip.tsx: every
  // fader/pan/chorus/reverb drag replaces the whole `tracks` array (new
  // reference) many times a second, but none of those fields are rendered
  // here — only group/name/color/mute/solo/visibility/keyboard/channel/
  // program/isDrum are. Subscribing to `s.tracks` directly reproduced the
  // same fader-drag stutter already fixed in the Mixer's own components; a
  // joined string is value-equal across renders whenever none of these
  // display-relevant fields changed. ──────────────────────────────────────
  const trackSignature = useStore((s) => s.tracks.map((t) =>
    `${t.index}:${t.group ?? ''}:${t.trackName ?? ''}:${t.gmName}:${t.color}:${t.muted}:${t.solo}:${t.visible}:${t.showOnKeyboard}:${(t as any).channel}:${t.program}:${t.isDrum}`
  ).join('|'))
  const tracks = useMemo(() => useStore.getState().tracks, [trackSignature])
  const midi = useStore((s) => s.midi)
  const trackPanelOpen = useStore((s) => s.trackPanelOpen)
  const setTrackPanelOpen = useStore((s) => s.setTrackPanelOpen)
  const updateTrack = useStore((s) => s.updateTrack)
  const muteGroup = useStore((s) => s.muteGroup)
  const setTrackMuteFilter = useStore((s) => s.setTrackMuteFilter)
  const autoMuteNonKeyboard = useStore((s) => s.autoMuteNonKeyboard)
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set())
  // ── Drag-to-reorder — session-only display order, never written to the file.
  // Piano/keys always stays pinned first (see `grouped` below) — group drag is
  // simply disabled for it, and it's excluded from any custom order snapshot.
  const [customGroupOrder, setCustomGroupOrder] = useState<string[] | null>(null)
  const [customTrackOrder, setCustomTrackOrder] = useState<Record<string, number[]>>({})
  const [draggedGroup, setDraggedGroup] = useState<string | null>(null)
  const [draggedTrack, setDraggedTrack] = useState<{ group: string; index: number } | null>(null)
  const [hoveredHandle, setHoveredHandle] = useState<string | null>(null)
  // ── Global visibility toggle — same allVisible pattern as the Console
  // Mixer's MasterStrip, reading/writing the same track.visible field so
  // both controls always agree. ─────────────────────────────────────────
  const allVisible = tracks.length > 0 && tracks.every((t) => t.visible)
  const handleVisibleAll = () => {
    const target = !allVisible
    tracks.forEach((t) => updateTrack(t.index, { visible: target }))
  }
  const midiEditorOpen          = useStore((s) => s.midiEditorOpen)
  const noteEditorEnabled       = useStore((s) => s.noteEditorEnabled)
  const noteEditorActive        = useStore((s) => s.noteEditorActive)
  const setNoteEditorActive     = useStore((s) => s.setNoteEditorActive)
  const noteEditorSoloTrackIndex = useStore((s) => s.noteEditorSoloTrackIndex)
  const soloTrackForEdit        = useStore((s) => s.soloTrackForEdit)
  const playbackState           = useStore((s) => s.playbackState)
  const { pause } = usePlayback()

  // ── Open editor — sets store flag; MidiEditor floating modal reads from store ─
  // Gated on confirmPendingImportBeforeEdit: an imported foreign-format file
  // must be saved as a real .mid before any Orfeo editing tool can touch it.
  const handleOpenEditor = async () => {
    if (!midi) return
    const { confirmPendingImportBeforeEdit } = await import('../../utils/foreignFormatImport')
    if (!(await confirmPendingImportBeforeEdit())) return
    useStore.getState().setMidiEditorOpen(true)
  }

  // ── Toggle note edit mode — moved here from TopBar; same gating (only
  // visible/enabled when noteEditorEnabled in Settings, and a file is loaded) ──
  const handleToggleNoteEditor = async () => {
    if (noteEditorActive) {
      setNoteEditorActive(false)
      NES.reset()
      return
    }
    const { confirmPendingImportBeforeEdit } = await import('../../utils/foreignFormatImport')
    if (!(await confirmPendingImportBeforeEdit())) return
    if (playbackState === 'playing') pause()
    NES.reset()
    setNoteEditorActive(true)
  }

  // ── Group tracks — partition by GM group key. Default order is GROUP_ORDER;
  // customGroupOrder/customTrackOrder (drag-reorder, session-only) override it
  // when present. Piano always renders first regardless — pinned, not draggable.
  const grouped = useMemo(() => {
    const map = new Map<string, TrackState[]>()
    for (const track of tracks) {
      const g = track.group ?? 'sfx'
      if (!map.has(g)) map.set(g, [])
      map.get(g)!.push(track)
    }
    const present = GROUP_ORDER.filter(g => map.has(g))
    const nonPiano = present.filter(g => g !== 'piano')
    const orderedNonPiano = customGroupOrder
      ? [...customGroupOrder.filter(g => nonPiano.includes(g)), ...nonPiano.filter(g => !customGroupOrder!.includes(g))]
      : nonPiano
    const orderedKeys = present.includes('piano') ? ['piano', ...orderedNonPiano] : orderedNonPiano

    return orderedKeys.map(g => {
      const groupTracks = map.get(g)!
      const order = customTrackOrder[g]
      const orderedTracks = order
        ? [...order.map(idx => groupTracks.find(t => t.index === idx)).filter((t): t is TrackState => !!t),
           ...groupTracks.filter(t => !order.includes(t.index))]
        : groupTracks
      return { key: g, label: GM_GROUPS[g]?.label ?? g, tracks: orderedTracks }
    })
  }, [tracks, customGroupOrder, customTrackOrder])

  // ── Group drag-to-reorder — piano is never draggable and never a valid drop
  // target's displacement (it's excluded from the reorderable list entirely,
  // so nothing can end up ahead of it). ────────────────────────────────────
  const reorderGroups = (draggedKey: string, targetKey: string) => {
    if (draggedKey === targetKey || draggedKey === 'piano' || targetKey === 'piano') return
    const base = customGroupOrder ?? grouped.filter(g => g.key !== 'piano').map(g => g.key)
    // ── Direction-aware insert — splicing at a flat `without.indexOf(target)`
    // always inserts BEFORE the target regardless of drag direction, which
    // only reads right when dragging upward. Dragging downward needs to
    // insert AFTER the target (the dragged item's removal shifts everything
    // below it up by one), or the reflow stalls/oscillates on every
    // downward hover instead of actually passing the target row — this was
    // the "up works, down doesn't" bug. ─────────────────────────────────────
    const movingDown = base.indexOf(targetKey) > base.indexOf(draggedKey)
    const without = base.filter(k => k !== draggedKey)
    const targetIdx = without.indexOf(targetKey) + (movingDown ? 1 : 0)
    without.splice(targetIdx, 0, draggedKey)
    setCustomGroupOrder(without)
  }

  // ── Track drag-to-reorder within a single group ───────────────────────────
  const reorderTracks = (groupKey: string, draggedIndex: number, targetIndex: number) => {
    if (draggedIndex === targetIndex) return
    const groupTracksNow = grouped.find(g => g.key === groupKey)?.tracks.map(t => t.index) ?? []
    const base = customTrackOrder[groupKey] ?? groupTracksNow
    // ── Direction-aware insert — see reorderGroups above for why: inserting
    // at a flat `without.indexOf(target)` only reads right moving upward;
    // downward drags need +1 or the reflow stalls on every downward hover. ──
    const movingDown = base.indexOf(targetIndex) > base.indexOf(draggedIndex)
    const without = base.filter(i => i !== draggedIndex)
    const targetIdx = without.indexOf(targetIndex) + (movingDown ? 1 : 0)
    without.splice(targetIdx, 0, draggedIndex)
    setCustomTrackOrder(prev => ({ ...prev, [groupKey]: without }))
  }

  const hasSolo = tracks.some(t => t.solo)

  // ── Focus on/off — the store's own flag (the Mixer uses the same) ─────────
  const isCurrentlyFiltered = useStore((s) => s.focusActive)

  // ── Toggle group collapse — adds/removes group key from collapsed set ─────
  const toggleGroupCollapse = (group: string) => {
    setCollapsedGroups(prev => {
      const next = new Set(prev)
      if (next.has(group)) next.delete(group); else next.add(group)
      return next
    })
  }

  // ── isGroupMuted — true when every track in the group is muted ───────────
  const isGroupMuted = (groupKey: string) =>
    tracks.filter(t => t.group === groupKey).every(t => t.muted)

  return (
    <div
      style={{
        width: trackPanelOpen ? 260 : 32,
        background: 'var(--bg-modal)',
        borderLeft: '1px solid var(--border2)',
        transition: 'width 0.2s ease',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        flexShrink: 0,
        position: 'relative',
      }}
    >
      {/* ── Closed state: 3-icon column ────────────────────────────────────── */}
      {!trackPanelOpen && (
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          height: '100%', paddingTop: 10,
        }}>
          <Tooltip title={t`Open Tracks panel`} description={t`Shows every track with its mute, solo, and visibility controls.`}>
          <button
            onClick={() => setTrackPanelOpen(true)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--text-dimmest)', padding: 4,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'color 0.15s',
            }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-amber)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dimmest)'}
          >
            <ListTree size={18} />
          </button>
          </Tooltip>
          <Tooltip
            title={!midi ? t`Open a MIDI file first` : midiEditorOpen ? t`MIDI Playback Editor is open` : t`MIDI Playback Editor`}
            description={!midi ? t`Load a MIDI file to edit its playback.` : midiEditorOpen ? t`Already open — check for it among your other windows.` : t`Edit what you want to hear and see: rename tracks, reassign instruments, merge/split ...`}
            wrapperStyle={{ marginTop: 8 }}
          >
          <button
            onClick={midi && !midiEditorOpen ? handleOpenEditor : undefined}
            style={{
              background: 'none', border: 'none',
              cursor: !midi || midiEditorOpen ? 'default' : 'pointer',
              color: midiEditorOpen ? 'var(--text-amber)' : !midi ? 'var(--state-disabled)' : 'var(--text-dimmest)',
              padding: 4,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'color 0.15s',
            }}
            onMouseEnter={e => { if (midi && !midiEditorOpen) e.currentTarget.style.color = 'var(--text-amber)' }}
            onMouseLeave={e => { if (midi && !midiEditorOpen) e.currentTarget.style.color = 'var(--text-dimmest)'; else (e.currentTarget as HTMLElement).style.color = midiEditorOpen ? 'var(--text-amber)' : !midi ? 'var(--state-disabled)' : 'var(--text-dimmest)' }}
          >
            <PencilSparklesIcon size={18} />
          </button>
          </Tooltip>
          {noteEditorEnabled && midi && (
            <Tooltip
              title={noteEditorActive ? t`Exit note edit mode` : t`MIDI note editor`}
              description={noteEditorActive ? t`Returns to normal playback view.` : t`Edit individual notes directly on the piano roll.`}
              wrapperStyle={{ marginTop: 8 }}
            >
            <button
              onClick={handleToggleNoteEditor}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                color: noteEditorActive ? 'var(--text-amber)' : 'var(--text-dimmest)',
                padding: 4,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'color 0.15s',
              }}
              onMouseEnter={e => { if (!noteEditorActive) e.currentTarget.style.color = 'var(--text-amber)' }}
              onMouseLeave={e => { if (!noteEditorActive) e.currentTarget.style.color = 'var(--text-dimmest)' }}
            >
              {/* strokeWidth compensates for this icon's larger render size (22 vs
                  siblings' 18) — same 24-unit viewBox means a fixed strokeWidth
                  renders visibly thicker at a bigger size; this keeps the actual
                  on-screen stroke weight matching its neighbors. ──────────────── */}
              <AudioLines size={22} strokeWidth={1.64} />
            </button>
            </Tooltip>
          )}
          <Tooltip title={t`Console Mixer`} description={t`Adjust volume, pan, and effects for every track individually.`} wrapperStyle={{ marginTop: 8 }}>
          <button
            onClick={() => useStore.getState().setMixerOpen(true)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--text-dimmest)', padding: 4,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'color 0.15s',
            }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-amber)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dimmest)'}
          >
            <SlidersVertical size={18} />
          </button>
          </Tooltip>
          {/* ── Dashed outline + low opacity — a same-shade disabled icon read as
              a normal, clickable nav icon until hovered; this makes "not yet
              shipped" visible at rest, not just on tooltip. ──────────────── */}
          <Tooltip title={t`A dedicated Practice mode is planned but not built yet.`} oneLine wrapperStyle={{ marginTop: 8 }}>
          <div
            style={{
              color: 'var(--state-disabled)', padding: 3,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'default', opacity: 0.55,
              border: '1px dashed var(--border2)', borderRadius: 4,
            }}
          >
            <Sparkles size={18} />
          </div>
          </Tooltip>
        </div>
      )}

      {trackPanelOpen && (
        <div style={{ display: 'flex', height: '100%', overflow: 'hidden' }}>

          {/* ── Left icon strip: chevron + coming soon + MIDI editor ──────── */}
          <div style={{
            width: 32, flexShrink: 0,
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            paddingTop: 10,
            borderRight: '1px solid var(--bg-tile)',
          }}>
            <Tooltip title={t`Close panel`} oneLine placement="left">
            <button
              onClick={() => setTrackPanelOpen(false)}
              style={{
                background: 'var(--bg-tile)', border: '1px solid var(--border2)', borderRight: 'none',
                borderRadius: '0 4px 4px 0',
                cursor: 'pointer', color: 'var(--text-dimmest)', padding: '4px 5px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'color 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--text-amber)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dimmest)'}
            >
              <ChevronRight size={15} />
            </button>
            </Tooltip>
            <Tooltip
              title={!midi ? t`Open a MIDI file first` : midiEditorOpen ? t`MIDI Playback Editor is open` : t`MIDI Playback Editor`}
              description={!midi ? t`Load a MIDI file to edit its playback.` : midiEditorOpen ? t`Already open — check for it among your other windows.` : t`Edit what you want to hear and see: rename tracks, reassign instruments, merge/split ...`}
              wrapperStyle={{ marginTop: 8 }}
            >
            <button
              onClick={midi && !midiEditorOpen ? handleOpenEditor : undefined}
              style={{
                background: 'none', border: 'none',
                cursor: !midi || midiEditorOpen ? 'default' : 'pointer',
                color: midiEditorOpen ? 'var(--text-amber)' : !midi ? 'var(--state-disabled)' : 'var(--text-dimmest)',
                padding: 4,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'color 0.15s',
              }}
              onMouseEnter={e => { if (midi && !midiEditorOpen) e.currentTarget.style.color = 'var(--text-amber)' }}
              onMouseLeave={e => { if (midi && !midiEditorOpen) e.currentTarget.style.color = 'var(--text-dimmest)'; else (e.currentTarget as HTMLElement).style.color = midiEditorOpen ? 'var(--text-amber)' : !midi ? 'var(--state-disabled)' : 'var(--text-dimmest)' }}
            >
              <PencilSparklesIcon size={16} />
            </button>
            </Tooltip>
            {noteEditorEnabled && midi && (
              <Tooltip
                title={noteEditorActive ? t`Exit note edit mode` : t`MIDI note editor`}
                description={noteEditorActive ? t`Returns to normal playback view.` : t`Add, delete and move individual notes directly on the piano roll. Assign notes to Left/Right hand.`}
                wrapperStyle={{ marginTop: 8 }}
              >
              <button
                onClick={handleToggleNoteEditor}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  color: noteEditorActive ? 'var(--text-amber)' : 'var(--text-dimmest)',
                  padding: 4,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'color 0.15s',
                }}
                onMouseEnter={e => { if (!noteEditorActive) e.currentTarget.style.color = 'var(--text-amber)' }}
                onMouseLeave={e => { if (!noteEditorActive) e.currentTarget.style.color = 'var(--text-dimmest)' }}
              >
                {/* strokeWidth compensates for this icon's larger render size (20 vs
                    siblings' 16) — see collapsed-rail instance above for why. ──── */}
                <AudioLines size={20} strokeWidth={1.6} />
              </button>
              </Tooltip>
            )}
            <Tooltip title={t`Console Mixer`} description={t`Adjust volume, pan, chorus, and reverb 
for every track and apply compression.`} wrapperStyle={{ marginTop: 8 }}>
            <button
              onClick={() => useStore.getState().setMixerOpen(true)}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                color: 'var(--text-dimmest)', padding: 4,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'color 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--text-amber)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-dimmest)'}
            >
              <SlidersVertical size={16} />
            </button>
            </Tooltip>
            {/* ── Dashed outline + low opacity — see collapsed-strip twin above ── */}
            <Tooltip title={t`Practice mode - coming soon`} oneLine wrapperStyle={{ marginTop: 8 }}>
            <div
              style={{
                color: 'var(--state-disabled)', padding: 3,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'default', opacity: 0.55,
                border: '1px dashed var(--border2)', borderRadius: 4,
              }}
            >
              {/* strokeWidth compensates for this icon's larger render size (20 vs
                  siblings' 16), same reason as the AudioLines note-editor instances above. */}
              <Sparkles size={20} strokeWidth={1.6} />
            </div>
            </Tooltip>
          </div>

          {/* ── Track content ─────────────────────────────────────────────── */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

          {/* Header */}
          <div style={{
            height: 40, display: 'flex', alignItems: 'center',
            padding: '0 10px 0 14px',
            borderBottom: '1px solid var(--border)', flexShrink: 0,
            gap: 'var(--space-2)',
          }}>
            <ListTree size={14} style={{ color: 'var(--text-inactive)', flexShrink: 0 }} />
            <span style={{ color: 'var(--text-dimmest)', fontSize: 'var(--text-sm)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
              {t`Tracks`}
            </span>
            {midi && (
              <>
                <span style={{ color: 'var(--text-inactive)', fontSize: 'var(--text-xs)', fontFamily: 'var(--font-mono)' }}>
                  {tracks.length}
                </span>
                <Tooltip
                  title={allVisible ? t`Hide all tracks` : t`Show all tracks`}
                  description={allVisible ? t`Hide every track’s notes on the Piano Roll 
— turn individual ones back on anytime` : t`Show every track’s notes 
on the Piano Roll again`}
                >
                <button
                  onClick={handleVisibleAll}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    padding: '2px 4px', display: 'flex', alignItems: 'center',
                    color: allVisible ? 'var(--text-muted)' : 'var(--text-amber)',
                  }}
                >
                  {allVisible ? <EyeClosed size={13} /> : <Eye size={13} />}
                </button>
                </Tooltip>
                {/* ── Mute-filter quick toggle — visible only when Selective Tracks Playback is on in Settings ── */}
                {autoMuteNonKeyboard && (
                  <Tooltip
                    title={isCurrentlyFiltered ? t`Focus on the keys` : t`Playing all tracks`}
                    description={isCurrentlyFiltered ? t`Hearing keys, bass & drums, seeing only the keys.\nClick to bring back all tracks as they were.` : t`Click to hear only keys, bass & drums\nand see only the keys — good for practising`}
                    wrapperStyle={{ marginLeft: 'auto' }}
                  >
                  <button
                    onClick={() => setTrackMuteFilter(!isCurrentlyFiltered)}
                    style={{
                      padding: '2px 8px',
                      borderRadius: 'var(--radius-sm)',
                      border: 'none',
                      background: 'var(--text-amber)',
                      color: 'var(--text-on-amber)',
                      fontSize: 10,
                      fontWeight: 700,
                      fontFamily: 'var(--font-ui)',
                      letterSpacing: '0.02em',
                      cursor: 'pointer',
                      whiteSpace: 'nowrap',
                      lineHeight: '18px',
                      flexShrink: 0,
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    <svg width="6" height="7" viewBox="0 0 6 7" style={{ marginRight: 3, flexShrink: 0 }}><polygon points="0,0 6,3.5 0,7" fill="currentColor"/></svg>
                    {isCurrentlyFiltered ? t`Focus ON` : t`Focus OFF`}
                  </button>
                  </Tooltip>
                )}
              </>
            )}
          </div>

          {/* Track list */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '4px 0' }}>
            {!midi && (
              <div style={{ padding: '12px 14px', fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>
                {t`Open a MIDI file to see tracks`}
              </div>
            )}

            {grouped.map(({ key, label, tracks: groupTracks }) => {
              const collapsed = collapsedGroups.has(key)
              const groupMuted = isGroupMuted(key)
              const isPiano = key === 'piano'
              const handleId = `group:${key}`

              return (
                <div
                  key={key}
                  style={{ marginBottom: 2, opacity: draggedGroup === key ? 0.4 : 1 }}
                  onDragOver={!isPiano ? (e) => e.preventDefault() : undefined}
                  onDrop={!isPiano ? () => { if (draggedGroup) reorderGroups(draggedGroup, key); setDraggedGroup(null) } : undefined}
                >
                  {/* Group header row */}
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    padding: '5px 10px 5px 10px',
                    background: 'var(--bg-row)',
                    borderTop: '1px solid var(--bg-tile)',
                    borderBottom: '1px solid var(--bg-tile)',
                  }}>
                    <button
                      onClick={() => toggleGroupCollapse(key)}
                      draggable={!isPiano}
                      onDragStart={!isPiano ? (e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', ''); setDraggedGroup(key) } : undefined}
                      onDragEnd={() => setDraggedGroup(null)}
                      onMouseEnter={() => setHoveredHandle(handleId)}
                      onMouseLeave={() => setHoveredHandle(h => h === handleId ? null : h)}
                      style={{
                        background: 'none', border: 'none', padding: 0, display: 'flex', alignItems: 'center',
                        color: 'var(--text-inactive)',
                        cursor: isPiano ? 'pointer' : (hoveredHandle === handleId ? 'grab' : 'pointer'),
                      }}
                    >
                      {!isPiano && hoveredHandle === handleId
                        ? <GripVertical size={11} />
                        : <ChevronDown size={11} style={{ transform: collapsed ? 'rotate(-90deg)' : 'none', transition: 'transform 0.15s' }} />}
                    </button>

                    <span style={{ flex: 1, fontSize: 11, fontWeight: 700, lineHeight: '12px', textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--text-dimmest)' }}>
                      {label}
                    </span>

                    {/* ── Collapsed: colored square per track — visual legend only. Its
                        onClick used to duplicate the chevron button's own toggle —
                        redundant, and its cursor:pointer falsely implied the swatches
                        themselves were individually clickable. ─────────────────── */}
                    {collapsed && (
                      <div style={{ display: 'flex', gap: 2 }}>
                        {groupTracks.map(tr => (
                          <Tooltip key={tr.index} title={tr.trackName ?? tr.gmName} description={t`Track's color in the piano roll`}>
                            <div style={{ width: 7, height: 7, borderRadius: 2, background: tr.color, flexShrink: 0 }} />
                          </Tooltip>
                        ))}
                      </div>
                    )}

                    <span style={{ fontSize: 10, color: 'var(--text-track-count)', fontFamily: 'var(--font-mono)' }}>
                      {groupTracks.length}
                    </span>
                    <Tooltip
                      title={groupMuted ? `Unmute all ${label}` : `Mute all ${label}`}
                      description={groupMuted ? t`Unmute and show every track in ${label}` : t`Mute and hide every track in ${label} at once`}
                    >
                    <button
                      onClick={() => muteGroup(key, !groupMuted)}
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        padding: '2px 4px', display: 'flex', alignItems: 'center',
                        color: groupMuted ? 'var(--text-amber)' : 'var(--text-muted)',
                      }}
                    >
                      {groupMuted ? <VolumeX size={12} /> : <Volume2 size={12} />}
                    </button>
                    </Tooltip>
                  </div>

                  {/* Track rows */}
                  {!collapsed && groupTracks.map((track) => {
                    const effectivelyMuted = track.muted || (hasSolo && !track.solo)
                    return (
                      <TrackRow
                        key={track.index}
                        track={track}
                        dimmed={effectivelyMuted}
                        onMute={() => useStore.getState().setTrackMuted(track.index, !track.muted)}
                        onSolo={() => updateTrack(track.index, { solo: !track.solo })}
                        onVisible={() => updateTrack(track.index, { visible: !track.visible })}
                        onKeyboard={() => updateTrack(track.index, { showOnKeyboard: !track.showOnKeyboard })}
                        onSoloForEdit={noteEditorActive ? () => soloTrackForEdit(track.index) : undefined}
                        isSoloedForEdit={noteEditorSoloTrackIndex === track.index}
                        isDragging={draggedTrack?.group === key && draggedTrack.index === track.index}
                        isHandleHovered={hoveredHandle === `track:${key}:${track.index}`}
                        onHandleHover={(hovered) => setHoveredHandle(hovered ? `track:${key}:${track.index}` : null)}
                        onDragStart={() => setDraggedTrack({ group: key, index: track.index })}
                        onDragEnd={() => setDraggedTrack(null)}
                        onDragOverRow={(e) => {
                          e.preventDefault()
                          e.dataTransfer.dropEffect = 'move'
                          // Live reflow — reorder as the dragged row passes over others,
                          // matching how modern apps visibly move rows before drop.
                          if (draggedTrack && draggedTrack.group === key && draggedTrack.index !== track.index) {
                            reorderTracks(key, draggedTrack.index, track.index)
                            setDraggedTrack({ group: key, index: draggedTrack.index })
                          }
                        }}
                        onDropRow={() => setDraggedTrack(null)}
                      />
                    )
                  })}
                </div>
              )
            })}
          </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Track row — three-line layout: name (top, full width) / track# + controls (mid) / ch+prog (bottom)
function TrackRow({
  track, dimmed, onMute, onSolo, onVisible, onKeyboard, onSoloForEdit, isSoloedForEdit,
  isDragging, isHandleHovered, onHandleHover, onDragStart, onDragEnd, onDragOverRow, onDropRow,
}: {
  track: TrackState; dimmed: boolean
  onMute: () => void; onSolo: () => void; onVisible: () => void; onKeyboard: () => void
  onSoloForEdit?: () => void; isSoloedForEdit?: boolean
  isDragging?: boolean; isHandleHovered?: boolean; onHandleHover?: (hovered: boolean) => void
  onDragStart?: () => void; onDragEnd?: () => void
  onDragOverRow?: (e: React.DragEvent) => void; onDropRow?: () => void
}) {
  // Friendly channel/program label
  const ch = (track as any).channel != null ? (track as any).channel + 1 : track.index + 1
  const prog = track.isDrum ? 'drums' : `prog ${track.program + 1}`
  const noteCount = useStore(s => (s.midi as any)?.tracks?.find((t: any) => t.index === track.index)?.notes?.length ?? 0)

  // ── Color-line VU meter — Settings-gated (Playback & Practice). Same
  // velocity-scan + decay mechanism as the Console Mixer's ChannelStrip VU
  // meter, but drives a CSS transform (not canvas/height) so N simultaneous
  // track rows never trigger layout reflow, just compositor work. The
  // bottom PILL_FLOOR fraction stays solid at full track color always —
  // the guaranteed color identifier the Mixer's own meter doesn't need,
  // since here it's the only thing telling tracks apart without opening it. ──
  const trackVuColorEnabled = useStore(s => s.trackVuColorEnabled)
  const vuFillRef = useRef<HTMLDivElement>(null)
  const vuLevel   = useRef(0)
  useEffect(() => {
    if (!trackVuColorEnabled) return
    const unsub = useStore.subscribe(state => {
      const { currentTime, playbackState, midi: md, tracks: tks } = state
      if (playbackState !== 'playing' || !md) return
      const tr = tks.find(t => t.index === track.index)
      if (!tr || tr.muted) return
      const pt = (md as any).tracks?.find((t: any) => t.index === track.index)
      if (!pt) return
      let maxVel = 0
      for (const note of pt.notes) {
        // Notes are sorted by time — skip once past current window
        if (note.time > currentTime + 0.02) break
        if (currentTime < note.time + note.duration && note.velocity > maxVel) maxVel = note.velocity
      }
      if (maxVel > 0) vuLevel.current = maxVel * tr.volume
    })
    let raf = 0
    const loop = () => {
      vuLevel.current = Math.max(0, vuLevel.current - 0.013)
      if (vuFillRef.current) vuFillRef.current.style.transform = `scaleY(${Math.min(1, vuLevel.current)})`
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    return () => { unsub(); cancelAnimationFrame(raf) }
  }, [trackVuColorEnabled, track.index])

  return (
    <div
      onClick={onSoloForEdit}
      onDragOver={onDragOverRow}
      onDrop={onDropRow}
      style={{
        padding: '6px 10px 5px 8px',
        borderBottom: '1px solid var(--border-row)',
        opacity: isDragging ? 0.4 : dimmed ? 0.45 : 1,
        transition: 'opacity 0.15s, background 0.1s',
        cursor: onSoloForEdit ? 'pointer' : 'default',
        background: isSoloedForEdit ? 'var(--accent-amber-selected-bg)' : 'transparent',
        borderLeft: isSoloedForEdit ? '2px solid var(--text-amber)' : '2px solid transparent',
      }}
      onMouseEnter={e => { if (onSoloForEdit && !isSoloedForEdit) (e.currentTarget as HTMLElement).style.background = 'var(--state-row-hover-overlay)' }}
      onMouseLeave={e => { if (onSoloForEdit && !isSoloedForEdit) (e.currentTarget as HTMLElement).style.background = 'transparent' }}
    >
      {/* ── Row 1: drag handle + color bar + instrument name ──────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <div
          draggable
          onDragStart={e => {
            e.stopPropagation()
            // Reorder is driven entirely by React state (draggedTrack), not
            // dataTransfer — but leaving dataTransfer completely untouched
            // made the OS/Chromium drag cursor default to the "not allowed"
            // no-drop badge for the whole drag, even over valid drop
            // targets with dropEffect='move' set. Declaring a real payload
            // + effectAllowed here is what actually lets the browser show
            // a plain "move" cursor instead.
            e.dataTransfer.effectAllowed = 'move'
            e.dataTransfer.setData('text/plain', '')
            onDragStart?.()
          }}
          onDragEnd={() => onDragEnd?.()}
          onMouseEnter={() => onHandleHover?.(true)}
          onMouseLeave={() => onHandleHover?.(false)}
          onClick={e => e.stopPropagation()}
          style={{
            width: 11, display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, cursor: isHandleHovered ? 'grab' : 'default',
            color: isHandleHovered ? 'var(--text-inactive)' : 'transparent',
          }}
        >
          <GripVertical size={11} />
        </div>
        {trackVuColorEnabled ? (
          <div style={{
            width: 3, height: 20, borderRadius: 2, flexShrink: 0,
            opacity: dimmed ? 0.6 : 1, position: 'relative', overflow: 'hidden',
          }}>
            {/* Dim tint — fills the whole pill so it always reads as this track's color ── */}
            <div style={{ position: 'absolute', inset: 0, background: track.color, opacity: 0.18 }} />
            {/* Floor — bottom 25%, full color, always on regardless of playback state ── */}
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: '25%', background: track.color }} />
            {/* VU fill — grows upward from the floor with playback level (transform, not height) ── */}
            <div ref={vuFillRef} style={{
              position: 'absolute', left: 0, right: 0, bottom: '25%', height: '75%',
              background: track.color, transform: 'scaleY(0)', transformOrigin: 'bottom',
            }} />
          </div>
        ) : (
          <div style={{ width: 3, height: 20, background: track.color, borderRadius: 2, flexShrink: 0, opacity: dimmed ? 0.6 : 1 }} />
        )}
        <MarqueeText name={track.trackName ?? track.gmName} spanStyle={{ fontSize: 'var(--text-sm)', fontWeight: 500, color: 'var(--text-muted)' }} />
      </div>

      {/* ── Row 2: track number (left) + M/S/V/K controls (right) ─────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 3, paddingLeft: 26 }}>
        <span style={{ fontSize: 10, color: 'var(--text-inactive)', fontFamily: 'var(--font-mono)' }}>{t`track`} {track.index + 1}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-1)' }}>
          <IBtn onClick={onMute} active={track.muted}
            title={track.muted ? t`Unmute` : t`Mute`}
            description={track.muted ? t`Unmute audio` : t`Mute audio`}
            activeColor="var(--status-error)">
            <span style={{ fontSize: 'var(--text-xs)', fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1 }}>M</span>
          </IBtn>
          <IBtn onClick={onSolo} active={track.solo}
            title={track.solo ? t`Unsolo` : t`Solo`}
            description={track.solo ? t`Unsolo track` : t`Solo track`}
            activeColor="var(--text-amber)">
            <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-mono)', lineHeight: 1 }}>S</span>
          </IBtn>
          <IBtn onClick={onVisible} active={!track.visible}
            title={track.visible ? t`Hide in roll` : t`Show in roll`}
            description={track.visible ? t`Hide notes on the Piano Roll` : t`Show notes on the Piano Roll`}
            activeColor="var(--status-error-hover)" inactiveColor="var(--status-success-text)">
            {track.visible ? <Eye size={12} /> : <EyeClosed size={12} />}
          </IBtn>
          <IBtn onClick={onKeyboard} active={track.showOnKeyboard}
            title={track.showOnKeyboard ? t`Lit on keyboard` : t`Not lit on keyboard`}
            description={track.showOnKeyboard ? t`Notes light up on keyboard` : t`Notes are not lit on keyboard`}
            activeColor="var(--text-amber)">
            <PianoKeysIcon width={13} height={9} />
          </IBtn>
        </div>
      </div>

      {/* ── Row 3: MIDI channel + program + note count ────────────────────── */}
      <div style={{ display: 'flex', gap: 6, marginTop: 2, paddingLeft: 26 }}>
        <span style={{ fontSize: 10, lineHeight: '11px', color: 'var(--text-track-meta)', fontFamily: 'var(--font-mono)' }}>{t`ch`} {ch}</span>
        <span style={{ fontSize: 10, lineHeight: '11px', color: 'var(--text-track-meta)', fontFamily: 'var(--font-mono)' }}>·</span>
        <span style={{ fontSize: 10, lineHeight: '11px', color: 'var(--text-track-meta)', fontFamily: 'var(--font-mono)' }}>{prog}</span>
        <span style={{ fontSize: 10, lineHeight: '11px', color: 'var(--text-track-meta)', fontFamily: 'var(--font-mono)' }}>·</span>
        <span style={{ fontSize: 10, lineHeight: '11px', color: 'var(--text-track-meta)', fontFamily: 'var(--font-mono)' }}>{noteCount} {t`notes`}</span>
      </div>
    </div>
  )
}

// ── IBtn — icon button for track controls: color driven by active state ───
function IBtn({ children, onClick, active, title, description, activeColor = 'var(--text-amber)', inactiveColor = 'var(--text-icon-inactive)' }: {
  children: React.ReactNode; onClick: () => void
  active?: boolean; title?: string; description?: string; activeColor?: string; inactiveColor?: string
}) {
  const button = (
    <button
      onClick={e => { e.stopPropagation(); onClick() }}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        width: 22, height: 22, background: 'none', border: 'none', cursor: 'pointer',
        color: active ? activeColor : inactiveColor,
        borderRadius: 4, transition: 'color 0.1s',
      }}
      onMouseEnter={e => { if (!active) e.currentTarget.style.color = 'var(--text-icon-hover)' }}
      onMouseLeave={e => { e.currentTarget.style.color = active ? activeColor : inactiveColor }}
    >
      {children}
    </button>
  )
  // oneLine tooltips take a single string — description is the more useful
  // half (what clicking actually does), title alone is just the button's
  // own state name (e.g. "Mute"), so it's the fallback, not the default.
  return title ? <Tooltip title={description ?? title} oneLine muted>{button}</Tooltip> : button
}
