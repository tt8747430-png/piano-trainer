import { useCallback, useRef, useEffect, useState } from 'react'
import {
  Play, Pause, SkipBack, SkipForward, Repeat,
  FolderOpen, RotateCcw, ChevronUp, ChevronDown,
  Rewind, FastForward,
} from 'lucide-react'
import { useStore } from '../../store'
import { usePlayback } from '../../hooks/usePlayback'
import { usePractice } from '../../practice/practice'
import { useMidiFile } from '../../hooks/useMidiFile'
import { formatTime } from '../../utils/midiParser'
import { formatKey, transposeDetectedKey } from '../../utils/keyDetection'
import { buildDebugTimestamp, buildFullSongTable, formatTimeMs } from '../../utils/debugTimestamp'
import OrfeoLogo from '../OrfeoLogo'
import MidiIcon from '../MidiIcon'
import VolumeKnob from '../VolumeKnob'
import LoopRegionStrip from '../LoopRegionStrip'
import Tooltip from '../Tooltip'
import { TapTempoPad } from './TapTempoPad'
import { TempoWarning } from './TempoWarning'
import { useCurrentTempoTrust } from '../../hooks/useTempoTrustScan'
import { stepDisplayedBpm } from '../../utils/bpmStep'
import { isCountingIn, cancelCountIn } from '../../utils/countInRunner'
import { ContextMenu, ContextMenuItem, ContextMenuDivider, useMenuDismiss } from '../ContextMenu'
import { t } from '../../utils/i18n'
import { useMidiSettings } from '../../store/midiSettings'
import { shortName } from '../../utils/midiDeviceNames'
import { confirmDiscardDirtyNoteEdits } from '../../utils/noteEditorState'
import { confirmDiscardDirtyTempoKey } from '../../utils/tempoKeySave'

// NOTE: no more `C` shorthand object — every color below is a literal
// `var(--token-name)` string written directly at its point of use, so the
// token being referenced is visible right here in the JSX without having to
// cross-reference a lookup table elsewhere in the file.
const SKIP_SECS = 5

// ── Windows caption-button overlay inset — the real reserved width for the
// native –/□/× buttons, read live from the Window Controls Overlay API
// (Electron's titleBarOverlay in electron/main.ts turns this on) instead of
// a fixed guess. If the group's right padding equals this exactly, its
// content's right edge lands precisely where the buttons start — zero
// horizontal overlap into their hit-region, regardless of vertical position,
// so the group can stay vertically centered like its siblings instead of
// needing to duck below the buttons' 40px zone. DPI/monitor changes fire
// `geometrychange`, so this tracks the real safe zone live. Falls back to a
// conservative constant if the API isn't present yet (first paint, or a
// non-Windows build).
const OVERLAY_INSET_FALLBACK = 174

function useTitlebarOverlayInset(): number {
  const [inset, setInset] = useState(OVERLAY_INSET_FALLBACK)

  useEffect(() => {
    const overlay = (navigator as any).windowControlsOverlay
    if (!overlay) return

    const update = () => {
      const rect = overlay.getTitlebarAreaRect()
      if (rect.width > 0) setInset(Math.round(window.innerWidth - rect.width - rect.x))
    }
    update()
    overlay.addEventListener('geometrychange', update)
    return () => overlay.removeEventListener('geometrychange', update)
  }, [])

  return inset
}

export default function TopBar() {
  useCurrentTempoTrust()
  const overlayInset = useTitlebarOverlayInset()
  const midi = useStore((s) => s.midi)
  const playbackState = useStore((s) => s.playbackState)
  const currentTime = useStore((s) => s.currentTime)
  const showPreciseScrubTime = useStore((s) => s.showPreciseScrubTime)
  const bpm = useStore((s) => s.bpm)
  const originalBpm = useStore((s) => s.originalBpm)
  const loopRegionEnabled  = useStore((s) => s.loopRegionEnabled)
  const loopRegionActive   = useStore((s) => s.loopRegionActive)
  const loopStart          = useStore((s) => s.loopStart)
  const loopEnd            = useStore((s) => s.loopEnd)
  const setLoopRegionActive = useStore((s) => s.setLoopRegionActive)
  const setBpm = useStore((s) => s.setBpm)
  const resetBpm = useStore((s) => s.resetBpm)
  const detectedKey = useStore((s) => s.detectedKey)
  const metronomeEnabled = useStore((s) => s.metronomeEnabled)
  const setMetronomeEnabled = useStore((s) => s.setMetronomeEnabled)
  const [metroMenu, setMetroMenu] = useState<{ x: number; y: number } | null>(null)
  const countInEnabled = useStore((s) => s.countInEnabled)
  const countInBars = useStore((s) => s.countInBars)
  const closeMetroMenu = useCallback(() => setMetroMenu(null), [])
  const midiDeviceConnected = useStore((s) => s.midiDeviceConnected)
  const midiDeviceName = useStore((s) => s.midiDeviceName)
  // Model of the keyboard being played, plus any others that are plugged in
  const midiActiveKey = useMidiSettings((s) => s.activeDevice)
  const midiOthers = useMidiSettings((s) => s.devices.filter(d => d.connected && d.key !== s.activeDevice).map(d => d.name).join(', '))
  const noteNaming = useStore((s) => s.noteNaming)
  const accidentals = useStore((s) => s.accidentals)
  const chordExplorerOpen = useStore((s) => s.chordExplorerOpen)
  const explorerPausesPlayback = useStore((s) => s.explorerPausesPlayback)
  const resetAll = useStore((s) => s.resetAll)
  const barStarts = useStore((s) => s.barStarts)
  const chordSequence = useStore((s) => s.chordSequence)


  const { play, pause, stop, seek, seekAndPlay } = usePlayback()
  const practiceRunning = usePractice((s) => s.running)
  const { openFile } = useMidiFile()
  const wasPlayingRef = useRef(false)

  const handlePlayPause = useCallback(() => {
    if (isCountingIn()) { cancelCountIn(); return }
    if (playbackState === 'playing' || usePractice.getState().running) pause(); else play()
  }, [playbackState, play, pause])

  const handleReset = useCallback(async () => {
    const proceed = await confirmDiscardDirtyNoteEdits('Save changes before resetting?')
    if (!proceed) return
    const proceedTempoKey = await confirmDiscardDirtyTempoKey('Save tempo/key changes before resetting?')
    if (proceedTempoKey) resetAll()
  }, [resetAll])

  const handleScrubStart = useCallback(() => {
    wasPlayingRef.current = playbackState === 'playing'
    if (wasPlayingRef.current) pause()
  }, [playbackState, pause])

  const handleScrubChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    useStore.setState({ currentTime: parseFloat(e.target.value) })
  }, [])

  const handleScrubEnd = useCallback((e: React.MouseEvent<HTMLInputElement>) => {
    const t = parseFloat(e.currentTarget.value)
    if (wasPlayingRef.current) seekAndPlay(t); else seek(t)
  }, [seek, seekAndPlay])

  // ── Right-click the scrub bar → "Copy timestamp" for chord-detection bug
  // reports. Ships in every build, including packaged ones — the user tests
  // remotely (build/install, not `npm run dev`) and needs this there too.
  // Deliberately undocumented (not in HOW_TO_USE.md): a debugging tool, not
  // a feature. ────────────────────────────────────────────────────────────
  const [scrubMenu, setScrubMenu] = useState<{ x: number; y: number } | null>(null)
  const handleScrubContextMenu = useCallback((e: React.MouseEvent) => {
    if (!midi) return
    e.preventDefault()
    setScrubMenu({ x: e.clientX, y: e.clientY })
  }, [midi])
  const scrubMenuIsRange = loopStart !== null && loopEnd !== null && loopEnd > loopStart

  const handleSkip = useCallback((dir: 1 | -1) => {
    if (!midi) return
    const t = Math.max(0, Math.min(midi.duration, currentTime + dir * SKIP_SECS))
    if (playbackState === 'playing') seekAndPlay(t); else seek(t)
  }, [midi, currentTime, playbackState, seek, seekAndPlay])

  const handleTranspose = (semitones: number) => {
    if (!detectedKey) return
    useStore.setState({ detectedKey: transposeDetectedKey(detectedKey, semitones) })
  }

  const transpose = detectedKey?.transpose ?? 0
  const duration = midi?.duration ?? 0
  const isTempoChanged = !!midi && bpm !== originalBpm
  const displayKey = detectedKey ? formatKey(detectedKey, noteNaming, accidentals) : '—'

  // ── Nudge: region selected but loop not yet activated (regardless of strip visibility) ──
  const nudgeLoop = !!midi && loopStart !== null && loopEnd !== null && !loopRegionActive

  // ── Loop button tooltip — context-aware based on region state ─────────────
  const loopStartBar = loopStart !== null ? (() => {
    let bar = 1
    for (let i = 0; i < barStarts.length; i++) { if (barStarts[i] <= loopStart) bar = i + 1 }
    return bar
  })() : null
  const loopEndBar = (loopEnd !== null && loopStartBar !== null) ? (() => {
    let rawBar = 1
    for (let i = 0; i < barStarts.length; i++) { if (barStarts[i] <= loopEnd) rawBar = i + 1 }
    const pastLastBarStart = barStarts.length === 0 || loopEnd > barStarts[barStarts.length - 1] + 0.001
    return Math.max(loopStartBar, pastLastBarStart ? rawBar : rawBar - 1)
  })() : null
  const loopTooltipTitle = loopStart !== null
    ? (loopRegionActive ? `Looping bars ${loopStartBar}–${loopEndBar}` : `Loop bars ${loopStartBar}–${loopEndBar}`)
    : 'Loop song or section'
  const loopTooltipDesc = loopStart !== null
    ? (loopRegionActive ? 'Click to disable looping.' : 'Click to enable looping.')
    : 'Click to loop the entire song, or Alt+Click & drag mouse on the piano roll to select a specific region.'

  // ── Live BPM — reads current tempo from _tempoMap so rubato files update ─
  const rawTempoMap = (midi as any)?._tempoMap as { bpm: number; time: number }[] | undefined
  const currentFileBpm = rawTempoMap?.length
    ? rawTempoMap.reduce(
        (acc: number, e: { bpm: number; time: number }) => e.time <= currentTime ? e.bpm : acc,
        rawTempoMap[0].bpm,
      )
    : bpm
  const userRatio = originalBpm > 0 ? bpm / originalBpm : 1
  const liveBpm = midi ? Math.round(currentFileBpm * userRatio) : 0

  // ── Live time signature — reads current signature from _timeSigMap so
  // songs that change bar length mid-way (e.g. 3/4 → 4/4) update too ──────
  const rawTimeSigMap = (midi as any)?._timeSigMap as { num: number; den: number; time: number }[] | undefined
  const currentTimeSig = rawTimeSigMap?.length
    ? rawTimeSigMap.reduce(
        (acc: { num: number; den: number }, e: { num: number; den: number; time: number }) => e.time <= currentTime ? e : acc,
        rawTimeSigMap[0],
      )
    : { num: midi?.timeSignatureNumerator ?? 4, den: midi?.timeSignatureDenominator ?? 4 }

  // ── Bar counter — uses same precomputed barStarts as PianoRoll ───────────
  const totalBars = barStarts.length
  // Binary search: find last index where barStarts[i] <= currentTime (= current bar index, 0-based)
  let currentBar = 0
  if (midi && barStarts.length > 0) {
    let lo = 0, hi = barStarts.length - 1
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1
      if (barStarts[mid] <= currentTime) lo = mid
      else hi = mid - 1
    }
    currentBar = lo + 1
  }

  return (
    <div
      className="app-drag-region"
      style={{
        // ── Height = the extra room this redesign needed: 20px clearance
        // above the tallest group's own content (center: filename +
        // transport + scrub, ~87.5px measured) + 20px clearance below it,
        // before the piano roll. Grown by the same 24px the loop-region
        // strip adds when present, same as before. ───────────────────────
        height: loopRegionEnabled ? 152 : 128,
        background: 'var(--bg-deep)',
        borderBottom: 'none',
        // ── CSS Grid, three real minmax(0,1fr) columns (not 1fr auto 1fr —
        // see CLAUDE.md's warning: an auto-sized center column combined with
        // content-driven side columns can still end up unequal width and
        // drag the center off true center). The center column is then
        // structurally centered by grid layout itself, not computed via
        // position:absolute + left:50%/transform math — that math measured
        // against the bar's full (asymmetrically-padded) width, which is
        // exactly what let the ~400px-wide center block overlap the side
        // groups near the 900px documented minimum window width. ──────────
        display: 'grid',
        gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr) minmax(0,1fr)',
        // ── Back to center — left (~39px) and right (~40px) vertically
        // center in the row like they always did. Only the center column
        // opts out (see its own `alignSelf:'flex-start'` below): its content
        // is much taller (~87.5px, it carries the transport row), and
        // center-aligning it put its own top just 4px from the row's edge.
        // Giving center its own top anchor + top margin — instead of
        // top-aligning the whole grid — keeps center's breathing room
        // without pulling left/right out of their normal centered spot. ──
        alignItems: 'center',
        // Symmetric 20px both sides, 0 top/bottom — the button dodge lives
        // on the right group's own box (see its comment below), not here,
        // and left/right's own vertical centering needs the grid's full,
        // unpadded height to center against (an asymmetric top-only pad
        // would skew their center off the row's true middle). Center's own
        // top clearance comes from its own margin instead (see below).
        padding: '0 20px',
        gap: 0,
        flexShrink: 0,
      }}
    >
      {/* ── LEFT GROUP: logo + BPM + KEY — independent of center, never shifts transport.
          Measured intrinsic width (~423px) exceeds this column's 1/3 share at the
          900px documented minimum (~235px content-box thirds) — stretched to the
          column and given the same internal-horizontal-scroll behavior as the
          Mixer's channel-strip row rather than letting it spill into the center
          column, so nothing is hidden/removed, just reachable via scroll at the
          floor width. `.topbar-scroll` (not `.mixer-scroll` — see index.css)
          keeps that scrolling but hides the scrollbar itself: app zoom shrinks
          the logical viewport the same way a narrow window does, so this can
          trigger at an ordinary window size and zoom level, where a persistent
          grey bar for a few px of overflow reads as a glitch, not the Mixer
          row's genuine many-tracks affordance. No effect at normal window
          widths/zoom, where the column is wide enough that no overflow occurs
          at all. ── */}
      <div className="topbar-scroll" style={{
        display: 'flex', alignItems: 'center', gap: 0, flexShrink: 0,
        justifySelf: 'stretch', minWidth: 0, overflowX: 'auto', overflowY: 'hidden',
        // room below the row for the tempo-warning dot under the TAP pad —
        // added inside and taken back outside, so nothing moves
        paddingBottom: 14, marginBottom: -14,
      }}>
      {/* ── LOGO ── */}
      <div className="app-no-drag" style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0, paddingRight: 'var(--space-3)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 1 }}>
          <Tooltip title={t`Reset`} description={t`Closes the file and resets tempo,
transpose, and playback to defaults.`} placement="bottom">
            <span onClick={handleReset} className="app-no-drag" style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 2 }}>
              <OrfeoLogo />
              <span style={{ color: 'var(--text-inactive)', fontSize: 10, fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap' }}>v{__APP_VERSION__}</span>
            </span>
          </Tooltip>
        </div>
        <Tooltip title={t`Open a file (Ctrl+O)`} description={t`Loads a supported file from
disk to start a new session.`} placement="bottom">
          <button
            onClick={openFile}
            className="app-no-drag"
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 'var(--button-height)', height: 'var(--button-height)', borderRadius: 'var(--radius-md)', background: 'transparent', border: 'none', color: 'var(--text-default)', cursor: 'pointer', flexShrink: 0, transition: 'color 0.12s' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--text-amber)'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-default)'}
          >
            <FolderOpen size={16} strokeWidth={1.5} />
          </button>
        </Tooltip>
      </div>

      <VSep />

      {/* ── BPM ── (tighter gap/padding than the other groups: with the TAP pad
          the left column must still fit at a 1366 px window) */}
      <div className="app-no-drag" style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0 var(--space-2)', flexShrink: 0 }}>
        <Tooltip title={`Tempo: ${liveBpm || '—'} BPM`} description={t`The song's current playback tempo,
scaled by your speed setting.`} placement="bottom">
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 1 }}>
              <span style={{ color: 'var(--text-muted)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>{t`BPM`}</span>
              <span style={{ color: 'var(--text-muted)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>{t`TEMPO`}</span>
            </div>
            <span style={{ color: isTempoChanged ? 'var(--text-amber)' : 'var(--text-active)', fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, minWidth: 36, textAlign: 'right', lineHeight: 1 }}>
              {midi ? liveBpm : '—'}
            </span>
          </div>
        </Tooltip>
        {/* ±1 steps the DISPLAYED tempo (file tempo at the playhead, incl. any
            tap-tempo correction), not the file's first tempo — see liveBpm. */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          <LongPressArrow onStep={() => { const s = useStore.getState(); setBpm(stepDisplayedBpm(s.bpm, s.originalBpm, currentFileBpm, 1)) }} disabled={!midi} title={t`BPM +1`} description={t`Nudges playback tempo up
by one beat per minute.`}><ChevronUp size={10} /></LongPressArrow>
          <LongPressArrow onStep={() => { const s = useStore.getState(); setBpm(stepDisplayedBpm(s.bpm, s.originalBpm, currentFileBpm, -1)) }} disabled={!midi} title={t`BPM -1`} description={t`Nudges playback tempo down
by one beat per minute.`}><ChevronDown size={10} /></LongPressArrow>
        </div>
        {/* ── Reset — space always reserved so its appearance never shifts the transport controls ── */}
        {/* wrapperStyle carries the same visibility as the button itself — the
            button's own visibility:hidden alone no longer excludes this area
            from hit-testing once it's nested inside Tooltip's wrapper div,
            which would otherwise still show the tooltip over reserved-but-
            hidden blank space. */}
        <Tooltip title={t`Reset tempo`} description={t`Restores the original BPM`} placement="bottom"
          wrapperStyle={{ visibility: isTempoChanged ? 'visible' : 'hidden', flexShrink: 0 }}
        >
          <button
            onClick={resetBpm}
            disabled={!isTempoChanged}
            style={{
              background: 'none', border: 'none', padding: 0, color: 'var(--text-amber)', display: 'flex',
              cursor: isTempoChanged ? 'pointer' : 'default',
            }}
          >
            <RotateCcw size={9} />
          </button>
        </Tooltip>
        <TapTempoPad />
      </div>

      <VSep />

      {/* ── KEY ── (position: relative anchors the tempo-warning badge, which
          takes no width of its own — this group has no spare room at 1366 px) */}
      <div className="app-no-drag" style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 6, padding: '0 var(--space-2)', flexShrink: 0 }}>
        <Tooltip
          title={t`Key: `}
          titleValue={`${displayKey}${transpose !== 0 ? ` (${transpose > 0 ? '+' : ''}${transpose} semitones)` : ''}`}
          description={t`The song's detected key, adjusted
by any transpose applied here.`}
          placement="bottom"
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 1 }}>
              <span style={{ color: 'var(--text-muted)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>{t`KEY`}</span>
              <span style={{ color: 'var(--text-muted)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>{t`TRANSPOSE`}</span>
            </div>
            <span style={{ color: transpose !== 0 ? 'var(--text-amber)' : 'var(--text-active)', fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, minWidth: 32, textAlign: 'right', lineHeight: 1 }}>
              {displayKey}
            </span>
          </div>
        </Tooltip>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          <ArrowBtn onClick={() => handleTranspose(1)} disabled={!midi || transpose >= 12} title={t`Transpose up`} description={t`Shifts the detected key up
by a semitone (max +12).`}><ChevronUp size={10} /></ArrowBtn>
          <ArrowBtn onClick={() => handleTranspose(-1)} disabled={!midi || transpose <= -12} title={t`Transpose down`} description={t`Shifts the detected key down
by a semitone (max −12).`}><ChevronDown size={10} /></ArrowBtn>
        </div>
        {/* ── Reset — space always reserved so its appearance never shifts the transport controls ── */}
        <Tooltip title={t`Reset key`} description={t`Restores the original key`} placement="bottom"
          wrapperStyle={{ visibility: transpose !== 0 ? 'visible' : 'hidden', flexShrink: 0 }}
        >
          <button
            onClick={() => useStore.setState({ detectedKey: detectedKey ? { ...detectedKey, transpose: 0 } : null })}
            disabled={transpose === 0}
            style={{
              display: 'flex', alignItems: 'center', color: 'var(--text-amber)',
              background: 'var(--accent-amber-subtle)', border: '1px solid var(--accent-amber-medium)',
              borderRadius: 4, padding: '1px 5px', fontSize: 9,
              cursor: transpose !== 0 ? 'pointer' : 'default',
            }}>
            <RotateCcw size={8} />
          </button>
        </Tooltip>
        <TempoWarning anchor="key" />
      </div>

      </div>

      {/* ── CENTER: transport + scrub + filename — its own grid column, so it's
          genuinely centered between the other two regardless of their content
          width; stretches to fill the (equal, minmax(0,1fr)) column instead of
          a fixed 400px box, so at the 900px floor it shrinks with the column
          rather than overflowing into the side groups. alignSelf:'flex-start'
          + its own marginTop opts this column out of the grid's
          alignItems:'center' (which left/right use) — center's content is
          tall enough (~87.5px) that center-aligning it left almost no gap
          above the transport row; anchoring it to the top with an explicit
          20px margin instead gives it the same breathing room without
          moving left/right off their normal centered spot. ── */}
      <div className="app-no-drag" style={{
        justifySelf: 'stretch', minWidth: 0, alignSelf: 'flex-start', marginTop: 20,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
      }}>
        {/* Filename — moved above the transport row so the center column's
            topmost line is comparably light (small text) to the left/right
            groups' top lines, now that all three groups share the same
            top-aligned start (see the grid's alignItems comment above). */}
        {midi?.fileName ? (
          <span style={{ color: 'var(--text-default)', fontSize: 'var(--text-sm)', fontFamily: 'var(--font-ui)', lineHeight: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 340 }}>
            {midi.fileName.replace(/\.(mid|midi)$/i, '')}
          </span>
        ) : (
          <span style={{ color: 'var(--text-default)', fontSize: 'var(--text-sm)', fontFamily: 'var(--font-ui)', lineHeight: '13px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 340 }}>
            {t`No file open`}
          </span>
        )}
        {/* Transport */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <TBtn onClick={stop} disabled={!midi} title={t`Go to start`} oneLine><SkipBack size={16} strokeWidth={1.5} /></TBtn>
          <TBtn onClick={() => handleSkip(-1)} disabled={!midi} title={`Rewind ${SKIP_SECS}s`} oneLine><Rewind size={15} strokeWidth={1.5} /></TBtn>
          <TBtn onClick={handlePlayPause} disabled={!midi || (chordExplorerOpen && explorerPausesPlayback)} accent title={t`Play / Pause (Space)`} large oneLine>
            {playbackState === 'playing' || practiceRunning
              ? <Pause size={24} fill="currentColor" strokeWidth={0} />
              : <Play size={24} fill="currentColor" strokeWidth={0} />}
          </TBtn>
          <TBtn onClick={() => handleSkip(1)} disabled={!midi} title={`Forward ${SKIP_SECS}s`} oneLine><FastForward size={15} strokeWidth={1.5} /></TBtn>
          <TBtn onClick={() => midi && seek(midi.duration)} disabled={!midi} title={t`Go to end`} oneLine><SkipForward size={16} strokeWidth={1.5} /></TBtn>
          {/* position:relative wrapper so the "click to loop" label can be
              position:absolute — it used to sit in normal flex flow as the
              row's last child, so its appearing/disappearing changed the
              row's total width, which shifted every button's position
              (the row is horizontally centered as a block, so a width
              change moves its center point). Absolute positioning removes
              it from flow entirely — buttons never move regardless of
              whether the label is showing. ── */}
          <div style={{ position: 'relative', display: 'flex' }}>
            <TBtn
              onClick={() => {
                const newActive = !loopRegionActive
                setLoopRegionActive(newActive)
                // Jump to loop start when activating with a selection, without forcing playback
                if (newActive && loopStart !== null) seek(loopStart)
              }}
              disabled={!midi} active={loopRegionActive} blink={nudgeLoop} title={loopTooltipTitle} description={loopTooltipDesc}
            ><Repeat size={13} strokeWidth={1.5} /></TBtn>
            {nudgeLoop && (
              <span style={{
                position: 'absolute', left: '100%', top: '50%', transform: 'translateY(-50%)',
                marginLeft: 4,
                color: 'var(--text-amber)', fontSize: 9, fontFamily: 'var(--font-ui)',
                whiteSpace: 'nowrap', letterSpacing: '0.04em',
                opacity: 0.85, pointerEvents: 'none', userSelect: 'none',
              }}>
                {t`click to loop`}
              </span>
            )}
          </div>
        </div>
        {/* Scrub + loop strip — shared column; width: min(100%, 400px) centers both at
            the same visual width as the old scrub content (34+6+320+6+34 = 400px).
            position: relative lets LoopRegionStrip anchor its icon outside this column. */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5, width: 'min(100%, 400px)', position: 'relative' }}>
          {/* Scrub — onContextMenu is a no-op in packaged builds (see handleScrubContextMenu).
              Left readout switches to millisecond precision when "Show precise
              scrub time" is on in Settings — always on then (playing, paused, or
              mid-drag), not just while actively dragging. The visible text is
              ALWAYS position:absolute (in both modes, not just precise mode) —
              right-anchored to the same spot and vertically centered via
              top:50%/translateY(-50%) — so it never itself affects this box's
              size; an invisible spacer holding the coarse format's width is what
              actually sizes the box, in every mode. That's what keeps this row's
              height fixed regardless of mode (a real span here — sized by its own
              content only when in normal flow — was collapsing to ~0 height in
              precise mode, since its content had nothing left in flow, which
              shifted the whole scrub row up) and keeps the digits vertically
              centered on the slider like the duration readout on the right
              (which never had this problem — it's still a single plain span). */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }} onContextMenu={handleScrubContextMenu}>
            <span style={{ position: 'relative', display: 'inline-block', minWidth: 34, flexShrink: 0 }}>
              <span aria-hidden style={{ visibility: 'hidden', fontFamily: 'var(--font-mono)', fontSize: 10 }}>
                {formatTime(currentTime)}
              </span>
              <span style={{
                position: 'absolute', right: 0, top: '50%', transform: 'translateY(-50%)',
                whiteSpace: 'nowrap',
                color: showPreciseScrubTime ? 'var(--text-amber)' : 'var(--text-muted)',
                fontFamily: 'var(--font-mono)', fontSize: 10,
              }}>
                {showPreciseScrubTime ? formatTimeMs(currentTime) : formatTime(currentTime)}
              </span>
            </span>
            <Tooltip title={t`Scrub position`} description={t`Drag to jump to any point in the song.`} wrapperStyle={{ flex: 1, maxWidth: 320 }}>
              <input
                type="range" min={0} max={duration || 1} step={0.01} value={currentTime}
                onMouseDown={handleScrubStart} onChange={handleScrubChange} onMouseUp={handleScrubEnd}
                className="scrub-slider" style={{ flex: 1, maxWidth: 320 }} disabled={!midi}
              />
            </Tooltip>
            <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 10, minWidth: 34, flexShrink: 0 }}>
              {formatTime(duration)}
            </span>
          </div>
          {/* Loop Region Strip — visible only when enabled in Settings */}
          {loopRegionEnabled && <LoopRegionStrip />}
        </div>
      </div>

      {scrubMenu && (
        <ScrubDebugMenu
          x={scrubMenu.x}
          y={scrubMenu.y}
          isRange={scrubMenuIsRange}
          buildText={() => buildDebugTimestamp({
            currentTime, loopStart, loopEnd, barStarts, chordSequence,
          })}
          buildTableText={() => buildFullSongTable({ duration, barStarts, chordSequence })}
          onClose={() => setScrubMenu(null)}
        />
      )}

      {/* ── TIME + METRONOME + MIDI — bottoms aligned. Same overflow treatment as
          the left group above: intrinsic width (~291px, more with the bar
          counter once a file's loaded) exceeds this column's ~235px share at
          the 900px floor, so it scrolls internally rather than spilling into
          the center column. This group was previously right-anchored
          (justifySelf:'end', flush against the window's right padding) — a
          plain overflowX:'auto' would pack content flush *left* instead
          (LTR overflow only accumulates rightward), visibly relocating the
          whole group at every window width, and MIDI/volume controls that
          overflow leftward off a flex-end box aren't reachable by scrolling
          at all (scrollWidth==clientWidth in that configuration — verified
          via CDP at 900x608, the Volume knob was invisible and unscrollable).
          direction:'rtl' on the scroll container + direction:'ltr' on the
          inner row is the standard fix: default (unscrolled) view still
          shows the group's right-anchored end (unchanged from before at
          normal widths), and the overflow that used to spill into the
          center column is now reachable by scrolling left instead. ── */}
      <div className="app-no-drag topbar-scroll" style={{
        justifySelf: 'stretch', minWidth: 0, overflowX: 'auto', overflowY: 'hidden', direction: 'rtl',
        // ── Top-aligned like its siblings (inherits the grid's own
        // alignItems:'flex-start') — stays flush-right against the real Win
        // overlay button boundary via paddingRight (overlayInset is measured
        // from the window's true right edge; the grid container itself only
        // contributes a flat 20px here, so this makes up the rest), not by
        // ducking below the buttons' 40px zone. Content's right edge lands
        // exactly where the buttons start, so there's no horizontal overlap
        // into their hit-region at any vertical position.
        paddingRight: Math.max(overlayInset - 20, 0),
      }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 0, flexShrink: 0, direction: 'ltr', width: 'max-content' }}>

        {/* VOLUME */}
        <VolumeKnob />
        <div style={{ width: 1, height: 'var(--button-height)', background: 'var(--border)', alignSelf: 'flex-end', marginBottom: 12 }} />

        {/* BAR COUNTER — only when a file is loaded */}
        {midi && (
          <>
            <Tooltip title={`Bar ${currentBar} of ${totalBars}`} description={t`Position in the song,
counted in bars.`} placement="bottom">
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0 var(--space-3)' }}>
                <div style={{
                  background: 'var(--bg-tile)', borderRadius: 4, padding: '2px 6px',
                  display: 'flex', alignItems: 'baseline', gap: 0,
                }}>
                  <span style={{ color: 'var(--topbar-bar-number)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)', fontWeight: 700, lineHeight: 1, minWidth: '3ch', textAlign: 'right', display: 'inline-block' }}>
                    {currentBar}
                  </span>
                  <span style={{ color: 'var(--topbar-bar-total)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)', lineHeight: 1 }}>
                    |{totalBars}
                  </span>
                </div>
                <span style={{ color: 'var(--topbar-bar-label)', fontSize: 9, fontFamily: 'var(--font-ui)', textTransform: 'uppercase', letterSpacing: '0.1em', lineHeight: 1, marginTop: 6 }}>
                  {t`BAR`}
                </span>
              </div>
            </Tooltip>
            <div style={{ width: 1, height: 'var(--button-height)', background: 'var(--border)', alignSelf: 'flex-end', marginBottom: 12 }} />
          </>
        )}

        {/* TIME SIGNATURE */}
        <Tooltip
          title={midi ? `Time signature: ${currentTimeSig.num}/${currentTimeSig.den}` : t`No file loaded`}
          description={t`Number of beats in each bar,
and which note value counts as one beat.`}
          placement="bottom"
        >
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '0 14px' }}>
            {midi ? (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1 }}>
                <span style={{ color: 'var(--text-active)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-base)', fontWeight: 700 }}>
                  {currentTimeSig.num}
                </span>
                <div style={{ width: 14, height: 1, background: 'var(--topbar-timesig-divider)', margin: '2px 0' }} />
                <span style={{ color: 'var(--text-active)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-base)', fontWeight: 700 }}>
                  {currentTimeSig.den}
                </span>
              </div>
            ) : (
              <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, lineHeight: 1 }}>—</span>
            )}
            <span style={{ color: 'var(--text-muted)', fontSize: 9, fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.1em', lineHeight: 1, marginTop: 6 }}>{t`TIME`}</span>
          </div>
        </Tooltip>

        <div style={{ width: 1, height: 'var(--button-height)', background: 'var(--border)', alignSelf: 'flex-end', marginBottom: 12 }} />

        {/* METRONOME */}
        <Tooltip
          title={metronomeEnabled ? t`Metronome on` : t`Metronome off`}
          description={countInEnabled
            ? t`Click to toggle metronome ON/OFF. Right-click for volume and count-in.`
            : t`Click to turn it ON, right-click \nfor volume and count-in.`}
          placement="bottom"
          disabled={!!metroMenu}
        >
          <button
            onClick={() => setMetronomeEnabled(!metronomeEnabled)}
            onContextMenu={(e) => { e.preventDefault(); const r = e.currentTarget.getBoundingClientRect(); setMetroMenu({ x: Math.max(8, r.right - METRO_MENU_WIDTH), y: r.bottom + 6 }) }}
            style={{
              position: 'relative',
              flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center',
              padding: '0 14px', border: 'none', cursor: 'pointer',
              background: 'transparent', color: metronomeEnabled ? 'var(--topbar-metronome-on)' : 'var(--topbar-metronome-off)', transition: 'color 0.15s',
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 11.4V9.1" />
              <path d="m12 17 6.59-6.59" />
              <path d="m15.05 5.7-.218-.691a3 3 0 0 0-5.663 0L4.418 19.695A1 1 0 0 0 5.37 21h13.253a1 1 0 0 0 .951-1.31L18.45 16.2" />
              <circle cx="20" cy="9" r="2" />
            </svg>
            <span style={{ fontSize: 9, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', lineHeight: 1, marginTop: 6 }}>
              {metronomeEnabled ? t`ON` : t`OFF`}
            </span>
            {/* count-in badge: how many bars Play will count in */}
            {countInEnabled && (
              <span aria-label={t`Count-in ${countInBars} bars`} style={{
                // inside the button's box: the row clips anything above it
                position: 'absolute', top: 0, right: 6, minWidth: 12, height: 12, borderRadius: 6, padding: '0 3px',
                background: 'var(--text-amber)', color: 'var(--bg-tooltip)', fontSize: 8, fontWeight: 700,
                fontFamily: 'var(--font-mono)', lineHeight: '12px', textAlign: 'center',
              }}>{countInBars}</span>
            )}
          </button>
        </Tooltip>
        {metroMenu && <MetronomeMenu x={metroMenu.x} y={metroMenu.y} onClose={closeMetroMenu} />}

        <div style={{ width: 1, height: 'var(--button-height)', background: 'var(--border)', alignSelf: 'flex-end', marginBottom: 12 }} />

        {/* MIDI — the keyboard being played; click opens its settings */}
        <Tooltip
          title={midiDeviceConnected ? midiDeviceName : t`No connected keyboards`}
          description={midiDeviceConnected
            ? (midiOthers ? t`Also connected: ${midiOthers}` + '\n' + t`Click for MIDI keyboard settings.` : t`Ready to play. Click for MIDI keyboard settings.`)
            : t`Connect one by USB. Click to \nopen MIDI keyboard settings.`}
          placement="bottom"
          wrapperStyle={{ flexShrink: 0 }}
        >
          <button className="app-no-drag" onClick={() => useStore.getState().openSettingsWindow('midi')} aria-label={t`MIDI keyboard settings`}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', padding: '0 14px', background: 'none', border: 'none', cursor: 'pointer', color: midiDeviceConnected ? 'var(--topbar-midi-on)' : 'var(--topbar-midi-off)' }}>
            <MidiIcon size={24} color={midiDeviceConnected ? 'var(--topbar-midi-on)' : 'var(--topbar-midi-off)'} />
            <span style={{ fontSize: 9, fontFamily: 'var(--font-mono)', letterSpacing: midiDeviceConnected ? '0.08em' : '0.05em', color: midiDeviceConnected ? 'var(--topbar-midi-on)' : 'var(--topbar-midi-off)', lineHeight: 1, marginTop: 6, whiteSpace: 'nowrap' }}>
              {midiDeviceConnected ? shortName(midiActiveKey || midiDeviceName) : t`NO KEYBOARD`}
            </span>
          </button>
        </Tooltip>


      </div>
      </div>
    </div>
  )
}

const METRO_MENU_WIDTH = 150

// ── Metronome right-click — click volume (0–150%) and count-in (on/off +
// 1–4 bars), both remembered between sessions. ───────────────────────────
function MetronomeMenu({ x, y, onClose }: { x: number; y: number; onClose: () => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const volume = useStore((s) => s.metronomeVolume)
  const setVolume = useStore((s) => s.setMetronomeVolume)
  const countInEnabled = useStore((s) => s.countInEnabled)
  const setCountInEnabled = useStore((s) => s.setCountInEnabled)
  const countInBars = useStore((s) => s.countInBars)
  const setCountInBars = useStore((s) => s.setCountInBars)
  useMenuDismiss(true, ref, onClose)
  const head: React.CSSProperties = { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, fontSize: 9, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }
  const pill = (on: boolean): React.CSSProperties => ({
    flex: 1, padding: '2px 0', fontSize: 10, fontFamily: 'var(--font-mono)', cursor: 'pointer', borderRadius: 'var(--radius-sm)',
    background: on ? 'var(--accent-amber-subtle)' : 'none', color: on ? 'var(--text-amber)' : 'var(--text-default)',
    border: `1px solid ${on ? 'var(--accent-amber-strong)' : 'var(--border)'}`,
  })
  return (
    <ContextMenu ref={ref} x={x} y={y} minWidth={METRO_MENU_WIDTH} ariaLabel={t`Metronome options`} className="app-no-drag">
      <div style={{ width: METRO_MENU_WIDTH, boxSizing: 'border-box', padding: '4px 10px 6px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={head}>
          <span>{t`Volume`}</span>
          <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-amber)' }}>{Math.round(volume * 100)}%</span>
        </div>
        <input
          type="range" min={0} max={150} step={5} value={Math.round(volume * 100)}
          onChange={(e) => setVolume(Number(e.target.value) / 100)}
          aria-label={t`Metronome volume`}
          style={{ width: '100%', accentColor: 'var(--text-amber)' }}
        />
      </div>
      <ContextMenuItem onClick={() => setVolume(1)} disabled={volume === 1}>{t`Reset to 100%`}</ContextMenuItem>
      <ContextMenuDivider />
      <div style={{ width: METRO_MENU_WIDTH, boxSizing: 'border-box', padding: '4px 10px 8px', display: 'flex', flexDirection: 'column', gap: 6 }}>
        <div style={head}>
          <span>{t`Count-in`}</span>
          <button
            role="switch" aria-checked={countInEnabled} aria-label={t`Count-in`}
            onClick={() => setCountInEnabled(!countInEnabled)}
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontSize: 9, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', color: countInEnabled ? 'var(--text-amber)' : 'var(--text-muted)' }}
          >{countInEnabled ? t`ON` : t`OFF`}</button>
        </div>
        {countInEnabled && (
          <>
            <div style={{ display: 'flex', gap: 4 }}>
              {[1, 2, 3, 4].map(n => (
                <button key={n} onClick={() => setCountInBars(n)} aria-label={t`${n} bars`} style={pill(countInBars === n)}>{n}</button>
              ))}
            </div>
            <span style={{ fontSize: 9, color: 'var(--text-faint)', lineHeight: 1.3 }}>{t`Bars of clicks before Play`}</span>
          </>
        )}
      </div>
    </ContextMenu>
  )
}

function VSep() {
  return <div style={{ width: 1, height: 'var(--button-height)', background: 'var(--border)', flexShrink: 0 }} />
}

// ── Scrub-bar right-click menu (see handleScrubContextMenu). Copies a
// `time · bar · chord` string to the clipboard for chord-detection bug
// reports. Ships in packaged builds too (undocumented) — see the comment
// at handleScrubContextMenu.
//
// Uses execCommand('copy') on a throwaway textarea, NOT navigator.clipboard:
// the async Clipboard API rejects under Electron with "Document is not focused"
// after a context-menu interaction, so nothing lands on the OS clipboard.
// execCommand is deprecated but still the reliable path inside Electron's
// Chromium.
function writeClipboard(text: string): boolean {
  try {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.setAttribute('readonly', '')
    ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0'
    document.body.appendChild(ta)
    ta.focus({ preventScroll: true })
    ta.select()
    ta.setSelectionRange(0, text.length)
    const ok = document.execCommand('copy')
    ta.remove()
    return ok
  } catch {
    return false
  }
}

function ScrubDebugMenu({ x, y, isRange, buildText, buildTableText, onClose }: {
  x: number; y: number; isRange: boolean
  buildText: () => string; buildTableText: () => string
  onClose: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const onCloseRef = useRef(onClose)
  onCloseRef.current = onClose

  // Set up outside-click / Escape dismissal ONCE. onClose is reached through a
  // ref so a new onClose identity each parent render (TopBar re-renders every
  // frame during playback) doesn't tear down and rebuild the listeners.
  useEffect(() => {
    const close = () => onCloseRef.current()
    const onDown = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) close() }
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close() }
    const id = setTimeout(() => {
      window.addEventListener('mousedown', onDown, true)
      window.addEventListener('keydown', onKey, true)
    }, 0)
    return () => {
      clearTimeout(id)
      window.removeEventListener('mousedown', onDown, true)
      window.removeEventListener('keydown', onKey, true)
    }
  }, [])

  return (
    // app-no-drag: this menu is rendered inside TopBar's app-drag-region
    // (Electron -webkit-app-region: drag, for native window dragging).
    // Without the override, Electron's OS-level drag handling swallows the
    // mousedown/click before React's onClick ever fires — the menu item
    // looked clickable but silently did nothing. Passed as className (not a
    // wrapping div) since ContextMenu is position:fixed/out-of-flow; a
    // wrapping block div would re-enter TopBar's grid flow and disrupt its
    // column layout.
    <ContextMenu ref={ref} x={x} y={y} minWidth={220} ariaLabel="Debug timestamp" className="app-no-drag">
      <DebugCopyItem
        idleLabel={isRange ? 'Copy timestamp range' : 'Copy timestamp'}
        logTag="timestamp"
        buildText={buildText}
        onDone={() => onCloseRef.current()}
      />
      <DebugCopyItem
        idleLabel="Copy full chord table"
        logTag="chord table"
        buildText={buildTableText}
        onDone={() => onCloseRef.current()}
      />
    </ContextMenu>
  )
}

// One self-contained copy action inside the debug menu — owns its own
// idle/ok/fail label so copying the table doesn't clobber the point/range
// item's state (and vice versa) when both live in the same menu.
function DebugCopyItem({ idleLabel, logTag, buildText, onDone }: {
  idleLabel: string; logTag: string; buildText: () => string; onDone: () => void
}) {
  const [result, setResult] = useState<'idle' | 'ok' | 'fail'>('idle')

  const copy = () => {
    const text = buildText()
    const ok = writeClipboard(text)
    // Always echo to the console — a fallback copy source if the clipboard is
    // blocked, and a running log of what was reported.
    console.info(`[${logTag}] ${text}${ok ? '' : '  (clipboard write failed)'}`)
    setResult(ok ? 'ok' : 'fail')
    setTimeout(onDone, 900)
  }

  const label = result === 'ok' ? 'Copied ✓'
    : result === 'fail' ? 'Clipboard blocked — see console'
    : idleLabel

  return <ContextMenuItem onClick={copy}>{label}</ContextMenuItem>
}

// Long-press button: single click = +1, hold = accelerating repeat
function LongPressArrow({ children, onStep, disabled, title, description }: {
  children: React.ReactNode; onStep: () => void; disabled?: boolean; title?: string; description?: string
}) {
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const stepsRef = useRef(0)

  const stop = () => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null }
    if (timeoutRef.current) { clearTimeout(timeoutRef.current); timeoutRef.current = null }
    stepsRef.current = 0
  }

  const start = () => {
    if (disabled) return
    onStep()
    stepsRef.current = 0
    // After 400ms hold, start repeating
    timeoutRef.current = setTimeout(() => {
      intervalRef.current = setInterval(() => {
        onStep()
        stepsRef.current++
      // Accelerate: start at 120ms, ramp down to 40ms after 20 steps
      }, Math.max(40, 120 - stepsRef.current * 4))
    }, 400)
  }

  useEffect(() => () => stop(), [])

  const button = (
    <button
      disabled={disabled}
      onMouseDown={start}
      onMouseUp={stop}
      onMouseLeave={stop}
      style={{
        width: 16, height: 13, background: 'var(--bg-tile)',
        color: disabled ? 'var(--text-dim-control)' : 'var(--text-amber)',
        border: 'none', borderRadius: 'var(--radius-sm)',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.25 : 1,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        userSelect: 'none',
      }}
    >
      {children}
    </button>
  )
  return title ? <Tooltip title={title} description={description} placement="bottom">{button}</Tooltip> : button
}

function ArrowBtn({ children, onClick, disabled, title, description }: {
  children: React.ReactNode; onClick?: () => void; disabled?: boolean; title?: string; description?: string
}) {
  const button = (
    <button onClick={onClick} disabled={disabled}
      style={{
        width: 16, height: 13, background: 'var(--bg-tile)',
        color: disabled ? 'var(--text-dim-control)' : 'var(--text-amber)',
        border: 'none', borderRadius: 'var(--radius-sm)',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.25 : 1,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}
    >
      {children}
    </button>
  )
  return title ? <Tooltip title={title} description={description} placement="bottom">{button}</Tooltip> : button
}

function TBtn({ children, onClick, disabled, accent, active, blink, title, description, large, oneLine }: {
  children: React.ReactNode; onClick?: () => void; disabled?: boolean
  accent?: boolean; active?: boolean; blink?: boolean; title?: string; description?: string; large?: boolean; oneLine?: boolean
}) {
  const sz = large ? 46 : 32
  const isAmber = active || accent || blink
  const button = (
    <button onClick={onClick} disabled={disabled}
      className={blink ? 'loop-nudge-blink' : undefined}
      style={{
        width: sz, height: sz,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 6, border: 'none', background: 'transparent',
        color: isAmber ? 'var(--text-amber)' : 'var(--text-default)',
        opacity: disabled ? 0.2 : 1,
        cursor: disabled ? 'default' : 'pointer',
        transition: blink ? undefined : 'color 0.1s',
      }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.color = 'var(--text-amber)' }}
      onMouseLeave={e => { e.currentTarget.style.color = isAmber ? 'var(--text-amber)' : 'var(--text-default)' }}
    >
      {children}
    </button>
  )
  return title ? <Tooltip title={title} description={description} placement="bottom" oneLine={oneLine}>{button}</Tooltip> : button
}
