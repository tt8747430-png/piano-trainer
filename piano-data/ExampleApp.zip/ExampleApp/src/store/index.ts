import { create } from 'zustand'
import type {
  ParsedMidi, ParsedTrack, PlaybackState, TrackState,
  KeyboardSize, KeyboardMode, NoteNaming, Accidentals, ChordEvent, TranscriptEntry, LibraryFile, HitEffectPattern, SoundfontId,
  ChordNamingStyle, ChordTrackingMode, ChordFollowSubMode, ChordReadingMode, TapSession, SettingsGroupId,
} from '../types'
import type { DetectedKey } from '../utils/keyDetection'
import type { ForeignFormat } from '../utils/foreignFormatImport'
import type { ProgressionVoicing } from '../utils/voiceLeading'
import { detectKeyFromTracks, parseKeySignature } from '../utils/keyDetection'
import { isKeyboardInstrument } from '../utils/gmInstruments'
import { parseMidiBuffer } from '../utils/midiParser'
import { songKey as computeSongKey } from '../utils/songIdentity'
import { applyTempoCorrection, sanitizeCorrections, correctionToSong, correctionToFile, type SongTempoCorrection } from '../utils/tempoCorrection'
import { prepareSong } from '../utils/prepareSong'
import { TRUST_VERSION, type TrustResult } from '../utils/tempoTrust'
import { velocityDropRatio, suggestCompressorPreset } from '../utils/velocityAnalysis'
import { applyHandColors, isHex, handHex, followedHandColor, DEFAULT_HAND_LH, DEFAULT_HAND_RH } from '../utils/handPalette'
import { HAND_ASSIGN_GROUPS, focusRole } from '../utils/keyboardGroups'

// ── Focus mode: every track's mute + eye from just before Focus went on, so
// the second click puts back exactly what you had. Null while Focus is off.
let _focusSnapshot: Map<number, { muted: boolean; visible: boolean }> | null = null

// Only these groups light up the piano keyboard
const KEYBOARD_DISPLAY_GROUPS = new Set(['piano', 'chromatic', 'organ'])

interface OrfeoStore {
  midi: ParsedMidi | null
  setMidi: (midi: ParsedMidi | null) => void
  barStarts: number[]

  playbackState: PlaybackState
  currentTime: number
  bpm: number
  originalBpm: number
  loopEnabled: boolean
  loopStart: number | null
  loopEnd: number | null
  loopRegionEnabled: boolean
  loopRegionActive: boolean

  setPlaybackState: (state: PlaybackState) => void
  setCurrentTime: (time: number) => void
  setBpm: (bpm: number) => void
  resetBpm: () => void
  setLoop: (enabled: boolean, start?: number, end?: number) => void
  setLoopRegionEnabled: (v: boolean) => void
  setLoopRegionActive: (v: boolean) => void
  setLoopRegion: (start: number, end: number) => void
  clearLoopRegion: () => void

  tracks: TrackState[]
  setTracks: (tracks: TrackState[]) => void
  updateTrack: (index: number, patch: Partial<TrackState>) => void
  muteGroup: (group: string, muted: boolean) => void

  keyboardSize: KeyboardSize
  keyboardMode: KeyboardMode
  activeKeys: Set<number>
  // ── Keys held down on a hardware MIDI keyboard right now (useMidiInput) —
  // only those, unlike activeKeys, which playback and clicks also light ──
  midiHeldKeys: Set<number>
  activeKeyColors: Map<number, string>

  setKeyboardSize: (size: KeyboardSize) => void
  setKeyboardMode: (mode: KeyboardMode) => void
  setActiveKeys: (keys: Set<number>) => void
  setActiveKeyColors: (colors: Map<number, string>) => void

  noteNaming: NoteNaming
  accidentals: Accidentals
  zoomLevel: number
  appTheme: AppTheme
  showBarNumbers: boolean
  setNoteNaming: (naming: NoteNaming) => void
  setAccidentals: (accidentals: Accidentals) => void
  setZoomLevel: (zoom: number) => void
  setAppTheme: (theme: AppTheme) => void
  setShowBarNumbers: (v: boolean) => void

  // ── Chord tracking (what the playback display/lock-a-chord follows) and
  // naming style (abbreviation vs symbol) — chordFollowTrackIndex is
  // deliberately NOT persisted, see restoreLibraryPrefs/useChordSequence. ──
  chordTrackingMode: ChordTrackingMode
  chordFollowSubMode: ChordFollowSubMode
  chordFollowGroup: string | null
  chordFollowTrackIndex: number | null
  chordNamingStyle: ChordNamingStyle
  // ── How eagerly the detector splits the beat into separate chords, 0..1.
  // The single user knob — replaces the old per-mode presets. Fed straight
  // into buildChordSequence's `sensitivity`. ──────────────────────────────
  chordSensitivity: number
  /** 'safe' (default, unchanged engine) vs 'progressive' (opt-in, trusts a
   *  real chord grab to show brief extensions Safe is too conservative to
   *  show). Settings › Notation & Chords › "Chord reading". See
   *  docs/Chord Engine Dual-Mode Plan.md. */
  chordReadingMode: ChordReadingMode
  // ── How the Chord / Scale Explorer voice the chords of a progression when
  // auditioning it — shared by both explorers, see utils/voiceLeading.ts. ──
  progressionVoicing: ProgressionVoicing
  setChordTrackingMode: (mode: ChordTrackingMode) => void
  setChordFollowSubMode: (mode: ChordFollowSubMode) => void
  setChordFollowGroup: (group: string | null) => void
  setChordFollowTrackIndex: (index: number | null) => void
  setChordNamingStyle: (style: ChordNamingStyle) => void
  setChordSensitivity: (v: number) => void
  setChordReadingMode: (mode: ChordReadingMode) => void
  setProgressionVoicing: (v: ProgressionVoicing) => void

  detectedKey: DetectedKey | null
  setDetectedKey: (key: DetectedKey | null) => void
  setTranspose: (semitones: number) => void

  metronomeEnabled: boolean
  setMetronomeEnabled: (enabled: boolean) => void

  midiDeviceConnected: boolean
  midiDeviceName: string
  setMidiDevice: (connected: boolean, name?: string) => void

  trackPanelOpen: boolean
  settingsOpen: boolean
  settingsPanelOpen: boolean
  setTrackPanelOpen: (open: boolean) => void
  setSettingsOpen: (open: boolean) => void
  setSettingsPanelOpen: (open: boolean) => void

  chordExplorerOpen: boolean
  chordExplorerMinimized: boolean
  setChordExplorerOpen: (open: boolean) => void
  setChordExplorerMinimized: (v: boolean) => void
  // ── One-shot signal: "open Chord Explorer pre-seeded with this chord" —
  // set by the playback chord-display context menu, consumed once by
  // ChordExplorer.tsx on open, then cleared. `voicing` (when present) is the
  // exact MIDI voicing under the paused playhead — the real inversion and
  // register from the file, which the Explorer restores verbatim instead of
  // its canonical root-position octave-4 rebuild. `inversionCount` is that
  // voicing's inversion number, for the on-keyboard chord-name label. ───────
  pendingChordExplorerSeed:
    | { rootPitchClass: number; intervals: string[]; voicing?: number[]; inversionCount?: number }
    | null
  setPendingChordExplorerSeed: (
    v: { rootPitchClass: number; intervals: string[]; voicing?: number[]; inversionCount?: number } | null,
  ) => void
  scaleExplorerOpen: boolean
  scaleExplorerMinimized: boolean
  setScaleExplorerOpen: (open: boolean) => void
  setScaleExplorerMinimized: (v: boolean) => void
  // ── Mirrors LockedChordModal's own local `modalOpen` state — exists only
  // so App.tsx's global Escape handler can exclude it the same way it
  // already excludes chordExplorerOpen/scaleExplorerOpen (both listeners
  // are on `window`; App.tsx's fires first, so it must know to skip stop()).
  lockedChordModalOpen: boolean
  setLockedChordModalOpen: (open: boolean) => void
  mixerOpen: boolean
  setMixerOpen: (open: boolean) => void
  // Snapshot of volume/pan/chorus/reverb as loaded from the file — diffed
  // against live `tracks` values on mixer close to detect unsaved changes.
  mixerBaseline: Record<number, { volume: number; pan: number; chorus: number; reverb: number }>
  midiEditorOpen: boolean
  setMidiEditorOpen: (open: boolean) => void
  pendingImportedFile: {
    sourcePath: string;
    format: ForeignFormat;
    midiBase64: string;
    fileName: string;
  } | null
  setPendingImportedFile: (
    value: {
      sourcePath: string;
      format: ForeignFormat;
      midiBase64: string;
      fileName: string;
    } | null
  ) => void
  presentationMode: boolean
  setPresentationMode: (v: boolean) => void
  noteEditorEnabled: boolean
  setNoteEditorEnabled: (v: boolean) => void
  // ── Tempo/Key save — off by default. When on, changing BPM/transpose from
  // the loaded file's own values offers a "Save changes" button in the
  // header that bakes them into a new versioned file (see TopBar.tsx). ────
  saveTempoKeyChangesEnabled: boolean
  setSaveTempoKeyChangesEnabled: (v: boolean) => void
  // ── Tap Tempo — per-song beat-grid corrections (see utils/tempoCorrection.ts).
  // Keyed by songKey (content hash) so a correction follows the file through
  // renames/moves. Only the beat layer changes; audio/notes/bpm never do. ──
  songKey: string | null
  tempoCorrections: Record<string, SongTempoCorrection>
  setTempoCorrections: (c: Record<string, SongTempoCorrection>) => void
  setSongCorrection: (key: string, c: SongTempoCorrection | null) => void
  reapplyCorrection: () => void
  setBeatGrid: (midi: ParsedMidi) => void
  tapTempoPadEnabled: boolean
  setTapTempoPadEnabled: (v: boolean) => void
  // 'beat' = tap every beat; 'bar' = tap only the 1 of each bar
  tapTempoMode: 'beat' | 'bar'
  setTapTempoMode: (v: 'beat' | 'bar') => void
  metronomeVolume: number
  setMetronomeVolume: (v: number) => void
  // ── Count-in (metronome right-click / Settings) — N bars of clicks before
  // every user-started Play; see utils/countInRunner.ts. countIn is the
  // session-only state of a count-in in progress (for the on-screen count).
  countInEnabled: boolean
  // ── Skip empty bars at the start (Settings › Playback; utils/prepareSong.ts):
  // songs open at their first musical bar; keepDrumCountIn keeps one or two
  // bars of plain drum clicks before it. Applied when a song is loaded.
  skipEmptyBars: boolean
  setSkipEmptyBars: (v: boolean) => void
  keepDrumCountIn: boolean
  setKeepDrumCountIn: (v: boolean) => void
  setCountInEnabled: (v: boolean) => void
  // ── Settings window (session only) — which group it shows; opened from
  // Quick Settings' gear icons / Open settings button / Ctrl + , ──────────
  settingsWindowOpen: boolean
  settingsWindowGroup: SettingsGroupId
  openSettingsWindow: (group?: SettingsGroupId) => void
  closeSettingsWindow: () => void
  // ── Saved: has Samples ever been used? The first time it's chosen from
  // Quick Settings, the Settings window opens on Audio to show the loading. ─
  samplesIntroduced: boolean
  setSamplesIntroduced: (v: boolean) => void
  countInBars: number
  setCountInBars: (n: number) => void
  countIn: { startPerf: number; clicks: { rel: number; n: number }[]; total: number } | null
  setCountIn: (c: { startPerf: number; clicks: { rel: number; n: number }[]; total: number } | null) => void
  tapSession: TapSession | null
  setTapSession: (s: TapSession | null) => void
  // ── Tempo warnings (Settings, off by default) — songs whose bar lines miss
  // the music's steady beat (see utils/tempoTrust.ts). Results cached by song
  // key; the Library index maps a path (+ size/mtime) to its song key so
  // unchanged files are never re-read. ──────────────────────────────────
  tempoWarningsEnabled: boolean
  setTempoWarningsEnabled: (v: boolean) => void
  tempoWarningDismissed: Record<string, true>
  dismissTempoWarning: (key: string) => void
  clearTempoWarningDismissals: () => void
  tempoTrustCache: Record<string, TrustResult & { v: number }>
  libraryTrustIndex: Record<string, { size: number; mtime: number; songKey: string }>
  setTrustEntry: (path: string | null, stat: { size: number; mtime: number } | null, key: string, result: TrustResult) => void
  currentTrust: TrustResult | null
  setCurrentTrust: (r: TrustResult | null) => void
  noteEditorActive: boolean
  setNoteEditorActive: (v: boolean) => void
  noteEditorToolbarX: number
  noteEditorToolbarY: number
  setNoteEditorToolbarPos: (x: number, y: number) => void
  noteEditorSoloTrackIndex: number | null
  preSoloTrackVisibility: boolean[] | null
  soloTrackForEdit: (index: number, opts?: { keepPlayhead?: boolean }) => void
  unsoloTrackForEdit: () => void
  noteEditorWalkthroughSeen: boolean
  setNoteEditorWalkthroughSeen: (v: boolean) => void
  // Velocity lane — manual toggle; only meaningful while a track is soloed
  // for edit (noteEditorSoloTrackIndex !== null), see PianoRoll.tsx.
  velocityPanelOpen: boolean
  setVelocityPanelOpen: (v: boolean) => void
  vuDisplayMode: 'bars' | 'wave'
  setVuDisplayMode: (mode: 'bars' | 'wave') => void
  explorerKeys: Set<number>
  explorerKeyColors: Map<number, string>
  setExplorerKeys: (keys: Set<number>, colors: Map<number, string>) => void
  clearExplorerKeys: () => void
  // ── Scale/Chord Explorer — highlight the chord/scale's true root pitch
  // class (any octave) in pink instead of blending into the uniform amber.
  // On by default. ──────────────────────────────────────────────────────
  colorRootNoteEnabled: boolean
  setColorRootNoteEnabled: (v: boolean) => void
  // ── Scale/Chord Explorer — shared octave shift for everything the
  // explorers play (0 = roots start in C3–B3). Session-only, not saved. ──
  explorerOctave: number
  setExplorerOctave: (v: number) => void
  displayedChord: string | null
  setDisplayedChord: (chord: string | null) => void
  clearDisplayedChord: () => void

  lockedKeys: Set<number>
  lockedColors: Map<number, string>
  setLockedKeys: (keys: Set<number>, colors: Map<number, string>) => void
  clearLockedKeys: () => void
  // ── Original chord identity preserved across inversion cycling ────────────
  originalLockedChordName: string | null
  setOriginalLockedChordName: (name: string | null) => void
  lockedInversionCount: number
  setLockedInversionCount: (n: number) => void
  lockedChordNoteCount: number
  setLockedChordNoteCount: (n: number) => void

  // ── Explorer chord display — name + inversion tracking for above-keyboard ─
  explorerChordDisplay: { name: string; invCount: number; noteCount: number } | null
  setExplorerChordDisplay: (d: { name: string; invCount: number; noteCount: number } | null) => void
  clearExplorerChordDisplay: () => void

  masterVolume: number
  setMasterVolume: (v: number) => void

  // ── Master compressor/limiter (Samples engine only) — protects against the
  // gain-staging headroom issue (SAMPLES_BOOST × masterVolume can exceed
  // unity) rather than relying on the user to keep the fader low enough.
  // Preset index into COMPRESSOR_PRESETS (useSamplesEngine.ts), not a raw
  // ratio — each position bundles threshold/ratio/attack/release together
  // so the positions actually sound distinct from each other. ─────────────
  masterCompEnabled: boolean
  setMasterCompEnabled: (v: boolean) => void
  masterCompPreset: number
  setMasterCompPreset: (v: number) => void

  // ── Auto-Level on load — off by default (a new file's playback shouldn't
  // change unexpectedly for existing users). When on, setMidi() analyzes the
  // newly-loaded file's velocity fluctuation (src/utils/velocityAnalysis.ts)
  // and, if it dips enough to be worth it, enables the compressor and bumps
  // its preset up to at least what the analysis suggests — never down, so
  // it only ever adds correction, never undoes a stronger preset the user
  // already had set for a reason. ──────────────────────────────────────────
  autoLevelOnLoad: boolean
  setAutoLevelOnLoad: (v: boolean) => void

  audioEngine: 'gm' | 'samples' | 'native'
  setAudioEngine: (engine: 'gm' | 'samples' | 'native') => void

  chordPrompterEnabled: boolean
  chordPrompterOpen: boolean
  chordSequence: ChordEvent[]
  setChordPrompterEnabled: (v: boolean) => void
  setChordPrompterOpen: (v: boolean) => void
  setChordSequence: (seq: ChordEvent[]) => void

  chordTranscriptionEnabled: boolean
  setChordTranscriptionEnabled: (v: boolean) => void

  hideDemoFolder: boolean
  setHideDemoFolder: (v: boolean) => void

  // ── Blinks the Library refresh icon after any resave (foreign-import save,
  // MidiEditor save, Note Editor save) — cleared once the user clicks refresh.
  // Stays as the fallback path (see notifyLibrarySaved below) for whenever
  // the automatic rescan can't run (no library folder open, or it fails). ──
  libraryNeedsRefresh: boolean
  setLibraryNeedsRefresh: (v: boolean) => void

  // ── Path of the file to briefly amber-highlight in the Library after an
  // automatic post-save rescan — cleared on its own after a few seconds. ──
  libraryHighlightPath: string | null
  setLibraryHighlightPath: (p: string | null) => void
  // ── Single entry point every save/import call site uses instead of
  // setLibraryNeedsRefresh directly: rescans the library folder right away
  // so the new file is immediately visible, and amber-highlights it. Falls
  // back to just flagging libraryNeedsRefresh (leaving the manual refresh
  // button as the way to pick it up) when there's no library folder open or
  // the rescan itself fails. ─────────────────────────────────────────────
  notifyLibrarySaved: (newFilePath: string) => Promise<void>

  demoFiles: { name: string; path: string }[]
  setDemoFiles: (files: { name: string; path: string }[]) => void

  libraryFolder: string | null
  libraryFiles: LibraryFile[]
  libraryFavourites: Set<string>
  setLibraryFolder: (folder: string | null) => void
  setLibraryFiles: (files: LibraryFile[]) => void
  setLibraryFolderAndFiles: (folder: string | null, files: LibraryFile[]) => void
  toggleFavourite: (path: string) => void
  setFavourites: (paths: string[], starred: boolean) => void
  hiddenLibraryFiles: string[]
  hideLibraryFile: (path: string) => void
  unhideLibraryFile: (path: string) => void
  showHiddenLibraryFiles: boolean
  setShowHiddenLibraryFiles: (v: boolean) => void
  remapLibraryPaths: (pairs: { oldPath: string; newPath: string }[]) => void
  lastFolderOf: Map<string, string | null>
  setLastFolderOf: (map: Map<string, string | null>) => void
  foldersWithUndo: Set<string>
  setFoldersWithUndo: (folders: Set<string>) => void

  splitBreakpointType: 'single' | 'range'
  setSplitBreakpointType: (t: 'single' | 'range') => void
  splitBreakpointNote: number
  setSplitBreakpointNote: (n: number) => void
  splitBreakpointRangeStart: number
  setSplitBreakpointRangeStart: (n: number) => void
  splitBreakpointRangeEnd: number
  setSplitBreakpointRangeEnd: (n: number) => void

  autoMuteNonKeyboard: boolean
  setAutoMuteNonKeyboard: (v: boolean) => void
  // ── Focus on/off for the loaded song (see focusRole, utils/keyboardGroups.ts) ──
  setTrackMuteFilter: (filtered: boolean) => void
  focusActive: boolean
  // Mute is sound only; what shows on the roll and keyboard is the eye (visible)
  setTrackMuted: (index: number, muted: boolean) => void

  settingsGroupsCollapsed: Record<string, boolean>
  setSettingsGroupCollapsed: (id: string, collapsed: boolean) => void

  showHandLabels: boolean
  setShowHandLabels: (v: boolean) => void

  // ── Reflect piano roll on keyboard (paused/scrubbing only) — a testing aid
  // so chord-hunting doesn't need a manual "Show on keyboard" every time.
  // While on and playback isn't running, the keyboard continuously lights
  // whatever notes are sounding at the playhead from tracks flagged "Lit on
  // keyboard" (track.showOnKeyboard) — same tracks real playback already
  // lights, just also live while paused. Never touches actual playback
  // lighting (untouched, still purely engine-driven). Off by default.
  reflectPianoRollOnKeyboard: boolean
  setReflectPianoRollOnKeyboard: (v: boolean) => void

  // ── Precise scrub time (millisecond position readout) — a debugging aid for
  // matching the position slider against an externally-timestamped reference
  // (e.g. a bar-by-bar chord table pasted from a spreadsheet). When on, the
  // existing coarse mm:ss readout to the left of the slider switches to
  // mm:ss.mmm instead, at all times a file is loaded (playing, paused, or
  // mid-drag) — not just while dragging. Off by default.
  showPreciseScrubTime: boolean
  setShowPreciseScrubTime: (v: boolean) => void

  // ── Hidable playbar (Phase 1) — off (hidden) means the piano roll's hit
  // line tracks the live keyboard position instead of a fixed line; default
  // true keeps today's behavior byte-for-byte unchanged.
  playbarVisible: boolean
  setPlaybarVisible: (v: boolean) => void
  // Viewport-space Y of the keyboard's top edge, kept live by whichever
  // Keyboard instance is mounted (docked or floating) while playbarVisible
  // is false. Null until measured, or whenever playbarVisible is true (no
  // measurement loop runs — zero overhead when the feature is off).
  keyboardTopY: number | null
  setKeyboardTopY: (y: number | null) => void

  // ── Note-hit visual effects (Phase 2) — additive layer on top of the
  // existing lightKey() glow; off by default.
  hitEffectsEnabled: boolean
  setHitEffectsEnabled: (v: boolean) => void
  hitEffectPattern: HitEffectPattern
  setHitEffectPattern: (p: HitEffectPattern) => void

  // ── Bloom controls (AdvancedBloomFilter, applied to the whole effects layer) ─
  hitEffectBloomThreshold: number
  setHitEffectBloomThreshold: (v: number) => void
  hitEffectBloomIntensity: number
  setHitEffectBloomIntensity: (v: number) => void
  hitEffectBloomSpread: number
  setHitEffectBloomSpread: (v: number) => void

  // ── Which tracks spawn effects: only ones actively lit on the keyboard
  // (default, matches existing key-glow scoping), or every track in the file
  // regardless of showOnKeyboard — purely visual, doesn't touch key lighting. ──
  hitEffectScope: 'keyboard' | 'all'
  setHitEffectScope: (v: 'keyboard' | 'all') => void
  // ── Overrides the effect particle color for every track at once — null means
  // "inherit each note's track color" (existing/default behavior). Never touches
  // the falling-note color or the key glow, only what HitEffects.spawn() renders. ──
  hitEffectColor: string | null
  setHitEffectColor: (v: string | null) => void

  // ── Active soundfont (Samples engine) — 'generaluser-gs' is always bundled;
  // the other two are downloaded on demand via window.electronAPI.
  selectedSoundfont: SoundfontId
  setSelectedSoundfont: (id: SoundfontId) => void

  showOctaveLabels: boolean
  setShowOctaveLabels: (v: boolean) => void
  // ── Scales Explorer shows the Starmap instead of the Circle of Fifths ──
  starmapEnabled: boolean
  setStarmapEnabled: (v: boolean) => void
  showNoteNamesOnKeyboard: boolean
  setShowNoteNamesOnKeyboard: (v: boolean) => void

  // ── Auto-collapse left/right drawers (library/settings + tracks) while
  // playing, restore them on pause/stop/new-file-load. _preAutoCollapse*
  // remembers what was actually open before auto-collapse hid it, so we
  // only reopen what the user had open, not force both open unconditionally.
  autoCollapseDrawers: boolean
  // Step Through: → / ← step note by note, plus arrows in the keyboard footer
  stepThroughEnabled: boolean
  setStepThroughEnabled: (v: boolean) => void
  // Export to audio (Settings › Audio): adds the Library right-click item; off by default
  exportAudioEnabled: boolean
  setExportAudioEnabled: (v: boolean) => void
  // Hand colours (Settings › Appearance) — the left/right hand pair, hex
  handColorLH: string
  handColorRH: string
  setHandColors: (lh: string, rh: string) => void
  // Orfeo's own tooltips (hints on hover); live value readouts while dragging stay
  tooltipsEnabled: boolean
  setTooltipsEnabled: (v: boolean) => void
  // The "Enjoying Orfeo?" note every 5th launch (components/SupportNote.tsx)
  supportNoteEnabled: boolean
  setSupportNoteEnabled: (v: boolean) => void
  // Opening the Chords or Scales Explorer pauses the song (Settings › Playback)
  explorerPausesPlayback: boolean
  setExplorerPausesPlayback: (v: boolean) => void
  setAutoCollapseDrawers: (v: boolean) => void

  // ── Tracks panel's per-track color line doubles as a mini VU meter during
  // playback when this is on; always shows the plain static color when off. ──
  trackVuColorEnabled: boolean
  setTrackVuColorEnabled: (v: boolean) => void

  handLabelMode: 'practice' | 'performance'
  setHandLabelMode: (mode: 'practice' | 'performance') => void

  // ── Accessibility — an "L"/"R" letter badge on hand-colored keys, for
  // colorblind users who can't rely on the blue/pink alone. Independent of
  // showHandLabels: a genuine split-hand track's keys stay blue/pink even
  // with Left/Right Hand off (see handColors.ts), so this needs its own
  // toggle rather than riding on that one. ──────────────────────────────────
  showHandLetters: boolean
  setShowHandLetters: (v: boolean) => void

  performanceSplitSensitivity: number
  setPerformanceSplitSensitivity: (n: number) => void

  // ── Max fingers per hand — drives the hand-assignment engine's hard cap on
  // how many notes of a wide chord one hand can take (RH from the top, LH
  // absorbing the rest); independently selectable, 4 (default) or 5. ─────────
  rhMaxFingers: 4 | 5
  setRhMaxFingers: (n: 4 | 5) => void
  lhMaxFingers: 4 | 5
  setLhMaxFingers: (n: 4 | 5) => void

  transcriptHistory: TranscriptEntry[]
  addTranscriptEntry: (entry: TranscriptEntry) => void

  resetAll: () => void
}

// ── makeTrackState — builds initial TrackState for a parsed track ────────────
// All tracks start unmuted; selective filtering is applied via the quick-toggle button.
function makeTrackState(track: ParsedTrack): TrackState {
  const showOnKeyboard = KEYBOARD_DISPLAY_GROUPS.has(track.group ?? '') && !track.isDrum

  return {
    index: track.index,
    name: track.name,
    gmName: track.gmName,
    trackName: track.gmName,  // user label — defaults to GM name, overridden on load if file has ORFEO_TRACK_NAME
    program: track.program,
    group: track.group,
    isDrum: track.isDrum,
    color: track.color,
    colorSource: 'default' as const,
    muted: false,
    solo: false,
    visible: true,
    showOnKeyboard,
    volume: (track as any)._cc7 ?? 1,
    pan: (track as any)._cc10 != null ? ((track as any)._cc10 - 0.5) * 2 : 0,
    chorus: (track as any)._cc93 ?? 0,
    reverb: (track as any)._cc91 ?? 0,
  }
}

export const useStore = create<OrfeoStore>((set, get) => ({
  midi: null,
  barStarts: [],
  setMidi: (midi) => {
    // ── Tap Tempo: a load/unload ends any live session, restoring the
    // metronome a preview may have forced on ─────────────────────────────
    const prevSession = get().tapSession
    const sessionReset = prevSession ? { tapSession: null, metronomeEnabled: prevSession.prevMetronome } : {}
    if (!midi) { set({ midi: null, tracks: [], mixerBaseline: {}, currentTime: 0, playbackState: 'stopped', trackPanelOpen: false, barStarts: [], chordSequence: [], chordPrompterOpen: false, loopStart: null, loopEnd: null, loopRegionActive: false, songKey: null, currentTrust: null, countIn: null, ...sessionReset }); return }
    // ── …and applies this song's stored beat-grid correction, if any. The
    // song is known by the file's own bytes, whether or not its empty bars
    // are skipped (prepareSong.ts); corrections are kept in the file's own
    // seconds and shifted to the song's. ─────────────────────────────────
    const raw = midi._origRaw ?? midi._raw
    const key = raw ? computeSongKey(raw) : null
    const corr = key ? get().tempoCorrections[key] : undefined
    midi = prepareSong(midi, { skip: get().skipEmptyBars, keepCountIn: get().keepDrumCountIn, correction: corr ?? null })
    if (corr) midi = applyTempoCorrection(midi, correctionToSong(corr, midi._leadSec ?? 0))
    // ── Apply ORFEO_TRACK_NAME / ORFEO_TRACK_COLOR overrides from header meta ──
    const orfeoNames = (midi as any)._orfeoTrackNames as Record<number, string> | undefined
    const orfeoColors = (midi as any)._orfeoTrackColors as Record<number, string> | undefined
    const orfeoVisible = (midi as any)._orfeoTrackVisible as Record<number, boolean> | undefined
    const orfeoKeyboard = (midi as any)._orfeoTrackKeyboard as Record<number, boolean> | undefined
    const newTracks = midi.tracks.map((t, i) => {
      const ts = makeTrackState(t)
      if (orfeoNames?.[i]) ts.trackName = orfeoNames[i]
      if (orfeoColors?.[i]) { ts.color = orfeoColors[i]; ts.colorSource = 'custom' }
      if (orfeoVisible?.[i] !== undefined) ts.visible = orfeoVisible[i]
      if (orfeoKeyboard?.[i] !== undefined) ts.showOnKeyboard = orfeoKeyboard[i]
      // A piano still on Orfeo's default blue/pink (older saved versions store
      // it) takes the user's hand colours
      if (HAND_ASSIGN_GROUPS.has(ts.group ?? '')) ts.color = followedHandColor(ts.color, handHex(), handHex()) ?? ts.color
      return ts
    })
    const mixerBaseline: OrfeoStore['mixerBaseline'] = {}
    for (const ts of newTracks) {
      mixerBaseline[ts.index] = { volume: ts.volume, pan: ts.pan, chorus: ts.chorus, reverb: ts.reverb }
    }
    _focusSnapshot = null
    set({
      ...sessionReset,
      focusActive: false,
      midi,
      songKey: key,
      currentTrust: null,
      countIn: null,
      tracks: newTracks,
      mixerBaseline,
      currentTime: 0,
      playbackState: 'stopped',
      bpm: midi.bpm,
      originalBpm: midi.bpm,
      trackPanelOpen: true,   // auto-open drawer when file loads
      barStarts: (midi as any)._barStarts ?? [],
      loopStart: null,
      loopEnd: null,
      loopRegionActive: false,
    })

    // ── Auto-Level on load (Settings → Audio) — analyze this file's velocity
    // fluctuation and, if it dips enough to be worth it, make sure the
    // compressor is on and bumped to at least the suggested preset. Never
    // lowers an existing stronger preset — this only ever adds correction,
    // it never undoes a choice the user already made for a reason. ─────────
    if (get().autoLevelOnLoad) {
      const suggested = suggestCompressorPreset(velocityDropRatio(midi.tracks))
      if (suggested !== null) {
        if (!get().masterCompEnabled) set({ masterCompEnabled: true })
        if (get().masterCompPreset < suggested) set({ masterCompPreset: suggested })
      }
    }
  },

  playbackState: 'stopped',
  currentTime: 0,
  bpm: 120,
  originalBpm: 120,
  loopEnabled: false,
  loopStart: null,
  loopEnd: null,
  loopRegionEnabled: false,
  loopRegionActive: false,

  setPlaybackState: (playbackState) => set({ playbackState }),
  setCurrentTime: (currentTime) => set({ currentTime }),
  setBpm: (bpm) => set({ bpm }),
  resetBpm: () => set((s) => ({ bpm: s.originalBpm })),
  setLoop: (loopEnabled, loopStart, loopEnd) =>
    set((s) => ({ loopEnabled, loopStart: loopStart ?? s.loopStart, loopEnd: loopEnd ?? s.loopEnd })),
  // ── Loop region setters ───────────────────────────────────────────────────
  setLoopRegionEnabled: (v) => set(v
    ? { loopRegionEnabled: true }
    : { loopRegionEnabled: false, loopRegionActive: false, loopStart: null, loopEnd: null }
  ),
  setLoopRegionActive: (loopRegionActive) => set({ loopRegionActive }),
  setLoopRegion: (start, end) => set({ loopStart: start, loopEnd: end }),
  clearLoopRegion: () => set({ loopStart: null, loopEnd: null, loopRegionActive: false }),

  tracks: [],
  setTracks: (tracks) => set({ tracks }),
  updateTrack: (index, patch) =>
    set((s) => ({ tracks: s.tracks.map((t) => (t.index === index ? { ...t, ...patch } : t)) })),
  muteGroup: (group, muted) =>
    set((s) => ({ tracks: s.tracks.map((t) => t.group === group ? { ...t, muted } : t) })),

  keyboardSize: 73,
  keyboardMode: 'docked',
  activeKeys: new Set(),
  midiHeldKeys: new Set(),
  activeKeyColors: new Map(),

  setKeyboardSize: (keyboardSize) => set({ keyboardSize }),
  setKeyboardMode: (keyboardMode) => set({ keyboardMode }),
  setActiveKeys: (activeKeys) => set({ activeKeys }),
  setActiveKeyColors: (activeKeyColors) => set({ activeKeyColors }),

  noteNaming: 'english',
  accidentals: 'flat',
  zoomLevel: 1,
  appTheme: 'dark',
  showBarNumbers: true,
  setNoteNaming: (noteNaming) => set({ noteNaming }),
  setAccidentals: (accidentals) => set({ accidentals }),
  setZoomLevel: (zoomLevel) => set({ zoomLevel }),
  setAppTheme: (appTheme) => set({ appTheme }),
  setShowBarNumbers: (showBarNumbers) => set({ showBarNumbers }),

  // 'auto' (follow the detected chord instrument) is the default — see
  // docs/superpowers/specs/2026-08-31-chord-detection-redesign-design.md.
  chordTrackingMode: 'auto',
  chordFollowSubMode: 'group',
  chordFollowGroup: null,
  chordFollowTrackIndex: null,
  chordNamingStyle: 'abbreviation',
  // 0.4 = the previous Auto preset, so existing setups read identically.
  chordSensitivity: 0.4,
  chordReadingMode: 'safe',
  // 'climbing' = the natural ascending-inversions reading; see voiceLeading.ts.
  progressionVoicing: 'climbing',
  setChordTrackingMode: (chordTrackingMode) => set({ chordTrackingMode }),
  setChordFollowSubMode: (chordFollowSubMode) => set({ chordFollowSubMode }),
  setChordFollowGroup: (chordFollowGroup) => set({ chordFollowGroup }),
  setChordFollowTrackIndex: (chordFollowTrackIndex) => set({ chordFollowTrackIndex }),
  setChordNamingStyle: (chordNamingStyle) => set({ chordNamingStyle }),
  setChordSensitivity: (chordSensitivity) => set({ chordSensitivity: Math.min(1, Math.max(0, chordSensitivity)) }),
  setChordReadingMode: (chordReadingMode) => set({ chordReadingMode }),
  setProgressionVoicing: (progressionVoicing) => set({ progressionVoicing }),

  detectedKey: null,
  setDetectedKey: (detectedKey) => set({ detectedKey }),
  setTranspose: (semitones) => set((s) => ({
    detectedKey: s.detectedKey ? { ...s.detectedKey, transpose: s.detectedKey.transpose + semitones } : null
  })),

  metronomeEnabled: false,
  setMetronomeEnabled: (metronomeEnabled) => set({ metronomeEnabled }),

  midiDeviceConnected: false,
  midiDeviceName: '',
  setMidiDevice: (midiDeviceConnected, midiDeviceName = '') => set({ midiDeviceConnected, midiDeviceName }),

  trackPanelOpen: false,
  settingsOpen: false,
  settingsPanelOpen: false,
  setTrackPanelOpen: (trackPanelOpen) => set({ trackPanelOpen }),
  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
  setSettingsPanelOpen: (settingsPanelOpen) => set({ settingsPanelOpen }),

  chordExplorerOpen: false,
  chordExplorerMinimized: false,
  pendingChordExplorerSeed: null,
  setPendingChordExplorerSeed: (pendingChordExplorerSeed) => set({ pendingChordExplorerSeed }),
  scaleExplorerOpen: false,
  scaleExplorerMinimized: false,
  lockedChordModalOpen: false,
  setLockedChordModalOpen: (lockedChordModalOpen) => set({ lockedChordModalOpen }),
  mixerOpen: false,
  mixerBaseline: {},
  vuDisplayMode: 'bars',
  explorerKeys: new Set(),
  explorerKeyColors: new Map(),
  colorRootNoteEnabled: true,
  setColorRootNoteEnabled: (colorRootNoteEnabled) => set({ colorRootNoteEnabled }),
  explorerOctave: 0,
  setExplorerOctave: (explorerOctave) => set({ explorerOctave }),
  // ── Opening always clears the minimized flag so restore-from-minimize works,
  // and lets go of a locked chord: both light the keyboard in amber, so they
  // never show at once (LockedChordModal closes itself too) ──
  setChordExplorerOpen: (chordExplorerOpen) =>
    chordExplorerOpen ? (get().clearLockedKeys(), set({ chordExplorerOpen, chordExplorerMinimized: false })) : set({ chordExplorerOpen }),
  setChordExplorerMinimized: (chordExplorerMinimized) => set({ chordExplorerMinimized }),
  setScaleExplorerOpen: (scaleExplorerOpen) =>
    scaleExplorerOpen ? (get().clearLockedKeys(), set({ scaleExplorerOpen, scaleExplorerMinimized: false })) : set({ scaleExplorerOpen }),
  setScaleExplorerMinimized: (scaleExplorerMinimized) => set({ scaleExplorerMinimized }),
  setMixerOpen: (mixerOpen) => set({ mixerOpen }),
  midiEditorOpen: false,
  setMidiEditorOpen: (midiEditorOpen) => set({ midiEditorOpen }),
  // ── Pending imported file — session-only, not persisted ──────────────────
  // Set when a foreign format (MusicXML, GP) is converted in-memory but not
  // yet saved to disk as a .mid cache file. Cleared on save or discard.
  pendingImportedFile: null,
  setPendingImportedFile: (value) => set({ pendingImportedFile: value }),
  presentationMode: false,
  setPresentationMode: (presentationMode) => set({ presentationMode }),
  setVuDisplayMode: (vuDisplayMode) => set({ vuDisplayMode }),
  setExplorerKeys: (explorerKeys, explorerKeyColors) => set({ explorerKeys, explorerKeyColors }),

  clearExplorerKeys: () => set({ explorerKeys: new Set(), explorerKeyColors: new Map() }),
  displayedChord: null,
  setDisplayedChord: (displayedChord) => set({ displayedChord }),
  clearDisplayedChord: () => set({ displayedChord: null }),

  lockedKeys: new Set(),
  lockedColors: new Map(),
  setLockedKeys: (lockedKeys, lockedColors) => set({ lockedKeys, lockedColors }),
  // ── Clears keys + resets all locked chord identity state ─────────────────
  clearLockedKeys: () => set({
    lockedKeys: new Set(), lockedColors: new Map(),
    originalLockedChordName: null, lockedInversionCount: 0, lockedChordNoteCount: 0,
  }),
  originalLockedChordName: null,
  setOriginalLockedChordName: (originalLockedChordName) => set({ originalLockedChordName }),
  lockedInversionCount: 0,
  setLockedInversionCount: (lockedInversionCount) => set({ lockedInversionCount }),
  lockedChordNoteCount: 0,
  setLockedChordNoteCount: (lockedChordNoteCount) => set({ lockedChordNoteCount }),

  explorerChordDisplay: null,
  setExplorerChordDisplay: (explorerChordDisplay) => set({ explorerChordDisplay }),
  clearExplorerChordDisplay: () => set({ explorerChordDisplay: null }),

  masterVolume: 0.8,
  setMasterVolume: (masterVolume) => set({ masterVolume: Math.max(0, Math.min(1, masterVolume)) }),

  // Default on, at the "Gentle" preset (index 1) — protects against the
  // gain-staging clipping bug out of the box rather than requiring opt-in.
  masterCompEnabled: true,
  setMasterCompEnabled: (masterCompEnabled) => set({ masterCompEnabled }),
  masterCompPreset: 1,
  setMasterCompPreset: (masterCompPreset) => set({ masterCompPreset: Math.max(0, Math.min(4, Math.round(masterCompPreset))) }),

  autoLevelOnLoad: false,
  setAutoLevelOnLoad: (autoLevelOnLoad) => set({ autoLevelOnLoad }),

  resetAll: () => {
    ;(window as any).__orfeoPlayer?.stop?.()
    set({
      midi: null, tracks: [], barStarts: [],
      bpm: 120, originalBpm: 120, detectedKey: null,
      activeKeys: new Set(), activeKeyColors: new Map(),
      explorerKeys: new Set(), explorerKeyColors: new Map(),
      lockedKeys: new Set(), lockedColors: new Map(),
      originalLockedChordName: null, lockedInversionCount: 0, lockedChordNoteCount: 0,
      explorerChordDisplay: null,
      displayedChord: null,
      chordExplorerOpen: false, scaleExplorerOpen: false, playbackState: 'stopped',
      currentTime: 0, trackPanelOpen: false, settingsPanelOpen: false,
      chordSequence: [], chordPrompterOpen: false,
      loopStart: null, loopEnd: null, loopRegionActive: false,
      currentTrust: null,
    })
  },

  audioEngine: 'gm',
  setAudioEngine: (audioEngine) => set({ audioEngine }),

  noteEditorEnabled: false,
  setNoteEditorEnabled: (noteEditorEnabled) => set({ noteEditorEnabled }),
  saveTempoKeyChangesEnabled: false,
  setSaveTempoKeyChangesEnabled: (saveTempoKeyChangesEnabled) => set({ saveTempoKeyChangesEnabled }),
  songKey: null,
  tempoCorrections: {},
  setTempoCorrections: (tempoCorrections) => { set({ tempoCorrections }); get().reapplyCorrection() },
  setSongCorrection: (key, c) => {
    const next = { ...get().tempoCorrections }
    // the open song's correction arrives in song time: stored in the file's own
    const lead = key === get().songKey ? (get().midi?._leadSec ?? 0) : 0
    if (c && c.segments.length > 0) next[key] = lead ? correctionToFile(c, lead, get().tempoCorrections[key]) : c; else delete next[key]
    set({ tempoCorrections: next })
    if (key === get().songKey) get().reapplyCorrection()
  },
  reapplyCorrection: () => {
    const { midi, songKey: key, tempoCorrections } = get()
    if (!midi || !key) return
    const c = tempoCorrections[key]
    get().setBeatGrid(applyTempoCorrection(midi, c ? correctionToSong(c, midi._leadSec ?? 0) : null))
  },
  setBeatGrid: (midi) => set({ midi, barStarts: (midi as any)._barStarts ?? [] }),
  tapTempoPadEnabled: false,
  setTapTempoPadEnabled: (tapTempoPadEnabled) => set({ tapTempoPadEnabled }),
  tapTempoMode: 'beat',
  setTapTempoMode: (tapTempoMode) => set({ tapTempoMode }),
  metronomeVolume: 1,
  setMetronomeVolume: (v) => set({ metronomeVolume: Math.min(1.5, Math.max(0, v)) }),
  countInEnabled: false,
  setCountInEnabled: (countInEnabled) => set({ countInEnabled }),
  skipEmptyBars: false,
  // never on together with Chord Transcription, whose charts number bars as
  // the file has them (switching one on switches the other off)
  setSkipEmptyBars: (skipEmptyBars) => set(skipEmptyBars ? { skipEmptyBars, chordTranscriptionEnabled: false } : { skipEmptyBars }),
  keepDrumCountIn: true,
  setKeepDrumCountIn: (keepDrumCountIn) => set({ keepDrumCountIn }),
  settingsWindowOpen: false,
  settingsWindowGroup: 'audio',
  openSettingsWindow: (group) => set((s) => ({ settingsWindowOpen: true, settingsWindowGroup: group ?? s.settingsWindowGroup })),
  closeSettingsWindow: () => set({ settingsWindowOpen: false }),
  samplesIntroduced: false,
  setSamplesIntroduced: (samplesIntroduced) => set({ samplesIntroduced }),
  countInBars: 1,
  setCountInBars: (n) => set({ countInBars: Math.max(1, Math.min(4, Math.round(n))) }),
  countIn: null,
  setCountIn: (countIn) => set({ countIn }),
  tapSession: null,
  setTapSession: (tapSession) => set({ tapSession }),
  tempoWarningsEnabled: false,
  setTempoWarningsEnabled: (tempoWarningsEnabled) => set({ tempoWarningsEnabled }),
  tempoWarningDismissed: {},
  dismissTempoWarning: (key) => set((s) => ({ tempoWarningDismissed: { ...s.tempoWarningDismissed, [key]: true } })),
  clearTempoWarningDismissals: () => set({ tempoWarningDismissed: {} }),
  tempoTrustCache: {},
  libraryTrustIndex: {},
  setTrustEntry: (path, stat, key, result) => set((s) => ({
    tempoTrustCache: { ...s.tempoTrustCache, [key]: { ...result, v: TRUST_VERSION } },
    ...(path && stat ? { libraryTrustIndex: { ...s.libraryTrustIndex, [path]: { size: stat.size, mtime: stat.mtime, songKey: key } } } : {}),
  })),
  currentTrust: null,
  setCurrentTrust: (currentTrust) => set({ currentTrust }),
  noteEditorActive: false,
  setNoteEditorActive: (noteEditorActive) => set(noteEditorActive ? { noteEditorActive } : { noteEditorActive, velocityPanelOpen: false }),
  noteEditorToolbarX: 24,
  noteEditorToolbarY: 80,
  setNoteEditorToolbarPos: (noteEditorToolbarX, noteEditorToolbarY) => set({ noteEditorToolbarX, noteEditorToolbarY }),

  // ── Note Editor: track solo + first-run walkthrough ───────────────────────
  noteEditorSoloTrackIndex: null,
  preSoloTrackVisibility: null,
  soloTrackForEdit: (index, opts) => {
    const s = get()
    if (s.noteEditorSoloTrackIndex === index) {
      // ── Un-solo: restore pre-solo visibility ────────────────────────────
      const restored = s.preSoloTrackVisibility
        ? s.tracks.map((t, i) => ({ ...t, visible: s.preSoloTrackVisibility![i] ?? true }))
        : s.tracks
      set({ tracks: restored, noteEditorSoloTrackIndex: null, preSoloTrackVisibility: null })
    } else {
      // ── Solo: snapshot visibility, hide all tracks except target ────────
      const preSolo   = s.tracks.map(t => t.visible)
      const soloed    = s.tracks.map(t => ({ ...t, visible: t.index === index }))
      set({ tracks: soloed, noteEditorSoloTrackIndex: index, preSoloTrackVisibility: preSolo })

      // ── Jump playback to just before this track's first note — otherwise
      // soloing a track whose notes start much later than the current
      // playhead (or sit outside the currently-visible pitch range) shows an
      // apparently-empty piano roll until playback catches up on its own.
      // Skipped when keepPlayhead is set: toggling Reassign-Hands mode solos
      // the piano track as a side effect, and yanking the playhead to bar 1
      // loses the exact spot the user had paused at to fix a note. ─────────
      if (!opts?.keepPlayhead) {
        const rawTrack = (s.midi as any)?.tracks?.find((t: any) => t.index === index)
        const firstNoteTime = rawTrack?.notes?.[0]?.time
        if (typeof firstNoteTime === 'number') {
          set({ currentTime: Math.max(0, firstNoteTime - 2) })
        }
      }
    }
  },
  unsoloTrackForEdit: () => {
    const s = get()
    if (s.noteEditorSoloTrackIndex === null) return
    const restored = s.preSoloTrackVisibility
      ? s.tracks.map((t, i) => ({ ...t, visible: s.preSoloTrackVisibility![i] ?? true }))
      : s.tracks
    set({ tracks: restored, noteEditorSoloTrackIndex: null, preSoloTrackVisibility: null })
  },
  noteEditorWalkthroughSeen: false,
  setNoteEditorWalkthroughSeen: (noteEditorWalkthroughSeen) => set({ noteEditorWalkthroughSeen }),
  velocityPanelOpen: false,
  setVelocityPanelOpen: (velocityPanelOpen) => set({ velocityPanelOpen }),

  chordPrompterEnabled: false,
  chordPrompterOpen: false,
  chordSequence: [],
  setChordPrompterEnabled: (chordPrompterEnabled) => set({ chordPrompterEnabled }),
  setChordPrompterOpen: (chordPrompterOpen) => set({ chordPrompterOpen }),
  setChordSequence: (chordSequence) => set({ chordSequence }),

  // ── Chord Transcription — per-file PDF generation, persisted ─────────────
  chordTranscriptionEnabled: false,
  setChordTranscriptionEnabled: (chordTranscriptionEnabled) => set(chordTranscriptionEnabled ? { chordTranscriptionEnabled, skipEmptyBars: false } : { chordTranscriptionEnabled }),

  // ── Demo folder visibility — persisted, default visible ───────────────────
  hideDemoFolder: false,
  setHideDemoFolder: (hideDemoFolder) => set({ hideDemoFolder }),

  libraryNeedsRefresh: false,
  setLibraryNeedsRefresh: (libraryNeedsRefresh) => set({ libraryNeedsRefresh }),

  libraryHighlightPath: null,
  setLibraryHighlightPath: (libraryHighlightPath) => set({ libraryHighlightPath }),
  notifyLibrarySaved: async (newFilePath) => {
    set({ libraryNeedsRefresh: true })
    const { libraryFolder } = get()
    if (!libraryFolder) return // no library open — manual refresh (once one is) is the only option anyway
    try {
      const files = await window.electronAPI.scanMidiFolder(libraryFolder)
      // Highlight the actual scanned row, not the path the save handler returned —
      // those can differ by drive-letter case or separator style (the file lands
      // in a pre-existing differently-cased Orfeo/ folder, say), and an exact
      // string compare in the list renderer would then match no row at all,
      // leaving the just-saved version with no amber flash and no pinned bar.
      const norm = (p: string) => p.replace(/\\/g, '/').toLowerCase()
      const match = files.find(f => norm(f.path) === norm(newFilePath))
      const highlightPath = match?.path ?? newFilePath
      set({ libraryFiles: files, libraryNeedsRefresh: false, libraryHighlightPath: highlightPath })
      setTimeout(() => {
        if (get().libraryHighlightPath === highlightPath) set({ libraryHighlightPath: null })
      }, 2500)
    } catch {
      // Rescan failed — leave libraryNeedsRefresh true so the manual button/blink stays the fallback.
    }
  },

  // ── Standalone demo files (shown when no library folder is set) ───────────
  demoFiles: [],
  setDemoFiles: (demoFiles) => set({ demoFiles }),

  // ── MIDI Editor split breakpoint — type and note values, all persisted ──────
  splitBreakpointType: 'single' as 'single' | 'range',
  setSplitBreakpointType: (splitBreakpointType) => set({ splitBreakpointType }),
  splitBreakpointNote: 60,
  setSplitBreakpointNote: (n) => set({ splitBreakpointNote: Math.max(48, Math.min(60, n)) }),
  splitBreakpointRangeStart: 52,
  setSplitBreakpointRangeStart: (n) => set((s) => ({ splitBreakpointRangeStart: Math.max(48, Math.min(s.splitBreakpointRangeEnd - 1, n)) })),
  splitBreakpointRangeEnd: 60,
  setSplitBreakpointRangeEnd: (n) => set((s) => ({ splitBreakpointRangeEnd: Math.max(s.splitBreakpointRangeStart + 1, Math.min(60, n)) })),

  // ── Selective playback button visibility — true = show quick-toggle in Track Panel ──
  autoMuteNonKeyboard: true,
  setAutoMuteNonKeyboard: (autoMuteNonKeyboard) => set({ autoMuteNonKeyboard }),
  // ── Focus — on: hear keys, bass & drums, see only the keys; off: every
  // track's mute and eye exactly as they were before ────────────────────────
  focusActive: false,
  setTrackMuteFilter: (filtered) => set((s) => {
    if (filtered) {
      if (!s.focusActive) _focusSnapshot = new Map(s.tracks.map(t => [t.index, { muted: t.muted, visible: t.visible }]))
      return { focusActive: true, tracks: s.tracks.map(t => { const r = focusRole(t); return { ...t, muted: r === 'off', visible: r === 'keys' } }) }
    }
    const snap = _focusSnapshot
    _focusSnapshot = null
    return { focusActive: false, tracks: s.tracks.map(t => ({ ...t, ...(snap?.get(t.index) ?? { muted: false, visible: true }) })) }
  }),
  setTrackMuted: (index, muted) =>
    set((s) => ({ tracks: s.tracks.map((t) => (t.index === index ? { ...t, muted } : t)) })),

  // ── Settings group collapse state — keyed by group id; true = collapsed.
  // All expanded by default so a fresh install's first Settings open shows
  // everything — persists per-user from there via orfeo-prefs.json, so this
  // only affects the very first open, never overrides what a returning user
  // left collapsed. ───────────────────────────────────────────────────────
  settingsGroupsCollapsed: {
    audio: false,
    'midi-files-library': false,
    'playback-editing': false,
    practice: false,
    editing: false,
    notation: false,
    keyboard: false,
    'piano-roll': false,
    appearance: false,
    midi: false,
  },
  setSettingsGroupCollapsed: (id, collapsed) => set((s) => ({
    settingsGroupsCollapsed: { ...s.settingsGroupsCollapsed, [id]: collapsed },
  })),

  // ── Hand labels — show LEFT/RIGHT HAND labels on the keyboard ────────────
  showHandLabels: false,
  setShowHandLabels: (showHandLabels) => set({ showHandLabels }),

  reflectPianoRollOnKeyboard: false,
  setReflectPianoRollOnKeyboard: (reflectPianoRollOnKeyboard) => set({ reflectPianoRollOnKeyboard }),

  showPreciseScrubTime: false,
  setShowPreciseScrubTime: (showPreciseScrubTime) => set({ showPreciseScrubTime }),

  playbarVisible: true,
  setPlaybarVisible: (playbarVisible) => set({ playbarVisible }),
  keyboardTopY: null,
  setKeyboardTopY: (keyboardTopY) => set({ keyboardTopY }),

  hitEffectsEnabled: true,
  setHitEffectsEnabled: (hitEffectsEnabled) => set({ hitEffectsEnabled }),
  hitEffectPattern: 'glowBloom',
  setHitEffectPattern: (hitEffectPattern) => set({ hitEffectPattern }),

  hitEffectBloomThreshold: 0.4,
  setHitEffectBloomThreshold: (v) => set({ hitEffectBloomThreshold: Math.max(0, Math.min(1, v)) }),
  hitEffectBloomIntensity: 1.5,
  setHitEffectBloomIntensity: (v) => set({ hitEffectBloomIntensity: Math.max(0, Math.min(4, v)) }),

  selectedSoundfont: 'generaluser-gs',
  setSelectedSoundfont: (selectedSoundfont) => set({ selectedSoundfont }),
  hitEffectBloomSpread: 4,
  setHitEffectBloomSpread: (v) => set({ hitEffectBloomSpread: Math.max(0, Math.min(12, v)) }),
  hitEffectScope: 'keyboard',
  setHitEffectScope: (hitEffectScope) => set({ hitEffectScope }),
  hitEffectColor: null,
  setHitEffectColor: (hitEffectColor) => set({ hitEffectColor }),

  // ── Keyboard label visibility — octave numbers and note name labels ────────
  showOctaveLabels: true,
  setShowOctaveLabels: (showOctaveLabels) => set({ showOctaveLabels }),
  starmapEnabled: false,
  setStarmapEnabled: (starmapEnabled) => set({ starmapEnabled }),
  showNoteNamesOnKeyboard: true,
  setShowNoteNamesOnKeyboard: (showNoteNamesOnKeyboard) => set({ showNoteNamesOnKeyboard }),

  autoCollapseDrawers: false,
  stepThroughEnabled: true,
  setStepThroughEnabled: (stepThroughEnabled) => set({ stepThroughEnabled }),
  exportAudioEnabled: false,
  setExportAudioEnabled: (exportAudioEnabled) => set({ exportAudioEnabled }),
  handColorLH: DEFAULT_HAND_LH,
  handColorRH: DEFAULT_HAND_RH,
  setHandColors: (handColorLH, handColorRH) => {
    if (!isHex(handColorLH) || !isHex(handColorRH)) return
    const prev = handHex(), next = { lh: handColorLH, rh: handColorRH }
    applyHandColors(handColorLH, handColorRH)
    // Pianos/organs on a hand colour switch with the pair, in the open song too
    set((s) => ({ handColorLH, handColorRH, tracks: s.tracks.map(t => {
      const c = HAND_ASSIGN_GROUPS.has(t.group ?? '') ? followedHandColor(t.color, prev, next) : null
      return c ? { ...t, color: c } : t
    }) }))
  },
  tooltipsEnabled: true,
  setTooltipsEnabled: (tooltipsEnabled) => set({ tooltipsEnabled }),
  supportNoteEnabled: true,
  setSupportNoteEnabled: (supportNoteEnabled) => set({ supportNoteEnabled }),
  explorerPausesPlayback: true,
  setExplorerPausesPlayback: (explorerPausesPlayback) => set({ explorerPausesPlayback }),
  setAutoCollapseDrawers: (autoCollapseDrawers) => set({ autoCollapseDrawers }),

  trackVuColorEnabled: true,
  setTrackVuColorEnabled: (trackVuColorEnabled) => set({ trackVuColorEnabled }),

  // ── Hand label mode — practice (static, tag-based) or performance (per-note, live) ─
  // Practice mode's UI toggle is disabled (see SettingsPanel.tsx) — proves
  // inconsistent, may return once improved. Always performance until then.
  handLabelMode: 'performance' as 'practice' | 'performance',
  setHandLabelMode: (handLabelMode) => set({ handLabelMode }),

  showHandLetters: false,
  setShowHandLetters: (showHandLetters) => set({ showHandLetters }),

  // ── Performance split sensitivity — hardware-input fallback only (file notes
  // read their exact stored tag, no sensitivity involved); semitone gap
  // threshold, persisted ──────────────────────────────────────────────────────
  performanceSplitSensitivity: 8,
  setPerformanceSplitSensitivity: (n) => set({ performanceSplitSensitivity: Math.max(2, Math.min(16, n)) }),

  rhMaxFingers: 4 as 4 | 5,
  setRhMaxFingers: (rhMaxFingers) => set({ rhMaxFingers }),
  lhMaxFingers: 4 as 4 | 5,
  setLhMaxFingers: (lhMaxFingers) => set({ lhMaxFingers }),

  // ── Transcript history — max 20 entries, oldest dropped when full ─────────
  transcriptHistory: [],
  addTranscriptEntry: (entry) => {
    const next = [entry, ...get().transcriptHistory].slice(0, 20)
    set({ transcriptHistory: next })
    window.electronAPI?.setPrefs?.({ transcriptHistory: next }).catch(() => {})
  },

  libraryFolder: null,
  libraryFiles: [],
  libraryFavourites: new Set(),
  setLibraryFolder: (libraryFolder) => set({ libraryFolder }),
  setLibraryFiles: (libraryFiles) => set({ libraryFiles }),
  setLibraryFolderAndFiles: (libraryFolder, libraryFiles) => set({ libraryFolder, libraryFiles }),
  toggleFavourite: (path) => set((s) => {
    const next = new Set(s.libraryFavourites)
    if (next.has(path)) next.delete(path); else next.add(path)
    return { libraryFavourites: next }
  }),
  // ── Bulk favourite/unfavourite — used by "star all files in this folder" ──
  setFavourites: (paths, starred) => set((s) => {
    const next = new Set(s.libraryFavourites)
    for (const p of paths) { if (starred) next.add(p); else next.delete(p) }
    return { libraryFavourites: next }
  }),
  // ── Per-session "undo last move" map — lives in the store (not component
  // state) so it survives LibraryPanel unmounting when Settings tabs switch.
  // Never persisted; resets on app restart. ─────────────────────────────────
  lastFolderOf: new Map(),
  setLastFolderOf: (lastFolderOf) => set({ lastFolderOf }),
  // ── Folder-level "has an undoable move" flag — tracked directly by folder name
  // rather than derived by matching file paths against lastFolderOf, so it can't
  // drift out of sync with a rescan. Session-only, same lifetime as lastFolderOf. ──
  foldersWithUndo: new Set(),
  setFoldersWithUndo: (foldersWithUndo) => set({ foldersWithUndo }),
  // ── Persisted client-side exclusion list — file stays on disk, just hidden ─
  hiddenLibraryFiles: [],
  hideLibraryFile: (path) => set((s) => ({
    hiddenLibraryFiles: s.hiddenLibraryFiles.includes(path)
      ? s.hiddenLibraryFiles
      : [...s.hiddenLibraryFiles, path],
  })),
  unhideLibraryFile: (path) => set((s) => ({
    hiddenLibraryFiles: s.hiddenLibraryFiles.filter(p => p !== path),
  })),
  showHiddenLibraryFiles: false,
  setShowHiddenLibraryFiles: (showHiddenLibraryFiles) => set({ showHiddenLibraryFiles }),
  // ── Applies old→new path pairs after a folder move/rename, so a starred or
  // hidden file doesn't silently lose that state when its path changes. ──────
  remapLibraryPaths: (pairs) => set((s) => {
    if (pairs.length === 0) return {}
    const map = new Map(pairs.map(p => [p.oldPath, p.newPath]))
    const nextFavourites = new Set(
      Array.from(s.libraryFavourites, p => map.get(p) ?? p),
    )
    const nextHidden = s.hiddenLibraryFiles.map(p => map.get(p) ?? p)
    return { libraryFavourites: nextFavourites, hiddenLibraryFiles: nextHidden }
  }),
}))

// ── Samples "first time" flag on restore — anyone already on Samples has
// used it, so they never get the first-time Settings window. ─────────────
export function applySamplesIntroducedPref(
  prefs: { audioEngine?: unknown; samplesIntroduced?: unknown },
  store: { setSamplesIntroduced: (v: boolean) => void },
) {
  if (typeof prefs.samplesIntroduced === 'boolean') store.setSamplesIntroduced(prefs.samplesIntroduced)
  if (prefs.audioEngine === 'samples') store.setSamplesIntroduced(true)
}

// ── Restore persisted library on startup ──────────────────────────────────────
async function restoreLibraryPrefs() {
  try {
    const prefs = await window.electronAPI?.getPrefs?.()
    if (!prefs) return
    const store = useStore.getState()
    if (prefs.libraryFolder) {
      const files = await window.electronAPI.scanMidiFolder(prefs.libraryFolder)
      store.setLibraryFolderAndFiles(prefs.libraryFolder, files)
    }
    // ── Always load demo files so they appear even before a library is chosen ─
    const demoFolder = await window.electronAPI.getDemoFolder?.()
    if (demoFolder) {
      const demoFiles = await window.electronAPI.scanMidiFolder(demoFolder)
      store.setDemoFiles(demoFiles)
    }
    if (Array.isArray(prefs.libraryFavourites)) {
      prefs.libraryFavourites.forEach((p: string) => store.toggleFavourite(p))
    }
    if (Array.isArray(prefs.hiddenLibraryFiles)) {
      useStore.setState({ hiddenLibraryFiles: prefs.hiddenLibraryFiles })
    }
    if (typeof prefs.showHiddenLibraryFiles === 'boolean') {
      useStore.setState({ showHiddenLibraryFiles: prefs.showHiddenLibraryFiles })
    }
    if (prefs.noteNaming) store.setNoteNaming(prefs.noteNaming)
    if (prefs.accidentals) store.setAccidentals(prefs.accidentals)
    if (prefs.chordTrackingMode === 'auto' || prefs.chordTrackingMode === 'harmony' || prefs.chordTrackingMode === 'follow') {
      store.setChordTrackingMode(prefs.chordTrackingMode)
    } else if (prefs.chordTrackingMode === 'classic') {
      store.setChordTrackingMode('auto') // Classic removed 2026-08-31
    }
    if (prefs.chordFollowSubMode === 'group' || prefs.chordFollowSubMode === 'track') store.setChordFollowSubMode(prefs.chordFollowSubMode)
    if (typeof prefs.chordFollowGroup === 'string' || prefs.chordFollowGroup === null) store.setChordFollowGroup(prefs.chordFollowGroup)
    if (prefs.chordNamingStyle === 'abbreviation' || prefs.chordNamingStyle === 'symbol') store.setChordNamingStyle(prefs.chordNamingStyle)
    if (typeof prefs.chordSensitivity === 'number') store.setChordSensitivity(prefs.chordSensitivity)
    if (prefs.chordReadingMode === 'safe' || prefs.chordReadingMode === 'progressive') store.setChordReadingMode(prefs.chordReadingMode)
    if (prefs.progressionVoicing === 'roots' || prefs.progressionVoicing === 'climbing' || prefs.progressionVoicing === 'smooth') store.setProgressionVoicing(prefs.progressionVoicing)
    if (typeof prefs.masterVolume === 'number') store.setMasterVolume(prefs.masterVolume)
    if (typeof prefs.masterCompEnabled === 'boolean') store.setMasterCompEnabled(prefs.masterCompEnabled)
    if (typeof prefs.masterCompPreset === 'number') store.setMasterCompPreset(prefs.masterCompPreset)
    if (typeof prefs.autoLevelOnLoad === 'boolean') store.setAutoLevelOnLoad(prefs.autoLevelOnLoad)
    if (prefs.audioEngine === 'samples') store.setAudioEngine('samples')
    // Native (beta) is Windows-only; elsewhere fall back to Samples
    if (prefs.audioEngine === 'native') store.setAudioEngine(navigator.userAgent.includes('Windows') ? 'native' : 'samples')
    applySamplesIntroducedPref(prefs, store)
    if (typeof prefs.showBarNumbers === 'boolean') store.setShowBarNumbers(prefs.showBarNumbers)
    if (typeof prefs.noteEditorEnabled === 'boolean') store.setNoteEditorEnabled(prefs.noteEditorEnabled)
    if (typeof prefs.saveTempoKeyChangesEnabled === 'boolean') store.setSaveTempoKeyChangesEnabled(prefs.saveTempoKeyChangesEnabled)
    if (typeof prefs.tapTempoPadEnabled === 'boolean') store.setTapTempoPadEnabled(prefs.tapTempoPadEnabled)
    if (prefs.tapTempoMode === 'beat' || prefs.tapTempoMode === 'bar') store.setTapTempoMode(prefs.tapTempoMode)
    if (typeof prefs.metronomeVolume === 'number') store.setMetronomeVolume(prefs.metronomeVolume)
    if (typeof prefs.countInEnabled === 'boolean') store.setCountInEnabled(prefs.countInEnabled)
    if (typeof prefs.skipEmptyBars === 'boolean') store.setSkipEmptyBars(prefs.skipEmptyBars)
    if (typeof prefs.keepDrumCountIn === 'boolean') store.setKeepDrumCountIn(prefs.keepDrumCountIn)
    if (typeof prefs.countInBars === 'number') store.setCountInBars(prefs.countInBars)
    if (prefs.tempoCorrections) store.setTempoCorrections(sanitizeCorrections(prefs.tempoCorrections))
    if (typeof prefs.tempoWarningsEnabled === 'boolean') store.setTempoWarningsEnabled(prefs.tempoWarningsEnabled)
    {
      const obj = (x: unknown) => (x && typeof x === 'object' && !Array.isArray(x) ? x as Record<string, any> : {})
      const dismissed = Object.fromEntries(Object.keys(obj(prefs.tempoWarningDismissed)).map(k => [k, true as const]))
      const cache = Object.fromEntries(Object.entries(obj(prefs.tempoTrustCache)).filter(([, v]) => v && typeof v.flagged === 'boolean' && typeof v.v === 'number'))
      const index = Object.fromEntries(Object.entries(obj(prefs.libraryTrustIndex)).filter(([, v]) => v && typeof v.songKey === 'string' && typeof v.size === 'number' && typeof v.mtime === 'number'))
      useStore.setState({ tempoWarningDismissed: dismissed, tempoTrustCache: cache, libraryTrustIndex: index })
    }
    if (typeof prefs.noteEditorToolbarX === 'number' && typeof prefs.noteEditorToolbarY === 'number') store.setNoteEditorToolbarPos(prefs.noteEditorToolbarX, prefs.noteEditorToolbarY)
    if (typeof prefs.chordPrompterEnabled === 'boolean') store.setChordPrompterEnabled(prefs.chordPrompterEnabled)
    if (typeof prefs.chordTranscriptionEnabled === 'boolean') store.setChordTranscriptionEnabled(prefs.chordTranscriptionEnabled)
    if (typeof prefs.hideDemoFolder === 'boolean') store.setHideDemoFolder(prefs.hideDemoFolder)
    if (prefs.splitBreakpointType === 'single' || prefs.splitBreakpointType === 'range') store.setSplitBreakpointType(prefs.splitBreakpointType)
    if (typeof prefs.splitBreakpointNote === 'number') store.setSplitBreakpointNote(prefs.splitBreakpointNote)
    if (typeof prefs.splitBreakpointRangeStart === 'number') store.setSplitBreakpointRangeStart(prefs.splitBreakpointRangeStart)
    if (typeof prefs.splitBreakpointRangeEnd === 'number') store.setSplitBreakpointRangeEnd(prefs.splitBreakpointRangeEnd)
    if (typeof prefs.showHandLabels === 'boolean') store.setShowHandLabels(prefs.showHandLabels)
    if (typeof prefs.reflectPianoRollOnKeyboard === 'boolean') store.setReflectPianoRollOnKeyboard(prefs.reflectPianoRollOnKeyboard)
    if (typeof prefs.loopRegionEnabled === 'boolean') store.setLoopRegionEnabled(prefs.loopRegionEnabled)
    // Only 'performance' is restorable — Practice's UI toggle is disabled,
    // so a stale saved 'practice' pref must not resurrect it with no way back.
    if (prefs.handLabelMode === 'performance') store.setHandLabelMode(prefs.handLabelMode)
    if (typeof prefs.showHandLetters === 'boolean') store.setShowHandLetters(prefs.showHandLetters)
    if (typeof prefs.performanceSplitSensitivity === 'number') store.setPerformanceSplitSensitivity(prefs.performanceSplitSensitivity)
    if (prefs.rhMaxFingers === 4 || prefs.rhMaxFingers === 5) store.setRhMaxFingers(prefs.rhMaxFingers)
    if (prefs.lhMaxFingers === 4 || prefs.lhMaxFingers === 5) store.setLhMaxFingers(prefs.lhMaxFingers)
    if (typeof prefs.showOctaveLabels === 'boolean') store.setShowOctaveLabels(prefs.showOctaveLabels)
    if (typeof prefs.starmapEnabled === 'boolean') store.setStarmapEnabled(prefs.starmapEnabled)
    if (typeof prefs.showNoteNamesOnKeyboard === 'boolean') store.setShowNoteNamesOnKeyboard(prefs.showNoteNamesOnKeyboard)
    if (typeof prefs.autoCollapseDrawers === 'boolean') store.setAutoCollapseDrawers(prefs.autoCollapseDrawers)
    if (typeof prefs.stepThroughEnabled === 'boolean') store.setStepThroughEnabled(prefs.stepThroughEnabled)
    if (typeof prefs.exportAudioEnabled === 'boolean') store.setExportAudioEnabled(prefs.exportAudioEnabled)
    if (isHex(prefs.handColorLH) && isHex(prefs.handColorRH)) store.setHandColors(prefs.handColorLH, prefs.handColorRH)
    if (typeof prefs.tooltipsEnabled === 'boolean') store.setTooltipsEnabled(prefs.tooltipsEnabled)
    if (typeof prefs.supportNoteEnabled === 'boolean') store.setSupportNoteEnabled(prefs.supportNoteEnabled)
    if (typeof prefs.explorerPausesPlayback === 'boolean') store.setExplorerPausesPlayback(prefs.explorerPausesPlayback)
    if (typeof prefs.trackVuColorEnabled === 'boolean') store.setTrackVuColorEnabled(prefs.trackVuColorEnabled)
    if (typeof prefs.autoMuteNonKeyboard === 'boolean') store.setAutoMuteNonKeyboard(prefs.autoMuteNonKeyboard)
    if (prefs.settingsGroupsCollapsed && typeof prefs.settingsGroupsCollapsed === 'object' && !Array.isArray(prefs.settingsGroupsCollapsed)) {
      const defaults = store.settingsGroupsCollapsed
      useStore.setState({ settingsGroupsCollapsed: { ...defaults, ...prefs.settingsGroupsCollapsed } })
    }
    if (Array.isArray(prefs.transcriptHistory)) useStore.setState({ transcriptHistory: prefs.transcriptHistory })
    if (typeof prefs.noteEditorWalkthroughSeen === 'boolean') store.setNoteEditorWalkthroughSeen(prefs.noteEditorWalkthroughSeen)
    if (typeof prefs.playbarVisible === 'boolean') store.setPlaybarVisible(prefs.playbarVisible)
    if (typeof prefs.hitEffectsEnabled === 'boolean') store.setHitEffectsEnabled(prefs.hitEffectsEnabled)
    const validPatterns: HitEffectPattern[] = ['glowBloom', 'rippleRing', 'particleBurst', 'smokePlume', 'colorAura', 'starburstNova', 'cometTrail']
    if (validPatterns.includes(prefs.hitEffectPattern)) store.setHitEffectPattern(prefs.hitEffectPattern)
    if (typeof prefs.hitEffectBloomThreshold === 'number') store.setHitEffectBloomThreshold(prefs.hitEffectBloomThreshold)
    if (typeof prefs.hitEffectBloomIntensity === 'number') store.setHitEffectBloomIntensity(prefs.hitEffectBloomIntensity)
    if (typeof prefs.hitEffectBloomSpread === 'number') store.setHitEffectBloomSpread(prefs.hitEffectBloomSpread)
    if (prefs.hitEffectScope === 'keyboard' || prefs.hitEffectScope === 'all') store.setHitEffectScope(prefs.hitEffectScope)
    if (typeof prefs.hitEffectColor === 'string' || prefs.hitEffectColor === null) store.setHitEffectColor(prefs.hitEffectColor)
    if (prefs.selectedSoundfont === 'fluidr3-gm' || prefs.selectedSoundfont === 'musescore-general') store.setSelectedSoundfont(prefs.selectedSoundfont)
  } catch (e) {
    console.error('[Orfeo] restoreLibraryPrefs:', e)
  }
}
setTimeout(restoreLibraryPrefs, 500)

// ── Persist library-list state — favourites + hidden exclusions ───────────────
// Debounced 1 s; gated on libraryFolder so it only fires once a library is set.
let _favTimer: ReturnType<typeof setTimeout> | null = null
const _unsubFav = useStore.subscribe((state) => {
  if (!state.libraryFolder) return
  if (_favTimer) clearTimeout(_favTimer)
  _favTimer = setTimeout(() => {
    window.electronAPI?.setPrefs?.({
      libraryFavourites:      Array.from(state.libraryFavourites),
      hiddenLibraryFiles:     state.hiddenLibraryFiles,
      showHiddenLibraryFiles: state.showHiddenLibraryFiles,
    }).catch(() => {})
  }, 1000)
})

// ── Persist tempo-warning results — batched (2 s after the last change), not
// one full prefs rewrite per Library song while the background scan runs. ──
let _trustTimer: ReturnType<typeof setTimeout> | null = null
let _trustSeen: { cache: object; index: object } | null = null
const _unsubTrust = useStore.subscribe((state) => {
  if (!_trustSeen) { _trustSeen = { cache: state.tempoTrustCache, index: state.libraryTrustIndex }; return }
  if (state.tempoTrustCache === _trustSeen.cache && state.libraryTrustIndex === _trustSeen.index) return
  _trustSeen = { cache: state.tempoTrustCache, index: state.libraryTrustIndex }
  if (_trustTimer) clearTimeout(_trustTimer)
  _trustTimer = setTimeout(() => {
    const s = useStore.getState()
    window.electronAPI?.setPrefs?.({ tempoTrustCache: s.tempoTrustCache, libraryTrustIndex: s.libraryTrustIndex })?.catch?.(() => {})
  }, 2000)
})

// Persist display settings when they change
// Use null sentinel so we never save on first subscriber fire (which would
// overwrite the restored value before restoreLibraryPrefs has run)
let _prevNoteNaming: string | null = null
let _prevAccidentals: string | null = null
let _prevMasterVolume: number | null = null
let _prevAudioEngine: string | null = null
let _prevShowBarNumbers: boolean | null = null
let _prevNoteEditorEnabled:    boolean | null = null
let _prevSaveTempoKeyChangesEnabled: boolean | null = null
let _prevTapTempoPadEnabled: boolean | null = null
let _prevTapTempoMode: string | null = null
let _prevTempoWarningsEnabled: boolean | null = null
let _prevTempoWarningDismissed: object | null = null
let _prevMetronomeVolume: number | null = null
let _prevCountInEnabled: boolean | null = null
let _prevSkipEmptyBars: boolean | null = null
let _prevKeepDrumCountIn: boolean | null = null
let _prevSamplesIntroduced: boolean | null = null
let _prevCountInBars: number | null = null
let _prevTempoCorrections: object | null = null
let _prevNoteEditorToolbarX:   number  | null = null
let _prevNoteEditorToolbarY:   number  | null = null
let _prevChordPrompterEnabled: boolean | null = null
let _prevChordTranscriptionEnabled: boolean | null = null
let _prevHideDemoFolder: boolean | null = null
let _prevSplitBreakpointType: string | null = null
let _prevSplitBreakpointNote: number | null = null
let _prevSplitBreakpointRangeStart: number | null = null
let _prevSplitBreakpointRangeEnd: number | null = null
let _prevShowHandLabels: boolean | null = null
let _prevReflectPianoRollOnKeyboard: boolean | null = null
let _prevLoopRegionEnabled: boolean | null = null
let _prevHandLabelMode: string | null = null
let _prevShowHandLetters: boolean | null = null
let _prevPerformanceSplitSensitivity: number | null = null
let _prevRhMaxFingers: number | null = null
let _prevLhMaxFingers: number | null = null
let _prevShowOctaveLabels: boolean | null = null
let _prevStarmapEnabled: boolean | null = null
let _prevShowNoteNamesOnKeyboard: boolean | null = null
let _prevAutoCollapseDrawers: boolean | null = null
let _prevStepThroughEnabled: boolean | null = null
let _prevExportAudioEnabled: boolean | null = null
let _prevHandColors: string | null = null
let _prevTooltipsEnabled: boolean | null = null
let _prevSupportNoteEnabled: boolean | null = null
let _prevExplorerPausesPlayback: boolean | null = null
let _prevTrackVuColorEnabled: boolean | null = null
let _prevAutoMuteNonKeyboard: boolean | null = null
let _prevSettingsGroupsCollapsed: string | null = null
let _prevNoteEditorWalkthroughSeen: boolean | null = null
let _prevPlaybarVisible: boolean | null = null
let _prevHitEffectsEnabled: boolean | null = null
let _prevHitEffectPattern: string | null = null
let _prevHitEffectBloomThreshold: number | null = null
let _prevHitEffectBloomIntensity: number | null = null
let _prevHitEffectBloomSpread: number | null = null
let _prevHitEffectScope: string | null = null
let _prevHitEffectColor: string | null | undefined = undefined
let _prevSelectedSoundfont: string | null = null
let _prevMasterCompEnabled: boolean | null = null
let _prevMasterCompPreset: number | null = null
let _prevAutoLevelOnLoad: boolean | null = null
let _prevChordTrackingMode: string | null = null
let _prevChordFollowSubMode: string | null = null
let _prevChordFollowGroup: string | null | undefined = undefined
let _prevChordNamingStyle: string | null = null
let _prevChordSensitivity: number | null = null
let _prevChordReadingMode: string | null = null
let _prevProgressionVoicing: string | null = null
const _unsubPrefs = useStore.subscribe((state) => {
  // Skip the very first fire (app init) — restore handles loading saved values
  if (_prevNoteNaming === null) {
    _prevNoteNaming = state.noteNaming
    _prevAccidentals = state.accidentals
    _prevMasterVolume = state.masterVolume
    _prevAudioEngine = state.audioEngine
    _prevShowBarNumbers = state.showBarNumbers
    _prevNoteEditorEnabled = state.noteEditorEnabled
    _prevSaveTempoKeyChangesEnabled = state.saveTempoKeyChangesEnabled
    _prevTapTempoPadEnabled = state.tapTempoPadEnabled
    _prevTapTempoMode = state.tapTempoMode
    _prevTempoWarningsEnabled = state.tempoWarningsEnabled
    _prevTempoWarningDismissed = state.tempoWarningDismissed
    _prevMetronomeVolume = state.metronomeVolume
    _prevCountInEnabled = state.countInEnabled
    _prevSkipEmptyBars = state.skipEmptyBars
    _prevKeepDrumCountIn = state.keepDrumCountIn
    _prevSamplesIntroduced = state.samplesIntroduced
    _prevCountInBars = state.countInBars
    _prevTempoCorrections = state.tempoCorrections
    _prevNoteEditorToolbarX = state.noteEditorToolbarX
    _prevNoteEditorToolbarY = state.noteEditorToolbarY
    _prevChordPrompterEnabled = state.chordPrompterEnabled
    _prevChordTranscriptionEnabled = state.chordTranscriptionEnabled
    _prevHideDemoFolder = state.hideDemoFolder
    _prevSplitBreakpointType = state.splitBreakpointType
    _prevSplitBreakpointNote = state.splitBreakpointNote
    _prevSplitBreakpointRangeStart = state.splitBreakpointRangeStart
    _prevSplitBreakpointRangeEnd = state.splitBreakpointRangeEnd
    _prevShowHandLabels = state.showHandLabels
    _prevReflectPianoRollOnKeyboard = state.reflectPianoRollOnKeyboard
    _prevLoopRegionEnabled = state.loopRegionEnabled
    _prevHandLabelMode = state.handLabelMode
    _prevShowHandLetters = state.showHandLetters
    _prevPerformanceSplitSensitivity = state.performanceSplitSensitivity
    _prevRhMaxFingers = state.rhMaxFingers
    _prevLhMaxFingers = state.lhMaxFingers
    _prevShowOctaveLabels = state.showOctaveLabels
    _prevStarmapEnabled = state.starmapEnabled
    _prevShowNoteNamesOnKeyboard = state.showNoteNamesOnKeyboard
    _prevAutoCollapseDrawers = state.autoCollapseDrawers
    _prevStepThroughEnabled = state.stepThroughEnabled
    _prevExportAudioEnabled = state.exportAudioEnabled
    _prevHandColors = state.handColorLH + state.handColorRH
    _prevTooltipsEnabled = state.tooltipsEnabled
    _prevSupportNoteEnabled = state.supportNoteEnabled
    _prevExplorerPausesPlayback = state.explorerPausesPlayback
    _prevTrackVuColorEnabled = state.trackVuColorEnabled
    _prevAutoMuteNonKeyboard = state.autoMuteNonKeyboard
    _prevSettingsGroupsCollapsed = JSON.stringify(state.settingsGroupsCollapsed)
    _prevNoteEditorWalkthroughSeen = state.noteEditorWalkthroughSeen
    _prevPlaybarVisible = state.playbarVisible
    _prevHitEffectsEnabled = state.hitEffectsEnabled
    _prevHitEffectPattern = state.hitEffectPattern
    _prevHitEffectBloomThreshold = state.hitEffectBloomThreshold
    _prevHitEffectBloomIntensity = state.hitEffectBloomIntensity
    _prevHitEffectBloomSpread = state.hitEffectBloomSpread
    _prevHitEffectScope = state.hitEffectScope
    _prevHitEffectColor = state.hitEffectColor
    _prevSelectedSoundfont = state.selectedSoundfont
    _prevMasterCompEnabled = state.masterCompEnabled
    _prevMasterCompPreset = state.masterCompPreset
    _prevAutoLevelOnLoad = state.autoLevelOnLoad
    _prevChordTrackingMode = state.chordTrackingMode
    _prevChordFollowSubMode = state.chordFollowSubMode
    _prevChordFollowGroup = state.chordFollowGroup
    _prevChordNamingStyle = state.chordNamingStyle
    _prevChordSensitivity = state.chordSensitivity
    _prevChordReadingMode = state.chordReadingMode
    _prevProgressionVoicing = state.progressionVoicing
    return
  }
  if (
    state.noteNaming !== _prevNoteNaming ||
    state.accidentals !== _prevAccidentals ||
    state.masterVolume !== _prevMasterVolume ||
    state.masterCompEnabled !== _prevMasterCompEnabled ||
    state.masterCompPreset !== _prevMasterCompPreset ||
    state.autoLevelOnLoad !== _prevAutoLevelOnLoad ||
    state.audioEngine !== _prevAudioEngine ||
    state.showBarNumbers !== _prevShowBarNumbers ||
    state.noteEditorEnabled !== _prevNoteEditorEnabled ||
    state.saveTempoKeyChangesEnabled !== _prevSaveTempoKeyChangesEnabled ||
    state.tapTempoPadEnabled !== _prevTapTempoPadEnabled ||
    state.tapTempoMode !== _prevTapTempoMode ||
    state.tempoWarningsEnabled !== _prevTempoWarningsEnabled ||
    state.tempoWarningDismissed !== _prevTempoWarningDismissed ||
    state.metronomeVolume !== _prevMetronomeVolume ||
    state.countInEnabled !== _prevCountInEnabled ||
    state.skipEmptyBars !== _prevSkipEmptyBars ||
    state.keepDrumCountIn !== _prevKeepDrumCountIn ||
    state.samplesIntroduced !== _prevSamplesIntroduced ||
    state.countInBars !== _prevCountInBars ||
    state.tempoCorrections !== _prevTempoCorrections ||
    state.noteEditorToolbarX !== _prevNoteEditorToolbarX ||
    state.noteEditorToolbarY !== _prevNoteEditorToolbarY ||
    state.chordPrompterEnabled !== _prevChordPrompterEnabled ||
    state.chordTranscriptionEnabled !== _prevChordTranscriptionEnabled ||
    state.hideDemoFolder !== _prevHideDemoFolder ||
    state.splitBreakpointType !== _prevSplitBreakpointType ||
    state.splitBreakpointNote !== _prevSplitBreakpointNote ||
    state.splitBreakpointRangeStart !== _prevSplitBreakpointRangeStart ||
    state.splitBreakpointRangeEnd !== _prevSplitBreakpointRangeEnd ||
    state.showHandLabels !== _prevShowHandLabels ||
    state.reflectPianoRollOnKeyboard !== _prevReflectPianoRollOnKeyboard ||
    state.loopRegionEnabled !== _prevLoopRegionEnabled ||
    state.handLabelMode !== _prevHandLabelMode ||
    state.showHandLetters !== _prevShowHandLetters ||
    state.performanceSplitSensitivity !== _prevPerformanceSplitSensitivity ||
    state.rhMaxFingers !== _prevRhMaxFingers ||
    state.lhMaxFingers !== _prevLhMaxFingers ||
    state.showOctaveLabels !== _prevShowOctaveLabels ||
    state.starmapEnabled !== _prevStarmapEnabled ||
    state.showNoteNamesOnKeyboard !== _prevShowNoteNamesOnKeyboard ||
    state.autoCollapseDrawers !== _prevAutoCollapseDrawers ||
    state.stepThroughEnabled !== _prevStepThroughEnabled ||
    state.exportAudioEnabled !== _prevExportAudioEnabled ||
    state.handColorLH + state.handColorRH !== _prevHandColors ||
    state.tooltipsEnabled !== _prevTooltipsEnabled ||
    state.supportNoteEnabled !== _prevSupportNoteEnabled ||
    state.explorerPausesPlayback !== _prevExplorerPausesPlayback ||
    state.trackVuColorEnabled !== _prevTrackVuColorEnabled ||
    state.autoMuteNonKeyboard !== _prevAutoMuteNonKeyboard ||
    JSON.stringify(state.settingsGroupsCollapsed) !== _prevSettingsGroupsCollapsed ||
    state.noteEditorWalkthroughSeen !== _prevNoteEditorWalkthroughSeen ||
    state.playbarVisible !== _prevPlaybarVisible ||
    state.hitEffectsEnabled !== _prevHitEffectsEnabled ||
    state.hitEffectPattern !== _prevHitEffectPattern ||
    state.hitEffectBloomThreshold !== _prevHitEffectBloomThreshold ||
    state.hitEffectBloomIntensity !== _prevHitEffectBloomIntensity ||
    state.hitEffectBloomSpread !== _prevHitEffectBloomSpread ||
    state.hitEffectScope !== _prevHitEffectScope ||
    state.hitEffectColor !== _prevHitEffectColor ||
    state.selectedSoundfont !== _prevSelectedSoundfont ||
    state.chordTrackingMode !== _prevChordTrackingMode ||
    state.chordFollowSubMode !== _prevChordFollowSubMode ||
    state.chordFollowGroup !== _prevChordFollowGroup ||
    state.chordNamingStyle !== _prevChordNamingStyle ||
    state.chordSensitivity !== _prevChordSensitivity ||
    state.chordReadingMode !== _prevChordReadingMode ||
    state.progressionVoicing !== _prevProgressionVoicing
  ) {
    _prevNoteNaming = state.noteNaming
    _prevAccidentals = state.accidentals
    _prevMasterVolume = state.masterVolume
    _prevAudioEngine = state.audioEngine
    _prevShowBarNumbers = state.showBarNumbers
    _prevNoteEditorEnabled = state.noteEditorEnabled
    _prevSaveTempoKeyChangesEnabled = state.saveTempoKeyChangesEnabled
    _prevTapTempoPadEnabled = state.tapTempoPadEnabled
    _prevTapTempoMode = state.tapTempoMode
    _prevTempoWarningsEnabled = state.tempoWarningsEnabled
    _prevTempoWarningDismissed = state.tempoWarningDismissed
    _prevMetronomeVolume = state.metronomeVolume
    _prevCountInEnabled = state.countInEnabled
    _prevSkipEmptyBars = state.skipEmptyBars
    _prevKeepDrumCountIn = state.keepDrumCountIn
    _prevSamplesIntroduced = state.samplesIntroduced
    _prevCountInBars = state.countInBars
    _prevTempoCorrections = state.tempoCorrections
    _prevNoteEditorToolbarX = state.noteEditorToolbarX
    _prevNoteEditorToolbarY = state.noteEditorToolbarY
    _prevChordPrompterEnabled = state.chordPrompterEnabled
    _prevChordTranscriptionEnabled = state.chordTranscriptionEnabled
    _prevHideDemoFolder = state.hideDemoFolder
    _prevSplitBreakpointType = state.splitBreakpointType
    _prevSplitBreakpointNote = state.splitBreakpointNote
    _prevSplitBreakpointRangeStart = state.splitBreakpointRangeStart
    _prevSplitBreakpointRangeEnd = state.splitBreakpointRangeEnd
    _prevShowHandLabels = state.showHandLabels
    _prevReflectPianoRollOnKeyboard = state.reflectPianoRollOnKeyboard
    _prevLoopRegionEnabled = state.loopRegionEnabled
    _prevHandLabelMode = state.handLabelMode
    _prevShowHandLetters = state.showHandLetters
    _prevPerformanceSplitSensitivity = state.performanceSplitSensitivity
    _prevRhMaxFingers = state.rhMaxFingers
    _prevLhMaxFingers = state.lhMaxFingers
    _prevShowOctaveLabels = state.showOctaveLabels
    _prevStarmapEnabled = state.starmapEnabled
    _prevShowNoteNamesOnKeyboard = state.showNoteNamesOnKeyboard
    _prevAutoCollapseDrawers = state.autoCollapseDrawers
    _prevStepThroughEnabled = state.stepThroughEnabled
    _prevExportAudioEnabled = state.exportAudioEnabled
    _prevHandColors = state.handColorLH + state.handColorRH
    _prevTooltipsEnabled = state.tooltipsEnabled
    _prevSupportNoteEnabled = state.supportNoteEnabled
    _prevExplorerPausesPlayback = state.explorerPausesPlayback
    _prevTrackVuColorEnabled = state.trackVuColorEnabled
    _prevAutoMuteNonKeyboard = state.autoMuteNonKeyboard
    _prevSettingsGroupsCollapsed = JSON.stringify(state.settingsGroupsCollapsed)
    _prevNoteEditorWalkthroughSeen = state.noteEditorWalkthroughSeen
    _prevPlaybarVisible = state.playbarVisible
    _prevHitEffectsEnabled = state.hitEffectsEnabled
    _prevHitEffectPattern = state.hitEffectPattern
    _prevHitEffectBloomThreshold = state.hitEffectBloomThreshold
    _prevHitEffectBloomIntensity = state.hitEffectBloomIntensity
    _prevHitEffectBloomSpread = state.hitEffectBloomSpread
    _prevHitEffectScope = state.hitEffectScope
    _prevHitEffectColor = state.hitEffectColor
    _prevSelectedSoundfont = state.selectedSoundfont
    _prevMasterCompEnabled = state.masterCompEnabled
    _prevMasterCompPreset = state.masterCompPreset
    _prevAutoLevelOnLoad = state.autoLevelOnLoad
    _prevChordTrackingMode = state.chordTrackingMode
    _prevChordFollowSubMode = state.chordFollowSubMode
    _prevChordFollowGroup = state.chordFollowGroup
    _prevChordNamingStyle = state.chordNamingStyle
    _prevChordSensitivity = state.chordSensitivity
    _prevChordReadingMode = state.chordReadingMode
    _prevProgressionVoicing = state.progressionVoicing
    window.electronAPI?.setPrefs?.({
      noteNaming: state.noteNaming,
      accidentals: state.accidentals,
      masterVolume: state.masterVolume,
      masterCompEnabled: state.masterCompEnabled,
      masterCompPreset: state.masterCompPreset,
      autoLevelOnLoad: state.autoLevelOnLoad,
      audioEngine: state.audioEngine,
      showBarNumbers: state.showBarNumbers,
      noteEditorEnabled: state.noteEditorEnabled,
      saveTempoKeyChangesEnabled: state.saveTempoKeyChangesEnabled,
      tapTempoPadEnabled: state.tapTempoPadEnabled,
      tapTempoMode: state.tapTempoMode,
      tempoWarningsEnabled: state.tempoWarningsEnabled,
      tempoWarningDismissed: state.tempoWarningDismissed,
      metronomeVolume: state.metronomeVolume,
      countInEnabled: state.countInEnabled,
      skipEmptyBars: state.skipEmptyBars,
      keepDrumCountIn: state.keepDrumCountIn,
      samplesIntroduced: state.samplesIntroduced,
      countInBars: state.countInBars,
      tempoCorrections: state.tempoCorrections,
      noteEditorToolbarX: state.noteEditorToolbarX,
      noteEditorToolbarY: state.noteEditorToolbarY,
      chordPrompterEnabled: state.chordPrompterEnabled,
      chordTranscriptionEnabled: state.chordTranscriptionEnabled,
      hideDemoFolder: state.hideDemoFolder,
      splitBreakpointType: state.splitBreakpointType,
      splitBreakpointNote: state.splitBreakpointNote,
      splitBreakpointRangeStart: state.splitBreakpointRangeStart,
      splitBreakpointRangeEnd: state.splitBreakpointRangeEnd,
      showHandLabels: state.showHandLabels,
      reflectPianoRollOnKeyboard: state.reflectPianoRollOnKeyboard,
      loopRegionEnabled: state.loopRegionEnabled,
      handLabelMode: state.handLabelMode,
      showHandLetters: state.showHandLetters,
      performanceSplitSensitivity: state.performanceSplitSensitivity,
      rhMaxFingers: state.rhMaxFingers,
      lhMaxFingers: state.lhMaxFingers,
      showOctaveLabels: state.showOctaveLabels,
      starmapEnabled: state.starmapEnabled,
      showNoteNamesOnKeyboard: state.showNoteNamesOnKeyboard,
      autoCollapseDrawers: state.autoCollapseDrawers,
      stepThroughEnabled: state.stepThroughEnabled,
      exportAudioEnabled: state.exportAudioEnabled,
      handColorLH: state.handColorLH,
      handColorRH: state.handColorRH,
      tooltipsEnabled: state.tooltipsEnabled,
      supportNoteEnabled: state.supportNoteEnabled,
      explorerPausesPlayback: state.explorerPausesPlayback,
      trackVuColorEnabled: state.trackVuColorEnabled,
      autoMuteNonKeyboard: state.autoMuteNonKeyboard,
      settingsGroupsCollapsed: state.settingsGroupsCollapsed,
      noteEditorWalkthroughSeen: state.noteEditorWalkthroughSeen,
      playbarVisible: state.playbarVisible,
      hitEffectsEnabled: state.hitEffectsEnabled,
      hitEffectPattern: state.hitEffectPattern,
      hitEffectBloomThreshold: state.hitEffectBloomThreshold,
      hitEffectBloomIntensity: state.hitEffectBloomIntensity,
      hitEffectBloomSpread: state.hitEffectBloomSpread,
      hitEffectScope: state.hitEffectScope,
      hitEffectColor: state.hitEffectColor,
      selectedSoundfont: state.selectedSoundfont,
      chordTrackingMode: state.chordTrackingMode,
      chordFollowSubMode: state.chordFollowSubMode,
      chordFollowGroup: state.chordFollowGroup,
      chordNamingStyle: state.chordNamingStyle,
      chordSensitivity: state.chordSensitivity,
      chordReadingMode: state.chordReadingMode,
      progressionVoicing: state.progressionVoicing,
    }).catch(() => {})
  }
})

// ── Auto-collapse drawers on playback — closes both the Tracks panel and
// the Settings/Library panel while playing, restores whichever were
// actually open on pause, stop, or a new file loading. ─────────────────────
let _prevPlaybackStateForCollapse: PlaybackState | null = null
let _prevMidiForCollapse: unknown = null
let _drawersAutoCollapsed = false
let _preCollapseTrackPanelOpen = false
let _preCollapseSettingsPanelOpen = false
// Seek operations (wheel-scrub, skip buttons) force a brief real
// playing->paused->playing transition to get the audio engine to rebuild at
// the new position — without this debounce, every one of those ~20ms blips
// would restore the panels and immediately re-collapse them, visibly
// flashing open. Only actually restore if playback is still non-playing
// after the debounce window.
let _restoreTimer: ReturnType<typeof setTimeout> | null = null
const RESTORE_DEBOUNCE_MS = 150
const _unsubCollapse = useStore.subscribe((state) => {
  if (!state.autoCollapseDrawers) { _drawersAutoCollapsed = false; return }

  // Identity of the loaded FILE, not the midi object — a Tap Tempo grid swap
  // (setBeatGrid) makes a new midi object for the same file mid-playback
  const fileId = state.midi ? ((state.midi as any)._raw ?? state.midi) : null
  if (fileId !== _prevMidiForCollapse) {
    _prevMidiForCollapse = fileId
    if (_drawersAutoCollapsed) {
      if (_restoreTimer) { clearTimeout(_restoreTimer); _restoreTimer = null }
      _drawersAutoCollapsed = false
      if (_preCollapseTrackPanelOpen) state.setTrackPanelOpen(true)
      if (_preCollapseSettingsPanelOpen) state.setSettingsPanelOpen(true)
    }
  }

  if (state.playbackState !== _prevPlaybackStateForCollapse) {
    const wasPlaying = _prevPlaybackStateForCollapse === 'playing'
    const isPlaying = state.playbackState === 'playing'
    _prevPlaybackStateForCollapse = state.playbackState

    if (isPlaying) {
      if (_restoreTimer) { clearTimeout(_restoreTimer); _restoreTimer = null }
      if (!_drawersAutoCollapsed) {
        _preCollapseTrackPanelOpen = state.trackPanelOpen
        _preCollapseSettingsPanelOpen = state.settingsPanelOpen
        _drawersAutoCollapsed = true
        if (state.trackPanelOpen) state.setTrackPanelOpen(false)
        if (state.settingsPanelOpen) state.setSettingsPanelOpen(false)
      }
    } else if (wasPlaying && _drawersAutoCollapsed) {
      if (_restoreTimer) clearTimeout(_restoreTimer)
      _restoreTimer = setTimeout(() => {
        _restoreTimer = null
        if (useStore.getState().playbackState === 'playing') return // was just a blip
        _drawersAutoCollapsed = false
        if (_preCollapseTrackPanelOpen) useStore.getState().setTrackPanelOpen(true)
        if (_preCollapseSettingsPanelOpen) useStore.getState().setSettingsPanelOpen(true)
      }, RESTORE_DEBOUNCE_MS)
    }
  }
})

// ── HMR safety — this module registers module-scope useStore.subscribe()
// listeners above. Vite hot-reloading this file re-runs all of that top-level
// code without tearing down the previous run's subscriptions first, so
// repeated edits during a dev session accumulate duplicate listeners, each
// with its own stale closure state (e.g. _drawersAutoCollapsed out of sync
// with a newer copy) — fighting each other and visibly flickering panel
// open/close state. Disposing the old module's subscriptions before Vite
// swaps it in prevents that pile-up. ──────────────────────────────────────────
if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    _unsubFav()
    _unsubPrefs()
    _unsubCollapse()
    if (_restoreTimer) clearTimeout(_restoreTimer)
  })
}

// ── Theme ─────────────────────────────────────────────────────────────────────
// Exported so PianoRoll and App.tsx can read it without subscribing to full store
export type AppTheme = 'dark' | 'warm'

/** The open song's Tap Tempo correction in song time (stored in the file's own
 *  seconds; a song opened with its empty bars skipped runs earlier) */
export function currentCorrection(s: Pick<OrfeoStore, 'songKey' | 'tempoCorrections' | 'midi'>): SongTempoCorrection | null {
  const c = s.songKey ? s.tempoCorrections[s.songKey] : undefined
  if (!c) return null
  const lead = s.midi?._leadSec ?? 0
  return lead ? correctionToSong(c, lead) : c
}
