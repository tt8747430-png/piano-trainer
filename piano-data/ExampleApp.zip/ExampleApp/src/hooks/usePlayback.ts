import { useEffect, useRef, useCallback } from 'react'
import { useStore } from '../store'
import { startCountIn } from '../utils/countInRunner'
import { practiceActive, startPractice, pausePractice, stopPractice } from '../practice/practice'

export function usePlayback() {
  const rafRef = useRef<number | null>(null)
  const isRunningRef = useRef(false)
  // Fallback clock when JZZ player not available yet
  const fallbackStartPerfRef = useRef(0)
  const fallbackStartTimeRef = useRef(0)

  const stopRaf = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
    isRunningRef.current = false
  }, [])

  const startRaf = useCallback(() => {
    stopRaf()
    isRunningRef.current = true
    const { bpm, originalBpm, currentTime } = useStore.getState()
    fallbackStartPerfRef.current = performance.now()
    fallbackStartTimeRef.current = currentTime
    const ratio = bpm / originalBpm

    const tick = () => {
      if (!isRunningRef.current) return
      const { playbackState, midi } = useStore.getState()
      if (playbackState !== 'playing') { stopRaf(); return }

      const player = (window as any).__orfeoPlayer
      if (player) {
        // Sync from JZZ player clock
        try {
          const ms = player.positionMS()
          if (typeof ms === 'number' && ms >= 0) {
            const secs = ms / 1000
            const duration = midi?.duration ?? 0
            const { loopRegionActive, loopStart, loopEnd } = useStore.getState()

            // ── Loop region seek — fires before end-of-file check ──────────────
            if (loopRegionActive && loopStart !== null && loopEnd !== null && secs >= loopEnd) {
              try { player.play(); player.jumpMS(Math.floor(loopStart * 1000)) } catch {}
              fallbackStartPerfRef.current = performance.now()
              fallbackStartTimeRef.current = loopStart
              useStore.setState({ currentTime: loopStart })
              rafRef.current = requestAnimationFrame(tick)
              return
            }

            if (secs >= duration && duration > 0) {
              // ── Entire-file loop when active with no region set ────────────
              if (loopRegionActive) {
                try { player.play(); player.jumpMS(0) } catch {}
                fallbackStartPerfRef.current = performance.now()
                fallbackStartTimeRef.current = 0
                useStore.setState({ currentTime: 0 })
                rafRef.current = requestAnimationFrame(tick)
                return
              }
              useStore.setState({ currentTime: duration, playbackState: 'stopped' })
              stopRaf(); return
            }
            useStore.setState({ currentTime: secs })
            rafRef.current = requestAnimationFrame(tick)
            return
          }
        } catch {}
      }

      // Fallback: performance.now() based clock
      const elapsed = (performance.now() - fallbackStartPerfRef.current) / 1000
      const newTime = fallbackStartTimeRef.current + elapsed * ratio
      const duration = midi?.duration ?? 0
      const { loopRegionActive, loopStart, loopEnd } = useStore.getState()

      // ── Loop region seek (fallback/samples path) ─────────────────────────
      if (loopRegionActive && loopStart !== null && loopEnd !== null && newTime >= loopEnd) {
        stopRaf()
        useStore.setState({ currentTime: loopStart, playbackState: 'paused' })
        Promise.resolve().then(() => useStore.setState({ playbackState: 'playing' }))
        return
      }

      if (newTime >= duration && duration > 0) {
        // ── Entire-file loop (fallback/samples path) ────────────────────────
        if (loopRegionActive) {
          stopRaf()
          useStore.setState({ currentTime: 0, playbackState: 'paused' })
          Promise.resolve().then(() => useStore.setState({ playbackState: 'playing' }))
          return
        }
        useStore.setState({ currentTime: duration, playbackState: 'stopped' })
        stopRaf(); return
      }
      useStore.setState({ currentTime: newTime })
      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)
  }, [stopRaf])

  const play = useCallback(async () => {
    // user-started play: count in first when that's switched on (the runner
    // starts playback itself, exactly one beat after its last click)
    // Practice mode on: the practice run plays the song instead
    if (practiceActive()) { startPractice(); return }
    if (startCountIn()) return
    useStore.setState({ playbackState: 'playing' })
    startRaf()
  }, [startRaf])

  const pause = useCallback(() => {
    pausePractice()
    stopRaf()
    useStore.setState({ playbackState: 'paused' })
  }, [stopRaf])

  const stop = useCallback(() => {
    stopPractice()
    stopRaf()
    useStore.setState({ playbackState: 'stopped', currentTime: 0 })
  }, [stopRaf])

  const seek = useCallback((timeSec: number) => {
    const clamped = Math.max(0, timeSec)
    const wasPlaying = useStore.getState().playbackState === 'playing'
    stopRaf()
    if (wasPlaying) {
      useStore.setState({ currentTime: clamped, playbackState: 'paused' })
    } else {
      useStore.setState({ currentTime: clamped })
    }
  }, [stopRaf])

  const seekAndPlay = useCallback((timeSec: number) => {
    const clamped = Math.max(0, timeSec)
    stopRaf()
    // useAudioEngine only rebuilds/repositions the actual player on a real
    // playbackState transition INTO 'playing' (ps === 'playing' && pp !==
    // 'playing') — setting playbackState straight to 'playing' while it's
    // already 'playing' (the common case: skip/scrub while mid-playback) is
    // a no-op transition, so the store's currentTime jumps but the real
    // player keeps going from its old position. Force a brief 'paused' blip
    // first so there's always a genuine transition to rebuild from, same
    // trick PianoRoll's wheel-scrub handler already uses (and which is the
    // only reason wheel-scrub-while-playing actually works today).
    useStore.setState({ playbackState: 'paused' })
    setTimeout(() => {
      fallbackStartPerfRef.current = performance.now()
      fallbackStartTimeRef.current = clamped
      useStore.setState({ currentTime: clamped, playbackState: 'playing' })
      startRaf()
    }, 20)
  }, [stopRaf, startRaf])

  // Watch for external state changes
  useEffect(() => {
    const unsub = useStore.subscribe((state, prev) => {
      if (state.playbackState === 'playing' && prev.playbackState !== 'playing') {
        fallbackStartPerfRef.current = performance.now()
        fallbackStartTimeRef.current = state.currentTime
        startRaf()
      }
      if (state.playbackState !== 'playing' && prev.playbackState === 'playing') {
        stopRaf()
      }
    })
    return unsub
  }, [startRaf, stopRaf])

  useEffect(() => () => stopRaf(), [stopRaf])

  return { play, pause, stop, seek, seekAndPlay }
}