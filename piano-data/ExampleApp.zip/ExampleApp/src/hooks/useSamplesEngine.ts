// ── Samples audio engine — spessasynth_lib + GeneralUser GS SF2 ──────────────
// Self-gates on audioEngine !== 'samples'. Loads the soundfont once via fetch
// and caches the synth for the lifetime of the app.
//
// WorkletSynthesizer is imported DYNAMICALLY inside initSamplesEngine so that
// spessasynth_lib is never bundled at app startup (prevents Vite dep-
// optimisation reload when spessasynth_core is encountered for the first time).

import { useEffect } from 'react'
import type { WorkletSynthesizer } from 'spessasynth_lib'
import { useStore } from '../store'
import { pushHitEffect, amberHex } from '../utils/hitEffectQueue'
import { isHomogeneousHandTrack, resolveHandAwareColor } from '../utils/handColors'
import { NES } from '../utils/noteEditorState'
import { programTimeline, programAt } from '../audio/programTimeline'
import { volumeAt, expressionAt, valueAt, volumeRatio } from '../audio/songVolume'
import { useMidiSettings, latencyOffsetSec, midiPrefsReady } from '../store/midiSettings'
import { isShown } from '../utils/trackShown'

// ── Live edit-buffer awareness — mirrors useAudioEngine.ts's activeMidiData().
// Gated on NES.dirty, not just NES.editMidi being non-null — the edit buffer
// exists the instant edit mode opens, before any real edit happens, and
// routing through it unconditionally broke audio the moment the toolbar
// opened (see useAudioEngine.ts for the full explanation). Only reroute once
// there's an actual edit worth protecting. ─────────────────────────────────
function activeMidiData(): any {
  return (NES.dirty && NES.editMidi) ? NES.editMidi : useStore.getState().midi
}

// ── GeneralUser GS outputs at a lower reference level than jzz-synth-tiny.
// This constant normalises perceived loudness at equal masterVolume settings.
export const SAMPLES_BOOST = 3.0

// ── Master compressor/limiter presets — each position bundles threshold,
// ratio, attack, AND release together, not just a ratio sweep with threshold
// fixed. A fixed threshold with only ratio changing either barely engages at
// low ratio or over-triggers at high ratio, so the 5 positions wouldn't
// actually sound distinct from each other. Index matches masterCompPreset
// in the store. Release fixed at 250ms across all — attack is what changes
// the felt character between "gentle glue" and "hard limiter".
//
// makeupDb — a compressor only ever pulls loud peaks DOWN toward its
// threshold; a DynamicsCompressorNode has no built-in makeup-gain stage, so
// on its own it does nothing for a passage that's just genuinely played
// quiet (real case: a file whose note velocities dip hard for a passage —
// no amount of ratio/threshold tweaking brings that back up, since there's
// nothing above the threshold there to compress). A gain boost, scaled to
// roughly how hard each preset squashes the loud parts, is what actually
// closes that gap — quiet passages end up louder in absolute terms even
// though the compressor itself never touched them. Values kept modest
// (halved from the first pass) and — critically — applied BEFORE _compNode,
// not after: see the chain-wiring comment below for why the original
// after-compressor placement caused audible clipping/distortion on any
// transient the compressor's attack hadn't fully caught yet (e.g. a fast
// glissando run into a loud downbeat), and why fixing the order is what
// actually caps that, not just lowering these numbers. ─────────────────────
interface CompPreset { threshold: number; ratio: number; attack: number; knee: number; makeupDb: number; label: string }
export const COMPRESSOR_PRESETS: CompPreset[] = [
  { label: 'Safety',  threshold: -1,  ratio: 2,  attack: 0.010, knee: 10, makeupDb: 0.5 },
  { label: 'Gentle',  threshold: -6,  ratio: 4,  attack: 0.008, knee: 8,  makeupDb: 1.5 },
  { label: 'Medium',  threshold: -12, ratio: 8,  attack: 0.005, knee: 6,  makeupDb: 3 },
  { label: 'Firm',    threshold: -18, ratio: 14, attack: 0.003, knee: 3,  makeupDb: 4.5 },
  { label: 'Limiter', threshold: -24, ratio: 20, attack: 0.003, knee: 0,  makeupDb: 6 },
]
export const COMPRESSOR_RELEASE = 0.25
const dbToGain = (db: number) => Math.pow(10, db / 20)

// ── Auto-Level (AGC) — static makeup gain (above) only ever applies a flat
// offset; it can't close a genuinely wide gap between a loud passage and a
// quiet one (real case this was built for: a file whose note velocities
// crash for a whole passage — a plain downward compressor never crosses
// threshold there at all, so neither compression nor a fixed makeup-gain
// value can lift it, only shift everything by the same fixed amount). This
// is a real closed-loop auto-gain instead: an AnalyserNode continuously
// measures RMS loudness of the (already-gain-adjusted) signal, compared
// against a target, and the error smoothly drives a GainNode via a slow time
// constant.
//
// Scoped to whole-SONG loudness drift, not individual notes/runs — this is
// the point of the slow time constants below, not an incidental detail.
// The first pass used a 0.6s attack and a 26dB max boost, which is fast and
// big enough to chase a single quiet passage of well under a second (a fast
// ornamental run like a glissando, or a bar of sparse notes before a
// downbeat) most of the way to full boost — so a loud hit landing right
// after one got amplified on top of whatever the compressor could catch,
// producing audible clipping/distortion. Multi-second time constants mean
// a poll 100ms into a quiet run moves the gain only a few percent of the
// way there — real per-tick correction targets still get computed off a
// single ~46ms analyser window (fftSize below), but the GAIN itself can't
// physically get anywhere close to a large correction within one bar, only
// across a genuinely sustained passage. That's what makes this "song-level"
// rather than "note-level" — not a maximum-boost cap alone. ─────────────────
let _agcGainNode: GainNode | null = null
let _analyserNode: AnalyserNode | null = null
let _agcTimer: ReturnType<typeof setInterval> | null = null
const AGC_TARGET_DB = -18
const AGC_NOISE_FLOOR_DB = -50   // below this, treat as silence/rest — hold gain, don't chase noise
const AGC_MAX_BOOST_DB = 9
const AGC_MAX_CUT_DB = 4
// Asymmetric, like a real leveler: catch up to a quiet passage faster than
// easing back down out of a loud one — but both now measured in several
// seconds, not fractions of one, so a single fast passage can't swing this.
const AGC_TIME_CONSTANT_UP = 3.0    // boosting (quiet passage) — seconds
const AGC_TIME_CONSTANT_DOWN = 5.0  // cutting (loud passage) — seconds
const AGC_POLL_MS = 100

// ── Module-level singletons ───────────────────────────────────────────────────
let _ctx: AudioContext | null = null
let _gainNode: GainNode | null = null
// High-shelf BiquadFilter for master tone control (Samples engine only)
let _filterNode: BiquadFilterNode | null = null
// User-facing compressor — presets/on-off from MasterStrip. NOT the last
// thing in the chain (see _safetyLimiterNode below) — this is tone-shaping
// the user opts into, not the thing that keeps output out of digital
// clipping. Confirmed by direct measurement: a dense 10-track arrangement
// (real case — "Abba - Dancing Queen") clips (peaks well past ±1.0) even
// with this compressor fully OFF (ratio 1:1/threshold 0dB, a mathematical
// no-op) — the raw synth+SAMPLES_BOOST signal is hot enough on its own to
// overload on a loud passage, regardless of anything this node does.
let _compNode: DynamicsCompressorNode | null = null
// Makeup gain — sits right before _compNode (see COMPRESSOR_PRESETS.makeupDb).
let _compMakeupNode: GainNode | null = null
// ── Safety limiter — the ACTUAL last stage before destination, always on
// regardless of masterCompEnabled/preset. A brick-wall limiter (near-20:1
// ratio, near-0 attack, threshold just under 0dBFS) that exists purely to
// stop digital clipping, not to shape tone — the user's own _compNode
// above is a completely separate, optional, musical decision (glue/
// character) that this doesn't replace or depend on. Needed because
// nothing upstream — not _gainNode's SAMPLES_BOOST, not the user
// compressor even at its most aggressive preset, not the AGC/makeup gain —
// actually guarantees output stays under 0dBFS on its own; only a real
// limiter as the final node can. ────────────────────────────────────────
let _safetyLimiterNode: DynamicsCompressorNode | null = null
// type-only — runtime reference populated after dynamic import
let _synth: WorkletSynthesizer | null = null
let _synthInitP: Promise<void> | null = null
let _synthReady = false
// ── Extra downloadable soundfont currently layered over GeneralUser-GS ──────
// null = only the bundled default is loaded. See loadSelectedSoundfont().
let _activeExtraBankId: string | null = null
// ── Tracks which channels have had programChange sent since last buildSamplesPlayer ──
// SpessaSynth defaults every channel to program 0 (piano). Before first playback,
// edit-mode clicks must send programChange themselves — this set prevents redundant calls.
const _samplesChanInit = new Set<number>()

// ── Real, measured gap between "scheduled to play" and "actually audible"
// (AudioContext.outputLatency — includes the OS/device's own output buffer;
// falls back to baseLatency, which only covers the context's own internal
// processing, on a browser/build that doesn't expose outputLatency). Used to
// delay VISUAL feedback (key lights, hit effects, the chord name — see
// Keyboard.tsx) so it lines up with what's actually heard, not with when the
// note was merely told to play. Exported so Keyboard.tsx's chord-name
// display can apply the same correction. ────────────────────────────────
export function getOutputLatencySec(): number {
  const measured = getMeasuredOutputLatencySec()
  return Math.max(0, measured + latencyOffsetSec())
}
// Raw device figure, without the user's manual offset (Settings readouts)
export function getMeasuredOutputLatencySec(): number {
  return _ctx?.outputLatency || _ctx?.baseLatency || 0
}

// ── Live-playing path — notes from the player's own MIDI keyboard ──────────
// Every DynamicsCompressorNode delays its output by a fixed 6 ms look-ahead
// (measured: impulse in at 0 ms, out at exactly 6.00 ms, even at ratio 1:1),
// so the master chain's compressor + safety limiter cost 12 ms on every
// note. Fine for song playback, wrong for a key being played live. The
// synth's worklet has one output per MIDI channel (0 = reverb/chorus,
// 1..16 = channels 0..15), so channel 15 — the live/preview channel — can
// take its own short path: gain → tone → zero-delay soft clip → speakers.
// Songs that put a real track on channel 15 keep it on the full chain
// (see applyLiveRouting) so that track still gets compressed/levelled.
const LIVE_CH = 15
const LIVE_OUTPUT = LIVE_CH + 1
let _liveGainNode: GainNode | null = null
let _liveFilterNode: BiquadFilterNode | null = null
let _liveClipNode: WaveShaperNode | null = null
let _liveRoutedDirect: boolean | null = null
// Set when song playback reprograms channel 15; the next live note restores piano
let _liveProgramDirty = true

// Linear up to 0.8, then a smooth knee that never exceeds 1.0 — transparent
// at normal playing levels, only shapes a hard 10-finger chord's peaks.
// oversample 'none' keeps it zero-delay.
function softClipCurve(): Float32Array<ArrayBuffer> {
  const n = 2049, curve = new Float32Array(n), knee = 0.8
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1, a = Math.abs(x)
    const y = a <= knee ? a : knee + (1 - knee) * Math.tanh((a - knee) / (1 - knee))
    curve[i] = Math.sign(x) * y
  }
  return curve
}

// ── Wire channel 15 to the live path or the full chain. Called at init, when
// the Live playing response setting changes, and when a song loads. ───────
export function applyLiveRouting(): void {
  const worklet = (_synth as any)?.worklet as AudioWorkletNode | undefined
  if (!worklet || !_gainNode || !_liveGainNode) return
  const midi = useStore.getState().midi as any
  const songUsesLiveCh = !!midi?.tracks?.some((t: any) => t.channel === LIVE_CH && !t.isDrum && t.notes?.length)
  const direct = useMidiSettings.getState().liveResponse !== 'balanced' && !songUsesLiveCh
  if (direct === _liveRoutedDirect) return
  try { worklet.disconnect(LIVE_OUTPUT) } catch {}
  worklet.connect(direct ? _liveGainNode : _gainNode, LIVE_OUTPUT)
  _liveRoutedDirect = direct
}

// Extra delay Orfeo itself adds to a live key right now (0 or 12 ms) — Settings
export function getLiveChainDelaySec(): number {
  return _liveRoutedDirect === false ? 0.012 : 0
}
// One synth processing block (128 samples) — the most a note can wait for its turn
export function getSynthBlockSec(): number {
  return _ctx ? 128 / _ctx.sampleRate : 0
}
// Whether the running sound engine was started with the larger Stable buffer
// (null = not started yet). The setting itself only applies on the next start.
let _startedStable: boolean | null = null
export function getStartedStable(): boolean | null { return _startedStable }
export function getSamplesSampleRate(): number {
  return _ctx?.sampleRate ?? 0
}
// The browser's own sound buffer for this output (Settings readout)
export function getSamplesBufferSec(): number {
  return _ctx?.baseLatency ?? 0
}

function ensureLiveChannel() {
  if (!_synth || !_liveProgramDirty) return
  try { _synth.programChange(LIVE_CH, 0) } catch {}
  _liveProgramDirty = false
}

// ── Live keyboard input — called straight from the MIDI message handler, before
// any screen update, so nothing queues ahead of the sound. ─────────────────
export function liveNoteOn(midiNum: number, vel127: number): void {
  if (!_synth || !_synthReady) return
  ensureLiveChannel()
  _synth.noteOn(LIVE_CH, midiNum, vel127)
}
export function liveNoteOff(midiNum: number): void {
  if (!_synth || !_synthReady) return
  _synth.noteOff(LIVE_CH, midiNum)
}
// Pedals, wheels, pressure — on the live channel
export function liveControl(cc: number, value: number): void {
  if (!_synth || !_synthReady) return
  try { ;(_synth as any).controllerChange(LIVE_CH, cc, value) } catch {}
}
export function livePitchBend(value14: number): void {
  if (!_synth || !_synthReady) return
  try { _synth.pitchWheel(LIVE_CH, value14) } catch {}
}
export function liveChannelPressure(value: number): void {
  if (!_synth || !_synthReady) return
  try { _synth.channelPressure(LIVE_CH, value) } catch {}
}
export function livePolyPressure(midiNum: number, value: number): void {
  if (!_synth || !_synthReady) return
  try { _synth.polyPressure(LIVE_CH, midiNum, value) } catch {}
}
// Clear stuck notes: everything on the live channel released, pedals up,
// wheels centred, pressure off
export function liveReset(): void {
  if (!_synth || !_synthReady) return
  try {
    for (const cc of [64, 66, 67, 1]) (_synth as any).controllerChange(LIVE_CH, cc, 0)
    ;(_synth as any).controllerChange(LIVE_CH, 11, 127)
    _synth.pitchWheel(LIVE_CH, 8192)
    _synth.channelPressure(LIVE_CH, 0)
    ;(_synth as any).controllerChange(LIVE_CH, 123, 0)
  } catch {}
}

// ── Per-note key-light timers ─────────────────────────────────────────────────
const _keyTimers = new Map<number, ReturnType<typeof setTimeout>>()

// ── setTimeout handles for the note schedule ──────────────────────────────────
const _schedule: ReturnType<typeof setTimeout>[] = []

// ── Rolling lookahead scheduling ──────────────────────────────────────────
// How far ahead (real seconds) buildSamplesPlayer keeps scheduled at any
// moment, and how often it tops that back up. Previously the whole REST OF
// THE SONG was scheduled in one synchronous burst at playback start — for a
// real file that's tens of thousands of individual timers (one each for
// every note-on, note-off, and key light) all in flight at once. Harmless
// while they're spread out over the song, but whenever the music itself
// puts a lot of them due at nearly the same instant — a full section
// landing together, a rich chord — the browser has to fire that whole
// cluster one at a time on its one JS thread, which is exactly the
// "stutters every bar or so" bug this fixes (confirmed live: 20,000+ timers
// armed at once on a real file, 141 clusters of 8-11 simultaneous fires in
// under a minute of playback). Keeping only a couple of seconds scheduled
// at a time bounds how large that cluster can ever get, independent of how
// the song is written or how long it is — the standard "don't schedule the
// whole timeline up front" pattern for real-time audio/MIDI playback.
const LOOKAHEAD_SEC = 1.5
const REFILL_MS = 400

let _refillTimer: ReturnType<typeof setInterval> | null = null
// ── Frozen at the start of each scheduling run (playback start/resume/seek,
// or a live rebuild on bpm/transpose/mute/solo/visibility change) and reused
// by every refill tick until the next one — matches the original one-shot
// scheduler's behaviour exactly: a live per-track setting doesn't retroactively
// change notes already scheduled, only the next rebuild does. ────────────────
let _epochTracks: ReturnType<typeof useStore.getState>['tracks'] = []
let _epochMidiData: any = null
let _epochRatio = 1
let _epochTranspose = 0
let _epochHitEffectScope: ReturnType<typeof useStore.getState>['hitEffectScope'] = 'keyboard'
let _epochHasSolo = false
let _epochPerformanceMode = false
let _epochShowHandLabels = false
let _epochStartPerf = 0     // performance.now() when this scheduling run began
let _epochStartFileSec = 0  // file-native seconds at that same moment
// trackIndex -> next index into that track's notes/sustainEvents to consider.
// Both arrays are already time-ordered (parsed straight off the MIDI file),
// so a forward-only cursor per track is enough — no re-scanning already-
// scheduled notes on every refill.
const _noteCursor = new Map<number, number>()
const _sustainCursor = new Map<number, number>()
// the song's own volume (CC7) and expression (CC11) moves still to come, per track
const _volumeCursor = new Map<number, number>()
const _expressionCursor = new Map<number, number>()
// per channel, the track whose volume moves play there (for the live fader)
const _volumeTrackByCh = new Map<number, any>()
// Instrument switches still to come this run, per channel (see programTimeline)
let _programSwitches: { ch: number; time: number; program: number }[] = []
let _programCursor = 0
// trackIndex -> isHomogeneousHandTrack(track.notes), computed once per rebuild
// rather than on every refill tick — the result can't change mid-run since
// _epochMidiData itself is frozen for the run.
const _homogeneousCache = new Map<number, boolean>()

// ── Current playback position in file-native seconds, computed the same way
// usePlayback.ts's own fallback clock does (elapsed real time × tempo ratio)
// — self-contained here rather than reading the store's `currentTime` so
// refill precision isn't tied to that hook's once-per-frame update cadence. ──
function nowFileSec(): number {
  return _epochStartFileSec + ((performance.now() - _epochStartPerf) / 1000) * _epochRatio
}

// ── Light a single piano key for durMs then extinguish ───────────────────────
function lightKey(midiNum: number, color: string, durMs: number) {
  const existing = _keyTimers.get(midiNum)
  if (existing) clearTimeout(existing)
  const { activeKeys, activeKeyColors } = useStore.getState()
  const nk = new Set(activeKeys); nk.add(midiNum)
  const nc = new Map(activeKeyColors); nc.set(midiNum, color)
  useStore.setState({ activeKeys: nk, activeKeyColors: nc })
  pushHitEffect(midiNum, color)
  const timer = setTimeout(() => {
    _keyTimers.delete(midiNum)
    const { activeKeys: k, activeKeyColors: c } = useStore.getState()
    const nk2 = new Set(k); nk2.delete(midiNum)
    const nc2 = new Map(c); nc2.delete(midiNum)
    useStore.setState({ activeKeys: nk2, activeKeyColors: nc2 })
  }, Math.max(50, durMs))
  _keyTimers.set(midiNum, timer)
}

// ── Clear all active key lights ───────────────────────────────────────────────
function clearAllKeys() {
  _keyTimers.forEach(t => clearTimeout(t))
  _keyTimers.clear()
  useStore.setState({ activeKeys: new Set(), activeKeyColors: new Map() })
}

// ── CC64 = 0 on every channel — a clean pedal baseline. stopAll() kills the
// voices but leaves each channel's sustain-controller state as it was, so a
// stop mid-pedal-down would otherwise hang the next playback's first notes. ─
function resetSustainPedals() {
  if (!_synth) return
  for (let ch = 0; ch < 16; ch++) {
    try { ;(_synth as any).controllerChange(ch, 64, 0) } catch {}
  }
}

// ── Cancel all pending note timeouts and silence the synth ───────────────────
function clearSchedule() {
  _schedule.forEach(t => clearTimeout(t))
  _schedule.length = 0
  if (_refillTimer) { clearInterval(_refillTimer); _refillTimer = null }
  try { _synth?.stopAll(true) } catch {}
  resetSustainPedals()
}

// ── Hardware-input/preview channel setup — program 0, full volume on ch 15 ──
// Re-asserted on every call, not just once: channel 15 isn't actually
// reserved at the MIDI-spec level, so a loaded file with a real track on
// channel 15 (e.g. a 7th+ melodic instrument, common once a file needs
// more non-drum channels than 0-8/10-15 comfortably give it) reprograms it
// during normal playback — a real MIDI file (Bruce Hornsby - The Way It
// Is, alto sax on channel 15) hit exactly this, permanently leaving the
// Lock-a-Chord/Explorer preview channel playing sax instead of piano for
// the rest of the session. A ProgramChange is cheap enough to just always
// send. ─────────────────────────────────────────────────────────────────
function ensureHwChannel() {
  if (!_synth) return
  _liveProgramDirty = false
  try {
    _synth.programChange(15, 0)
    ;(_synth as any).controllerChange(15, 7, 127)
  } catch {}
}

// ── Send CC7=127 (max volume) to every MIDI channel ──────────────────────────
// The gain node controls master level; CC7 controls the synth's internal level.
function applyChannelVolumes() {
  if (!_synth) return
  for (let ch = 0; ch < 16; ch++) {
    try { ;(_synth as any).controllerChange(ch, 7, 127) } catch {}
  }
}

// ── Initialise AudioContext + worklet + synth + soundfont ─────────────────────
// onProgress receives 0..1 as the SF2 fetch progresses.
// WorkletSynthesizer is imported dynamically here to prevent Vite from bundling
// spessasynth_lib at startup, which triggered a dep-optimisation page reload.
export async function initSamplesEngine(onProgress: (p: number) => void): Promise<void> {
  if (_synthReady) return
  if (_synthInitP) return _synthInitP

  _synthInitP = (async () => {
    try {
      // 'interactive' is Chromium's default today, set explicitly so a future
      // default can't quietly slow live playing down. Stable playback asks
      // for the larger buffer (measured: +10 ms, fewer crackles on a busy
      // machine); read once here, so it takes effect on the next start.
      await midiPrefsReady
      const stable = useMidiSettings.getState().liveResponse === 'stable'
      _ctx = new AudioContext({ latencyHint: stable ? 'playback' : 'interactive' })
      _startedStable = stable

      // ── Worklet: use ./ relative path so it resolves correctly in both dev
      // (http://localhost:5173/spessasynth_processor.min.js) and packaged
      // (file:///…/app.asar/out/renderer/spessasynth_processor.min.js).
      // Leading / resolves to filesystem root in file:// and breaks in packaged.
      // The file must also be in asarUnpack — AudioWorklet.addModule() bypasses
      // Electron's asar protocol handler and needs the real filesystem path.
      const workletUrl = new URL('./spessasynth_processor.min.js', location.href).href
      console.log('[Orfeo Samples] loading worklet from:', workletUrl)
      await _ctx.audioWorklet.addModule(workletUrl)

      // Dynamic import keeps spessasynth_lib out of the initial bundle
      const { WorkletSynthesizer } = await import('spessasynth_lib')
      _synth = new WorkletSynthesizer(_ctx)
      await _synth.isReady
      // Diagnostic for the audio/visual sync fix — see getOutputLatencySec()
      // below. Logged once so it's visible in DevTools on any machine,
      // packaged build included, without needing a remote-debugging setup.
      console.log('[Orfeo Samples] measured output latency:', _ctx.outputLatency, 's (base latency:', _ctx.baseLatency, 's)')

      // ── SF2: same relative-path fix; fetch() goes through Electron's file://
      // protocol handler which supports asar, so no asarUnpack needed here.
      const sf2Url = new URL('./GeneralUser-GS.sf2', location.href).href
      console.log('[Orfeo Samples] fetching SF2 from:', sf2Url)
      const response = await fetch(sf2Url)
      if (!response.ok) throw new Error(`SF2 fetch failed: ${response.status} (url: ${sf2Url})`)
      const total = Number(response.headers.get('content-length') ?? 0)
      const reader = response.body!.getReader()
      const chunks: Uint8Array[] = []
      let loaded = 0
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) { chunks.push(value); loaded += value.byteLength }
        if (total > 0) onProgress(loaded / total)
      }
      const buffer = new Uint8Array(loaded)
      let offset = 0
      for (const chunk of chunks) { buffer.set(chunk, offset); offset += chunk.byteLength }

      await _synth.soundBankManager.addSoundBank(buffer.buffer, 'GeneralUser-GS')

      // Set all channels to max internal volume; gain node handles master level
      applyChannelVolumes()
      // ── Force reverb/chorus sends to 0 on every channel at init — MasterStrip's
      // Chorus/Reverb knobs default their React state to 0, but nothing was ever
      // pushing that to the synth itself, so channels sat at whatever send level
      // GeneralUser-GS/SpessaSynth defaults to (typically a non-zero GM default
      // reverb send) until the user touched a knob. That meant reverb/chorus DSP
      // ran continuously from the very first note despite the UI showing "off" —
      // real, silent CPU cost with no matching user-visible control. ────────────
      setMasterReverb(0)
      setMasterChorus(0)

      // Wire gain node — apply SAMPLES_BOOST so perceived level matches GM Synth
      _gainNode = _ctx.createGain()
      _gainNode.gain.value = useStore.getState().masterVolume * SAMPLES_BOOST

      // High-shelf tone control — inserted between gain and destination
      _filterNode = _ctx.createBiquadFilter()
      _filterNode.type = 'highshelf'
      _filterNode.frequency.value = 3000
      _filterNode.gain.value = 0  // flat at center position

      // Auto-Level (AGC) — see the block comment above where these are
      // declared. Sits between tone control and the peak compressor so the
      // compressor still catches whatever transients AGC's slow response
      // doesn't. AnalyserNode passes audio through unchanged — it's a real
      // link in the chain, not just a tap.
      _agcGainNode = _ctx.createGain()
      _agcGainNode.gain.value = 1
      _analyserNode = _ctx.createAnalyser()
      _analyserNode.fftSize = 2048
      _analyserNode.smoothingTimeConstant = 0

      // Master compressor/limiter — last stage before destination, no
      // exceptions. Always created and wired in; "off" is a real transparent
      // state (ratio 1:1, threshold 0dB — mathematically a no-op, never
      // reduces gain) rather than disconnecting/reconnecting the graph on
      // every toggle. Makeup gain sits BEFORE it (off = 0dB/gain 1 the same
      // way), not after: makeup gain first shipped applied AFTER _compNode
      // with nothing downstream to catch its output, so any transient the
      // compressor's attack hadn't fully clamped yet got amplified straight
      // through with zero further limiting — audible as clipping/distortion
      // on fast attacks (a glissando run into a loud downbeat was the
      // reported case). Putting it before the compressor instead doesn't
      // weaken the quiet-passage boost it exists for — content that's still
      // below threshold after the makeup boost passes through the
      // compressor untouched either way — but now anything the boost pushes
      // OVER threshold gets caught and controlled by the one dynamics node
      // in this chain, instead of bypassing it entirely.
      _compNode = _ctx.createDynamicsCompressor()
      _compNode.release.value = COMPRESSOR_RELEASE
      _compMakeupNode = _ctx.createGain()
      {
        const { masterCompEnabled, masterCompPreset } = useStore.getState()
        setMasterCompressor(masterCompEnabled, masterCompPreset)
      }

      // Safety limiter — see the declaration comment above. Fixed settings,
      // not user-configurable, always engaged.
      _safetyLimiterNode = _ctx.createDynamicsCompressor()
      _safetyLimiterNode.threshold.value = -1
      _safetyLimiterNode.ratio.value = 20
      _safetyLimiterNode.knee.value = 0
      _safetyLimiterNode.attack.value = 0.001
      _safetyLimiterNode.release.value = 0.05

      // Live-playing path (see applyLiveRouting) — mirrors master volume and tone
      _liveGainNode = _ctx.createGain()
      _liveGainNode.gain.value = _gainNode.gain.value
      _liveFilterNode = _ctx.createBiquadFilter()
      _liveFilterNode.type = 'highshelf'
      _liveFilterNode.frequency.value = 3000
      _liveFilterNode.gain.value = _filterNode.gain.value
      _liveClipNode = _ctx.createWaveShaper()
      _liveClipNode.curve = softClipCurve()
      _liveClipNode.oversample = 'none'
      _liveGainNode.connect(_liveFilterNode)
      _liveFilterNode.connect(_liveClipNode)
      _liveClipNode.connect(_ctx.destination)

      // Outputs 0..15 (effects + channels 0-14) always take the full chain;
      // output 16 (channel 15) is wired by applyLiveRouting
      {
        const worklet = (_synth as any).worklet as AudioWorkletNode
        for (let i = 0; i < LIVE_OUTPUT; i++) worklet.connect(_gainNode, i)
      }
      _liveRoutedDirect = null
      applyLiveRouting()
      _gainNode.connect(_filterNode)
      _filterNode.connect(_agcGainNode)
      _agcGainNode.connect(_analyserNode)
      _analyserNode.connect(_compMakeupNode)
      _compMakeupNode.connect(_compNode)
      _compNode.connect(_safetyLimiterNode)
      _safetyLimiterNode.connect(_ctx.destination)

      startAgcLoop()

      _synthReady = true
      onProgress(1)
      console.log('[Orfeo Samples] spessasynth ready')

      const wanted = useStore.getState().selectedSoundfont
      if (wanted !== 'generaluser-gs') loadSelectedSoundfont(wanted).catch(() => {})
    } catch (e: any) {
      _synthInitP = null
      console.error('[Orfeo Samples] init error:', e?.message ?? e)
      throw e
    }
  })()
  return _synthInitP
}

// ── Swap the active soundfont — 'generaluser-gs' is the bundled default and
// always stays loaded; the other IDs are downloaded extras read from userData
// via IPC and layered on top with higher priority. GeneralUser-GS remains as
// fallback for any preset the extra bank doesn't cover.
export async function loadSelectedSoundfont(id: string): Promise<void> {
  if (!_synth || !_synthReady) return
  if (id === _activeExtraBankId || (id === 'generaluser-gs' && !_activeExtraBankId)) return

  if (_activeExtraBankId) {
    try { await _synth.soundBankManager.deleteSoundBank(_activeExtraBankId) } catch {}
    _activeExtraBankId = null
  }
  if (id === 'generaluser-gs') return

  const raw = await window.electronAPI.readSoundfont(id as any)
  if (!raw) { console.warn('[Orfeo Samples] soundfont not downloaded:', id); return }
  const bytes = new Uint8Array(raw)
  await _synth.soundBankManager.addSoundBank(bytes.buffer, id)
  _synth.soundBankManager.priorityOrder = [id, 'GeneralUser-GS']
  _activeExtraBankId = id
}

// ── Start a rolling scheduling run for playback beginning at startSec ────────
// usePlayback.ts handles currentTime tracking and end-of-song detection —
// this only handles note-on/off scheduling and key lighting. Does the cheap,
// track-count-proportional setup (program changes, pedal-already-down replay,
// per-track cursors) up front, schedules the first LOOKAHEAD_SEC window
// immediately, then leaves refillSchedule() running on a timer to keep
// topping that window up for as long as this playback run lasts — see the
// rolling-lookahead comment above _refillTimer for why, instead of scheduling
// every note in the file in one go here.
// ── When Orfeo's Native engine (or any other app) takes the sound card for
// itself, the browser suspends this context and never resumes it on its own:
// switching back to Samples played nothing until a restart. Woken whenever
// Samples is chosen again or starts playing. ───────────────────────────────
function wakeContext() {
  if (_ctx && _ctx.state === 'suspended') _ctx.resume().catch(() => {})
}

function buildSamplesPlayer(startSec: number) {
  if (!_synthReady || !_synth) return
  wakeContext()
  clearSchedule(); clearAllKeys()
  applyChannelVolumes()

  const { tracks, bpm, originalBpm, detectedKey, hitEffectScope, showHandLabels, handLabelMode, noteEditorActive } = useStore.getState()
  const midiData = activeMidiData()
  if (!midiData) return

  _epochTracks = tracks
  _epochMidiData = midiData
  _epochTranspose = detectedKey?.transpose ?? 0
  _epochRatio = bpm / originalBpm
  _epochHasSolo = tracks.some(t => t.solo)
  _epochPerformanceMode = handLabelMode === 'performance'
  // Note Editor's own Hand toggle governs key-light coloring while editing —
  // same split as the piano roll, see useAudioEngine.ts's identical fix.
  _epochShowHandLabels = showHandLabels || (noteEditorActive && NES.reassignHandsMode)
  _epochHitEffectScope = hitEffectScope
  _epochStartPerf = performance.now()
  ;(window as any).__orfeoEngineStartedAt = _epochStartPerf
  _epochStartFileSec = startSec

  // Program changes, and each track's starting cursor position — cheap,
  // proportional to track count rather than note count, so still fine to do
  // for the whole file up front (this was never the source of the freeze).
  _samplesChanInit.clear()
  _noteCursor.clear()
  _sustainCursor.clear()
  _volumeCursor.clear()
  _expressionCursor.clear()
  _homogeneousCache.clear()
  applyTrackMix(midiData, tracks, startSec)
  // Each channel's instrument where playback starts, then its switches to come
  // (a file track that changes instrument is split into one track per instrument)
  _programSwitches = []
  _programCursor = 0
  for (const [ch, switches] of programTimeline(midiData, tracks)) {
    try { _synth.programChange(ch, programAt(switches, startSec)) } catch {}
    _samplesChanInit.add(ch)
    if (ch === LIVE_CH) _liveProgramDirty = true
    for (const sw of switches) if (sw.time > startSec) _programSwitches.push({ ch, time: sw.time, program: sw.program })
  }
  _programSwitches.sort((a, b) => a.time - b.time)
  for (const track of midiData.tracks) {
    const ts = tracks.find(t => t.index === track.index)
    if (!ts || ts.muted || (_epochHasSolo && !ts.solo)) continue
    _homogeneousCache.set(track.index, isHomogeneousHandTrack(track.notes))

    // ── note.time and startSec are both in the file's OWN timeline (real
    // seconds at the file's original tempo) — find the first note at or
    // after startSec directly on that shared timeline, same fix as before
    // (see git history for the tempo/scrub desync this line once caused). ──
    let startIdx = track.notes.findIndex((n: any) => n.time >= startSec)
    if (startIdx === -1) startIdx = track.notes.length
    _noteCursor.set(track.index, startIdx)
    // volume/expression: the values at startSec are already set (applyTrackMix)
    for (const [cursor, ev] of [[_volumeCursor, track.volumeEvents], [_expressionCursor, track.expressionEvents]] as const) {
      if (!ev?.length) continue
      const i = ev.findIndex((e: any) => e.time > startSec)
      cursor.set(track.index, i === -1 ? ev.length : i)
    }

    // ── Sustain pedal (CC64) — if playback starts under a held pedal, set it
    // down now so the passage isn't dry. clearSchedule() already reset every
    // channel to 0. ─────────────────────────────────────────────────────────
    const sustain = track.sustainEvents
    if (sustain && sustain.length > 0) {
      let downAtStart = false
      let sIdx = 0
      for (; sIdx < sustain.length; sIdx++) {
        if (sustain[sIdx].time < startSec) { downAtStart = sustain[sIdx].down; continue }
        break
      }
      _sustainCursor.set(track.index, sIdx)
      if (downAtStart) {
        try { ;(_synth as any).controllerChange(track.channel, 64, 127) } catch {}
      }
    } else {
      _sustainCursor.set(track.index, 0)
    }
  }

  refillSchedule()
  _refillTimer = setInterval(refillSchedule, REFILL_MS)
}

// ── Top up the note/pedal schedule out to LOOKAHEAD_SEC ahead of "now" ───────
// Called once immediately when a scheduling run starts, then on its own
// timer for as long as that run lasts. Each call only schedules whatever
// newly falls inside the window — the per-track cursors mean already-
// scheduled notes are never revisited, so steady-state cost is proportional
// to how much of the song plays in one REFILL_MS tick, not to the song's
// total length or note count.
function refillSchedule() {
  if (!_synth || !_epochMidiData) return
  const targetFileSec = nowFileSec() + LOOKAHEAD_SEC * _epochRatio

  // Instrument switches first, a few ms ahead, so the new instrument's first note gets it
  while (_programCursor < _programSwitches.length && _programSwitches[_programCursor].time < targetFileSec) {
    const sw = _programSwitches[_programCursor++]
    const delay = Math.max(0, (sw.time - nowFileSec()) / _epochRatio * 1000 - 5)
    _schedule.push(setTimeout(() => { try { _synth?.programChange(sw.ch, sw.program) } catch {} }, delay))
  }

  for (const track of _epochMidiData.tracks) {
    const ts = _epochTracks.find(t => t.index === track.index)
    // a track you hear; whether it lights the keyboard is what the roll shows
    // (trackShown.ts, below) — a hidden track plays along without lighting
    if (!ts || ts.muted || (_epochHasSolo && !ts.solo)) continue
    const defaultColor = ts.color ?? amberHex()
    const homogeneousTrack = _homogeneousCache.get(track.index) ?? false
    const ch = track.channel

    let cursor = _noteCursor.get(track.index) ?? track.notes.length
    while (cursor < track.notes.length && track.notes[cursor].time < targetFileSec) {
      const note = track.notes[cursor]
      cursor++
      const delay = Math.max(0, (note.time - nowFileSec()) / _epochRatio * 1000)
      const durMs = Math.max(note.duration / _epochRatio * 1000, 40)
      const midiNum = note.midi + _epochTranspose
      const color = resolveHandAwareColor(note, defaultColor, { homogeneousTrack, showHandLabels: _epochShowHandLabels, performanceMode: _epochPerformanceMode })

      _schedule.push(setTimeout(() => {
        if (!_synth) return
        try {
          _synth.noteOn(ch, midiNum, Math.round(note.velocity * 127))
          const offT = setTimeout(() => { try { _synth?.noteOff(ch, midiNum) } catch {} }, durMs)
          _schedule.push(offT)
        } catch (e) {
          console.error('[Orfeo Samples] noteOn error:', e)
        }
      }, delay))

      // ── Visual feedback (key light / hit effect) fires separately from the
      // note-on above, delayed by the audio device's own output latency —
      // the gap between "told the sound card to play this" and the sound
      // actually reaching the speakers (AudioContext.outputLatency, real and
      // measured). Without this, the keyboard lights and the chord name (see
      // getAudioOutputLatencySec() in Keyboard.tsx) visibly lead what you
      // actually hear by however much the output device buffers. "Lit on
      // keyboard" only actually lights the keyboard while the track is also
      // visible on the piano roll; "all tracks" hit-effect scope likewise
      // still requires visibility. ─────────────────────────────────────────
      const vt = setTimeout(() => {
        if (ts.showOnKeyboard && isShown(ts, _epochHasSolo)) lightKey(midiNum, color, Math.min(durMs + 30, 2500))
        else if (_epochHitEffectScope === 'all' && isShown(ts, _epochHasSolo)) pushHitEffect(midiNum, color)
      }, delay + getOutputLatencySec() * 1000)
      _schedule.push(vt)
    }
    _noteCursor.set(track.index, cursor)

    const sustain = track.sustainEvents
    if (sustain && sustain.length > 0) {
      let sCursor = _sustainCursor.get(track.index) ?? sustain.length
      while (sCursor < sustain.length && sustain[sCursor].time < targetFileSec) {
        const ev = sustain[sCursor]
        sCursor++
        const delay = Math.max(0, (ev.time - nowFileSec()) / _epochRatio * 1000)
        const pedT = setTimeout(() => {
          try { ;(_synth as any)?.controllerChange(ch, 64, ev.down ? 127 : 0) } catch {}
        }, delay)
        _schedule.push(pedT)
      }
      _sustainCursor.set(track.index, sCursor)
    }

    // ── The song's volume and expression moves; volume under the fader as it is when each plays
    for (const [cursor, ev, cc] of [[_volumeCursor, track.volumeEvents, 7], [_expressionCursor, track.expressionEvents, 11]] as const) {
      if (!ev?.length) continue
      let c = cursor.get(track.index) ?? ev.length
      while (c < ev.length && ev[c].time < targetFileSec) {
        const e = ev[c++]
        const delay = Math.max(0, (e.time - nowFileSec()) / _epochRatio * 1000)
        const trackIndex = track.index
        _schedule.push(setTimeout(() => {
          const fader = useStore.getState().tracks.find(t => t.index === trackIndex)?.volume ?? 1
          const v = cc === 7 ? volumeAt(track, fader, e.time) : e.value
          try { ;(_synth as any)?.controllerChange(ch, cc, Math.round(v * 127)) } catch {}
        }, delay))
      }
      cursor.set(track.index, c)
    }
  }
}

// ── Master Chorus/Reverb knob, once touched, overrides every channel's own
// send (the per-track mix pushed at play start included) — same as Native ──
let _masterChorus: number | null = null
let _masterReverb: number | null = null

// ── applyTrackMix — each track's volume, pan, reverb and chorus as the
// Console shows them (seeded from the file's own CC7/10/91/93 on load). Pushed
// at every play start: until this existed the synth only heard them once a
// knob was moved, so every song played at full volume, centred and dry. ────
function applyTrackMix(midiData: any, tracks: ReturnType<typeof useStore.getState>['tracks'], startSec = 0): void {
  _volumeTrackByCh.clear()
  for (const track of midiData.tracks) {
    const ts = tracks.find(t => t.index === track.index)
    if (!ts) continue
    const ch = track.channel
    const cc = (n: number, v: number) => { try { ;(_synth as any).controllerChange(ch, n, Math.round(Math.max(0, Math.min(1, v)) * 127)) } catch {} }
    // the song's volume and expression where playback starts (songVolume.ts)
    cc(7, volumeAt(track, ts.volume, startSec))
    cc(11, expressionAt(track, startSec))
    if (track.volumeEvents?.length && !_volumeTrackByCh.has(ch)) _volumeTrackByCh.set(ch, track)
    try { ;(_synth as any).controllerChange(ch, 10, Math.round(Math.max(0, Math.min(127, ((ts.pan ?? 0) + 1) * 63.5)))) } catch {}
    cc(91, _masterReverb ?? ts.reverb ?? 0)
    cc(93, _masterChorus ?? ts.chorus ?? 0)
  }
}

// ── setMasterChorus — broadcast CC93 to all 16 channels (Samples engine only) ─
export function setMasterChorus(value: number): void {
  if (!_synth || !_synthReady) return
  _masterChorus = value
  const val = Math.round(Math.max(0, Math.min(1, value)) * 127)
  for (let ch = 0; ch < 16; ch++) {
    try { ;(_synth as any).controllerChange(ch, 93, val) } catch {}
  }
}

// ── setMasterReverb — broadcast CC91 to all 16 channels (Samples engine only) ─
export function setMasterReverb(value: number): void {
  if (!_synth || !_synthReady) return
  _masterReverb = value
  const val = Math.round(Math.max(0, Math.min(1, value)) * 127)
  for (let ch = 0; ch < 16; ch++) {
    try { ;(_synth as any).controllerChange(ch, 91, val) } catch {}
  }
}

// ── setMasterPan — broadcast CC10 to all 16 channels (Samples engine only) ────
// value: −1…+1 (bipolar knob); 0 = center; maps to CC10 0–127 (64 = center)
export function setMasterPan(value: number): void {
  if (!_synth || !_synthReady) return
  const val = Math.round(((value + 1) / 2) * 127)
  for (let ch = 0; ch < 16; ch++) {
    try { ;(_synth as any).controllerChange(ch, 10, val) } catch {}
  }
}

// ── setMasterTone — adjust high-shelf filter gain ±12 dB (Samples engine only) ─
// value: −1…+1 (bipolar knob); 0 = flat; +1 = +12 dB treble boost
export function setMasterTone(value: number): void {
  if (!_filterNode) return
  _filterNode.gain.value = value * 12
  if (_liveFilterNode) _liveFilterNode.gain.value = value * 12
}

// ── setMasterCompressor — called on/off/preset change from MasterStrip, and
// once at init time with the store's starting values. "Off" sets ratio 1:1 /
// threshold 0dB, a real transparent no-op (never reduces gain) rather than a
// bypass-via-reconnect — avoids rewiring the graph on every toggle. ────────
export function setMasterCompressor(enabled: boolean, preset: number): void {
  if (!_compNode) return
  const p = enabled ? COMPRESSOR_PRESETS[preset] : null
  const now = _compNode.context.currentTime
  const threshold = p ? p.threshold : 0
  const ratio     = p ? p.ratio     : 1
  const attack    = p ? p.attack    : 0.003
  const knee      = p ? p.knee      : 0
  _compNode.threshold.setTargetAtTime(threshold, now, 0.01)
  _compNode.ratio.setTargetAtTime(ratio, now, 0.01)
  _compNode.attack.setTargetAtTime(attack, now, 0.01)
  _compNode.knee.setTargetAtTime(knee, now, 0.01)
  _compMakeupNode?.gain.setTargetAtTime(dbToGain(p ? p.makeupDb : 0), now, 0.01)
}

// ── getMasterCompReduction — live gain reduction in dB (0 = none, negative =
// reducing), for the master-knob/track-fader visual-dip gimmick. Real-time,
// unsmoothed — callers should lerp toward this each frame, not use it raw. ──
export function getMasterCompReduction(): number {
  return _compNode?.reduction ?? 0
}

// ── startAgcLoop — the closed-loop auto-gain poll (see the AGC block
// comment near the module-level declarations for why this exists). Started
// once at init and left running for the app's lifetime, same as every other
// node here — when the compressor's off it just eases _agcGainNode back to
// unity every tick rather than stopping, so there's no separate start/stop
// wiring to keep in sync with setMasterCompressor. ──────────────────────────
function startAgcLoop(): void {
  if (_agcTimer || !_analyserNode || !_agcGainNode) return
  const buf = new Float32Array(_analyserNode.fftSize)
  _agcTimer = setInterval(() => {
    const analyser = _analyserNode, agc = _agcGainNode, ctx = _ctx
    if (!analyser || !agc || !ctx) return
    const now = ctx.currentTime
    // Direction is current gain vs. where we're headed, not the sign of the
    // correction alone — e.g. easing off an existing boost is still a "down"
    // move even though the passage is still quieter than target.
    const moveTo = (targetGain: number) => {
      const tc = targetGain > agc.gain.value ? AGC_TIME_CONSTANT_UP : AGC_TIME_CONSTANT_DOWN
      agc.gain.setTargetAtTime(targetGain, now, tc)
    }
    if (!useStore.getState().masterCompEnabled) {
      moveTo(1)
      return
    }
    analyser.getFloatTimeDomainData(buf)
    let sumSquares = 0
    for (let i = 0; i < buf.length; i++) sumSquares += buf[i] * buf[i]
    const rms = Math.sqrt(sumSquares / buf.length)
    if (rms <= 0) return // true digital silence — hold current gain
    const rmsDb = 20 * Math.log10(rms)
    if (rmsDb < AGC_NOISE_FLOOR_DB) return // rest/near-silence — don't chase noise floor
    const correctionDb = Math.max(-AGC_MAX_CUT_DB, Math.min(AGC_MAX_BOOST_DB, AGC_TARGET_DB - rmsDb))
    moveTo(dbToGain(correctionDb))
  }, AGC_POLL_MS)
}

// ── setChannelChorus — CC93 on a single MIDI channel (Samples engine only) ────
// ch: track.channel from the parsed MIDI file (0-based, NOT trackIndex)
export function setChannelChorus(ch: number, value: number): void {
  if (!_synth || !_synthReady) return
  const val = Math.round(Math.max(0, Math.min(1, value)) * 127)
  try { ;(_synth as any).controllerChange(ch, 93, val) } catch {}
}

// ── setChannelReverb — CC91 on a single MIDI channel (Samples engine only) ────
export function setChannelReverb(ch: number, value: number): void {
  if (!_synth || !_synthReady) return
  const val = Math.round(Math.max(0, Math.min(1, value)) * 127)
  try { ;(_synth as any).controllerChange(ch, 91, val) } catch {}
}

// ── setChannelPan — CC10 on a single MIDI channel (Samples engine only) ───────
// value: −1…+1 (bipolar knob); 0 = center; maps to CC10 0–127 (64 = center)
export function setChannelPan(ch: number, value: number): void {
  if (!_synth || !_synthReady) return
  const val = Math.round(((value + 1) / 2) * 127)
  try { ;(_synth as any).controllerChange(ch, 10, val) } catch {}
}

// ── setChannelVolume — CC7 on a single MIDI channel (Samples engine only) ─────
// value: 0…1 (fader); maps to CC7 0–127
export function setChannelVolume(ch: number, value: number): void {
  if (!_synth || !_synthReady) return
  // a channel the song moves: its volume right now, under the new fader position
  const t = _volumeTrackByCh.get(ch)
  const v = t ? valueAt(t.volumeEvents, nowFileSec()) * volumeRatio(t, value) : value
  const val = Math.round(Math.max(0, Math.min(1, v)) * 127)
  try { ;(_synth as any).controllerChange(ch, 7, val) } catch {}
}

// ── Pending note-offs for timed click-to-play notes, keyed ch*128+note ──────
const _clickNoteOffs = new Map<number, ReturnType<typeof setTimeout>>()

// ── Hook: self-gates on audioEngine !== 'samples' ────────────────────────────
export function useSamplesEngine() {
  // ── Register global click-to-play and hardware note-on/off handlers ─────────
  useEffect(() => {
    // channel: MIDI channel 0-based. Undefined = dedicated preview channel (15).
    // visual = false skips the timed key-light — glissando drives the keyboard
    // light itself (instant swap, no fade timer) instead of this note-duration ring.
    ;(window as any).__orfeoPlayNoteSamples = (midiNum: number, vel: number, durMs: number, channel?: number, visual = true, color?: string) => {
      if (!_synth || !_synthReady) return
      const ch = channel ?? 15
      if (ch === 15) {
        ensureHwChannel()
      } else if (!_samplesChanInit.has(ch)) {
        // SpessaSynth defaults all channels to program 0 (piano).
        // Send programChange now — buildSamplesPlayer hasn't run yet (pre-first-play).
        const midi = useStore.getState().midi as any
        const track = (midi?.tracks as any[] | undefined)?.find((t: any) => t.channel === ch && !t.isDrum)
        try { _synth.programChange(ch, track?.program ?? 0) } catch {}
        _samplesChanInit.add(ch)
      }
      // ── Re-striking a note that's still ringing: release it first and drop
      // its pending note-off, or the older strike's timer cuts the new one
      // short (repeat clicks on a chord tile sounded clipped). ──────────────
      const key = ch * 128 + midiNum
      const pending = _clickNoteOffs.get(key)
      if (pending) { clearTimeout(pending); _synth.noteOff(ch, midiNum) }
      _synth.noteOn(ch, midiNum, Math.round(vel * 127))
      _clickNoteOffs.set(key, setTimeout(() => { _clickNoteOffs.delete(key); _synth?.noteOff(ch, midiNum) }, durMs))
      if (visual) lightKey(midiNum, color ?? amberHex(), durMs + 100)
    }
    return () => {
      delete (window as any).__orfeoPlayNoteSamples
    }
  }, [])

  // ── Live path routing follows the setting and the loaded song ─────────────
  useEffect(() => {
    let prevMidi = useStore.getState().midi
    const unsubSong = useStore.subscribe((state) => {
      if (state.midi === prevMidi) return
      prevMidi = state.midi
      applyLiveRouting()
    })
    let prevResp = useMidiSettings.getState().liveResponse
    const unsubResp = useMidiSettings.subscribe((s) => {
      if (s.liveResponse === prevResp) return
      prevResp = s.liveResponse
      applyLiveRouting()
    })
    return () => { unsubSong(); unsubResp() }
  }, [])

  // ── Subscribe to playback state and engine changes ───────────────────────
  useEffect(() => {
    let prevState = useStore.getState().playbackState as string
    let prevAudioEngine = useStore.getState().audioEngine
    let prevBpm = useStore.getState().bpm
    let prevTranspose = useStore.getState().detectedKey?.transpose ?? 0
    // ── Schedule-affecting signature — mute/solo/showOnKeyboard/visible are the
    // only per-track fields that change WHICH notes get scheduled or whether
    // they light the keyboard/spawn hit effects (see buildSamplesPlayer's
    // hasSolo/muted/solo gate and its showOnKeyboard/visible branch below).
    // Missing showOnKeyboard or visible here meant toggling either mid-playback
    // never rebuilt the schedule — already-scheduled notes kept firing
    // lightKey/pushHitEffect from their original closures (with the stale
    // values baked in) until some other change forced a rebuild, so hit
    // effects kept appearing for a track the user had just hidden. Volume/
    // pan/chorus/reverb are still deliberately excluded — they're pushed
    // straight to the synth via setChannelVolume/Pan/Chorus/Reverb at the
    // same call site that patches the store, so reacting to every `tracks`
    // reference change here (as a raw `!==` would) rebuilds the whole scheduled
    // (the instrument IS included: a channel's instrument switches depend on it)
    // player on every fader mousemove — dozens of times a second — which is
    // what was stuttering/pausing playback while dragging a Console fader. ───
    const scheduleSignature = (ts: ReturnType<typeof useStore.getState>['tracks']) =>
      ts.map(t => (t.muted ? 'm' : t.solo ? 's' : '.') + (t.showOnKeyboard ? 'k' : '.') + (t.visible ? 'v' : '.') + t.program).join(',')
    let prevSignature = scheduleSignature(useStore.getState().tracks)

    const unsub = useStore.subscribe((state) => {
      const engineChanged = state.audioEngine !== prevAudioEngine
      const prevEngine = prevAudioEngine

      // CRITICAL: update ALL prev values BEFORE any calls that may trigger
      // useStore.setState so that recursive subscriber re-entries see the
      // updated values and skip spurious actions (infinite recursion guard).
      const pp = prevState
      prevState = state.playbackState
      prevAudioEngine = state.audioEngine

      if (state.audioEngine !== 'samples') {
        // Engine leaving 'samples' — stop all scheduled notes immediately
        if (prevEngine === 'samples') {
          clearSchedule(); clearAllKeys()
        }
        return
      }

      if (engineChanged) wakeContext()
      const ps = state.playbackState
      const bpmChanged = state.bpm !== prevBpm
      const transposeChanged = (state.detectedKey?.transpose ?? 0) !== prevTranspose
      const signature = scheduleSignature(state.tracks)
      const tracksChanged = signature !== prevSignature

      prevBpm = state.bpm
      prevTranspose = state.detectedKey?.transpose ?? 0
      prevSignature = signature

      if (engineChanged && ps === 'playing') {
        // Engine just switched TO samples while playback is active
        buildSamplesPlayer(state.currentTime)
      } else if (ps === 'playing' && pp !== 'playing') {
        buildSamplesPlayer(state.currentTime)
      } else if (ps === 'paused' && pp === 'playing') {
        clearSchedule(); clearAllKeys()
      } else if (ps === 'stopped' && pp !== 'stopped') {
        clearSchedule(); clearAllKeys()
      } else if (ps === 'playing' && (bpmChanged || transposeChanged || tracksChanged)) {
        buildSamplesPlayer(state.currentTime)
      }
    })
    return () => { unsub(); clearSchedule(); clearAllKeys() }
  }, [])

  // ── Live soundfont switching (Settings panel dropdown) ────────────────────
  useEffect(() => {
    let prevId = useStore.getState().selectedSoundfont
    const unsub = useStore.subscribe((state) => {
      if (state.selectedSoundfont === prevId) return
      prevId = state.selectedSoundfont
      if (_synthReady) loadSelectedSoundfont(prevId).catch(() => {})
    })
    return () => unsub()
  }, [])

  // ── Live master volume changes via GainNode ───────────────────────────────
  useEffect(() => {
    let prevVol = useStore.getState().masterVolume
    const unsub = useStore.subscribe((state) => {
      if (state.audioEngine !== 'samples') return
      if (state.masterVolume === prevVol) return
      prevVol = state.masterVolume
      if (_gainNode) _gainNode.gain.value = state.masterVolume * SAMPLES_BOOST
      if (_liveGainNode) _liveGainNode.gain.value = state.masterVolume * SAMPLES_BOOST
    })
    return () => unsub()
  }, [])

  // ── Live master compressor on/off + preset changes ────────────────────────
  useEffect(() => {
    let prevEnabled = useStore.getState().masterCompEnabled
    let prevPreset  = useStore.getState().masterCompPreset
    const unsub = useStore.subscribe((state) => {
      if (state.audioEngine !== 'samples') return
      if (state.masterCompEnabled === prevEnabled && state.masterCompPreset === prevPreset) return
      prevEnabled = state.masterCompEnabled
      prevPreset  = state.masterCompPreset
      setMasterCompressor(prevEnabled, prevPreset)
    })
    return () => unsub()
  }, [])
}
