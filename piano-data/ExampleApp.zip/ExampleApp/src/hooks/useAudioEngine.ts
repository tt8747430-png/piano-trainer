// ── Combined audio engine dispatcher ─────────────────────────────────────────
// Routes to the active backend (gm | samples). Each backend self-gates on its
// own audioEngine value. The click handler (window.__orfeoPlayNote) forwards to
// whichever backend is currently selected.

import { useEffect, useRef } from 'react'
import { useStore } from '../store'
import { useSamplesEngine } from './useSamplesEngine'
import { pushHitEffect, amberHex } from '../utils/hitEffectQueue'
import { isHomogeneousHandTrack, resolveHandAwareColor } from '../utils/handColors'
import { NES } from '../utils/noteEditorState'
import { editableCopyToBuffer } from '../utils/noteEditorCommands'
import { useMidiSettings, latencyOffsetSec, midiPrefsReady } from '../store/midiSettings'
import { useNativeEngine, nativeLightKey, nativeLivePiano } from '../audio/useNativeEngine'
import { nativeCall } from '../audio/nativeClient'
import { isShown } from '../utils/trackShown'

let _jzzReady = false
let _jzzInitP: Promise<void> | null = null
let _JZZ: any = null
let _port: any = null
// jzz-synth-tiny instance, kept once created so switching the GM output back
// to Orfeo's own synth doesn't build a second audio context
let _tinyPort: any = null
// Name of the MIDI output port actually open ('' = Orfeo's built-in synth)
let _openOutput = ''
let _player: any = null
// ── Module-level muted channel set — updated in-place so the live filter reads it ──
let _mutedCh = new Set<number>()
// ── Promise for the channel-warmup operation triggered on edit-mode enter ────
// Null = warmup not yet started; resolved promise = warmup done.
// Cleared in destroyPlayer so the next edit-mode entry after a file reload
// or playback-stop re-warms correctly.
let _warmupPromise: Promise<void> | null = null

// ── Real, measured gap between "scheduled to play" and "actually audible" —
// same purpose as useSamplesEngine.ts's identical export. Only meaningful
// when the jzz-synth-tiny software fallback is active (it exposes its own
// AudioContext); a real system MIDI output device (openMidiOut() above)
// has no equivalent to measure this way, so this returns 0 for that case —
// not compensated, not yet measured. ─────────────────────────────────────
export function getOutputLatencySec(): number {
  return Math.max(0, getMeasuredOutputLatencySec() + latencyOffsetSec())
}
// Raw device figure, without the user's manual offset (Settings readouts)
export function getMeasuredOutputLatencySec(): number {
  try {
    const ctx = typeof _port?.getAudioContext === 'function' ? _port.getAudioContext() : null
    return ctx?.outputLatency || ctx?.baseLatency || 0
  } catch { return 0 }
}
export function getGmOutputName(): string { return _openOutput }

function initJZZ(): Promise<void> {
  if (_jzzReady) return Promise.resolve()
  if (_jzzInitP) return _jzzInitP
  _jzzInitP = (async () => {
    try {
      const jzzMod = await import('jzz')
      _JZZ = jzzMod.default ?? jzzMod
      const smfMod = await import('jzz-midi-smf')
      ;(smfMod.default ?? smfMod)(_JZZ)
      const tinyMod = await import('jzz-synth-tiny')
      ;(tinyMod.default ?? tinyMod)(_JZZ)
      const engine = _JZZ()
      await new Promise<void>((resolve) => {
        engine.and(function(this: any) { resolve() }).or(() => resolve())
      })
      // ── Output: Orfeo's own synth unless the player chose a MIDI output in
      // Settings → MIDI Keyboard. This used to be openMidiOut() with no
      // name = "first MIDI output there is". Chromium hides Windows' GS
      // Wavetable Synth, so with a USB keyboard plugged in, the first output
      // was the KEYBOARD's own MIDI port — songs and live keys were sent
      // back to the keyboard (silent on a controller without speakers).
      // Confirmed with a simulated Launchkey port: JZZ opened it and the
      // note went there. ──────────────────────────────────────────────────
      await midiPrefsReady
      const wanted = useMidiSettings.getState().gmOutput
      const openTiny = () => new Promise<void>((resolve) => {
        if (_tinyPort) { _port = _tinyPort; _openOutput = ''; _jzzReady = true; resolve(); return }
        _JZZ.synth.Tiny().and(function(this: any) {
          _port = _tinyPort = this; _openOutput = ''; _jzzReady = true
          console.log('[Orfeo GM] jzz-synth-tiny active')
          // Diagnostic for the audio/visual sync fix — see
          // getOutputLatencySec() above.
          console.log('[Orfeo GM] measured output latency:', getMeasuredOutputLatencySec(), 's')
          resolve()
        }).or((e: any) => {
          console.error('[Orfeo GM] built-in synth failed:', e)
          _jzzReady = true; resolve()
        })
      })
      if (wanted) {
        await new Promise<void>((resolve) => {
          _JZZ().openMidiOut(wanted).and(function(this: any) {
            _port = this; _openOutput = wanted; _jzzReady = true
            console.log('[Orfeo GM] MIDI out:', this.name())
            resolve()
          }).or(() => {
            console.warn('[Orfeo GM] chosen MIDI output not available, using the built-in synth:', wanted)
            openTiny().then(resolve)
          })
        })
      } else {
        await openTiny()
      }
    } catch (e) {
      _jzzInitP = null
      console.error('[Orfeo GM] JZZ init error:', e)
      throw e
    }
  })()
  return _jzzInitP
}

// ── Click/preview channel setup — program 0 on ch 14. Re-asserted every
// call, not just once: channel 14 isn't reserved at the MIDI-spec level, so
// a loaded file with a real track on channel 14 reprograms it during normal
// playback, permanently leaving the preview channel on the wrong instrument
// for the rest of the session (same class of bug as ensureHardwareChannel
// below, and useSamplesEngine.ts's ensureHwChannel — found against a real
// MIDI file, Bruce Hornsby - The Way It Is, whose alto sax track collided
// with the equivalent Samples-engine preview channel). A ProgramChange is
// cheap enough to just always send. ──────────────────────────────────────
function ensureClickChannel() {
  if (!_port) return
  try {
    _port.send([0xCE, 0])
  } catch (e) {
    console.warn('[Orfeo GM] ensureClickChannel error:', e)
  }
}

// ── Hardware-input channel setup — program 0 on ch 15, same always-reassert
// reasoning as ensureClickChannel above. ─────────────────────────────────
function ensureHardwareChannel() {
  if (!_port) return
  try {
    _port.send([0xCF, 0])
  } catch (e) {
    console.warn('[Orfeo GM] ensureHardwareChannel error:', e)
  }
}

const _keyTimers = new Map<number, ReturnType<typeof setTimeout>>()

function lightKey(midiNum: number, color: string, durMs: number) {
  const existing = _keyTimers.get(midiNum)
  if (existing) clearTimeout(existing)
  const { activeKeys, activeKeyColors } = useStore.getState()
  const nk = new Set(activeKeys); nk.add(midiNum)
  const nc = new Map(activeKeyColors); nc.set(midiNum, color)
  useStore.setState({ activeKeys: nk, activeKeyColors: nc })
  pushHitEffect(midiNum, color)
  const timer = setTimeout(() => {
    _keyTimers.delete(midiNum)
    const { activeKeys: k, activeKeyColors: c } = useStore.getState()
    const nk2 = new Set(k); nk2.delete(midiNum)
    const nc2 = new Map(c); nc2.delete(midiNum)
    useStore.setState({ activeKeys: nk2, activeKeyColors: nc2 })
  }, Math.max(50, durMs))
  _keyTimers.set(midiNum, timer)
}

function clearAllKeys() {
  _keyTimers.forEach(t => clearTimeout(t))
  _keyTimers.clear()
  useStore.setState({ activeKeys: new Set(), activeKeyColors: new Map() })
}

const _lightSchedule: ReturnType<typeof setTimeout>[] = []
function clearLightSchedule() {
  _lightSchedule.forEach(t => clearTimeout(t))
  _lightSchedule.length = 0
}

function destroyPlayer() {
  try { _player?.stop() } catch {}
  _player = null
  ;(window as any).__orfeoPlayer = null
  _warmupPromise = null   // allow re-warm on next edit-mode entry
}

// ── Live edit-buffer awareness — once the Note Editor holds a REAL unsaved
// edit (NES.dirty), playback must schedule from that buffer, not the
// untouched store copy — otherwise a deleted/added/moved note plays back
// exactly as it was before the edit: gone from the piano roll, still
// audible, because the store's `midi` is deliberately never mutated by the
// editor (see noteEditorCommands.ts's midiToEditableCopy) and nothing was
// re-pointing playback at the live copy.
//
// Gated on NES.dirty, NOT merely `NES.editMidi` being non-null — the edit
// buffer is created the instant edit mode opens, before any edit happens,
// and re-serializing it (editableCopyToBuffer) is a real round-trip through
// @tonejs/midi's encoder, not a byte-identical copy of the original file.
// Routing through it unconditionally broke audio the moment the toolbar
// opened, with zero edits made — a real regression, not just an unlikely
// edge case. Only pay that round-trip once there's an actual edit worth
// protecting. ───────────────────────────────────────────────────────────
function activeMidiData(): any {
  return (NES.dirty && NES.editMidi) ? NES.editMidi : useStore.getState().midi
}

// ── updateMutedChannels — live mute/solo update without rebuilding the player ──
// Repopulates _mutedCh and rebuilds the key-lighting schedule from currentTime.
// Called on track-state changes during playback so the filter takes effect instantly.
function updateMutedChannels() {
  const { tracks, bpm, originalBpm, detectedKey, currentTime, hitEffectScope, showHandLabels, handLabelMode, noteEditorActive } = useStore.getState()
  const midiData = activeMidiData()
  if (!midiData || !_player) return
  const hasSolo = tracks.some((t: any) => t.solo)
  const transpose = detectedKey?.transpose ?? 0
  const ratio = bpm / originalBpm
  const performanceMode = handLabelMode === 'performance'
  // Global Settings toggle stays authoritative here too (see PianoRoll.tsx's
  // handColoringOn) — the Note Editor's own Hand toggle only adds to it,
  // never takes coloring away from what the global setting already shows.
  const effectiveShowHandLabels = showHandLabels || (noteEditorActive && NES.reassignHandsMode)
  _mutedCh.clear()
  for (const tr of midiData.tracks) {
    const ts = tracks.find((t: any) => t.index === tr.index)
    if (!ts || ts.muted || (hasSolo && !ts.solo)) _mutedCh.add(tr.channel)
  }
  clearLightSchedule(); clearAllKeys()
  for (const track of midiData.tracks) {
    const ts = tracks.find((t: any) => t.index === track.index)
    // the keyboard lights what the roll shows (trackShown.ts, below)
    if (!ts) continue
    // "Lit on keyboard" only actually lights the keyboard while the track is
    // still visible on the piano roll — a track hidden from the roll but
    // still flagged "Lit on keyboard" used to keep lighting the keyboard in
    // its own color during real playback with nothing on screen to explain
    // why (the "random notes light up" report). hitEffectScope === 'all'
    // separately lets non-keyboard tracks still spawn hit effects (purely
    // visual, at the note's key position) without lighting the key itself —
    // also gated on visible, same reasoning.
    const eligibleForHitEffect = isShown(ts, hasSolo) && (ts.showOnKeyboard || hitEffectScope === 'all')
    if (!eligibleForHitEffect) continue
    const defaultColor = ts.color ?? amberHex()
    const homogeneousTrack = isHomogeneousHandTrack(track.notes)
    for (const note of track.notes) {
      // Same fix as useSamplesEngine.ts's identical pattern: compare native
      // (unscaled) times, then scale the gap — not the other way around,
      // which only agreed with reality when currentTime was 0.
      if (note.time < currentTime) continue
      const delay = (note.time - currentTime) / ratio * 1000
      const durMs = Math.max(note.duration / ratio * 1000, 40)
      const midiNum = note.midi + transpose
      const color = resolveHandAwareColor(note, defaultColor, { homogeneousTrack, showHandLabels: effectiveShowHandLabels, performanceMode })
      // These timers are purely visual (JZZ's own player drives the actual
      // audio on its own clock) — delayed by the output device's own
      // latency so the key light/chord name line up with what's actually
      // heard, not with when the note was merely scheduled. See
      // getOutputLatencySec() above.
      const t = setTimeout(() => {
        if (ts.showOnKeyboard) lightKey(midiNum, color, Math.min(durMs + 30, 2500))
        else pushHitEffect(midiNum, color)
      }, delay + getOutputLatencySec() * 1000)
      _lightSchedule.push(t)
    }
  }
}

// ── Count-in head start: the JZZ synth switching on (~1.2 s on first use) and
// building the song's player (~0.2 s) both happen BEFORE the first note can
// sound. A count-in prepares them while it clicks, so when the music is due
// buildPlayer only has to press play (see utils/countInRunner.ts). The
// prepared player is used once, and only for the exact same song bytes. ──
let _prepared: { raw: ArrayBuffer; player: any } | null = null
function currentRaw(): ArrayBuffer | undefined {
  return (NES.dirty && NES.editMidi) ? editableCopyToBuffer(NES.editMidi) : (useStore.getState().midi as any)?._raw
}
async function prepareStart() {
  try {
    await initJZZ()
    if (!_jzzReady || !_port || !_JZZ || NES.dirty) return
    const raw = currentRaw()
    if (!raw || _prepared?.raw === raw) return
    _prepared = { raw, player: new _JZZ.MIDI.SMF(new Uint8Array(raw)).player() }
  } catch (e) { console.warn('[Orfeo GM] prepareStart failed:', e) }
}
;(window as any).__orfeoPrepareStart = () => { if (useStore.getState().audioEngine === 'gm') void prepareStart() }

function buildPlayer(startSec: number) {
  if (!_jzzReady || !_port) return
  try {
    // Play from the Note Editor's live edit buffer once it holds a real edit,
    // not the untouched store copy — see activeMidiData() above for why this
    // is gated on NES.dirty, not just NES.editMidi being non-null. Computed
    // inside the try so a re-encode failure logs instead of silently
    // aborting the whole rebuild (previously computed before the try block).
    const raw = currentRaw()
    if (!raw) { console.warn('[Orfeo GM] buildPlayer: no raw bytes available, dirty=', NES.dirty, 'editMidi=', !!NES.editMidi); return }
    destroyPlayer(); clearAllKeys(); clearLightSchedule()
    const { tracks, bpm, originalBpm, detectedKey, hitEffectScope, showHandLabels, handLabelMode, noteEditorActive } = useStore.getState()
    const performanceMode = handLabelMode === 'performance'
    const effectiveShowHandLabels = showHandLabels || (noteEditorActive && NES.reassignHandsMode)
    const transpose = detectedKey?.transpose ?? 0
    const ratio = bpm / originalBpm
    const midiData = activeMidiData()
    const hasSolo = tracks.some((t: any) => t.solo)
    _mutedCh = new Set<number>()
    for (const tr of midiData.tracks) {
      const ts = tracks.find((t: any) => t.index === tr.index)
      if (!ts || ts.muted || (hasSolo && !ts.solo)) _mutedCh.add(tr.channel)
    }
    // ── Start the real audio clock BEFORE scheduling any light timers ─────────
    // JZZ's player anchors its internal tick clock (_t0) the instant play()/
    // jumpMS() run. Building the SMF (parses the whole file, builds its tempo
    // table) and player.play() must happen first — previously the light
    // setTimeouts were all registered *before* this, computed relative to an
    // earlier "now" than the audio clock's actual anchor, coupling visual
    // sync to however long SMF construction + the note loop took. Doing audio
    // setup first minimizes that gap instead of leaving it to chance.
    const ready = _prepared && _prepared.raw === raw ? _prepared.player : null
    _prepared = null
    const player = ready ?? new _JZZ.MIDI.SMF(new Uint8Array(raw)).player()
    player.connect(_port)
    player.filter(function(this: any, msg: any) {
      const status = msg[0] & 0xF0
      const ch = msg[0] & 0x0F
      if (_mutedCh.has(ch)) return
      if (transpose !== 0 && (status === 0x90 || status === 0x80)) {
        const newNote = Math.max(0, Math.min(127, msg[1] + transpose))
        this._receive(_JZZ.MIDI(msg[0], newNote, msg[2]))
        return
      }
      this._receive(msg)
    })
    player.onEnd = () => {
      useStore.setState({ playbackState: 'stopped', currentTime: 0 })
      ;(window as any).__orfeoPlayer = null
      clearAllKeys()
    }
    player.speed(ratio)
    player.play()
    // when playback really started (the count-in learns this delay)
    ;(window as any).__orfeoEngineStartedAt = performance.now()
    // Seeking while "playing" (jumpMS below) makes the SMF player run its own
    // sndOff(), which sends MIDI "Reset All Controllers" on every channel —
    // the software synth recomputes each channel's gain from its own internal
    // state when it receives that, wiping out whatever volume we send before
    // the jump. Applying our volume AFTER play()/jumpMS() makes it the last
    // word regardless — this is what was making resume (and any seek while
    // playing) land much quieter than a fresh start, which never jumps.
    if (startSec > 0.1) player.jumpMS(Math.floor(startSec * 1000))
    applyMasterVolume(useStore.getState().masterVolume)
    _player = player
    setTimeout(() => { ;(window as any).__orfeoPlayer = player }, 50)

    for (const track of midiData.tracks) {
      const ts = tracks.find((t: any) => t.index === track.index)
      if (!ts) continue
      // Same rule as the live-update function above: what the roll shows.
      const eligibleForHitEffect = isShown(ts, hasSolo) && (ts.showOnKeyboard || hitEffectScope === 'all')
      if (!eligibleForHitEffect) continue
      const defaultColor = ts.color ?? amberHex()
      const homogeneousTrack = isHomogeneousHandTrack(track.notes)
      for (const note of track.notes) {
        // Same fix as useSamplesEngine.ts's identical pattern — see its comment.
        if (note.time < startSec) continue
        const delay = (note.time - startSec) / ratio * 1000
        const durMs = Math.max(note.duration / ratio * 1000, 40)
        const midiNum = note.midi + transpose
        const color = resolveHandAwareColor(note, defaultColor, { homogeneousTrack, showHandLabels: effectiveShowHandLabels, performanceMode })
        // Purely visual, same output-latency compensation as above.
        const t = setTimeout(() => {
          if (ts.showOnKeyboard) lightKey(midiNum, color, Math.min(durMs + 30, 2500))
          else pushHitEffect(midiNum, color)
        }, delay + getOutputLatencySec() * 1000)
        _lightSchedule.push(t)
      }
    }
  } catch (e) {
    console.error('[Orfeo GM] buildPlayer error:', e)
  }
}

// ── MIDI CC 7 (Main Volume) on all 16 channels ───────────────────────────────
function applyMasterVolume(v: number) {
  if (!_port) return
  const val = Math.round(Math.max(0, Math.min(1, v)) * 127)
  try { for (let ch = 0; ch < 16; ch++) _port.send([0xB0 | ch, 7, val]) } catch {}
}

// ── Settings → MIDI Keyboard changed the GM output: silence, close the old
// port, open the new one. Playback is paused first so the song player isn't
// left connected to a closed port; Play resumes on the new output. ────────
export async function reopenGmOutput(): Promise<void> {
  if (!_jzzReady && !_jzzInitP) return  // not started yet — next init reads the setting
  const st = useStore.getState()
  if (st.audioEngine === 'gm' && st.playbackState === 'playing') st.setPlaybackState('paused')
  try { await _jzzInitP } catch {}
  // GM's lights/player only — with Samples playing, its lights stay untouched
  if (st.audioEngine === 'gm') stopAudio()
  else destroyPlayer()
  if (_port && _port !== _tinyPort) { try { _port.close() } catch {} }
  _port = null; _jzzReady = false; _jzzInitP = null; _prepared = null
  await initJZZ()
}

// ── Live keyboard input (GM) — always channel 16 (index 15) ──────────────────
// The very first key before the synth exists waits for it rather than being lost
export function liveNoteOn(midiNum: number, vel127: number): void {
  const play = () => { if (!_port) return; ensureHardwareChannel(); try { _port.send([0x9F, midiNum, vel127]) } catch {} }
  if (_port) play(); else initJZZ().then(play).catch(() => {})
}
export function liveSend(bytes: number[]): void {
  if (!_port) { void initJZZ(); return }
  try { _port.send(bytes) } catch {}
}
export function liveReset(): void {
  if (!_port) return
  try {
    for (const cc of [64, 66, 67, 1]) _port.send([0xBF, cc, 0])
    _port.send([0xBF, 11, 127])
    _port.send([0xEF, 0, 64])
    _port.send([0xDF, 0])
    _port.send([0xBF, 123, 0])
  } catch {}
}

function stopAudio() {
  destroyPlayer(); clearLightSchedule(); clearAllKeys()
  if (_port) {
    try { for (let ch = 0; ch < 16; ch++) _port.send([0xB0 | ch, 123, 0]) } catch {}
  }
}

// ── warmupEditChannels — prime GM channel programs before first note-editor click ──
// Sends program changes through a real JZZ SMF player (the same path buildPlayer
// uses) so jzz-synth-tiny's internal pipeline is correctly activated.  A filter
// blocks all note events so no sound is emitted.  The promise is stored in
// _warmupPromise so playNote can await it if the user clicks before the 150 ms
// settling window has elapsed.
async function warmupEditChannels() {
  // Skip if a player is active — its SMF events have already set programs.
  // Skip if warmup already in flight / done for this file session.
  if (_player || _warmupPromise) return
  _warmupPromise = (async () => {
    try {
      await initJZZ()
      if (!_port || !_JZZ) return
      const raw = (useStore.getState().midi as any)?._raw as ArrayBuffer | undefined
      if (!raw) return
      const smfFile = new _JZZ.MIDI.SMF(new Uint8Array(raw))
      const wPlayer = smfFile.player()
      wPlayer.connect(_port)
      // Only let program changes and bank-select CCs through — no notes emitted
      wPlayer.filter(function(this: any, msg: any) {
        const status = msg[0] & 0xF0
        if (status === 0xC0) { this._receive(msg); return }
        if (status === 0xB0 && (msg[1] === 0 || msg[1] === 32)) { this._receive(msg) }
      })
      wPlayer.play()
      // Program changes live at tick 0 and are dispatched immediately after play();
      // 150 ms is ample time for all of them to reach the synthesizer.
      await new Promise<void>(r => setTimeout(r, 150))
      try { wPlayer.stop() } catch {}
    } catch (e) { console.warn('[Orfeo GM] warmupEditChannels error:', e) }
  })()
  return _warmupPromise
}

// ── Pending note-offs for timed click-to-play notes, keyed ch*128+note ──────
const _clickNoteOffs = new Map<number, ReturnType<typeof setTimeout>>()

// ── Combined hook ─────────────────────────────────────────────────────────────
export function useAudioEngine() {
  // Always mount Samples engine (it self-gates on audioEngine !== 'samples')
  useSamplesEngine()
  // …and the Native engine (beta), which self-gates on audioEngine !== 'native'
  useNativeEngine()

  const prevStateRef = useRef('stopped')
  const prevBpmRef = useRef(120)
  const prevTransposeRef = useRef(0)
  const prevTracksRef = useRef<any>(null)
  const prevVolumeRef = useRef<number>(useStore.getState().masterVolume)
  const schedulingRef = useRef(false)
  // ── Track audioEngine so we can react to engine switches ────────────────
  const prevAudioEngineRef = useRef<string>(useStore.getState().audioEngine)

  useEffect(() => {
    // ── Timed click-to-play (shared by both engines) ─────────────────────────
    // channel: MIDI channel 0-based. Undefined = preview channel (14 GM / 15 samples).
    // visual = false skips the timed key-light entirely — used for glissando,
    // which drives the keyboard light itself (instant swap, no fade timer)
    // instead of relying on this note-duration-based ring.
    const playNote = async (midiNum: number, vel = 90, durMs = 500, channel?: number, visual = true, color?: string) => {
      const { audioEngine } = useStore.getState()
      if (audioEngine === 'native') {
        // channel undefined = the live/preview channel (16), as in Samples
        if (channel === undefined) nativeLivePiano()
        nativeCall('noteFor', channel ?? 15, midiNum, Math.max(1, Math.round(vel * 127)), durMs / 1000)
        if (visual) nativeLightKey(midiNum, color ?? amberHex(), durMs + 100)
        return
      }
      if (audioEngine === 'samples') {
        const fn = (window as any).__orfeoPlayNoteSamples
        if (fn) { fn(midiNum, vel, durMs, channel, visual, color); return }
      }
      // GM: ch 14 is the dedicated preview channel (piano). Track channels have
      // correct programs after __orfeoWarmupEditChannels runs on edit-mode enter.
      const ch = channel ?? 14
      try {
        // If a channel warmup is in flight, wait for it before sending note-on
        // so the program change arrives before the note on the first click.
        if (channel !== undefined && _warmupPromise) await _warmupPromise
        await initJZZ()
        if (!_port) return
        if (ch === 14) ensureClickChannel()
        // ── Re-striking a note that's still ringing: release it first and
        // drop its pending note-off, or the older strike's timer cuts the
        // new one short (repeat clicks on a chord tile sounded clipped). ──
        const key = ch * 128 + midiNum
        const pending = _clickNoteOffs.get(key)
        if (pending) { clearTimeout(pending); _port.send([0x80 | ch, midiNum, 0]) }
        _port.send([0x90 | ch, midiNum, Math.round(vel * 127)])
        _clickNoteOffs.set(key, setTimeout(() => {
          _clickNoteOffs.delete(key)
          try { _port.send([0x80 | ch, midiNum, 0]) } catch {}
        }, durMs))
        if (visual) lightKey(midiNum, color ?? amberHex(), durMs + 100)
      } catch (e) { console.error('[Orfeo GM] playNote error:', e) }
    }
    ;(window as any).__orfeoPlayNote = playNote

    // ── Warm up GM channels via a temporary silent SMF player ────────────────
    ;(window as any).__orfeoWarmupEditChannels = () => {
      if (useStore.getState().audioEngine === 'gm') warmupEditChannels()
    }

    return () => {
      delete (window as any).__orfeoPlayNote
      delete (window as any).__orfeoWarmupEditChannels
      stopAudio()
    }
  }, [])

  useEffect(() => {
    const unsub = useStore.subscribe((state) => {
      const engineChanged = state.audioEngine !== prevAudioEngineRef.current
      const prevEngine = prevAudioEngineRef.current
      prevAudioEngineRef.current = state.audioEngine

      if (state.audioEngine !== 'gm') {
        // Engine leaving 'gm' — stop JZZ immediately so it doesn't keep playing
        if (prevEngine === 'gm') {
          stopAudio()
        }
        return
      }

      // audioEngine === 'gm' from here
      const ps = state.playbackState
      const pp = prevStateRef.current
      const bpmChanged = state.bpm !== prevBpmRef.current
      const transposeChanged = (state.detectedKey?.transpose ?? 0) !== prevTransposeRef.current
      const tracksChanged = state.tracks !== prevTracksRef.current

      prevStateRef.current = ps
      prevBpmRef.current = state.bpm
      prevTransposeRef.current = state.detectedKey?.transpose ?? 0
      prevTracksRef.current = state.tracks

      if (engineChanged && ps === 'playing') {
        // Engine just switched TO gm while playback is active — rebuild player
        if (schedulingRef.current) return
        schedulingRef.current = true
        initJZZ()
          .then(() => buildPlayer(state.currentTime))
          .catch(console.error)
          .finally(() => { schedulingRef.current = false })
      } else if (ps === 'playing' && pp !== 'playing') {
        if (schedulingRef.current) return
        schedulingRef.current = true
        initJZZ()
          .then(() => buildPlayer(state.currentTime))
          .catch(console.error)
          .finally(() => { schedulingRef.current = false })
      } else if (ps === 'paused' && pp === 'playing') {
        try { _player?.pause() } catch {}
        clearLightSchedule(); clearAllKeys()
      } else if (ps === 'stopped' && pp !== 'stopped') {
        stopAudio()
      } else if (ps === 'playing' && (bpmChanged || transposeChanged)) {
        // BPM/transpose change requires a full rebuild (tempo/pitch affects note timing)
        if (schedulingRef.current) return
        schedulingRef.current = true
        buildPlayer(state.currentTime)
        schedulingRef.current = false
      } else if (ps === 'playing' && tracksChanged) {
        // Mute/solo/visible changed — update live filter + lighting without rebuilding player
        updateMutedChannels()
      }
    })
    return () => { unsub(); stopAudio() }
  }, [])

  // ── Live volume changes — send CC 7 immediately while port is open ──────────
  useEffect(() => {
    const unsub = useStore.subscribe((state) => {
      if (state.audioEngine !== 'gm') return
      if (state.masterVolume === prevVolumeRef.current) return
      prevVolumeRef.current = state.masterVolume
      applyMasterVolume(state.masterVolume)
    })
    return () => unsub()
  }, [])
}
