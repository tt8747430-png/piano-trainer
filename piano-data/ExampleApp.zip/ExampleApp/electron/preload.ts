import { contextBridge, ipcRenderer, webUtils } from 'electron'

// ── zoom:changed needs more than one live listener at once — App.tsx (the
// hint toast) and SettingsPanel.tsx (the live Appearance readout) are both
// mounted simultaneously. removeAllListeners (the offX pattern every other
// push-event channel here uses) is only safe when a channel has at most one
// listener for the app's whole lifetime; with two, either side's cleanup
// effect re-running (e.g. on a hot-reload update to just one of them) wipes
// out the OTHER one's listener too. This map lets offZoomChanged remove
// only the one it was given. ────────────────────────────────────────────
const zoomListeners = new Map<(data: any) => void, (e: unknown, data: any) => void>()

// ── Native audio engine: main hands us one end of a MessageChannel; pass it
// to the page (a MessagePort can't cross contextBridge, window.postMessage can) ──
ipcRenderer.on('audio:port', (e) => { window.postMessage('orfeo-audio-port', '*', e.ports) })

contextBridge.exposeInMainWorld('electronAPI', {
  // Native audio engine (beta)
  connectNativeAudio:     () => ipcRenderer.invoke('audio:connect'),
  nativeSoundfontPaths:   (extraId: string | null) => ipcRenderer.invoke('audio:soundfontPaths', extraId),
  onNativeAudioHostExit:  (fn: (code: number) => void) => { ipcRenderer.removeAllListeners('audio:host-exit'); ipcRenderer.on('audio:host-exit', (_e, code) => fn(code)) },
  // Existing
  openMidiFile:       () => ipcRenderer.invoke('dialog:openMidi'),
  windowMinimize:     () => ipcRenderer.invoke('window:minimize'),
  windowMaximize:     () => ipcRenderer.invoke('window:maximize'),
  windowClose:        () => ipcRenderer.invoke('window:close'),
  // Prefs
  getPrefs:           () => ipcRenderer.invoke('prefs:get'),
  setPrefs:           (data: any) => ipcRenderer.invoke('prefs:set', data),
  // Library
  openFolder:         () => ipcRenderer.invoke('dialog:openFolder'),
  scanMidiFolder:     (path: string) => ipcRenderer.invoke('fs:scanMidiFolder', path),
  getDemoFolder:      () => ipcRenderer.invoke('app:getDemoFolder'),
  loadMidiFromPath:   (path: string) => ipcRenderer.invoke('fs:loadMidiFromPath', path),
  saveExport:         (songPath: string, libraryFolder: string | null, fileName: string, bytes: Uint8Array) => ipcRenderer.invoke('export:save', songPath, libraryFolder, fileName, bytes),
  statFiles:          (paths: string[]) => ipcRenderer.invoke('fs:statFiles', paths),
  // MIDI Editor
  saveFileDialog:     (opts: any) => ipcRenderer.invoke('dialog:saveFile', opts),
  saveMidiEditor:     (payload: any) => ipcRenderer.invoke('editor:save', payload),
  saveMixerChannels:  (payload: any) => ipcRenderer.invoke('mixer:save', payload),
  openExternal:       (url: string) => ipcRenderer.invoke('shell:openExternal', url),
  openFolderInExplorer: (folderPath: string) => ipcRenderer.invoke('shell:openFolder', folderPath),
  showItemInFolder:   (filePath: string) => ipcRenderer.invoke('shell:showItemInFolder', filePath),
  listLibraryFolders: (libraryFolder: string) => ipcRenderer.invoke('fs:listLibraryFolders', libraryFolder),
  createLibraryFolder: (libraryFolder: string, name: string) => ipcRenderer.invoke('fs:createLibraryFolder', libraryFolder, name),
  renameLibraryFolder: (libraryFolder: string, oldName: string, newName: string) => ipcRenderer.invoke('fs:renameLibraryFolder', libraryFolder, oldName, newName),
  deleteLibraryFolder: (libraryFolder: string, name: string) => ipcRenderer.invoke('fs:deleteLibraryFolder', libraryFolder, name),
  renameLibraryFile: (filePath: string, newName: string) => ipcRenderer.invoke('fs:renameLibraryFile', filePath, newName),
  getFileLog:  (filePath: string) => ipcRenderer.invoke('fileinfo:getLog', filePath),
  logFileEvent: (filePath: string, type: string, summary: string) => ipcRenderer.invoke('fileinfo:logEvent', filePath, type, summary),
  listFileVersions: (filePath: string) => ipcRenderer.invoke('fileinfo:listVersions', filePath),
  moveLibraryFiles: (filePaths: string[], libraryFolder: string, destFolderName: string | null) => ipcRenderer.invoke('fs:moveLibraryFiles', filePaths, libraryFolder, destFolderName),
  transcriptGenerate: (midiPath: string, noteNaming: string, accidentals: string) => ipcRenderer.invoke('transcript:generate', midiPath, noteNaming, accidentals),
  // Note Editor
  saveNoteEditor:      (payload: any) => ipcRenderer.invoke('noteEditor:save', payload),
  saveTempoKey:        (payload: any) => ipcRenderer.invoke('tempoKey:save', payload),
  showMessageBox:      (opts: any)    => ipcRenderer.invoke('dialog:messageBox', opts),
  confirmClose:        ()             => ipcRenderer.invoke('app:confirm-close'),
  setFullScreen:       (value: boolean) => ipcRenderer.invoke('window:setFullScreen', value),
  onSaveBeforeClose:   (fn: () => void) => ipcRenderer.on('app:save-before-close', () => fn()),
  offSaveBeforeClose:  ()             => ipcRenderer.removeAllListeners('app:save-before-close'),
  // Drag-and-drop file import
  getPathForFile:     (file: File) => webUtils.getPathForFile(file),
  copyMidiToLibrary:  (sourcePath: string, libraryFolder: string) => ipcRenderer.invoke('fs:copyMidiToLibrary', sourcePath, libraryFolder),
  // Foreign format import cache
  getCachedImport:    (sourcePath: string, cachePath: string) => ipcRenderer.invoke('fs:getCachedImport', sourcePath, cachePath),
  writeCachedImport:  (destPath: string, base64: string) => ipcRenderer.invoke('fs:writeCachedImport', destPath, base64),
  // Downloadable extra soundfonts
  listSoundfonts:     () => ipcRenderer.invoke('soundfont:list'),
  downloadSoundfont:  (id: string) => ipcRenderer.invoke('soundfont:download', id),
  deleteSoundfont:    (id: string) => ipcRenderer.invoke('soundfont:delete', id),
  readSoundfont:      (id: string) => ipcRenderer.invoke('soundfont:read', id),
  importSoundfont:    () => ipcRenderer.invoke('soundfont:import'),
  onSoundfontProgress: (fn: (data: { id: string; progress: number }) => void) => ipcRenderer.on('soundfont:progress', (_e, data) => fn(data)),
  offSoundfontProgress: () => ipcRenderer.removeAllListeners('soundfont:progress'),
  // Auto-update (GitHub Releases)
  getUpdateInfo:      () => ipcRenderer.invoke('update:info'),
  checkForUpdates:    () => ipcRenderer.invoke('update:check'),
  installUpdate:       () => ipcRenderer.invoke('update:install'),
  onUpdateStatus:      (fn: (data: any) => void) => ipcRenderer.on('update:status', (_e, data) => fn(data)),
  offUpdateStatus:     () => ipcRenderer.removeAllListeners('update:status'),
  // "Enjoying Orfeo?" note + Rate Orfeo (Store build)
  getSupportNoteInfo: () => ipcRenderer.invoke('note:info'),
  requestReview:      () => ipcRenderer.invoke('review:request'),
  neverShowSupportNote: () => ipcRenderer.invoke('note:never'),
  snoozeSupportNote:  () => ipcRenderer.invoke('note:snooze'),
  // App zoom (Ctrl +/−/0)
  getZoom:             () => ipcRenderer.invoke('zoom:get'),
  setZoom:             (percent: number) => ipcRenderer.invoke('zoom:set', percent),
  onZoomChanged:       (fn: (data: { percent: number; capped: boolean }) => void) => {
    const wrapped = (_e: unknown, data: any) => fn(data)
    zoomListeners.set(fn, wrapped)
    ipcRenderer.on('zoom:changed', wrapped)
  },
  offZoomChanged:      (fn: (data: { percent: number; capped: boolean }) => void) => {
    const wrapped = zoomListeners.get(fn)
    if (wrapped) { ipcRenderer.off('zoom:changed', wrapped); zoomListeners.delete(fn) }
  },
})
