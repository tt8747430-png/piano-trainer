# Changelog

<!-- Release notes are built from this file (scripts/release-notes.mjs).
     Each version: ## [X.Y.Z] — D. M. YYYY — Title, then an optional **In short**
     list of 2–4 one-line bullets, then ### New / ### Changed / ### Fixed.
     Newest version at the top. -->

## [1.6] — 31. 10. 2026 — Export to audio, skip empty bars, your own hand colours

**In short**
- New: save any song as an MP3 or WAV file: as written, just keys, bass and drums, or exactly as you hear it.
- New: songs can start right where the music starts, skipping the silent bars at the beginning.
- New: choose your own left- and right-hand colours. The piano roll and keyboard now always show the same parts (eye, mute and solo work together).
- Clearer uninstall choices, a tidier velocity editor, and a security update.

### New
- **Export to audio** (Settings › Audio, off until you switch it on). Right-click any song in the Library and choose *Export to audio* to save it as a file to listen to anywhere. Pick the version: *Original* (the song as written), *Focus* (keys, bass and drums only) or *As I hear it* (your tempo, key, muted parts, Mixer and loop, for the song you have open). Then pick the sound, Studio or Native, with any of your sound sets. The format is MP3 (320 kbps, 44.1 kHz stereo) or WAV (44.1 kHz, 16-bit stereo, CD quality). Every file starts at the first note, rings out for 2 seconds after the last one and is levelled so it never clips. Files go to the *Exports* folder inside your Library's *Orfeo* folder (or *Music › Orfeo › Exports* if you haven't set a Library) and never overwrite an earlier export. A song that's playing pauses while it exports, and *Cancel* stops an export at any time.
- **Skip empty bars at the start** (Settings › Playback, also in Setup). Songs that begin with silent bars open with the music on bar 1: the piano roll, bar numbers, playback, loops and step-through all start where the music starts. *Keep drum count-ins* (on by default) keeps one or two bars of plain drum clicks before the music; switch it off to skip those too. A real drum intro or fill always stays. Your files are never changed: switch it off and every song is exactly as written again, the open one straight away. Edits you save keep the silent bars, and exports start where the music starts. It can't be on together with *Chord Transcription*, whose charts number the bars as the file has them: switching one on switches the other off.
- **Hand colours** (Settings › Appearance). Choose the colours for your left and right hand on the piano roll, the keyboard and the split preview. Pick a ready-made pair (*Bright*, *Sky* and *Mint* stay easy to tell apart with colour blindness) or any two colours of your own. A note warns when the two hands look too alike. *Back to Orfeo's colours* restores the defaults. Piano tracks switch to your hand colours straight away, in the open song too. The Hand Assignment card links straight to it.

### Changed
- **Focus mode is pure keys.** One click and you hear the keys (pianos, organs, accordions), bass and drums, but only the keys stay on the piano roll and the keyboard. Every other track is muted and hidden. Click again and every track comes back exactly as it was. Stepping with ← / → follows what you see: a hidden track never makes a step or sounds in one.
- **Velocity editor without the clutter.** The numbers no longer sit on every bar, where close notes made them overlap. Point at a bar to see its velocity, and the value follows live as you drag it up or down. Select a note on the piano roll and its bar lights up in amber, so in a busy passage you can see which bar is which.
- **Clearer choices when uninstalling.** The Yes / No / Cancel box is gone. A page of four clearly named choices takes its place, each saying exactly what it does: *Delete everything*, *Keep my edited files*, *Remove Orfeo, keep my data* (handy before a reinstall) and *Keep everything*, which really cancels the uninstall. All of them leave your Library folder alone. The empty *Choose Components* page is gone too.
- **Piano roll and keyboard always agree.** The keys lit while playing, Reflect on keyboard and stepping with ← / → show exactly what's on the piano roll. Switch a track's eye off and it keeps playing along as accompaniment without showing anywhere — hear the saxophone melody without its notes on the keys. Mute a track and it's silent and off the roll; solo one and only that track is heard and shown. Mute and solo no longer switch the eye on or off, so the buttons stay separate.
- **Clearer track colours.** Other instruments never start in the piano's colours any more. Each one gets a colour that stands apart from the hands and from the instruments before it.
- **Audio at a glance.** The sound engine's details in Setup and Settings › Audio now sit in a small framed display, with a new fourth line: the sound set that's playing (or *Built-in GM*).
- **Roomier Playback settings.** Loop region and Focus mode moved to the first column of Settings › Playback, so the whole page fits without scrolling. In the *Skip empty bars* card, *Keep drum count-ins* has a paragraph of its own.

### Fixed
- Right-click menus near the bottom of the Library open upwards, so they're never cut off.
- The Library remembers where you scrolled, your search and your open folders when you switch to Setup and back, or close and reopen the side panel.
- The Chords Explorer's *next inversion* arrow no longer gets its tip cut off.
- The MIDI Note Editor keeps its size as you move the mouse over it. Before, it grew and shrank as the hint text below the tools changed between one and two lines.
- In the MIDI Note Editor, undoing a change also removes the white outline from the notes it changed. Before, the outline stayed, and right-click couldn't clear it.

### Updated
- Electron 44.9.3 → 44.10.0 (security fixes)
- electron-updater 6.8.9 → 6.8.11

## [1.5.4] — 25. 10. 2026 — Lots of polish, plus a few new things

**In short**
- A lot of polish and tweaks under the hood: Settings pages in a clearer order with a new Editing page, steadier colours on the keyboard, and stray hover labels gone.
- New: the Chords and Scales Explorers have the keyboard to themselves, play piano on every sound engine, and can let the song keep playing (Settings › Playback).
- New: the song keeps its track colours on the keyboard even when paused, so an auditioned or locked chord (amber) stands out.
- New: a small "Enjoying Orfeo?" note now and then, and Microsoft Store users can rate Orfeo right in the app.

### New
- **"Enjoying Orfeo?"** Every fifth time you open Orfeo, a small note in the corner offers ways to help it grow: a review, the Orfeo community on Reddit, or a coffee on Ko-fi. *Disable for 30 days* pauses it, and Settings › Appearance turns it off.
- **Explorers pause playback** (Settings › Playback). Opening the Chords or Scales Explorer pauses the song, as before. Switch it off to keep the song playing while you explore. Play and Space then keep working with an Explorer open.
- **Rate Orfeo** (Microsoft Store version). A star next to *Check for updates* opens the Store's review window right over Orfeo: pick the stars, write a few words, done. In this version the note offers the same, with *Later* and *Don't show again*, and stops for good once you've rated Orfeo.

### Changed
- **Settings pages in a clearer order.**
  - MIDI Keyboard now comes right after Audio.
  - Playback & Editing is split into **Playback** and a new **Editing** page. Editing holds hand assignment, the MIDI Note Editor and the track colour level meters.
  - *Reflect on keyboard* and *Starmap* move to Practice, and *Show precise scrub time* moves to Playback.
  - *Notation & Chords* is now **Chords & Notation**, with the chord settings first.
  - *Keyboard* is now **Virtual Keyboard**.
  - Playback and Piano Roll fit on one row, with no scrolling.
  - The MIDI Keyboard tabs (Keyboards, Sound & Latency) fit without scrolling, even with three keyboards connected.
  - On the Editing and Piano Roll pages, only the first column grows when its cards need more room. The other columns keep their size.
  - In *Playing live*, the two part headings are amber so they stand out. A pedal or control that hasn't been touched yet now reads *not detected*.
- **Engine and playing-mode buttons explain themselves.** Pointing at GM, Studio or Native, or at Low latency, Balanced or Stable, shows a one-line hint of what each is best for. You can switch these hints off with the other tooltips.
- **Long names scroll instead of being cut off** — the sound card and its mode in Audio, and keyboard names in the MIDI Keyboard list. *Only ticked* is now *Select*.
- **The song keeps its colours on the keyboard when paused.** Notes lit at a paused playhead (*Reflect on keyboard*, Step Through) now show in their track colours, or left/right hand colours, just as while playing. Amber is only for the tools now: the Explorers and lock-a-chord.
- **Lock-a-chord is amber**, like the Explorers. The two never show at once: opening an Explorer lets go of a locked chord.
- **The Explorers have the keyboard to themselves.** With a song paused, the song's notes leave the keyboard while the Chords or Scales Explorer is open and come back the moment it closes.
- **Step Through tooltips** fit on one line: *Next note or chord (Shift+→ next bar)*.

### Fixed
- **Explorers play piano again with the Native engine.** After a song with its own instrument on MIDI channel 16 had played, the Explorers, Lock-a-Chord and your keyboard could keep sounding that instrument (a sax or strings) instead of piano for the rest of the session.
- **No more plain white hover labels.** Since 1.5.2, pointing at a track, a piano key or some buttons could show a small white label next to Orfeo's own tooltip. They're gone.

## [1.5.3] — 23. 10. 2026 — Native mode sounds like Studio, clearer Settings

**In short**
- Orfeo's native mode now sounds like Studio: the same balance, placement, room and punch, measured song by song.
- Both sound engines play a song's own volume swells and fades, and tracks sharing a channel now share its mix.
- Clearer Settings: the engines are now GM, Studio and Native, with a Shared or Exclusive choice for Native. The MIDI Keyboard page is tidier, and tooltips can be switched off.

### Changed
- **Clearer Settings.**
  - Every page now opens with a short heading.
  - **Sound engine:** the three engines are now called GM, Studio (formerly Samples) and Native. Under them you see your sound card, its mode with sample rate and buffer, and the latency. The description shows only the engine you've picked.
  - **Low latency mode** (Native): two buttons, Shared and Exclusive, each explaining what it does. Exclusive warns that Orfeo takes over the whole sound card.
  - **Setup** shows the same engine buttons and rows.
  - **MIDI Keyboard:** the cards sit three across, at equal height. *Reconnect automatically* has its own card. "No keyboards connected" and your keyboard-to-speaker delay sit at the right of the tab row. The *Sound & Latency* tab has the Delay check, a *Playing live* card rewritten to be easier to follow, and the delay offset with General MIDI sound.
- **Tooltips can be switched off.** A new *Tooltips* switch under *Appearance*, in Settings and in Setup, is on by default. Turn it off once you know your way around, and the hints stop popping up when you point at buttons, knobs and icons. A knob still shows its value while you turn it. Windows' own small tips, such as file names, aren't affected.
- **Choose whether a keyboard switches Native to Exclusive.** A new switch under *MIDI Keyboard › Sound & Latency*, on by default. It's recommended when you play along on a keyboard and nothing else on the computer needs sound. Off: Native stays in the mode you choose.
- **The Library's "Right-click for options" hint** now appears just above the song, inside the Library, and only after you rest on a song for 3 seconds, not every time the mouse passes over.

### Fixed
- **Orfeo's native mode now mixes songs exactly like Studio.** Parts placed to one side of the stereo picture, such as a piano, guitars or a horn section panned left or right, came out 1.5–3 dB quieter in native mode, while parts in the middle got slightly louder. Their reverb stayed as loud as before, so those parts sounded pushed to the back of the mix. Instruments recorded in stereo, like the piano and horns in many sound sets, were also squeezed to one side, losing their width. Native mode now places every note left and right exactly as Studio does, keeping stereo instruments as wide as they are. Measured part by part on eight songs and two sound sets, every part is now within about 1 dB of Studio in level and in its left–right placement. Before, levels differed by up to 4 dB and placement by up to 13 dB. This works for every song, with nothing to set.
- **Orfeo's native mode no longer sounds thin next to Studio.** It played about 4 dB hotter into its peak limiter, which then flattened the bass and drum hits all the time, so loud songs lost their punch and the midrange came forward. Its level now matches Studio before any limiting. Its ceiling sits just under full scale, as Studio's does. Measured on whole songs, both engines now sound the same within about 1 dB in every octave, from the deepest bass to the top.
- **Parts that share a MIDI channel now share its mix.** Many files set a channel's volume, panning, reverb and chorus once, then add more tracks on that channel without repeating them. Orfeo gave those extra tracks full volume, centre position and no effects, so a pad, an organ or a lead on such a track could come out too loud and dry, or in the wrong place. Every track now takes its channel's settings from the song, wherever in the file they're written.
- **Both sound engines now play a song's own volume moves.** Many arrangements fade parts in and out, bring a guitar up for its solo, or swell the strings, sometimes hundreds of times in one song. Both engines used to hold every part at its starting volume, so those moves were lost. Now they play as written. The Console faders still work as before: pulling one down turns the whole part down, swells included.
- **Orfeo's native mode now puts songs in the same room as Studio.** It used FluidSynth's own reverb and chorus, which sound different from Studio's. Now it uses exactly the same reverb and chorus as Studio, fed the same way: each part's amount from the song, plus the touch the sound set gives each instrument. Measured on several songs with two sound sets, they're within about 1 dB of Studio. Switching engines no longer changes how close or far away the music sounds.

## [1.5.2] — 22. 10. 2026 — Studio interfaces, instrument changes, security

**In short**
- Orfeo's native mode now matches your sound card's real speed by itself in *Low latency*, so studio interfaces like the UAD Apollo no longer sound slowed down and distorted.
- Songs whose parts switch instrument mid-song (oboe, then guitar…) now play the right instrument at the right moment, on both sound engines.
- Security update to a newer Electron, Chromium and Node. *Check for updates* now takes you to orfeo.cc or to Orfeo's page in the Microsoft Store.

### Changed
- **Security update.** Orfeo now runs on Electron 44, with Chromium 152 and Node 24.22. The Electron 42 version it was built on stopped receiving security fixes this week. File pickers (Open MIDI file, Import SoundFont, library folder) still open in the folder you last used: Electron 44 would otherwise open them in *Downloads* every time.
- **Check for updates sends you to the right place.** In the Microsoft Store version it opens Orfeo's own page in the Store, with its *Update* button. In the portable version, and if an automatic update ever fails, it opens [orfeo.cc/download](https://orfeo.cc/download) instead of GitHub.

### Fixed
- **Parts that change instrument mid-song now do, on both sound engines.** Some arrangers switch a part's instrument partway through: a lead melody might be a nylon guitar in the intro, an oboe in the verse, then a guitar again. Orfeo shows such a part as one track per instrument in the Tracks panel, but they all share one MIDI channel, and both engines played that channel with a single instrument for the whole song: Samples the last one (oboe throughout), Native the first one (guitar throughout). Both now switch at the right moment, exactly as the file intends. An instrument you change in the Tracks panel is heard straight away, even mid-song.
- **Orfeo's native mode could play slowed down and distorted on some studio interfaces in *Low latency*.** Some audio interfaces (Universal Audio's Apollo, for example) run at the sample rate set in their own control app or your DAW, while telling Windows another one. Orfeo sent its sound at the speed Windows reported, and the interface played it at its own: too slow, too low, and crackling. Orfeo now times how fast the sound card really plays during its first two seconds. If that differs from what it reported, Orfeo switches to the card's real rate and checks again, staying in *Low latency*. You don't need to change any setting. If a card can't be matched, Orfeo shares it through Windows, which converts it correctly, and *Settings › Audio* says why.
- **The MIDI keyboard log (*Save log…*) now includes the sound card connection.** It records the sound card, its sample rate and format, the buffer, how fast the card really plays, and why it isn't in *Low latency*, if it isn't. One saved file is now enough to diagnose a sound problem.

## [1.5.1] — 22. 10. 2026 — Native sound, safe on every sound card

**In short**
- Urgent fix for the Native sound engine: on some sound cards it played at full volume, far too loud and distorted. It now follows your Windows volume on every sound card.
- Native can no longer overload any sound card, from a built-in chip to a studio interface. Two limiters now keep it clean at any volume.
- Native's *Low latency* is now off unless a MIDI keyboard is connected, so websites and videos keep playing alongside Orfeo.

### Fixed
- **Native played at full volume on sound cards without their own volume control, loud and distorted.** Windows' volume (the taskbar slider and the volume keys) is usually applied by Windows itself, after every app. *Low latency* talks to the sound card directly and skipped that step. Sound cards that do volume themselves, as most built-in chips and USB headsets do, weren't affected. Sound cards that leave it to Windows played Orfeo at full level, whatever the slider said: far louder than everything else, with the loudest passages audibly clipped. These include audio interfaces such as Universal Audio's Apollo, and HDMI or DisplayPort monitors. Native now applies the Windows volume and mute itself whenever the sound card doesn't, following the slider live. It's exactly as loud as the rest of your computer, on every sound card.
- **Native can no longer overload your sound card, whatever its make, driver or volume settings.** The song and the metronome now pass through two limiters. The first keeps loud passages in shape, as with the Samples sound. The second sets a hard ceiling just under full scale: it sees every peak coming a split second ahead and eases the level down just enough, never chopping the sound. Nothing goes above that ceiling, even with every volume at maximum. This happens inside Orfeo, so it doesn't depend on the sound card, its driver or any volume setting. The keys you play don't wait for the look-ahead, so they're heard as quickly as before.
- **Native's *Low latency* took over the sound card even with no keyboard plugged in**, so a website or video playing alongside Orfeo went silent. *Low latency* is now off unless a MIDI keyboard is connected. Plugging one in turns it on; unplugging the last one turns it off. Switching it by hand holds until the next keyboard is plugged in or unplugged, and every start of Orfeo begins from that rule.

## [1.5] — 22. 10. 2026 — Play your own keyboard, without the lag

**In short**
- A new sound engine for Windows (Native, beta): what you play on a USB keyboard is heard in under 10 ms instead of 40 ms or more, so playing along finally feels like a real instrument.
- A whole new MIDI Keyboard page in Settings: your keyboards, touch, pedals, and a delay check that shows where every millisecond goes.
- Step Through: go through any song one note or chord at a time with → and ←, at your own pace.
- Songs on the Samples sound now play the mix their arranger made, and Orfeo is in the Microsoft Store.

### New
- **Native sound engine (beta, Windows).** Until now every note went through Windows' own sound mixer, which holds it back 40 ms or more: enough that a fast passage on a USB keyboard felt sticky, as if the piano answered late. *Settings › Audio › Sound engine › Native (beta)* plays the same sound sets with Orfeo's own engine, straight to your sound card. On a USB audio interface or headphones, what you play is heard in under 10 ms.
  - **Low latency** (on by default) talks to the sound card directly, for the shortest delay. Other apps stay silent while Orfeo is open. Switch it off to share the sound card, so a browser lesson or a video call keeps playing alongside.
  - **It switches itself on when you connect a MIDI keyboard**, because that's when the delay matters. Switch it off by hand and it stays off until a keyboard is plugged in again.
  - **Richer, wider sound.** Every instrument sits where the song puts it: two guitars panned left and right, strings to one side, reverb where the arrangement asks for it.
  - **Rock-steady timing.** Songs, the metronome and the count-in all run on the engine's own clock, so the first note after a count-in lands exactly on the beat.
  - **Survives unplugging.** Pull your headphones or USB interface out mid-song and the music carries on through the next sound card without stopping, and comes back when you plug it in again.
  - The mixer, compressor, auto-level, tone control, chord previews and your MIDI keyboard settings all work just as with Samples, and you can switch engines in the middle of a song.
  - *Beta* means it's new and has been tested on a handful of machines. If anything sounds wrong, switch back to Samples in one click and tell us.
- **Settings › MIDI Keyboard**, a new page at the bottom of the Settings window, in three tabs:
  - **Keyboards** — every connected keyboard by its own model name, with a light that flashes as you play. Listen to all of them or only the ones you tick, reconnect automatically after unplugging, or *Rescan*. The first time you connect a new keyboard, Settings opens on this page.
  - **Sound & delay** — *Live playing response* for the Samples sound (*Low latency*, *Balanced*, or *Stable* for computers that crackle); an *Audio delay offset* that lines up key lights, the count-in and tapping with what you hear on Bluetooth headphones or an external instrument; a choice to play General MIDI through Orfeo or through your digital piano or sound module; and the **Delay check**, which shows how long each part of the trip from your key to your ear takes on your computer, with a log to send along with a bug report.
  - **Touch & pedals** — touch response (*Soft*, *Normal*, *Hard* or *Fixed*), ignoring very light touches and capping the loudest note; a filter for keys that accidentally sound twice; and the sustain, sostenuto and soft pedals, pitch bend, modulation, aftertouch, expression and volume from your keyboard, each marked *detected* once you use it and each one switchable off. The sustain pedal now works when you play your own keyboard.
  - **Reset & repair** — clear stuck notes, reconnect every keyboard, or put this page back to how it started.
- **Step Through** (*Settings › Practice*, on by default). Press → or click the amber arrow in the keyboard bar, and Orfeo jumps to the next moment something is played, a single note or a whole chord, sounds it, lights it on the keyboard and moves the playhead there. ← goes back one, and Shift jumps a whole bar. No tempo, no loop to set up: made for learning fast solos at your own pace and for writing them down.
  - Notes that start within 30 ms of each other count as one step, so MIDI files made from audio recordings, whose chords never start at exactly the same moment, still step chord by chord.
  - Muted tracks and drums are skipped: if another instrument leaks into the part you're learning, mute it and step through just yours.
  - Press → while the song plays and it stops on the next note; Space plays on from there.
- **Orfeo is in the Microsoft Store.** Install it from the Store and it keeps itself up to date there. The GitHub installer and portable version stay as they are.

### Changed
- **Keys you play on the Samples sound are heard 12 ms sooner.** They used to pass through the song's compressor and safety limiter, which hold every note back even when switched off. Songs still go through both.
- **The MIDI icon in the top bar** shows the keyboard you're actually playing, not the first entry in Windows' device list. Its tooltip lists any other keyboards, and clicking it opens the MIDI Keyboard settings.
- **No more hanging notes** when you unplug a keyboard mid-note or minimise Orfeo while holding keys or the sustain pedal.
- **"Practising" is spelled the British way** where it's a verb, as in "to practise the piano".

### Fixed
- **The Samples sound ignored each song's own mix.** The Console showed every track's volume, pan, reverb and chorus as the file sets them, but Samples played every track at full volume, centred and dry until you moved a knob. Songs now sound as their arranger balanced them: instruments placed left and right, quieter parts quieter, reverb where the file asks for it.
- **General MIDI went silent with a USB keyboard plugged in.** Orfeo sent the song, and what you played, to the keyboard's own MIDI connection instead of its own synth. It now always uses its own synth, unless you choose an instrument in *Settings › MIDI Keyboard › General MIDI sound*.
- **The Microsoft Store version no longer tries to update itself from GitHub.** The Store keeps it up to date, and *Check for updates* opens the Store.

## [1.4.4] — 15. 10. 2026 — Starmap

**In short**
- New Starmap view in the Scales Explorer: the chord you hear drawn as a glowing star on a ring of the 12 notes, gliding from chord to chord. Turn it on in Settings › Appearance.
- Play a chord on your MIDI keyboard and the Starmap draws it too.
- Hand-lettered start screen, and the keyboard bar's hint now stays centred in the window.

### New
- **Starmap view in the Scales Explorer.** Turn it on in *Settings › Appearance › Starmap*, then flip the *Starmap* switch in the explorer's right-hand column to swap the Circle of Fifths (still the default) for a ring of the 12 notes, C at the top.
  - The chord you hear is drawn as a glowing star joining its notes, in its root's own colour, with its name in the centre. Every major chord is the same triangle turned, every minor chord its mirror image, and 7ths and 9ths are four- and five-pointed stars.
  - **The star glides from chord to chord**: notes the two chords share stay put, the others travel round the ring, the colour blends and the names cross-fade. The glide always finishes before the next chord, even at the fastest speed. With Windows' animation effects turned off, the star jumps instead.
  - The scale's notes are bright, the home note amber, and with no chord playing a faint outline joins the scale's notes. In the blues scales the blue note has a blue ring.
  - **Play it yourself:** hold a chord of 3 to 6 notes on your MIDI keyboard and the Starmap draws it as a star with its name, gliding from chord to chord as you play. Let go and it glides back to the explorer's chord. The explorer's own chord and keys stay as they were.
  - **Two ring orders**, switched in the corner of the ring: *Semitones* (C, C♯, D…) or *Fifths* (C, G, D… — the Circle of Fifths order, where a scale is one unbroken arc and chords pack tight). The star glides between them.
  - Hovering a note lights its band of the ring (where its name sits) amber (tooltip: *Click to play* that key in the selected scale); the note's star dot shows the key name.
  - Click a note on the ring to pick the key. *Maj | Min* next to the Starmap switch decides which: switching it turns C major into C minor. A scale that already fits (Dorian, Lydian…) stays selected.

### Changed
- **The start screen's "Let's face the music"** is now hand-lettered, in amber.
- **The keyboard bar's hint** (*Shift+Click three keys…*) stays in the middle of the window whether the side panels are open or closed — it used to slide sideways.
- **The switch to the other Explorer** (*Chords Explorer ↗* / *Scales Explorer ↗*) now looks the same in both: a dashed amber outline, text turning amber on hover.
- **Scales Explorer chord tiles** show every note of the chord on its own line above the chord's name, so names like *C♯/G♯* no longer cut the notes off. The tiles are a little taller.

## [1.4.3] — 15. 10. 2026 — Chords Explorer styles

**In short**
- Two new Styles in the Chords Explorer: Gospel and Flamenco. Ipanema now plays its tritone substitution.
- The Chords Explorer shows the chord you're hearing, with its inversion and notes, right inside the window.
- A tidier Chords Explorer footer, and a few Style chords that never sounded now play as described.
- A hidden surprise somewhere in the Chords Explorer.

### New
- **The Chords Explorer now shows the chord you're hearing.** The row under the progressions has the chord's name in amber in the middle, with its inversion (e.g. *Cmaj7/E 1st inv*), the same as above the keyboard. With nothing lit it shows the selected root. *Sequence ›* and the progression's numerals sit on the left; the lit notes, low to high, and *‹ Notes* on the right. The labels stay put however long the chord is.
- **A hidden surprise in the Chords Explorer.** Hover the Orfeo logo in its title bar.
- **Two new Styles in the Chords Explorer: Gospel and Flamenco** (nine in all).
  - **Gospel:** church harmony. A 6/9 home chord, maj9 on IV and VI, minor 9ths and 11ths, a 13th on V, ♭VII as a dominant 9th and vii° as a full diminished 7th. Pop in C: C6/9 – G13 – Am11 – Fmaj9.
  - **Flamenco:** Phrygian colour. V becomes a 7♭9 (also when it's a minor v), and VI opens into maj7♯11, like the open-string guitar chord. Andalusian in A minor: Am – G – Fmaj7♯11 – E7♭9.
- **Ipanema now really uses the tritone substitution.** A V that resolves down a fifth is replaced by the dominant chord a tritone away: Jazz Standard in C plays Dm11 – D♭7♯11 – Cmaj9 instead of Dm11 – G13 – Cmaj9.

### Changed
- **Chords Explorer footer tidied up.** Six controls, evenly spaced: *Show as*, *Octave*, *Inversion* (was *Play Inversion*), *Accent Root*, *Clear* and *Scales Explorer*. *Clear* now also stops a playing progression and works for power chords.
- **Amber scrollbars in the Chords Explorer** — the chord tiles and the progression list — the same as in the Scales Explorer.

### Fixed
- **Some Style chords never played.** Ipanema's IV (Fmaj7♯11 in C), Velvet's V (G7♭9♭13) and Velvet's vii (Hm9♭5) were silently played as the selected tile's chord, usually a plain triad. They now sound as described.
- **Styles no longer change chord quality where they have no chord of their own.** In Roadhouse, Pop's vi played as A major instead of Am, and in Cinematic, the ii° of Minor Jazz played as a major chord. These steps now fall back to the plain chord the numeral names.

## [1.4.2] — 15. 10. 2026 — Explorers upgrade

**In short**
- The Scales Explorer has a new, cleaner layout: a bigger Circle of Fifths, with every setting in one column on the right and the full progression list always open.
- Both Explorers now follow exactly the same rules: the same 61 progressions, played exactly as written, with three clearly different voicings.
- New Major Blues and Minor Blues scales, and an Octave control in both Explorers.
- Dragging an Explorer by its title no longer grabs or un-maximizes the whole Orfeo window.

### New
- **Major Blues and Minor Blues scales** in the Scales Explorer. Their tiles are the chords you play the scale over — C7, C6, A7, C7♯9 for C Major Blues; Cm7, C7, F7, G7 for C Minor Blues — because stacking every other note of a blues scale gives odd chords.
- **Octave control in both Explorers.** *Octave* with up and down arrows and a reset (bottom left in the Chords Explorer, in the settings column in the Scales Explorer) moves everything the Explorers play up or down by whole octaves (from C2 to C5 roots). The chord that's lit on the keyboard moves with it, and both Explorers share the setting.
- **Accent root note in the Chord Explorer.** The same switch as in the Scales Explorer, now at the bottom right of the Chord Explorer too: the chord's root shows in pink on the keyboard, in every octave.
- **Smooth voicing for Chord Explorer tiles.** With Voicing set to Smooth, a chord tile clicked while another chord is lit plays the version closest to it — C, then Cmaj7, then C7 stay under one hand instead of each starting from the root.
- **Hand-lettered "Circle of Fifths"** title in the middle of the circle.

### Changed
- **Both Explorers now follow the same rules.** The same progressions, speeds, starting register, inversion buttons, chord colours and the way a clicked chord sounds — any later change applies to both.
- **The Scales Explorer has the full progression list** — 20 progressions, 61 counting the versions that start on another chord, the same list as the Chord Explorer, with the variants indented under each one.
- **Progressions play exactly as their numerals say, in both Explorers.** I–♭VII–IV in C plays C–B♭–F, Andalusian gets its major V, and Pop is always I–V–vi–IV. In the Scales Explorer a progression can now step outside the selected scale; steps that match a tile still light it.
- **Voicing now applies to the chord tiles and the "Chords in the Scale" run**, not just progressions, and takes effect the moment you pick it — the selected tile moves to its new place on the keyboard. Each tile shows the chord as it's voiced, with the bass note after a slash (Dm/F).
- **The three voicings sound clearly different.** *Roots*: every chord in root position. *Climbing*: the chords climb through inversions (C, Dm/F, Em/G, F/A …). *Smooth*: the chords stay under one hand around the starting position.
- **Every key starts in the same place.** The scale run, the chord tiles and the first chord of a progression start with the root between C3 and B3 in both Explorers, in every key.
- **Speed applies to the "Chords in the Scale" run too**, and changes take effect on the next chord. The speed arrows are bigger.
- **Clicked chords ring longer**, like holding the sustain pedal, and chords sound the moment you press a tile or an inversion arrow.
- **The pink root note is always the chord's own root**, in every voicing, in both Explorers — and switching *Accent root note* recolours the keyboard straight away, even mid-run.
- **New Scales Explorer layout.** The two rows of controls under the tiles are gone: every setting now sits in a column on the right — *Progressions* as an always-open, scrolling list with a reset arrow (clears the pick) and PLAY right under it (PLAY is greyed out until you pick one; pick another while one plays to switch straight to it). The picked progression stays pinned to the top of the list while you scroll, and the list's scroll handle is amber. Then *Inversions*, *Chord voicing*, *Playback speed*, *Octave*, *Accidentals*, *Accent root note*, a placeholder for the upcoming Starmap view, *Reset explorer* (starts over: clears the key, scale and progression), and the *Chords Explorer* switch — each with a one-line description. The Circle of Fifths is bigger and centred, the guide text at the top left reads in fewer, evenly broken lines, the scale name and notes under it are larger, and *Chords in the Scale* (also larger) sits centred under the circle with more room above it. The window opens centred, with its bottom edge just above the chord name row over the keyboard. The selected tile is light amber, *SCALE* is in amber, and Roots mode has a new note icon.
- **The ↺ beside the inversion arrows now undoes the inversions**, in both Explorers: it puts the lit chord back to the shape it had when you played it, however many times you flipped it — even after moving it with *Octave*. In the Scales Explorer it used to wipe the whole explorer; that's now *Reset explorer*. In the Chords Explorer it used to turn the chord off; that's now *Clear*, next to *Octave*.
- **Chord Explorer:** the PLAY button appears once a progression is picked, the selected tile is light amber, and sharps show as ♯.

### Fixed
- **Scales Explorer chord tiles in keys other than C jumped around the keyboard.** Each tile was placed on its own, so in G the C chord dropped below the G chord. The row is now laid out as one run from the home chord in every key.
- **♭VII and ♭III progressions** (Mixolydian Rock, Grunge · Modal, Step-Down) **played the home chord** in place of those steps in the Scales Explorer.
- **Looping progressions in Roots and Climbing kept rising** every time round, up to the top of the keyboard. They now come back down after about two octaves.
- **Clicking the same chord tile quickly cut its sound short.**
- **Turning off *Accent root note*** left the last chord's root pink and didn't affect a run already playing.
- **Grabbing an Explorer window by its title sometimes moved or un-maximized the whole Orfeo window** instead, whenever the explorer sat over the top bar — you had to hit the very edge of the title to drag it. The same fix covers the Chords Explorer, Lock-a-Chord, the floating keyboard, the MIDI editor, the mixer and File Info.

## [1.4.1] — 11. 10. 2026 — Smaller download

**In short**
- Smarter chord reading: chord names now appear when you hear the chord, follow the instruments actually playing the harmony, and there's a new Progressive mode.
- Tap Tempo: fix songs whose bar lines and metronome don't match the music — tap along and Orfeo lines up the beat, with optional warnings for songs that need it.
- Count-in of 1–4 bars before the music starts, a metronome volume control, and clicks that follow time-signature changes.
- A new Settings window with search and links to the online manual, the everyday switches kept in Setup, and zoom for the whole app with Ctrl + / Ctrl −.

### Changed
- **Smaller download.** The installer no longer carries website screenshots, duplicate copies of the demo songs and PDF fonts, or developer-only map files.
- **The user manual now lives at [orfeo.cc/docs](https://orfeo.cc/docs)** and is linked from the top of the README; it's no longer kept in this repository.
- **The installer is now called `Orfeo-Setup-<version>.exe`**, without spaces, matching the portable `Orfeo-<version>-portable.exe`.

## [1.4] — 4. 10. 2026 — Settings window

### New
- **A full Settings window.** Every setting now has a proper home with room to explain itself: the eight groups are listed down the left, and each group opens with a sentence on what it's for, then its settings as cards — three across, or two or one on a small window or at a high App Zoom — each with its full description written out, no hovering needed. Options that only matter once a setting is on (Tap Tempo counting, count-in bars, max fingers per hand, the visual-effect pattern and glow, the instrument to follow) sit inside that setting's card and appear when it's on. Open it from the **Open settings** button, from any group in Setup, or with **`Ctrl` `,`** from anywhere; `Esc`, the `X` or a click outside closes it, and the music keeps playing. Drag it by its header like the Mixer.
- **Search settings** — type in the box at the top of the window to find any setting by name or by what it does, across all groups.
- **Open in user manual** — every group links to its page of the online manual at orfeo.cc.
- **ORFEO, the version and Check for updates** sit at the bottom of the group list in the window.

### Changed
- **The left panel's Settings tab is now Setup** (sliders icon) and holds only the everyday switches: sound engine, demo songs, Focus mode, Tap Tempo, Hand Assignment, Chord Prompter, note names, sharps/flats, chord tracking, key range, keyboard labels, piano-roll zoom, bar lines, the playbar and App Zoom. Each has a short line underneath saying what it does, and the at-a-glance details stay (output delay, which sound set is loaded, note-name and sharps/flats previews, what the chord-tracking mode listens to). Everything else is in the Settings window, under the same group names.
- **Open settings** sits at the top of Setup and stays put while you scroll; a small ↗ arrow on each Setup group opens that group in the Settings window.
- The first time you pick **Samples** in Setup, the Settings window opens on Audio so you can see the sounds load. Picking **Follow** before choosing what to follow opens it on Notation & Chords so you can choose.
- **Output delay** now shows its number in amber, and the Settings window explains what it means.
- **Tooltips in the top bar and the Tracks panel** break into two shorter lines instead of one very wide one, and the tooltips on each track's mute, solo, show-in-roll and keyboard-light buttons use the same quieter text as the rest. The update icon's tooltip now simply says "Check for updates".

## [1.3.2] — 4. 10. 2026 — Settings polish

### Changed
- **Demo content** is now *Show demo content* — on shows the demo songs in the Library, off hides them, and the description below it says which one you're on.
- **App Zoom** (Settings → Appearance) sits on one line, with the zoom buttons and reset on the right, and explains that `Ctrl` `+` / `Ctrl` `-` / `Ctrl` `0` work exactly as in a web browser.
- Hand Assignment is no longer marked BETA.
- The greyed-out Chord sensitivity slider is no longer shown; it comes back with the reworked chord tracking.
- The User Manual link at the bottom of Settings now opens the online manual at orfeo.cc/docs.

## [1.3.1] — 3. 10. 2026 — Tooltip and docs polish

### Changed
- Shorter, clearer tooltips for the TAP pad and the metronome, and the MIDI indicator now reads "NO KEYBOARD" when no keyboard is connected.
- How to Use and the README now explain that Orfeo needs no internet connection to play, practise or edit, which sound sets come with the installer, and which are optional downloads.

## [1.3] — 3. 10. 2026 — Count-in

### New
- **Count-in.** Hear 1–4 bars of clicks before the music starts — right-click the metronome (or Settings → Playback & Editing) to turn it on and pick the number of bars; a small number on the metronome shows it's on. It counts at the song's real tempo and time signature (your speed setting and any kept Tap Tempo included), skips empty bars at the start so it leads straight into the first note, lets an upbeat come in where it belongs, and counts mid-song restarts into the start of the bar. A big 1-2-3-4 counts along over the piano roll; Space, Esc or Play cancels. The sound engine gets ready during the clicks, so the music comes in right on the beat even on the first Play after opening a song — on both sound engines.

### Fixed
- **When playback started exactly on a beat, the metronome skipped that first click.** It now clicks the first beat too.

## [1.2.1] — 3. 10. 2026 — Tempo warnings

### New
- **Tempo warnings — find the songs whose bar lines and metronome don't match the music.** Turn on *Tempo warnings* in Settings → Playback & Editing (off by default). Orfeo checks each song for a steady beat that its bar lines miss: affected songs get an amber dot in the Library, and a pulsing light under the TAP pad when you open one. Click the light to see what's off in plain words — for example "the beat sounds closer to about 91 than the file's 60 — check by ear", or "the bar lines sit off the played notes — the tempo may be right, or counted at double or half speed" — then fix it with Tap Tempo or dismiss it for that song. Freely played music (rubato piano, free-time intros, sparse lead sheets) is never flagged, and the warning clears by itself once you keep a Tap Tempo that lines up with the music. The Library check runs quietly while the Library tab is open, never while a song is playing, and remembers its results.
- **"Original is fine"** — when your tapped tempo matches the file's own, the Tap Tempo panel offers to keep the file as it is and stop warning about that song.

### Fixed
- **Scrolling while a Tap Tempo session was waiting for your taps closed it**, and Space went back to pausing the song. Scrolling now just moves the start point to where you scroll to.
- **On songs that start right on the first beat, the first few Space taps could pause the song** instead of counting as taps. Fixed — tapping works from the very first beat.
- **After keeping a tapped tempo, the tempo warning stayed on** in the top bar and the Library. It now goes away; only the small dot on the TAP pad remains.
- **No way to bring back a dismissed tempo warning for one song** — right-click the TAP pad → *Show tempo warning again*.
- **On windows 1366 px wide or narrower, the TAP pad pushed the Key/Transpose arrows partly out of view.** The pad is a little smaller and the spacing around the tempo and key boxes a little tighter, so everything fits again.

## [1.2] — 2. 10. 2026 — Tap Tempo

### New
- **Tap Tempo: fix songs whose bar lines and metronome don't match the music.** Some MIDI files carry the wrong tempo, so the clicks drift off the drums or the tempo reads double or half what you hear, even though the song itself plays fine. Turn on *Tap Tempo* in Settings → Playback & Editing, put the playhead where things go wrong, click the red **TAP** pad and tap along with `Space` or any key on your MIDI keyboard — on every beat, or only on the 1 if you prefer (a Settings choice). Click TAP again to see the measured tempo. Orfeo lines your beat up with the song's own drums and bass, so the bar lines and clicks land exactly on the music rather than on your slightly early or late taps. Listen back with the panel still open, move the 1 by a beat or the clicks by a few milliseconds while it plays, and press Keep. From that point on, the bar lines, metronome, bar counter, BPM readout and chord display all follow your tempo. The song's sound never changes, your MIDI file is never modified, and the tempo is remembered for that song (even after renaming or moving it, and when Orfeo saves a new version of it). Songs can have several tapped tempos, e.g. a slow intro and a faster groove. A small dot on the pad shows a song has them; right-click the pad to reopen one and adjust it, remove it, or reset them all. Every change is listed in File Info → Orfeo History.
- **Songs counted at double or half speed get their tempo number fixed without touching their bar lines.** When your tapped beat lands exactly on every second beat of the file (the file says 190 but you hear about 95), Orfeo offers to keep the file's own bar lines, time-signature changes and clicks exactly as they are and only correct the tempo number.
- **Metronome volume** — right-click the metronome to make the clicks louder or quieter (0–150%).

### Fixed
- The key tooltip showed key names in capitals ("EBM" instead of "Ebm"). Note and key names in tooltips now keep their real spelling.

### Changed
- The BPM ▲ / ▼ arrows now move the tempo you *see* by exactly one. Before, on a song that changes tempo partway through, one click could move the readout by more or less than one.

## [1.1.2] — 1. 10. 2026 — Metronome/bar-grid time-signature fix

### Fixed
- **The click track and the piano roll's bar lines/bar counter could drift off the real "one" on any song that changes time signature partway through** (for example a run of 3/4 bars followed by a 4/4 bar, then back again). Both only ever looked at the very first time signature written into the file and assumed every bar afterward was that same length — so once the song actually switched bar lengths, a four-beat bar got counted as a three-beat bar (or the reverse), and every accent and bar line after that point landed on the wrong beat for the rest of the song. Both now follow every time-signature change in the file, not just the first one, so the click and the bar grid stay locked to the real beat 1 all the way through, on any song that shifts between different bar lengths.
- **The little time-signature readout next to the tempo box had the same problem — it showed whatever the song started in and never updated**, so a song that moves between, say, 3/4 and 4/4 kept showing the very first one for the whole song even while a four-beat bar was actually playing. It now tracks the real current bar as the song plays, the same way the tempo number next to it already does.
- **Editing controls in the MIDI Playback Editor (Piano Roll toggle, Keyboard toggle, Merge, Split, color picker, instrument revert) stayed clickable even after you unticked a track to leave it out of the save** — nothing actually happened when you used them, but they didn't look disabled either, which could make it seem like your changes weren't sticking. Only the Include checkbox itself still responds on an excluded track now; everything else dims and stops reacting, matching how the row's own greyed-out look already suggested it should behave.
- Note Editor: Snap button now uses the Lucide magnet icon (the old custom glyph was drawn about twice as thick as the other toolbar icons).
- Track Panel and MIDI Playback Editor: the keyboard toggle now uses the same 3-key piano icon as the Console Mixer. All four places share one `PianoKeysIcon` component.

## [1.1.1] — 28. 9. 2026 — App zoom, piano roll freeze fix

### New
- **App zoom** — `Ctrl` `+` / `Ctrl` `-` / `Ctrl` `0` scale the whole app up or down in fixed steps (80% to 200%), the same as zooming a browser page. Works everywhere, even with a text field focused. Capped so the window can never shrink to an unusably small size on a smaller screen; also available as a control in Settings → Appearance. Remembered between sessions.

### Fixed
- **Audio and the piano roll could stutter or briefly pause during playback in the development build** (`npm run dev`), especially on busy songs — never an issue in the packaged release. Every note for the rest of the song was queued up the instant playback started; the polished, packaged build breezes through that instantly, but the unoptimized development build could visibly and audibly catch up whenever the music bunched up a lot of notes at once. Playback now only keeps the next second and a half queued at a time, continuously topped up as the song plays, so there's never more than a small amount of work to do at once, no matter how dense or long the song is.
- **The piano roll could completely freeze — no falling notes, though the music kept playing and the keyboard kept lighting up correctly — on any screen set to 125%, 150%, or 175% Windows scaling.** A rounding mismatch between the roll's drawing size and the screen's actual scaled size made it think it needed to resize on literally every single frame, and it was bailing out to do that resize instead of ever getting to actually draw the notes. 100% and 200% scaling happened not to trigger the rounding error, which is why it looked like an all-or-nothing thing. Changing your screen's scaling while Orfeo is already open now also updates the roll immediately, instead of needing a restart. The Mixer's level meters had the same kind of rounding blind spot and are fixed the same way.
- **A thin grey line could appear on the left and right of the top bar at 150% app zoom.** A pre-existing fallback that lets the logo/tempo cluster and the transport/MIDI cluster scroll internally, rather than get clipped, on a very narrow window was showing its scrollbar at an ordinary window size once app zoom shrank the usable space enough to trigger it. Scrolling still works if it's ever genuinely needed; the bar itself no longer shows.
- **The "no file open" screen could grow into and get covered by the top bar and keyboard at higher app zoom levels.** It now stays at its normal size and position no matter what zoom you're at, since the rest of the window's usable space doesn't grow to match.

### Updated
- Electron 42.8.1 → 42.11.8
- React / React DOM 19.2.8 → 19.3.0
- Zustand 5.0.14 → 5.0.15
- Pixi.js 8.19.0 → 8.21.0
- spessasynth_lib 4.3.13 → 4.3.14
- lucide-react 1.31.0 → 1.48.0
- pdfkit 0.19.1 → 0.20.2

## [1.1.0] — 13. 9. 2026 — Progressive chord reading, chord display timing fix, playback volume fix

### Fixed
- **A chord could display up to three quarters of a second before you actually heard it**, when a brief chord just before it happened to die out in the same beat the next chord's own display was reading from. The display now anchors to the exact moment the new chord's own notes are struck together, not just the nearest beat line.
- **Volume dropped after resuming playback or seeking to a new spot mid-song** (GM sound engine only). Seeking sends a MIDI "reset all controllers" message that was quietly cancelling out the volume level right after it was set; volume is now re-applied after the seek instead of before, so it holds.
- **"Follow" chord tracking with no instrument or group chosen yet was silently reading every track in the file, bass included**, instead of falling back to the same smart default Auto mode uses — this is what made Follow mode look like it was "reading the bass" on some songs.
- **Locked or right-click-shown chords on the on-screen keyboard now light up in their own color** (a soft pink) instead of amber, so they're never confused with "Reflect piano roll on keyboard"'s amber reading when both apply to the same notes at once.
- **Right-clicking a chord and choosing "Show on keyboard" showed a generic, rebuilt voicing instead of the chord exactly as it's played.** The real notes at the playhead were already being read correctly, then discarded in favor of a synthesized one-octave shape — so a chord's actual register, inversion, and any doubled notes never matched what's on the piano roll. It now shows the real voicing, straight from the file. ("Open in Chord Explorer" is unaffected — it still gets the clean, canonical shape, which is what that view is for.) As a side effect, this also fixes a doubling bug with "Reflect piano roll on keyboard" (Settings → Keyboard): right-clicking to lock a chord while that's on used to add a second, differently-voiced copy of the same chord instead of matching what was already lit.
- **Isolating a track to review its chords — hiding everything else on the piano roll — didn't show anything on the keyboard.** Both "Reflect piano roll on keyboard" and right-click "Show on keyboard" were reading which tracks are flagged to light up during real playback (piano/keys by default) instead of which tracks are actually shown on the piano roll. Now they always match whatever you've got visible — hide down to one guitar or string part and its notes light the keyboard, exactly as advertised.
- **The right-click menu on the chord name covered the name it was opened from.** Nudged up and to the right so the chord name stays visible underneath.
- **Downloading or importing a soundfont didn't switch to it.** After a FluidR3 / MuseScore download finished, or after importing your own .sf2, you still had to open the dropdown and pick it by hand. It's now selected and loaded automatically — the dropdown is just for switching between soundfonts you've already got.
- **A hidden track could still light up the on-screen keyboard during playback, in its own color, for no visible reason.** Real-time keyboard lighting only checked a track's "Lit on keyboard" switch, not whether it was actually shown on the piano roll — so a track you'd hidden could still light the keys during playback with nothing on screen to explain it. Now it only lights up while both switches agree, matching how pausing/scrubbing and right-click "Show on keyboard" already behave.
- **The chord name and keyboard lights could run slightly ahead of the sound itself.** Every sound device has some real delay between "play this note" and it actually reaching the speakers; nothing in the app accounted for it, so the display always updated a touch early. It now reads that delay from your actual audio setup and holds the display back to match — measured at about 40ms on a typical setup. How much this fully resolves "not quite on the beat" depends on your own hardware; a further pass may still be needed once real-world testing confirms how far it closes the gap.

The live chord display was erratic enough to be a hindrance rather than a help: it flickered through wrong names as a melody moved over a held chord, over-analyzed plain triads into extended jazz voicings, surfaced obscure names almost no one would recognize, and went blank through instrument-only intros. This release rebuilds how the playback chord bar and prompter decide what to show.

### New
- **A second, opt-in way to read chords — "Chord reading" (Settings → Notation & Chords), Safe or Progressive.** Safe is the existing reading and stays the default, completely unchanged. Progressive also trusts a real, clean grab of notes — several played together, or rolled quickly within about an octave — to show a brief chord's extra color (like a 7th) right away, even when it doesn't ring long enough for Safe's own check to trust it. Switches instantly on a song that's already open, no reload needed.
- **A measured output-delay readout next to the Sound engine setting** (Settings → Audio) — shows the real gap between telling your sound card to play a note and it actually reaching the speakers, since every machine answers this differently.
- **Auto chord-tracking mode, now the default.** Reads the chord chart the way a musician would. It listens to the instruments that actually play chords (piano, keys, guitar, strings, ensembles), sets the melodic fills aside so the tune never changes the chord, and marks a new chord only where the accompaniment genuinely turns over — so a held chord under a busy melody stays put, an arpeggio is gathered into one name, and three real changes in a bar show as three chords. Each span is named against the full vocabulary, with a lean toward the plainer name so a passing note can't turn a triad into a 13th. The bass line adds a slash / inversion, nothing more.
- **The chord prompter now compresses quick chord changes** into a tight cluster — smaller type, no full-width slot each — so a burst of short chords reads as a run rather than shoving everything else off-screen.
- **Chord sensitivity slider** (Settings → Notation & Chords). One control for how finely the detector splits the beat — left for the underlying harmony, right to catch passing and embellishing chords. It applies to every tracking mode, so the mode now only chooses which tracks are read and the slider chooses the detail.
- **Progression playback in both Explorers is voiced like a player, not triggered.** A new **Voicing** toggle — Roots (root position, stepping up), Climbing (first chord low, then the nearest inversion just above each time — always ascending, never resetting to the octave), Smooth (the nearest voicing to the one before, fewest notes moving) — replaces the old off / sequential / random inversion buttons, and is shared between the Chord and Scale Explorers. Each chord is lightly rolled bottom-up with a little velocity variation. The separate Style dropdown still sets the chord quality per degree.
- **"Reflect piano roll on keyboard"** (Settings → Keyboard). While paused or scrubbing, the on-screen keyboard continuously lights whatever notes are sounding at the playhead, straight from whichever tracks are currently visible on the piano roll — no more right-clicking a chord and choosing "Show on keyboard" just to see what's under the cursor while scrubbing through a passage. Off by default; real playback lighting is untouched either way.
- **"Hide all" button on the Tracks panel.** Same eye icon and idea as the Mixer's mute-all — clears every track off the piano roll in one click so you can bring individual ones back manually while reviewing a song. Matches the same toggle already in the Console Mixer, so both stay in sync.

### Changed
- **"Harmony" and "Follow" are scope choices only now.** "Harmony" pools every non-drum track (melody included) for dense arrangements where no one instrument holds the chords; "Follow" scopes to one instrument or group you pick. How much detail each surfaces is the new Chord sensitivity slider, not the mode — the old fixed per-mode sensitivity is gone.
- **"Classic" tracking mode removed.** It pooled every track by note onset and flickered on essentially any input; a saved "Classic" preference now loads as Auto.
- **The chord sensitivity slider is temporarily switched off** (dimmed in Settings, reads at a fixed level) while the underlying chord-reading algorithm itself is still being tuned — a moving target on the detail level made it unclear whether a wrong reading came from the algorithm or from wherever the slider happened to be sitting. Nothing is deleted; it'll come back once the algorithm is settled.
- `src/App.tsx`, `src/components/ChordExplorer.tsx`, `src/components/ContextMenu.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/Transport/TopBar.tsx`, `src/hooks/useAudioEngine.ts`, `src/hooks/useChordSequence.ts`, `src/hooks/useSamplesEngine.ts`, `src/store/index.ts`, `src/types/index.ts`, `src/utils/beatGrid.ts` (new), `src/utils/beatGridTest.ts` (new), `src/utils/chordDetection.ts`, `src/utils/chordSequenceBuilder.ts` (new), `src/utils/chordSequenceBuilderTest.ts` (new), `src/utils/chordVocabulary.ts` (new), `src/utils/chordVocabularyTest.ts` (new), `src/utils/debugTimestamp.ts` (new), `src/utils/midiParser.ts`, `src/utils/trackChordRole.ts` (new), `src/utils/trackChordRoleTest.ts` (new), `src/utils/voiceLeading.ts` (new).

### Fixed
- **Erratic chord flicker under a moving melody.** Every micro-change to the set of ringing notes that produced a different name was pushed as its own event, and passing melody and ornament notes were counted as chord tones. A sustained A-major triad with a flute line over it cycled through "A", "Dmaj9/A", "Amaj7", "A6add9" and back; it now holds "A" — the melodic line is identified per note and set aside before the chord is read.
- **Chord changes inside a bar were averaged away.** The old detector summarised roughly a bar at a time, so three quick chords in one bar collapsed to one. It now marks a change wherever the set of held chord tones actually turns over, at any rate the music does.
- **A held pad hid the chords played over it.** When a string patch sustained one triad while the piano moved the harmony on top, the pad's energy swamped the piano and the whole passage read as one chord. A note that has been ringing for several bars now fades in weight, so the instrument actually playing the changes is heard.
- **No chords shown during an instrument-only intro.** A solo-guitar opening left the display blank because detection pooled all tracks and found nothing stable. The track picker now identifies the guitar as the chord source and names chords from the first bar.
- **Obscure chord names** like "Bsus24" or "Gb7b6". Detection weighed roughly a hundred `tonal` chord types equally and then tried to argue the strange ones down after the fact. Both the live display and the paused read-out now match against a hand-checked template set — every extended and altered quality a chart would actually use (maj7, 6/9, m7♭5, 9, 13, altered dominants…), and nothing that isn't a real chord name.
- **3/4 to 4/4 alternating-meter songs placed chord changes off the beat.** The beat grid read only the first time signature in the file; it now honours the full tempo and time-signature map, so changes land on the real downbeats even when the meter shifts every bar.
- **The chord name flashed up before you heard the chord.** It appeared on the beat line — the metronome position — so a chord struck late in the beat, or pushed onto the off-beat, showed its name up to a beat early (most of a second on a slow tune). The name now lands on the actual strike; tightly-quantised files are unaffected, expressive and syncopated playing now tracks the ear.
- **A rolled or arpeggiated chord chopped into a new name every beat.** On solo piano especially, a broken chord moved its lowest note each beat and the detector called each one a fresh chord — a single held bar could read as a dozen. It now recognises the same notes ringing underneath and holds one name until genuinely new notes are struck. (Sheet-music editions that print the sung melody into the piano staff can still over-colour a triad — being sharpened.)
- **A chord spelled out one note at a time — a guitar strum, a rolled piano chord, a broken bass line — could read as unrelated single notes instead of the chord it adds up to.** The chord-change logic was rebuilt around when notes are actually struck, gathering notes that arrive one after another into the one chord they spell, with the name landing right on the first note of the new chord rather than a beat later.
- **Whole instrument families (brass, reed, pipe, synth lead) were silently left out of the chord read.** A synth-brass part comping the actual changes is exactly as valid a chord source as a piano; a solo trumpet line is exactly as much a distraction as a solo flute line. Auto mode no longer filters by instrument name — only drums, the bass line, and true sound-effect patches are set aside — so which tracks carry the harmony is judged by what they actually play.
- **The chord sensitivity slider didn't change anything.** One of its two smoothing passes wasn't wired to it at all, so every setting produced an identical display. Both passes now respond to the slider.
- **A brief passing chord — struck for well under a beat, then straight back to what came before — could vanish from the display entirely**, on top of a separate issue where even a fully clean, confidently-read one was smoothed away at the normal sensitivity setting and only appeared with the slider turned up. Both fixed — a real passing chord now shows at the default setting.
- **A chord could appear before any note had actually sounded**, when the display was reading purely off a lone, unaccompanied melodic pickup note before the rest of the band comes in (a solo piano pickup at the start of a song could show a chord name across several bars before anything else played). It now waits for that note's own onset, same as any other chord.
- **Right-clicking the playback chord name could lock in — or open in the Chord Explorer — a completely different chord than the one on screen.** "Show on keyboard" was re-guessing the chord from every note sounding anywhere in the file at that instant, with no regard for which instruments actually carry the harmony; one extra note from an unrelated track playing at the same moment was enough to name something else entirely (a plain "A" could lock in as "Dmaj9/A"). It now always uses the exact chord already shown above the keyboard — only the voicing (register, bass note, inversion) is still read from the real notes at the playhead.
- **Changing the tempo and then scrubbing to a spot before pressing play threw the audio out of sync with the piano roll** — playback could sound like it was picking up from far earlier than the visible playhead, worse the further you'd scrubbed and the more the tempo had changed. A scheduling calculation was mixing a tempo-adjusted time with an unadjusted one; only lined up by coincidence when starting from the very beginning. Play now starts exactly where the playhead is, at any tempo.

## [1.0.2] — 30. 8. 2026 — Chord right-click voicing fixes, Scales Explorer playback controls, tooltip cleanup

### Fixed
- **Right-clicking the playback chord name while paused now acts on the exact voicing under the playhead**, not a thin snapshot taken when the chord name last changed. Both "Show on keyboard" and "Open in Chord Explorer" reconstruct the real notes actually sounding at that instant — same register, same inversion as the file. Previously a `D7/A` in the file could lock a single lone `A`, name itself a bare root-position `D7`, and open the Chord Explorer at a canonical `D4` root position.
- **The keys "Show on keyboard" lights now carry each note's source-track color** (the same colors the piano roll and playback use), so it's clear which instrument the locked chord came from, instead of a flat amber. Left/Right-Hand and Note Editor modes still override to the fixed blue/pink hand colors, matching everywhere else.
- **Lock-a-Chord now labels the inversion of a right-clicked chord** (`D7/A · 2ⁿᵈ inv`), matching the playback display, rather than always showing root position.
- **Scales Explorer — "Key of" now appears the moment a key is picked on the circle**, or the scale type is changed, instead of only after a chord tile is clicked.
- **Scales Explorer — the Circle of Fifths highlight follows scale-type changes.** Switching to a minor-family scale moves the lit segment to the inner ring at the same tonic (and vice versa) — e.g. picking D major then clicking Natural Minor lights `Dm`; a stale `Cm` no longer stays lit after switching to Major Pentatonic.
- **Scales Explorer — the "Chords in the Scale" play button is now a toggle.** A second click, or the spacebar, stops playback; clicking again restarts from the beginning. The button shows a stop icon while running.
- **Loop Region bar-range popup** — background aligned to the standard popup color; the trigger icon swapped for a cleaner ordered-list glyph.
- **Chord Transcription (Settings) — the file-row tooltip is split and no longer doubles up.** Hovering the filename shows "Right-click for options"; hovering the transcript icon shows only its own hint, now in plain text that fits the tooltip instead of overflowing amber caps.
- **Lock-a-Chord modal** — removed the redundant per-button tooltips.
- **The installer is now per-user again (`perMachine: false`).** 1.0.1's switch to a per-machine install is what broke "uninstall → delete everything": the uninstaller then ran elevated under the all-users shell context, where `$APPDATA` resolves to `C:\ProgramData`, so the cleanup deleted a folder that doesn't exist and the real `orfeo-prefs.json` (with the library-folder link) survived — a fresh reinstall reopened straight into the old library. Per-user install means no UAC prompt to install/uninstall/update, it lands in `%LOCALAPPDATA%\Programs\Orfeo`, and the uninstaller always runs as the right user so the data cleanup works. The cleanup itself was also hardened: it forces the invoking user's context, deletes the prefs/log files by name before the recursive delete (so a locked cache subfolder can't leave the library link behind), never touches data during an auto-update (`--updated`) or silent (`/S`) uninstall, and shows the exact path if the prefs file is somehow still locked rather than failing silently. **If you have an existing per-machine install in `C:\Program Files\Orfeo`, uninstall it once by hand.**
- **"Check for updates" is now split cleanly by build type.** `electron/main.ts` decides once whether this build does real auto-updates (`'auto'` — the installed Windows build only) or not (`'manual'` — portable, macOS, Linux, dev), and the renderer reads that on open. The installed build's button checks the GitHub feed and, if there's a newer release, starts the download automatically, then shows "Update ready — click to install" (or "Orfeo is up to date"). The portable build's button now has a fixed tooltip — "Check for new releases on GitHub" — and a single click opens the Releases page in the browser; it never shows a spurious "checking…"/round-trip state or needs a second click.
- **A failed update check no longer fills the screen.** electron-updater's errors are a full multi-line HTTP dump (every response header); the "no published release yet" case came through as one and the whole thing rendered as a giant tooltip that stuck around. Errors are now collapsed to a single short sentence, the tooltip is hard-capped in size, and the error state fades on its own. The GitHub `owner`/`repo` in the publish config were also corrected to the real casing (`Squarebow/Orfeo`).

### Changed
- `build/installer.nsh`, `docs/CHANGELOG.md`, `docs/CONTRIBUTING.md`, `docs/INSTALLATION.md`, `electron/main.ts`, `electron/preload.ts`, `package.json`, `src/components/ChordExplorer.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/LockedChordModal.tsx`, `src/components/LoopRegionStrip.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/Tooltip.tsx`, `src/store/index.ts`, `src/types/index.ts`, `src/utils/midiParser.ts`.

## [1.0.1] — 29. 8. 2026 — GPLv3 relicense, embedded edit history, piano-roll performance fixes, documentation overhaul

Orfeo is now licensed under the GNU GPLv3 (or later), not MIT — see `LICENSE.md`. GSAP, the one dependency that can't itself be GPLv3 (GreenSock's own "Standard No Charge" license), is covered by an explicit linking exception under GPLv3 §7, documented in both `LICENSE.md` and `THIRD_PARTY_LICENSES.md`.

### New
- **Edit history is now embedded directly in the `.mid` file itself**, not a separate app-only log. Every Playback Editor save, Note Editor save, tempo/key save, and mixer save writes an `ORFEO_HISTORY` entry into the file's own MIDI meta-events — same technique already used for `ORFEO_KEY`/`ORFEO_TRACK_NAME`. Previously this lived only in a JSON file inside the app's userData folder, which meant switching between the portable and installed builds (or a clean uninstall) silently orphaned it. A file's edit history is now genuinely part of the file — travels with it anywhere, survives any install change.
- **Library auto-refreshes after every save.** A save from the Playback Editor, Note Editor, Mixer, tempo/key, or a foreign-format import now rescans the library folder immediately, expands the `Orfeo/` subfolder the new version landed in (previously it was created collapsed, so a just-saved file — and its embedded history in File info — was hidden until you found and opened that folder by hand), and briefly amber-highlights the new file. The highlight now matches against the actual rescanned row rather than the raw save path, so a drive-letter-case or separator mismatch can't leave the new version with no flash and no pinned bar. The manual refresh button and its blink-when-stale indicator stay as a fallback for whenever the automatic rescan can't run.
- **The Windows installer now shows a real license page** — full GPLv3 text plus the GSAP exception, scroll-to-accept, before install proceeds (`build/license.txt`).
- **The Console Mixer now saves per-channel volume, pan, chorus, and reverb into the file.** Closing the mixer after changing any of them prompts **Save & Reload** (writes a new `_ORFEO_vN` version with a history entry and reloads it, same as the Playback Editor), Discard, or Cancel. The master strip and mute/solo stay session-only. The confirm button was renamed from "Save" to "Save & Reload" to match the Playback Editor's.
- **Uninstalling asks what to do with your Orfeo data — a three-way choice, not just Yes/No.** **Yes** deletes everything (preferences, library-folder link, cached soundfonts, demo files, and any edited MIDI saved without a library folder set); **No** moves those edited MIDI files to an `Orfeo Edited Files` folder on the Desktop and deletes the rest; **Cancel** keeps everything. Your library folder itself is never touched. A follow-up check retries and warns if the install folder couldn't be fully removed (a locked file or an antivirus scan) instead of silently reporting success.

### Fixed
- **Performance regression on the piano roll — slow file loads and high idle CPU.** Two hot paths were doing expensive work every playback tick: the live chord detector re-ran tonal.js's combinatorial chord search from scratch on every tick for both Classic and sustained modes (now memoized by exact sorted-MIDI content), and the chord-sequence derivation subscribed to `currentTime` and re-computed every frame (now keyed to the resolved note-on/off index). Plus draw-loop and re-render trims across `App`, `Keyboard`, `PianoRoll`, and `SettingsPanel`.
- **File info showed an empty history for a file you'd just saved.** The modal froze its target path at first mount, so renaming a file in the popup — or reopening File info on a different row while one was open — left the metadata, history, and version list describing the previous file. It now follows the file you actually clicked. (Combined with the auto-expand fix above, the Console Mixer's save history is now visible where you'd expect it.)
- **The Note Editor didn't fully close on a file switch.** With no unsaved edits it stayed open across opening a new file or Reset, still pointing at the old one: the right-click Assign Left/Right Hand options silently disappeared, and toggling hand-colour mode wiped the roll (the old file's solo-visibility snapshot applied positionally onto the new file's tracks). It now always closes and resets on every file switch, like its own ✕ button.
- **Scale Explorer — Circle of Fifths key-signature labels crowded the ring at some angles and floated free at others.** The ♯/♭ groups used a fixed anchor radius, but the label text is never rotated, so its width ate the gap near the horizontal midline and its height near the vertical one, both growing with symbol count. The radius is now solved per angle from the real glyph metrics, keeping a constant visual gap for 1 through 6 accidentals at every position.
- **Auto-Level on Load could distort loud passages.** The makeup-gain boost was applied *after* the compressor, so a loud hit landing right after a fast quiet run (a glissando into a downbeat) got amplified past what the compressor's attack had caught, clipping. The boost now sits before the compressor, its values are halved, and its time constants are stretched to multiple seconds so the gain only moves for genuinely sustained quiet passages, not brief ornamental runs. (Samples engine.)
- **Focus Mode** toggle behaviour corrected across the Tracks panel, Console Mixer master strip, and Settings.
- **A chord could display as "Halt7/C"** — meaningless-looking text that happened to spell a real German word purely by coincidence. Root cause: tonal.js's obscure "altered dominant, no 5th" chord type has the raw internal name `alt7`, which the chord-name formatter didn't recognize and passed straight through; combined with Central European note naming (B → H), `Balt7/C` became `Halt7/C`. Now formatted to the same `alt` abbreviation the Chord Explorer's own catalog already used for this type. Also fixed a related scoring bug (`No5` vs. tonal's actual lowercase `no5`) that meant chords missing their 5th were never deprioritized in favor of a cleaner reading when one existed.
- **Hit-effect particles (glow bloom, ripple ring, etc.) kept appearing for tracks hidden from both the piano roll and the keyboard**, whenever Hit Effect Scope was set to "All tracks" — that mode was meant to let non-keyboard tracks still spawn effects, but never checked whether the track was visible at all. Also fixed a related staleness bug in the Samples engine: toggling a track's visibility or keyboard-light setting mid-playback didn't rebuild the note schedule, so already-scheduled notes kept firing with stale settings for the rest of the song.
- **The shipped app was completely unminified.** electron-vite defaults the renderer build to `minify: false`, and nothing in Orfeo's own config overrode it. Explicitly enabled esbuild minification — cuts the three largest JS chunks by roughly half — while pinning `legalComments: 'inline'` so every bundled dependency's license banner (GSAP's included) stays intact in the output.

### Changed
- **CHANGELOG.md and CONTRIBUTING.md moved into `docs/`** — only `README.md`, `LICENSE.md`, and `THIRD_PARTY_LICENSES.md` stay in the repo root now.
- **`THIRD_PARTY_LICENSES.md` regenerated** via a new `scripts/generate-licenses.mjs`, grouped by license type with full text shown once per group instead of repeated per package.
- **Documentation restructured.** `docs/HOW_TO_USE.md` rewritten as a deep, navigable guide staged by mode of use (Play / Edit / Practice / Manage files / Extras) with per-feature tips and cross-links; `README.md` shortened to a feature overview that links out to the docs; `ARCHITECTURE.md`, `CONTRIBUTING.md`, `INSTALLATION.md`, and `SHORTCUTS.md` restyled to one house format and corrected against the shipping code — notably that the installer is per-machine and requires elevation now (`perMachine: true`), and that the audio section no longer describes the retired Tone.js / WAV-sample engine.

**Changed:** `package.json`, `electron/main.ts`, `electron.vite.config.ts`, `build/installer.nsh`, `build/license.txt` (new), `LICENSE.md` (renamed from `LICENSE`), `README.md`, `docs/CHANGELOG.md` (renamed), `docs/CONTRIBUTING.md` (renamed), `docs/ARCHITECTURE.md`, `docs/HOW_TO_USE.md`, `docs/INSTALLATION.md`, `docs/SHORTCUTS.md`, `THIRD_PARTY_LICENSES.md`, `scripts/generate-licenses.mjs` (new), `public/midi-editor.svg` (removed), `.gitignore`, `src/App.tsx`, `src/store/index.ts`, `src/components/FileInfoModal.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/MixerConsole.tsx`, `src/components/Mixer/MasterStrip.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/PianoRoll/PianoRoll.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/hooks/useAudioEngine.ts`, `src/hooks/useChordSequence.ts`, `src/hooks/useSamplesEngine.ts`, `src/utils/chordDetection.ts`, `src/utils/foreignFormatImport.ts`, `src/utils/midiMetadata.ts`, `src/utils/noteEditorState.ts`, `src/utils/tempoKeySave.ts`, `src/utils/velocityAnalysis.ts`.

## [1.0.0] — 20. 8. 2026 — First public release: chord tracking modes, deep chord-detection overhaul, alto sax preview fix

Orfeo's first public release — installer and portable builds downloadable from GitHub. Versioning restarts here (see `CLAUDE.md`); everything before this point is pre-public development history.

### New
- **"Chords" settings section** — merged into "Notation & Chords" (same collapsible group as note-naming/accidentals, subsections kept in order). Two independent controls:
  - **Chord tracking** — what the live playback chord display and Lock-a-Chord follow: **Classic** (today's onset-clustering across all tracks, kept as-is), **General Harmony** (new — sustain-aware, tracks which notes are actually *ringing* at each instant rather than just which attack together, so a sustained chord under a moving melody stays correctly named instead of flickering between incidental melody/bass combinations), or **Follow Instrument** (General Harmony's algorithm scoped to one GM group — persisted — or one specific track in the current file — per-file, resets on load — with automatic fallback to General Harmony if the chosen group/track isn't present).
  - **Chord naming** — Abbreviations (`Bb(b5)/D`) or Symbols (`Bb(♭5)/D`, `+`/`°`/`ø`/`Δ` for aug/dim/half-dim/maj7), applied consistently everywhere a chord name appears: playback display, Lock-a-Chord, Chords Explorer, Scales Explorer.

### Fixed
- **Chord detection/naming was picking genuinely wrong or needlessly obscure names.** Two compounding bugs: `scoreChord` ranked candidates by raw string length, so a short exotic type (tonal.js's obscure quartal-harmony `"4"` type, e.g. `A4/C`) could beat a far more usable longer name (`D7sus4/C`); and tonal.js has no "omitted 3rd" chord types, so a common voicing missing its 3rd (e.g. C-D-G-B, a maj9 with no 3rd) detected as an unrelated, badly-altered chord from a different root (`Bmb6b9/C`) instead of anything C-rooted. Rewrote the scoring to weight actual complexity instead of length, and added a fallback that tries inserting a hypothetical 3rd and accepts it only when tonal agrees on the resulting root — verified against a real MIDI file end-to-end (`Bmb6b9/C`→`Cmaj9`, `A4/C`→`C6add9`, plus a same-notes-different-bass case found during testing, →`Cmaj9/B`).
- **A slash chord whose quality started with "M" lost its bass note** — e.g. `GM/D` (G major, 2nd inversion) rendered as `G( /D)`. The bass annotation was getting swallowed into the same-session naming-style formatter's parenthesization. Now split off before formatting and reattached after.
- **Lock-a-Chord / Chord Explorer preview audio played the wrong instrument** (e.g. alto sax instead of piano) once a real track in the loaded file happened to use the MIDI channel reserved for chord previews (channel 14 GM / 15 Samples) — its program-change setup only ever ran once per session, so a track using that channel during normal playback permanently reprogrammed the preview channel for the rest of the session. Now re-asserted before every preview note in both engines.
- **"Show on keyboard" (right-click the paused chord display) showed the chord in the wrong octave** — several octaves away from where it was actually playing — because it reconstructed a canonical fixed-octave voicing instead of using the real notes. Now uses the exact MIDI notes that were actually sounding, clamped to the current keyboard's range.
- **Closing Lock-a-Chord after Shift+clicking keys directly (not via right-click) left a stray amber focus-ring stuck on a key.** Piano keys are real focusable elements (for Enter/Space playability); clicking one gave it genuine browser focus, and the modal's focus-trap correctly restored focus to it on close per standard accessibility practice — triggering the app's `:focus-visible` amber outline rule with nothing to ever clear it. Mouse clicks on keys no longer take browser focus at all (`preventDefault` on mousedown); real Tab-driven keyboard navigation and its focus ring are unaffected.
- **MIDI Note Editor toolbar header** — title text ("MIDI NOTE EDITOR") was clipping, and the persistent centered hint wasn't reliably centered. Fixed-width side columns recalculated against the title's actual rendered width; disabled/inert info icon removed entirely rather than shown greyed-out.
- **Chords Explorer's fallback matching** — "Open in Chord Explorer" (from the playback chord-display's right-click menu) silently failed for any chord type outside the app's curated tile catalog (e.g. a major triad with a flattened 5th, `BbMb5`/`Bb(b5)`, only added a note off — no match), and searching by notes for the same chord returned nothing. Both now fall back to tonal.js's full chord dictionary when the curated catalog has no match, so any chord tonal can name is always reachable.
- **Settings panel: active/selected buttons and dropdowns rendered in monospace** (Sound Engine, Sound Fonts dropdown, hit-effect-pattern dropdown, the new Chords controls) instead of the UI's grotesk font — inconsistent with every other label in the panel.

### Improved
- **NoteEditorToolbar's hover-tooltip hint text** and the Snap/Quantize icons' tooltips rewritten for clarity — Snap and Quantize grid previously gave no indication of what they actually do (round a moved/resized/added note's timing to the grid; irrelevant while Snap is off), which read as "does nothing" since there's no visual grid overlay, only an effect at the moment you edit a note.

**Changed:** `CLAUDE.md` (new Versioning section, local-only), `package.json`, `src/components/ChordExplorer.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/hooks/useAudioEngine.ts`, `src/hooks/useChordSequence.ts`, `src/hooks/useSamplesEngine.ts`, `src/store/index.ts`, `src/types/index.ts`, `src/utils/chordDetection.ts`.

## [1.11.7] — 19. 8. 2026 — Branded installer, live chord-display fixes, playback chord context menu

### Fixed
- **Userdata folder was created lowercase (`orfeo`) instead of `Orfeo`.** Electron's `app.getName()` defaults to package.json's internal `"name"` field, not `"productName"` — every settings/library-pointer/soundfont-cache path was affected. `app.setName('Orfeo')` now runs before any `app.getPath('userData')` call.
- **The live chord display above the keyboard stuck on whatever chord was showing when you paused**, even after scrubbing or shift-scrolling the playhead elsewhere. It was pinned to a frozen index that only updated during actual playback. It now always tracks `currentTime`, so the chord name updates live while paused too — instantly, without the 450ms minimum-display hold that real-time playback uses to avoid flicker (that hold only makes sense at playback speed, not while scrubbing).

### New
- **Branded Windows installer and uninstaller** — a dark, gradient sidebar (shown on the Welcome/Finish wizard pages) with the amber Orfeo mark, wordmark, and the tagline "From MIDI to mastery.", plus a light header banner on the interior pages. Configured via `nsis.installerHeader`/`installerSidebar`/`uninstallerSidebar` in `package.json`, assets in `build/`.
- **Uninstaller: opt-in "Delete my Orfeo settings and library data" checkbox** — unchecked by default, so a plain uninstall never touches your library folder pointer, preferences, or cached soundfonts unless you explicitly ask it to (`build/installer.nsh`, via electron-builder's `customUnInstallSection` hook).
- **Right-click the chord display while paused** for two new options: **Show on keyboard** locks the chord's notes exactly like Shift+clicking them on the keyboard — same floating modal with play/inversion-cycling; **Open in Chord Explorer** opens it pre-selected, lit on the keyboard, and ready for inversions/progressions. Both reconstruct the same canonical voicing (via a newly-shared `buildChordMidi`), so what you see in the lock and what you see in the Explorer always match.
- **One-line hover hints on the chord display** — "Pause to study the chord" during playback, "Right-click for options" once paused (and there's actually a chord the menu can act on).
- **"Set your MIDI folder" button now blinks amber** until a library folder is actually set — same nudge treatment already used for the library-refresh icon.

### Improved
- **Settings panel: all 8 groups now start expanded** on a fresh install (previously only "MIDI Files & Library" did, the rest started collapsed). Still remembers whatever you leave expanded or collapsed from then on — this only changes the very first open.

**Changed:** `package.json`, `electron/main.ts`, `build/installer.nsh` (new), `build/installerHeader.bmp` / `installerSidebar.bmp` / `uninstallerSidebar.bmp` (new), `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/ChordExplorer.tsx`, `src/utils/chordDetection.ts`, `src/hooks/useChordSequence.ts`, `src/types/index.ts`, `src/store/index.ts`.

## [1.11.6] — 18. 8. 2026 — Settings reorganized into 8 sections, MIDI Note Editor and Library spacing fixes

### Changed
- **Settings fully reordered and regrouped.** New top-to-bottom order: Audio, MIDI Files & Library, Playback & Editing, Practice, Notation, Keyboard, Piano Roll, Appearance. All existing functionality carried over unchanged — this is a reshuffle, not a feature change.
  - **Audio** (unchanged icon) now leads, and its Sound Fonts catalog bullets each entry (GeneralUser GS, FluidR3 GM, MuseScore General) — the bullet comes from the same list the catalog already renders from, so any soundfont added later gets one automatically.
  - **MIDI Files & Library** dropped its book icon for Lucide's Files icon; MIDI Note Editor moved out to Playback & Editing.
  - **Playback & Editing** (renamed from Playback & Practice, same icon): MIDI Note Editor, Left/Right Hand, Max Fingers (now sits directly under Left/Right Hand instead of trailing after Hand Tags), Loop region, Focus mode (moved in from Audio). Left/Right Hand's description was rewritten in plainer language and now ends with a note pointing at the hand icon used to enter edit mode; Loop region's description now points at the loop icon the same way.
  - **Practice** is a new section (Lucide open-book icon, freed up once MIDI Files & Library switched to the Files icon): Chord Prompter, Close panels on playback, Hand Tags, Track color VU meters — all relocated here from Playback & Practice with no behavior change.
  - Every setting's description/hint text now renders in italic, for a lighter visual weight against the bright labels above it.
- **MIDI Note Editor's tools/modes row** gained 4px of padding above and below the icons (was flush top/bottom); the floating toolbar grows to fit automatically.
- **Library's active-folder-path row** (under the search bar) got a touch more top/bottom padding — was flush against the search bar above and the All/★ filter row below.
- **Tooltip copy tightened** across the Console Mixer's channel/master strips and the Tracks panel — shorter titles ("MIDI Playback Editor" instead of "Open MIDI Playback Editor", "Console Mixer" instead of "Open Console Mixer"), trimmed descriptions on Mute/Solo/Hide/Lit-on-keyboard and the Chorus/Reverb knobs, and a couple of hint updates (split/merge tracks wording, "Coming soon - practice mode.").

### Removed
- Two unused font families cleaned out of `index.css` and `src/assets/fonts/`: **Founders Grotesk** (lost the UI-font trial to Familjen Grotesk) and **JetBrains Mono** (superseded by IBM Plex Mono as `--font-mono`). Mona Sans stays installed as a live candidate. A stale `'JetBrains Mono'` fallback literal in `PianoRoll.tsx`'s canvas text setup was also updated to `'IBM Plex Mono'` to match.

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/PianoRoll/PianoRoll.tsx`, `src/components/Mixer/{ChannelStrip,MasterStrip}.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/store/index.ts`, `src/index.css`.

## [1.11.5] — 18. 8. 2026 — Colorblind-accessible hand-letter badges, decoupled from Left/Right Hand

### Fixed
- **The keyboard's "L"/"R" hand-letter badge ignored the Left/Right Hand setting entirely.** Root cause: the badge was derived purely from a key's resolved color (`getColorHand` in `Keyboard.tsx`) rather than from any setting — and a genuinely split Left Hand/Right Hand track (e.g. from Split Hands in the Playback Editor) always renders blue/pink by design, regardless of the Left/Right Hand toggle, per `handColors.ts`. So for split-track files the letter was permanently on and un-hideable, while the sibling hardware-note indicator (`getHardwareHand`) correctly respected the toggle the whole time.

### New
- **Hand letters is now its own Settings toggle** (Playback & Practice, under Left/Right Hand, off by default) instead of riding on key color. It's deliberately independent of Left/Right Hand — split-track coloring stays on either way, so the letter needed a switch that actually controls it in every case, not just the toggle-able mixed-track case.
- **Badge redesigned for legibility**: a solid square instead of plain shadowed text — dark background + white letter on white keys, white background + dark letter on black keys (inverted per key type, not per hand) — sized via `clamp()` against each key's own rendered width so it scales correctly across all three keyboard sizes (61/73/88 keys are inversely related to key width, not directly — 88 keys gives the *narrowest* keys, not 61) rather than risking a fixed-px badge over- or under-sizing.
- **White-key badge repositioned** from a top-left corner (which sat directly under the overlapping black key, half-hidden) to just below the black keys' own bottom edge, centered — a band that's always fully exposed white key on every note, with clear space above the note-name label.

**Changed:** `src/components/Keyboard/Keyboard.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/store/index.ts`.

## [1.11.4] — 18. 8. 2026 — Track color VU meters in the Tracks panel

### New
- **Each track's color line in the Tracks panel now doubles as a mini VU meter during playback** — no need to open the Console Mixer to see who's actually sounding. The bottom quarter of the 3×20px color pill stays solid at full track color always (the guaranteed identifier, since this is the only thing distinguishing tracks at a glance without opening the mixer), a dim 18%-opacity tint of the same color fills the rest of the pill so it always reads as "this track's color" even at rest, and the zone above the floor fills in from the bottom as the track's live note velocity rises — same subscribe-and-decay mechanism as the Console Mixer's own `ChannelStrip` VU meters, but driven by a CSS `transform: scaleY()` rather than canvas or `height`, so animating many track rows at once costs compositor work only, never layout.
- New **"Track color VU meters" toggle** in Settings → Playback & Practice (on by default) turns the animation off entirely, reverting each pill to its original plain static color, for anyone who prefers the simpler look.

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/store/index.ts`.

## [1.11.3] — 18. 8. 2026 — Library sticky-folder fix, Playback Editor title centering, modal background consistency pass

A follow-up polish pass covering a sticky-positioning bug the font-sizing audit didn't reach, plus a styling-consistency pass across the app's three floating-modal-style panels (MIDI Playback Editor, MIDI Note Editor, Console Mixer), using the Playback Editor as the reference.

### Fixed
- **Library's individual folder headers (e.g. "Demo", "Orfeo") weren't actually sticky.** Same root cause as the pinned active-file row fixed in 1.11.2 — `RowTooltip`'s wrapper `<div>` shrink-wraps to exactly its child's height, leaving `position:sticky` no room to operate within its own containing block — just a separate instance of the pattern one level down that the earlier pass didn't catch. Fixed the same way: `position:sticky` moved onto `RowTooltip`'s own `wrapperStyle` instead of the inner row `<div>`. Verified live via CDP — the header now locks in place at the correct offset while its files scroll underneath, releasing only once the folder's content ends.
- **MIDI Note Editor toolbar's background didn't match every other modal** — still on the plain `--panel` gray (`#1e1e1e`, warm/brownish next to the app's cooler near-black modals) instead of `--bg-modal-header`. Now matches the Playback Editor exactly.
- **Console Mixer's main container was one shade lighter than its own header** (`--bg-modal` vs `--bg-modal-header`), the reverse of the Playback Editor's single-tone approach. Container now uses `--bg-modal-header` too; the channel strips and master strip keep their lighter `--bg-tile` shade, which now reads as intentional depth instead of an accident of two similarly-dark tones.

### New
- **Library**: a small amber-dimmed divider now separates a folder's contents from the root-level files below it (shown only when the Folders section is actually expanded), and each expanded folder shows a small chevron next to its icon — nothing extra for collapsed folders.
- **MIDI Playback Editor**: the loaded file's name in the header is now centered between the fixed title and the close button, and marquee-scrolls left on hover when it's too long to fit — the same measured-overflow mechanism Console Mixer's header description already used, applied here for consistency.
- **Console Mixer**: each channel strip's fader now shows "−∞" and "dB" flanking its lowest tick, like a hardware fader's printed floor mark.

### Changed
- **Mixer icon buttons restyled** — Mute/Solo/Hide-on-roll/Lit-on-keyboard on every channel strip, plus the matching 3 icons on the master strip, dropped their filled dark background for a border (colored to the active state) instead, matching the Playback Editor's own icon language rather than standing out as a different pattern.
- **Master strip**: the BARS/FFT toggle and the mute-all/visible-all/keyboard-all icon row pulled up 15px, opening more breathing room between the icons and the Chorus/Reverb knobs below — a matching 15px spacer keeps FX/Tone/Compressor/Volume exactly where they were rather than the whole strip shifting.
- Channel strip's static label under the fader shortened from "VOLUME" to "VOL".

**Changed:** `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/{ChannelStrip,MasterStrip,MixerConsole}.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`.

## [1.11.2] — 17. 8. 2026 — App-wide font-sizing audit, real layout-shift bugs fixed along the way

A full pass over every below-readable-size font in the app (many sites sitting at 8-9px), covering 11 UI sections: TopBar, Library, Settings, Tracks panel, Keyboard, File Info, MIDI Playback Editor, Console Mixer, MIDI Note Editor, Chord Explorer, Scale Explorer — plus Lock-a-Chord, which the original scope missed. Every single edit was measured live via Chrome DevTools before and after (not eyeballed) under one hard rule: a font-size change is never allowed to move, resize, or reflow anything else on screen. Followed by three rounds of corrections from the user's own review pass.

### Fixed — real bugs found while doing the sweep, not just sizing
- **Library's pinned active-file row silently stopped sticking to the top of the list.** Root cause: `RowTooltip`'s wrapper `<div>` shrink-wraps to exactly its child's height, leaving `position:sticky` zero room to operate within its own containing block — the row just scrolled away with everything else instead of clamping in place, and the sticky "Folders" header beneath it (correctly stuck) was left with a gap showing the scrolling list peeking through above it. Confirmed with a live scroll test before and after the fix (the drift matched the broken math exactly, then clamped correctly at any scroll depth once fixed). Fixed by moving the sticky positioning onto `RowTooltip`'s own wrapper instead of the nested content `<div>`.
- **File Info modal's metadata rows silently exceeded their own `minHeight:24` floor** once the row content grew past what the row's padding+border budget allowed — a 1px-per-row creep that would have cascaded down through every row, Save/Cancel, and the History section. Caught via measurement (not visually) and fixed with a `lineHeight` pin sized to the tightest bordered row's real budget (11px), not a naive copy of the unbordered row's value.
- **MIDI Playback Editor** had four separate instances of the same class of bug — a relative `lineHeight` (`1.25`, `1.4`) or a default browser line-height silently growing past its element's real budget once the font size increased: the column-header row, two disclaimer rows, the Select-all/Clear-all buttons, and the Browse/Show-in-folder button (verified by comparing it against its never-touched sibling, the path-preview field, until both matched exactly).
- **Scale Explorer's chord-tile row was already exceeding its own `minHeight:44` floor before this pass touched it** (a pre-existing quirk of its two-line note+roman-numeral stack) — confirmed the true pre-edit height via a live DOM probe, then held the row to that same value instead of accidentally "fixing" a pre-existing 1px discrepancy that wasn't this pass's to fix. Its below-Circle-of-Fifths info row (root name/scale-quality/note-sequence) also needed pinning — it sits in normal flow, not a fixed box, so unpinned it would have grown the whole Circle-of-Fifths section and pushed every row below it down.
- **MIDI Note Editor's own header started truncating its title** ("MIDI NOTE EDIT…") the moment its font size grew to match every other modal — the panel was too narrow for the larger text. Measured the actual overflow instead of guessing: widened the toolbar and its header's two flanking grid columns (kept symmetric, so the centered hint text stays truly centered per this repo's own CSS Grid convention) until the title fit with zero clipping.

### Changed — sizing, weight, and family
- Every modal's header title now reads 14px (previously anywhere from 10-12px depending on which modal), the "global header" size applied consistently across MIDI Playback Editor, Console Mixer, MIDI Note Editor, Chord Explorer, Scale Explorer, File Info, and Lock-a-Chord.
- Library, Settings, Tracks, Keyboard, Chord/Scale Explorer, and the Console Mixer all had their smallest labels (8-9px) brought up to a 10-12px floor; several shared row-label constants got `fontWeight` eased from 700 to 600 per a follow-up review pass.
- **Filename text reverted from monospace back to the UI font (Grotesk)** in the TopBar and Library, after an earlier pass in this same audit had switched it to mono alongside the size bump — the user's actual preference was size-only there.
- New `FingerStepper` control (`< 4 >` toggle) replaces two full-width button rows for Settings' Max Fingers Left/Right, now one compact line under a single heading.
- New `labelOffset` prop on `MixerKnob` shifts a knob's label vertically with an equal-and-opposite compensating margin, so the widget's total footprint — and everything below it — never moves; used to pull the Chorus/Reverb/Tone/Compressor labels 10px closer to their knobs in both the channel strip and master strip.
- Settings' Visual Effects color swatch now defaults to a solid fill (the app's fixed piano left-hand blue) instead of a checkered "transparent" pattern when no color has been chosen yet; the Intensity/Spread/Threshold bloom sliders gained a "Drag to change" one-line tooltip (no evidence any existed before the 1.11.0 tooltip overhaul).
- TopBar playback-control tooltips (Go to start, Rewind 5s, Play/Pause, Forward 5s, Go to end) restyled to the app's one-line tooltip format; Loop's tooltip deliberately left in the richer two-part style. The tooltip on the loaded filename itself was removed entirely.

**Changed:** `src/components/{ChordExplorer,FileInfoModal,LockedChordModal,ScaleExplorer}.tsx`, `src/components/Keyboard/{Keyboard,KeyboardControls}.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/{ChannelStrip,MasterStrip,MixerConsole,MixerKnob}.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/components/Transport/TopBar.tsx`, `src/components/VolumeKnob.tsx`.

## [1.11.0] — 16. 8. 2026 — App-wide tooltip system overhaul, Capella import support, demo-library sync fix

The Mixer's stylish tooltip styling (introduced in 1.10.0) is now the tooltip system for the entire app — every remaining native `title=` popup, replaced across three rounds of live-testing fixes. Alongside it: a third notation format (Capella) can now be imported and converted to MIDI, and the bundled demo library now actually reaches existing users when new demo files ship, not just fresh installs.

### New — app-wide tooltip system
- **A global boundary-clamping rule for every tooltip.** `TooltipBox` now measures its own rendered size and clamps/flips itself against the real window bounds before ever painting (two-pass: an invisible probe render to measure, then a `useLayoutEffect` correction before the browser's first paint, so there's no visible jump). This is what "the app's own rule" for tooltips near an edge means in practice — it's based on the anchor's actual on-screen position, so it automatically accounts for collapsed vs. expanded side panels, left-docked vs. right-docked rails, without any per-site special-casing. Fixes every reported edge-cropping case at once: collapsed Library/Settings/Tracks rails, the Orfeo logo, Chords, keyboard-size buttons, Scales, Presentation Mode, and more.
- **A second `oneLine` style**, alongside the original amber-heading + muted-description layout: plain white, normal-case, normal-weight text (can still wrap to two lines) with no heading row, for short self-explanatory hints that don't need the two-part structure. Applied to ~230 sites app-wide — Library (file/folder rows, star icons, folder actions), Settings (Sound Engine, Soundfonts, keyboard-size buttons, Orfeo/Manual/Download links), Tracks and the Console Mixer (Mute/Solo/Visible/Keyboard-lit), Chord Explorer, Scale Explorer, Lock-a-Chord, and TopBar. The original amber-heading style stays reserved for cases that genuinely need a title+explanation pair (Visual Effects scope/color, the Mixer's own knobs, MidiEditor's Save Tempo & Key toggle).
- **Tooltips removed entirely** wherever the control already explains itself elsewhere: Settings' toggle-icon rows (each has its own inline description already), Display System/Accidentals/keyboard-range buttons, Soundfonts' redundant per-item tooltip, the "Collapse all folders" header, close (X) buttons on Lock-a-Chord and the Playback Editor, root-row chord notes, and the note-count readout under the keyboard.
- **Right-click context menus unified into a shared `ContextMenu.tsx`** (`ContextMenu`, `ContextMenuItem`, `ContextMenuDivider`, `ContextMenuLabel`), replacing ~110 lines of copy-pasted `MENU_ITEM_STYLE` + per-button hover handlers across the Library's file- and folder-actions menus. Retheme to the same dark-panel/amber-border/glow language as the tooltips, instead of the old muted `--drag-handle-dot`/`--border-popover` borders.
- **New `useTooltip` hook** for elements that can't tolerate `Tooltip`'s wrapper `<div>` at all — e.g. a button living inside a `display:'contents'` CSS Grid row, where a wrapper element would either break the grid's direct-child passthrough or (if given `display:contents` itself) return a zero-sized rect at the window's origin from `getBoundingClientRect()`, putting the tooltip in the screen's top-left corner. `useTooltip` attaches hover-tracking and the anchor ref straight onto the caller's own element instead of introducing anything new into the DOM.

### Fixed — real bugs found while doing the sweep, not just styling
- **Library file/folder rows lost their full width and right-aligned favourite stars.** Root cause: `Tooltip`'s wrapper defaults to `display:'inline-flex'`, which does not stretch its child along the main axis even when the wrapper itself is given `width:'100%'` — the row inside kept shrinking to its own content width. This explained three symptoms at once: background painting only as wide as the filename, stars losing the extra space `MarqueeText`'s own `flex:1` used to push them into, and the marquee's overflow-detection measuring a collapsed width (so long filenames stopped scrolling). Fixed by pairing `display:'block'` with every `wrapperStyle={{width:'100%'}}` site; documented directly in `Tooltip.tsx`'s prop comment so it can't quietly recur.
- **Hovering a file's star icon showed two tooltips stacked at once** ("Add to favourites" and the row's own "Right-click for options") — the row's hover state stays true the whole time the pointer is anywhere inside it, including over a nested child, since `mouseenter`/`mouseleave` only fire on boundary crossings. Fixed with a small suppression-aware set (`RowTooltip`, `FavouriteStar`, `RowIconButton` in `SettingsPanel.tsx`) where nested icons report their own hover state up to the row via a ref-counted callback, so the row tooltip hides itself whenever a nested icon's tooltip is showing. Applied to all three places this pattern exists, including the folder row's Undo-all-moves and bulk-star icons, which had the identical latent bug before it was ever reported.
- **Soundfont Remove/Download tooltips rendered in the screen's top-left corner.** An earlier fix for this same section had tried `wrapperStyle={{display:'contents'}}` to preserve its CSS Grid row's direct-child passthrough — which traded one bug for another, since a `display:contents` element has no box of its own and its `getBoundingClientRect()` degenerates to a zero-sized rect at the origin. Replaced with the new `useTooltip` hook (see above), which never introduces a wrapper in the first place.
- **User-created Library folders had broken, overflowing tooltip text.** Folder rows had never been converted off the original elaborate "Expand folder — right-click for rename/delete/move options" wording, which is a full sentence rendered in the amber heading row's `whiteSpace:nowrap` styling (sized for short labels) — it visibly overflowed the tooltip box's own border. Recolored/reworded to match file rows ("Right-click for options", one-line).
- **TrackPanel's Mute/Solo/Visible/Keyboard-lit tooltips rendered as a tall block "growing upward in rows"** instead of a normal short tooltip. Not a positioning bug — several of the descriptions were 50-73 characters, wrapping to 3-4 lines inside the 200px-wide box. Shortened all 8 (both states × 4 buttons) to 1-2 lines. (Later converted to the `oneLine` style entirely, alongside the Console Mixer's equivalent icons, which live in a separate local `IBtn` implementation in `ChannelStrip.tsx`.)

### New — Capella (`.cap`) import support
- Added as a third foreign notation format alongside MusicXML and Guitar Pro, converted to Standard MIDI File bytes the same way (alphaTab's importer + `MidiFileGenerator`, disabled rendering engine). `ForeignFormat` is now `'musicxml' | 'guitarpro' | 'capella'`; every extension whitelist that gated this (drag-drop validation in `App.tsx`/`SettingsPanel.tsx`, the demo-folder sync filter, the recursive library scanner, the native "Open MIDI File" dialog filter) updated together, plus the `EmptyState` hint text. `pendingImportedFile.format` in the store was hardcoded to the old two-value union — caught by the type checker, now references `ForeignFormat` directly so this can't drift out of sync again.

### Fixed — bundled demo files now actually reach existing installs
- `ensureDemoFolder()` previously copied `public/demo/` into the user's library exactly once, ever, gated by a `.demo-installed` flag written on first launch — meaning new demo files added to `public/demo` in a later app version were invisible to anyone who'd already launched the app once, forever, even across updates. Rewritten to run on every launch instead, checking per-file whether it's already present at the destination rather than gating on a single flag: cheap (a handful of small files), self-healing (new files/subfolders in a later release reach existing installs on their next launch), and non-destructive (anything a user's deleted from their own `Demo/` folder stays deleted, since the sync is purely additive). Also now copies recursively, so subfolders in `public/demo/` (e.g. grouping MusicXML/Guitar Pro sample files separately from the root MIDI set) are preserved into the copy — the previous version silently skipped any directory since its flat `readdir` filtered on file extension.

**Changed:** `electron/main.ts`, `src/App.tsx`, `src/store/index.ts`, `src/utils/foreignFormatImport.ts`, `src/components/EmptyState.tsx`, `src/components/Tooltip.tsx`, `src/components/{ChordExplorer,LockedChordModal,LoopRegionStrip,ScaleExplorer,SpeedControl,VolumeKnob}.tsx`, `src/components/Keyboard/{Keyboard,KeyboardControls,FloatingKeyboard}.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/ChannelStrip.tsx`, `src/components/PianoRoll/PianoRoll.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/components/Transport/TopBar.tsx`. **New:** `src/components/ContextMenu.tsx`.

## [1.10.1] — 16. 8. 2026 — Mixer disabled-state tooltips, Note Editor gating, Playback Editor confidence color, Piano Roll loop-region regression fix

A cleanup pass on four separate UX rough edges reported after the 1.10.0 release: silent dimmed controls with no explanation, a confusingly-destructive click, an under-visible warning color, and a loop-region drag regression from three releases back.

### Fixed — Mixer knobs gave no explanation when dimmed
- **Chorus/Reverb/Tone/Pan and the Compressor (toggle + preset knob) now explain themselves on hover while dimmed**, instead of showing nothing at all. Root cause: `MixerKnob`'s wrapper set `pointer-events:none` on itself whenever `disabled`, which also blocked its own `onMouseEnter`/`onMouseLeave` — the exact events its tooltip depends on. Fixed by keeping the wrapper hoverable always and relying on the `disabled` checks already inside the drag/keyboard handlers to block actual interaction (tabIndex was already `-1` while disabled). New `disabledHint` prop overrides the tooltip's description with an explanation — "You must switch to Samples engine to use ___." — everywhere GM engine disables a control.

### Fixed — Playback Editor's Note Editor icon silently closed the modal
- Clicking the note-editor icon in a track's confidence row used to call `setNoteEditorActive(true)` and close the Playback Editor unconditionally — including when **MIDI Note Editor** is turned off in Settings, where nothing useful happens next. The icon now dims and disables itself when the setting is off, with a tooltip explaining "Turn on MIDI Note Editor in Settings to use this," instead of performing a no-op close.

### Fixed — low-confidence flag hard to spot in the collapsed row
- The "N% flagged low-confidence" text in a track's always-visible confidence-row summary was the same muted dark red as the legend swatch and the timeline overlay band — both of which are deliberately quiet, always-on chrome. Recolored just this one instance to `var(--status-error-hover)`, the same bright red the closed-eye "hidden" track icon uses, so it reads as an actual alert at a glance. Legend and overlay untouched.

### Fixed — Piano Roll: plain click+drag could start a loop region again
- Regressed in 1.7.0: a fix for an unrelated unclickable-icon bug also stripped the `Alt`-key gate on starting a new loop-region selection, so any plain click+drag on the roll now started one — confusing next to the boundary-handle drags and right-click-to-clear gestures that don't need Alt. Restored `if (!e.altKey) return` in the drag-start handler only; left the cursor and `pointer-events` unconditional (both were also tied to an Alt-held state pre-1.7.0) so the cursor no longer flickers between states like it used to.

**Changed:** `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/{ChannelStrip,MasterStrip,MixerKnob}.tsx`, `src/components/PianoRoll/PianoRoll.tsx`.

## [1.10.0] — 15. 8. 2026 — Master compressor/limiter, Mixer tooltip system, global focus-ring fix

The Console Mixer's master bus gets a compressor/limiter with five presets, a full pass of stylish hover tooltips replacing native browser ones across every knob and icon, and a global fix for a focus-ring bug that had been visible everywhere in the app, not just the Mixer.

### New — Master compressor/limiter
- **Real `DynamicsCompressorNode`, inserted last in the Samples-engine chain** (`gain → tone filter → compressor → destination`), catching whatever the gain and tone stages produce. Five presets (Safety / Gentle / Medium / Firm / Limiter) each bundle threshold, ratio, attack, and knee together rather than sweeping just one parameter — a fixed threshold with only ratio changing either barely engages at the gentle end or over-triggers at the aggressive end, so the presets wouldn't have sounded distinct from each other. Release is fixed at 250ms across all five; attack is what actually shifts the felt character from "gentle glue" to "hard limiter." On by default at the Gentle preset — this directly addresses a real gain-staging bug found earlier (`SAMPLES_BOOST × masterVolume` can exceed unity with zero limiting in the chain, causing clipping at default settings) rather than leaving it opt-in.
- **"Off" is a real transparent state** (ratio 1:1, threshold 0dB — mathematically a no-op) instead of disconnecting/reconnecting the audio graph on every toggle.
- **Master strip redesign** to fit the new control: the three global-action icons (mute-all/waterfall-all/keyboard-all) and the mute-filter button merged into one row to free up space without growing the strip; a new Tone+Compressor row puts the compressor's preset knob opposite Tone, with a bare on/off icon (amber = on, white = off, no button chrome) centered between them via CSS Grid — this repo's own layout convention (`minmax(0,1fr) auto minmax(0,1fr)`, documented in `CLAUDE.md`) rather than flex+space-between, so the toggle can't drift off-center if the two side knobs' widths ever diverge again. Strip widened 160px → 184px to fit.
- **Compressor icon** (`CompressorIcon.tsx`) restyled from a supplied reference SVG to match every other Orfeo icon's `currentColor` stroke pattern.
- **Preset knob has no static radial labels.** An early version placed ratio numbers around the knob, but those made its footprint wider than a plain knob and threw off its right-alignment against Reverb above it — removed in favor of a dynamic tooltip: hovering a tick shows that preset's info regardless of what's currently selected, hovering the knob's own center shows whichever preset is actually active.
- `getMasterCompReduction()` exported from the audio engine (live gain-reduction in dB, unsmoothed) — infrastructure for a planned visual-only "the master/track faders visibly dip while the limiter is working" treatment. Not wired to the UI yet.

### New — stylish tooltip system for the Mixer
- **`Tooltip.tsx`** — dark background, amber border, amber title row + muted description row, portaled to `document.body`. Replaces native `title=` browser tooltips on every Mixer knob (Chorus, Reverb, Tone, Compressor, Master Volume) and icon button (mute/waterfall/keyboard-all, mute-filter, Bars/FFT toggle, drag-handle, M/S/Eye/Kbd per track).
- **Master Volume's tooltip is live**, not static: shows the current percentage on hover AND while actively dragging the knob (via a new `onDragChange` callback on `MixerKnob`), replacing the permanent `%` readout that used to sit below the knob. Uses a new `left` placement (anchors to the rect's vertical center, not its top edge) — the default `top` placement floated the tooltip far above the actual 202px-tall knob since it positions off the anchor's top edge, not wherever the knob's value/handle actually is.
- **Note found for later:** the PianoRoll already has its own cursor-following rich tooltip style (`PianoRoll.tsx:359-381` — different tokens, `borderRadius:4`, no bold/uppercase title) that predates this one. Migrating the Mixer's `Tooltip.tsx` to match it is a deliberately deferred follow-up, not done in this pass.

### Fixed — global focus-ring bug (not just the Mixer)
- **Clicking a button with the mouse no longer leaves a stale focus ring that a later, unrelated keypress lights back up.** `:focus-visible` is spec-correct but non-intuitive: it shows based on "is the page's input modality currently keyboard AND does this element currently have focus," not "did this keypress activate this element." A mouse click leaves a button focused (normal browser behavior); the next keypress anywhere — including Space for play/pause, a global shortcut here that doesn't even depend on focus — flips the modality flag and the stale-focused button's ring reappears for a keypress that had nothing to do with it. Fixed by blurring non-text controls immediately after a genuine mouse click (`event.detail === 0` distinguishes a real pointer click from a synthetic click that Enter/Space fires when activating a focused element via keyboard, so real keyboard activation keeps its ring as intended).
- **Root-cause bug found while shipping the above fix:** the blur handler's target check used `el instanceof HTMLElement`, which silently rejected every click landing on an icon — most buttons in this app render an SVG as their visible content, and `SVGElement` is not an instance of `HTMLElement` (separate DOM interfaces). The fix looked correct against a synthetic test that clicked the `<button>` element directly, but failed on every real click, which almost always lands on the icon inside it. Caught via a CDP-dispatched trusted click (not `element.dispatchEvent(...)`, which doesn't reproduce this) after a user report; fixed by checking `instanceof Element` instead.

### Fixed — Mixer layout
- **Compressor knob/toggle alignment.** The "COMPRESSOR" label (wider than the 52px knob) was warping its flex column's shrink-to-fit width, so `justifySelf:'end'` aligned the wider label's edge to the grid track instead of the knob's — visibly left of Reverb above it. Fixed by giving both Tone and Compressor a fixed 52×52 box with the label absolutely positioned below, out of flow. CDP-measured after the fix: both knobs share exact left/right edges with Chorus/Reverb, and the toggle sits at the exact horizontal midpoint.
- Chorus/Reverb knob-to-label gap doubled (3px → 7px, `MixerKnob`'s own internal spacing — applies to every knob app-wide) after it read as "dangerously close."
- Master Volume knob's tick strokes halved via a new per-instance `tickStrokeScale` prop (0.5 on this knob only — every other knob keeps the app-wide default) after the density of its 36 ticks made full-thickness strokes look heavy.

### New — Console Mixer header marquee
- The permanent header description ("Adjust track levels, apply effects and compress overall loudness") now marquee-scrolls on hover when a narrow modal (few tracks loaded) can't fit the full sentence, instead of ellipsis-truncating; when it fits, it stays centered and static exactly as before. Overflow is measured live via `ResizeObserver` against the actual rendered text, not assumed from a fixed width, since track count changes the modal's width at runtime. Respects `prefers-reduced-motion`.
- **Bug found and fixed while building it:** the overflow-measuring effect was keyed to the store's `mixerOpen` flag, but the component itself renders `null` until a separate `everOpened` flag flips true one render later — so the very first measurement ran against refs that didn't exist yet (silently bailing), and by the time the DOM existed, `mixerOpen` was no longer changing, so the effect never ran again. Net effect: overflow was permanently reported as `0`, and with `overflow:hidden` centering, actually-overflowing text clipped to a meaningless slice from the *middle* of the sentence rather than showing the start. Rekeyed to `everOpened`, the flag that actually gates the DOM's existence.

**Changed:** `src/App.tsx`, `src/components/Mixer/{ChannelStrip,MasterStrip,MixerConsole,MixerKnob}.tsx`, `src/hooks/useSamplesEngine.ts`, `src/index.css`, `src/store/index.ts`. **New:** `src/components/CompressorIcon.tsx`, `src/components/Tooltip.tsx`.

## [1.9.0] — 15. 8. 2026 — New app icon, TopBar realignment, font-swap trial infrastructure, Tailwind removed

A grab-bag day: a redrawn app icon, two rounds of TopBar layout fixes driven by live testing, the ground laid for trying out new UI-font pairings (three candidates installed, none committed to yet), a real cross-cutting bug fix, and a dependency cut.

### App icon
- **Replaced entirely.** The old icon was the logo mark inside an orange ring/circle; the ring is gone — just the mark, sized to fill ~82% of the canvas (standard breathing room for a solid-glyph Windows icon, not edge-to-edge and not swimming in padding). Rendered directly from the source SVG at each target resolution (16/20/24/32/40/48/64/96/128/256px — the fuller Windows DPI-scaling set, not just the minimal 4-5 sizes most icons ship with) rather than upscaling a single raster, so it stays crisp at every size Explorer actually requests. A reported "dark border/blurriness" on the desktop turned out to be Windows' own built-in shortcut drop-shadow effect (confirmed present on other apps' icons too, just far less visible on their bulkier shapes) — not a defect in the file.

### TopBar — right-group alignment, root-caused twice
- **Volume label misalignment, root cause fixed.** `VolumeKnob`'s bars were centering themselves independently of their row siblings (Time/Metronome/MIDI, which bottom-align via the row's own `alignItems:'flex-end'`) using an absolutely-positioned label as a workaround — the two approaches drifted apart. Rebuilt as the same real-flow `[content, label]` column shape as its siblings, so it inherits the row's bottom-alignment naturally instead of faking it from outside the flow.
- **Whole-bar realignment.** Under the previous `alignItems:'center'`, the center column (transport + scrub, ~87.5px tall) sat almost flush with the row's top edge while the left/right groups (~40px tall) sat 28px down — the actual reason every previous right-group padding tweak kept fighting itself. Moved the filename above the transport row (so the center column's own top line is comparably light to the side groups') and top-anchored just that column with its own margin, while left/right went back to true vertical centering — CDP-measured: both groups land at identical `top` values, filename retains its own clearance.

### Typography — three new pairing candidates installed for trial
- **Founders Grotesk / IBM Plex Mono**, then **Familjen Grotesk** and **Mona Sans** (all self-hosted, no CDN) installed alongside the existing Inter/JetBrains Mono — `--font-ui`/`--font-mono` swap between them with a one-line edit, no re-fetching needed. IBM Plex Mono is the settled mono pairing; the UI-font trial is ongoing (currently pointed at Familjen Grotesk). Founders Grotesk's files are kept for now, pending a final decision.
- Self-hosted fonts relocated from `public/fonts/` to `src/assets/fonts/`, now going through Vite's normal hashed-asset pipeline instead of the raw-copy `public/` bucket — no change to what ships, purely a source-tree tidiness move. `public/fonts/` now holds only the unrelated PDF-export TTFs used by `electron/main.ts`.
- Mona Sans was initially sourced from its GitHub repo directly; switched to Google Fonts' hosted copy instead (identical SIL OFL-1.1 file, just already in the same one-file-per-script-range variable form the rest of this block uses) for consistency with the other self-hosted fonts.

### Fixed — form controls silently ignoring the app's fonts
- **`button`/`input`/`select`/`textarea` don't inherit `font-family` from the page in any browser** — a long-standing CSS quirk that had 33 form controls across 9 files quietly rendering in the platform's default font (Arial on Windows) regardless of `--font-ui`, undetected until a font swap made it visually obvious on the Library/Settings drawer tabs. Fixed at the root with a single `font-family: inherit` rule on all four element types, rather than patching each site — also protects any future control that forgets to set it explicitly.

### Removed — Tailwind CSS
- Uninstalled entirely (`tailwindcss`, `@tailwindcss/vite`, `tailwind.config.ts`, the Vite plugin registration, the `@import` in `index.css`). Audit found only 10 real utility-class usages app-wide, all in one file (`Keyboard.tsx`), and the custom theme it was configured with (colors, font families) was referenced nowhere and already stale. Those 10 sites converted to inline styles — the pattern already used by the other 99% of the app — with zero visual change (CDP-verified).

### Also
- `lucide-react` updated `0.503.0` → `1.31.0` (180 releases behind; the version jump to `1.0.0` was flagged by upstream as published in error, not an intentional breaking change). Verified all 76 icon names this codebase imports still exist under the same names before upgrading.

**New:** `src/assets/fonts/` (18 files — Inter, JetBrains Mono, Founders Grotesk, Familjen Grotesk, Mona Sans, IBM Plex Mono). **Removed:** `tailwind.config.ts`, `public/fonts/*.woff2` (moved to `src/assets/fonts/`). **Changed:** `public/icon.ico`, `src/components/Transport/TopBar.tsx`, `src/components/VolumeKnob.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/index.css`, `electron.vite.config.ts`, `package.json`.

## [1.8.0] — 14. 8. 2026 — Accessibility overhaul, performance fixes, self-hosted typography

A full `/impeccable audit`-driven pass: the app scored 12/20 on a technical audit (accessibility, performance, theming, responsive design, implementation integrity) going in, 15/20 after the first fix round, and every item from both audits is resolved as of this release. Also includes a font-tokenization + self-hosting pass and a handful of real bugs found via live testing rather than audit findings.

### Accessibility — the app's weakest audited dimension, now addressed end to end
- **Visible keyboard focus app-wide.** `button:focus{outline:none}` had no replacement anywhere in the app — a sighted keyboard-only user tabbing through the UI had no way to see where focus was. Added a visible `:focus-visible` ring (amber accent) that doesn't reappear on mouse clicks.
- **Keyboard equivalents for mouse-only controls.** Mixer knobs, the channel fader, and on-screen piano keys were `<svg>`/`<div>` drag targets with no `tabIndex` or `onKeyDown` — a keyboard-only user could not adjust any mixer control or play a note from the on-screen keyboard at all. Added `tabIndex` + arrow-key increment/decrement to knobs and the fader; `tabIndex`/Enter-Space to piano keys. Also added a keyboard path to the Chords/Scales explorer triggers and the chord-prompter toggle, which were still `<span>`/`<div onClick>` even after the rest of the keyboard batch landed.
- **Modal semantics, done correctly, not blanket.** Every true modal (Mixer Console, Note Editor, Playback Editor, Scale/Chord Explorer, Lock-a-Chord, File Info, Confirm dialogs) now gets `role="dialog"`, `aria-modal="true"`, and a real focus trap (`src/hooks/useFocusTrap.ts`). Persistent non-modal tool panels (Floating Keyboard, Note Editor toolbar) deliberately got `role="region"`/`role="toolbar"` instead — a focus trap on those would have prevented keyboard users from ever tabbing back out to the rest of the app while either was open. Two follow-up bugs surfaced and fixed during this pass: the Mixer's focus trap silently never attached (a one-render mount-timing gap between `mixerOpen` and the modal actually existing in the DOM), and removing a stray Escape guard broke Chord/Scale Explorer's Escape behavior in a different way than intended — both fixed with the guard's real reasoning documented in place this time.
- **Consistent Escape-to-dismiss.** Scale Explorer and the Locked Chord modal had no Escape handler at all (confirmed by grep — the app's global handler was silently deferring to a component handler that didn't exist). All floating panels now dismiss on Escape. Locked Chord modal also previously double-fired global playback `stop()` on top of its own close (no store presence to exclude it from the global guard the way Chord/Scale Explorer already had) — added a `lockedChordModalOpen` store field for exactly that.
- **`prefers-reduced-motion` respected.** The TopBar's infinite loop-blink animation had zero motion-sensitivity guard anywhere in the codebase. Added a reduced-motion media query.
- **Contrast fixes.** `--text-track-meta`, `--text-track-count`, `--text-inactive`, and `--text-faint` all fell below WCAG AA's 4.5:1 minimum against their actual rendered backgrounds — every track row's channel/program/note-count text, and inactive icon states app-wide, were near-invisible for low-vision users. Raised all four to clear AA while preserving their relative dimness ordering.
- **ARIA on custom dropdowns/menus.** Settings' dropdown, the quantize-grid popover, Library's file/folder context menus, and the Piano Roll's right-click menu had no `role="listbox"/"menu"`, no `aria-expanded` — screen readers announced nothing beyond "button, unlabeled state." All four now carry proper roles.
- **Hand assignment (LH/RH) is no longer color-only during playback.** This is the app's stated pedagogical differentiator (which hand plays a note), and during normal falling-note playback it relied solely on `--hand-lh`/`--hand-rh` hue — a colorblind user lost the app's core teaching signal exactly when it mattered most. Added a non-color backup: a small L/R glyph on lit keyboard keys, and a thin left/right edge accent on hand-colored falling notes in the Piano Roll (shape/position, not hue, so it survives color-vision deficiency).
- **Settings form inputs now have a programmatic label association**, not DOM-proximity-only. `OptionRow` (used by nearly every Settings control) is wired as `role="group"` + `aria-labelledby` via `useId()` — a real `<label htmlFor>` wasn't feasible since its `children` is an opaque per-call-site control, not always one labelable element.

### Performance
- **Fader-drag stutter, root-caused and fixed everywhere it existed.** `TrackPanel.tsx`, `MidiEditor.tsx`, and `NoteEditorToolbar.tsx` all subscribed to the entire `tracks` array, which gets a new reference on every fader/pan/chorus/reverb drag tick from the Mixer — forcing a full re-render of whichever of those three happened to be open, dozens of times a second, on every drag. All three now subscribe to a narrow display-relevant signature string instead (the same pattern already proven in `ChannelStrip`/`MasterStrip`/`MixerConsole`), so unrelated drags no longer cascade into panels that don't even display the fields that changed.
- **Mixer VU-meter animation loops now stop when the Mixer is closed.** `ChannelStrip`/`MasterStrip` stay mounted (`display:none`) after first open so their internal state survives hide/show, but their `requestAnimationFrame` decay loops kept running indefinitely regardless — gated both on real `mixerOpen` state.

### Responsive design — TopBar and Mixer Console at the documented 900×600 floor
- Mixer Console's modal width now caps to the viewport (`calc(100vw - 24px)`) instead of computing up to ~1218px unbounded at high channel counts, which could render clipped off-window at the app's own documented minimum width.
- TopBar's center transport block rebuilt as a real 3×`minmax(0,1fr)` CSS Grid, replacing flex+absolute centering that could overlap the side groups near the 900px floor — the exact anti-pattern this repo's own `CLAUDE.md` already documents from an earlier `ChordExplorer.tsx` incident. A live-CDP-tested follow-up fix also stopped the left/right side groups themselves from overflowing into the center column at that width.
- **TopBar's right-side button-clearance padding, fixed twice — the first pass solved the wrong problem.** The Windows caption-button overlay (`–□×`) reserves real horizontal space, and the app was carrying a flat `174px` guess as permanent right-padding across the bar's entire height to avoid it — a much larger gap than actually needed, and one that didn't scale with the user's real display DPI. First attempt measured the real reserved width live via `navigator.windowControlsOverlay` (down to 137px on a 1920px-wide, 100%-scale display) but also bottom-anchored the right icon group below the buttons' 40px-tall zone to tighten the gap further — which fixed the padding but broke vertical alignment with the left/center groups (live user feedback caught this, not testing). Corrected: the group stays vertically centered like its siblings, and the live-measured inset moved to the group's own `paddingRight` instead of the row's shared padding, so its content's right edge lands exactly at the real button boundary — CDP-verified, zero overlap, no vertical trade-off. A genuinely clipped Volume-knob label (cut off 2.5px early by `overflowY:hidden`, found while measuring the above) was fixed in the same pass.

### Typography — tokenized, then self-hosted
- **Every hardcoded `'Inter'`/`'JetBrains Mono'` literal — 235 of them across 24 files — replaced with `var(--font-ui)`/`var(--font-mono)`.** Zero visual change; this was pure infrastructure so a future font swap is a two-line edit instead of a 235-site hunt. `--font-logo` is a separate token for the ORFEO wordmark's own distinct fallback stack, independently swappable from the UI font. Canvas2D `ctx.font` strings (the Piano Roll's falling-note overlay) can't resolve `var()`, so those plug into the file's existing resolve-once-from-CSS pattern (`resolvePianoRollColorsFromCSS`, already used there for PixiJS/Canvas colors) instead of duplicating the font names as separate literals.
- **Google Fonts CDN dependency removed entirely.** `PRODUCT.md` states this app is local-first with no network dependency for core playback; the UI font was quietly violating that on every launch. Downloaded the same files Google was serving (both are variable fonts, so only 4 physical `.woff2` files total cover the whole weight range) and committed them to `public/fonts/`, declared via local `@font-face` blocks. Verified against an actual `electron-vite build` output, not just the dev server — production Electron loads via `file://`, where absolute asset paths can resolve incorrectly; confirmed the build correctly rewrites them to relative paths that survive it.
- **Fixed a real, unrelated bug found while doing this**: weight 700 was never loaded for either font (only 400/500/600 for Inter, 400/600 for JetBrains Mono) despite being the single most-used weight app-wide — 69 uses across BPM/key numbers, chord names, mute/solo labels, and the logo. All of those were rendering as Chromium's synthetic/faux bold this whole time, not the fonts' real bold faces. Both now load 400/500/600/700 (Inter) and 400/600/700 (JetBrains Mono).

### Also fixed
- Drop-error toast (shown for unsupported file types) now has click-to-dismiss alongside its 2.5s auto-timeout.
- `SettingsPanel.tsx`'s hard-coded color literals (including one red encoded two different ways in the same file) tokenized; a leftover diagnostic `console.log` removed from the Mixer's close handler.
- The disabled "coming soon" practice-mode icon in the Track Panel now has a dashed outline and reduced opacity, so it reads as unavailable at rest instead of only on hover.
- A redundant `onClick` on the Track Panel's collapsed-group color-swatch row (a "visual legend only" element, per its own comment) removed — it duplicated the adjacent chevron button's toggle and falsely implied the swatches themselves were clickable.
- `MidiEditor.tsx`'s duplicated, undocumented `LOW_CONF` hex literal tokenized to `--status-low-confidence`.

**New:** `src/hooks/useFocusTrap.ts`, `public/fonts/Inter-Variable-{latin,latin-ext}.woff2`, `public/fonts/JetBrainsMono-Variable-{latin,latin-ext}.woff2`. **Changed:** most of `src/components/` (accessibility/perf/token passes touched nearly every floating panel and the Mixer/TrackPanel/Keyboard/PianoRoll/TopBar/SettingsPanel families), `src/store/index.ts`, `src/index.css`.

## [1.7.0] — 13. 8. 2026 — Pre-release polish pass: floating-panel bugs, Mixer rebuild, Playback Editor split redesign

A broad polish/bugfix pass across nearly every floating panel in the app, done ahead of the first public release. Two real regressions stand out: an Electron window-drag region silently swallowing clicks on the Loop Region's bar-select icon, and every draggable modal's close button becoming unclickable once dragged near the titlebar.

### Fixed — Loop Region bar-select icon completely unresponsive
Root cause: TopBar sits inside an Electron `-webkit-app-region: drag` region (native window dragging), and the icon/popup never got the `app-no-drag` exemption class every other TopBar control has. A real mouse click was being intercepted at the OS level as a window-drag gesture before it ever reached React — the button still looked and hovered normally, and synthetic/programmatic click events still fired (they bypass native OS interception), which made this exceptionally hard to reproduce under automated testing. Added `app-no-drag` to the icon, its popup, and the strip canvas itself. Also fixed a separate popup-open race (the outside-click-to-close listener attaching in the same tick as the opening click, sometimes swallowing it) by deferring attachment by one tick, and moved the popup to a `document.body` portal with `position: fixed` — it was `position: absolute` inside TopBar and could render half-clipped behind the piano roll.

### Fixed — every draggable modal's close button unclickable near the titlebar
Every floating modal (Note Editor, Playback Editor, Scale Explorer, Chord Explorer, Lock-a-Chord, Mixer Console, Floating Keyboard, File Info) clamped its y-position to a floor of 0 when dragged or repositioned, letting the top edge — and its close button — slide up under Electron's 40px `titleBarOverlay`, where Windows draws its own native window controls on top of everything in the DOM regardless of z-index. Raised the floor to 44px everywhere (matching the fix already shipped for Scale Explorer in 1.6.1), so no modal can be dragged into the dead zone. Also unified every modal's close-button styling (size, border, hover color) to match the Note Editor's — extracted to `src/utils/modalCloseButtonStyle.ts`.

### Fixed — MIDI Note Editor toolbar
- Only a 16px logo icon was draggable — moved the drag handle to the whole header row, matching every other modal.
- Header hint text's last word wrapped to its own line — side columns were 150px wide with only ~126–62px of actual content; narrowed to 130px each.
- "Fine-tune it yourself" note-editor icon in the Playback Editor was completely unresponsive: `handleOpenInNoteEditor` was a `useCallback([])` declared before an early `return null` that fires on first render (before its own closed-over state existed) — React locked the callback to that broken first-render closure forever, throwing `ReferenceError` on every click. Fixed by converting it to a plain (non-memoized) function declared after the early return.

### Mixer Console — Master Volume knob rebuilt, playback stutter fixed
- Master Volume knob redrawn and repositioned to sit flush with the channel strips' own bottom edge (matching their Track-N label), with a new dB/percent readout beneath it.
- Chorus/Reverb/Tone knobs (both Master and per-channel) now show a hover tooltip explaining what each control does.
- VU meter now scales with the channel's own fader position — it previously showed raw note velocity only, so dragging a fader never visibly moved its meter.
- Fixed a real playback stutter while dragging any Console fader/knob: `ChannelStrip`, `MasterStrip`, and the sample-engine's playback-scheduling effect were all subscribing to the *entire* `tracks` array, so every fader mousemove re-rendered all 8+ channel strips and re-evaluated the playback scheduler dozens of times a second. Narrowed each to only the specific fields it actually needs (this channel's own track object; a mute/solo/visible signature string) so unrelated drags no longer cascade.
- Hide/show-in-roll icon recolored to the app's actual success/error status colors (was amber/red).

### Track Panel
- Custom drag-to-reorder (both track groups and tracks within a group) only worked dragging upward — dragging a row downward past its target stalled or oscillated instead of passing it. The insert index was always computed as "before the target," which only reads correctly moving up; downward drags now insert after.
- `NoteEditorIcon.tsx` (a custom SVG) deleted and replaced everywhere with lucide's `AudioLines`/`ListTree` — one less bespoke icon to maintain, no visual regression once stroke-width was compensated for its larger render size.

### Settings — Library & Hand Labels
- Library folder list: the app's own `Orfeo` folder is now always pinned topmost (above the existing `Demo` pin).
- Protected folders (`Orfeo`) now still get a right-click menu — just "Show in explorer" instead of Rename/Move/Delete, instead of no menu at all.
- Max Fingers redesigned: heading + Left/Right rows with one shared description below, instead of two separately-hinted rows.
- Practice mode (the averaged split-line hand-label display) disabled in the UI — proved inconsistent in practice; the underlying code and store value are untouched (still selectable via a `{false && ...}` guard) so it can come back once improved. A stale saved `'practice'` preference from before this change is no longer restorable.

### Piano Roll — velocity editor and loop overlay
- Velocity lane bars now spread across the lane's full width by the soloed track's own pitch range (min–max, centered) instead of sitting at each note's literal keyboard X — a track using only a narrow slice of the keyboard no longer crowds all its bars into one edge.
- Notes at the same pitch within the visible window now nudge sideways instead of stacking exactly on top of each other.
- Loop region selection: removed the Alt-key gate entirely — a plain click+drag on the piano roll now starts a selection (previously required holding Alt, a leftover from an earlier design that was never fully removed from the tooltip text either).
- Loop region cursor tooltip only shows while a region is actively selected, not on every hover with nothing selected. Text updated to "Loop region set" / "Drag to reorder, right-click to clear".

### Lock-a-Chord
- Header restyled to match the Note Editor's (background, border token, logo/title sizing).
- Shows the actual note names in place of dashes for the first 1–2 shift-clicked notes, before enough are locked for a chord name to resolve.
- Play-icon style unified with Scale Explorer's rounded chevron (extracted to a shared `ChevronPlayIcon.tsx`, removing a duplicate that lived in `ScaleExplorer.tsx`).

### Also fixed
- TopBar transport buttons visibly shifted left whenever the amber "click to loop" label appeared/disappeared — the label was a normal flex sibling whose presence changed the centered row's total width. Removed from flow via `position: absolute`.
- A React "conflicting style property" warning (`border` shorthand + `borderTop` override) fired continuously during playback from `Keyboard.tsx`'s black-key glow, since that element re-renders on every key-light color change — switched to per-side longhand.
- Internal drag-reorder (Track Panel/Console/Library rows) showed a flickering native "no-drop" cursor in the gaps between drop targets — `dragover`/`dragenter` now call `preventDefault()` unconditionally for non-file drags.

**New:** `src/utils/modalCloseButtonStyle.ts`, `src/components/ChevronPlayIcon.tsx`. **Removed:** `src/components/NoteEditorIcon.tsx`. **Changed:** most floating-panel components (`NoteEditorToolbar.tsx`, `MidiEditor.tsx`, `ScaleExplorer.tsx`, `ChordExplorer.tsx`, `LockedChordModal.tsx`, `MixerConsole.tsx`, `FloatingKeyboard.tsx`, `FileInfoModal.tsx`), `LoopRegionStrip.tsx`, `TopBar.tsx`, `PianoRoll.tsx`, `TrackPanel.tsx`, `SettingsPanel.tsx`, `VolumeKnob.tsx`, `Mixer/*.tsx`, `useSamplesEngine.ts`, `store/index.ts`, `App.tsx`.

## [1.6.1] — 11. 8. 2026 — Chord-display transpose bug, tempo/key save rewiring, Scale Explorer root-note coloring

### Fixed — chord names above the keyboard didn't update on transpose
`useChordSequence.ts` pre-computes the whole file's chord sequence from each note's raw MIDI pitch, but its effect only re-ran on `[midi, noteNaming, accidentals]` — never on key/transpose changes. Playback, the audio engine, and the keyboard all correctly shifted pitch by the current transpose; the chord-name strip never did, so changing key left every chord label showing the file's *original* key. Fixed by folding transpose into the note pitches before chord detection and re-running whenever it changes.

### Tempo/Key save — rewired into the Playback Editor
The opt-in "save tempo/key changes" feature (v1.6.0) had its toggle in Settings and its own standalone Save button in the TopBar, disconnected from the Playback Editor that already owns file-versioning saves. Reworked: the toggle now lives in the Playback Editor's select-all/clear-all row ("Save Tempo & Key changes", off by default), and its logic is folded directly into that modal's own Save & Reload write — one click, one `_ORFEO_vN`, one changelog entry, instead of two independent saves stacking two versions. The TopBar button is gone. The underlying bake-in math (`computeTempoKeyPayload()` in `tempoKeySave.ts`) is unchanged and still shared with the standalone Reset/close/drag-drop unsaved-changes guard, which still needs to save tempo/key changes even when the Playback Editor isn't open.

### Scale Explorer — root note coloring (new, opt-in-by-default)
New "color root note" toggle (top-right of the Chords-in-the-Scale row, on by default): highlights the true root pitch class in pink (same pink as the Note Editor's RH hand color) instead of blending into the uniform amber used for every other note. Two deliberately different rules, both keyed on the chord's *pitch class* rather than voicing position (fixing a real bug — the old code colored whichever note happened to be the current bass, which broke under inversion since the true root can land anywhere in the voicing once inverted):
- **Chord tiles** (click, octave tile, root-position progression steps): colors the **scale's** root — a diatonic chord only gets a pink note if it actually contains the scale root (e.g. in F# major only F#, B, and D#m contain F#).
- **Inversions** (the ◂/▸ inversion steppers, and inverted progression steps): always colors the **chord's own** root, regardless of the scale. Intended to be ported to the Chord Explorer and Chord Locker next.

### Fixed — Scale Explorer's close button occasionally maximized the app window
The Electron window uses a 40px `titleBarOverlay` (Windows draws its own native minimize/maximize/close buttons there, on top of the page regardless of DOM z-index). Scale Explorer's modal is tall enough (600px) that its default vertical position clamps to a floor on smaller windows — and that floor was 8px, landing the modal's own header (and × button) right under Windows' real maximize button. Clicks aimed at Orfeo's close button were sometimes actually hitting the OS control instead. Floor raised to 44px (clears the overlay) for both the initial position and manual header-drag.

### Mixer Console
- **Channel drag-to-reorder** (new): piano/keys channels stay locked leftmost; every other channel gets a grip handle in its name bar and can be dragged to reorder, same pattern as the Track Panel's existing group drag-reorder.
- Minimize button removed from the header (state and all wiring fully deleted, not just hidden).

### Track Panel icon rail
Reordered to MIDI Playback Editor → MIDI Note Editor → Console Mixer → placeholder (was Mixer first). Fixed a real visual inconsistency, not just a preference: `NoteEditorIcon` and the placeholder star render at a larger size (22px/20px) than their siblings (18px/16px) against the same 24-unit SVG viewBox, so an identical `strokeWidth` rendered visibly heavier at the larger size — compensated with a lower `strokeWidth` on those two instances only, no icon changed visual size.

### Keyboard footer layout
The "Shift+Click three keys or more…" hint moved from the keyboard header into the bottom control bar's true center (rebuilt as a 3-column CSS Grid, matching this repo's convention for rows needing guaranteed centering against asymmetric side content) — hidden whenever the practice-mode moving split-line is actively rendering, or in Presentation Mode.

### Dependency updates
Patch/minor bumps: React/React DOM/`@types` 19.2.8, Tailwind 4.3.3, `fuse.js` 7.5.0, `spessasynth_lib` 4.3.13, Electron 42.4.1 → 42.8.1 within its current major (closes a moderate Electron cache-reuse advisory). `npm audit fix` cleared the rest — all transitive `electron-builder` build-tooling advisories, dev-only, never shipped in the packaged app. 0 vulnerabilities. All other runtime deps (JZZ family, Tonal, Tone.js, `@tonejs/midi`, AlphaTab, PixiJS, GSAP, PDFKit, etc.) were already at latest. Also re-included `package-lock.json` in git tracking — it had picked up a stale skip-worktree bit at some point, silently excluding it from every commit for a long time. Deferred (major-version jumps, need their own test pass): `electron-vite` 5.x, `@vitejs/plugin-react` 6.x, `typescript` 7.x, `lucide-react` 1.x, Electron 43.x.

**New:** `src/hooks/useChordSequence.ts` transpose dependency, `computeTempoKeyPayload()` (`src/utils/tempoKeySave.ts`), `colorRootNoteEnabled` store toggle, Mixer channel drag-to-reorder (`ChannelStrip.tsx`/`MixerConsole.tsx`). **Changed:** `electron/main.ts` (`editor:save` payload), `src/components/MidiEditor/MidiEditor.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/Transport/TopBar.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/Keyboard/KeyboardControls.tsx`, `src/store/index.ts`, `src/types/index.ts`.

## [1.6.0] — 10. 8. 2026 — Note Editor manual hand assignment, tempo/key saving, and a real data-loss fix

The big one. Manual LH/RH hand correction inside the Note Editor, a full toolbar rebuild, a new opt-in tempo/key saving feature, and — found while chasing an unrelated report — a versioning bug that could silently overwrite an earlier saved version instead of creating a new one.

### Note Editor — manual hand assignment
The Note Editor gained a full correction workflow for the automatic LH/RH hand-splitting algorithm: a dedicated **Hand** toggle (separate from the Settings LH/RH algorithm toggle — this one only controls what the editor shows/lets you fix right now) that visually isolates the piano/keys track on the roll and keyboard (hides every other track — purely visual, doesn't touch audio) and enables **Assign to Left/Right Hand** in the right-click context menu. Manually assigned notes are tagged `handSource: 'manual'` and protected from being silently overwritten by a fresh algorithm run on the next load. Assign/reassign is fully undo-capable (Ctrl+Z, or the context menu's Undo/Redo, always present and disabled-aware). Split/Merge/Save in the Playback Editor now respects manually-corrected tags end-to-end via an extended `ORFEO_HAND_MAP` persistence format that carries a per-note computed/manual source alongside the hand itself.

### Note Editor — toolbar rebuild and tool isolation
Full 3-row toolbar redesign: header (logo, title, permanent "click a track to solo it" hint, close), a combined TOOLS+MODES row, and a context-aware tooltip row. Each tool (Select/Pen/Marquee/Lasso) now does exactly one thing — Pen only adds (Alt+click) or marks notes for delete, Marquee/Lasso only select, Select handles move/resize/pan. Right-click always opens a context menu (Assign LH/RH when Hand mode is on, Deselect, Undo, Redo, Delete always last) instead of ever instant-deleting. Every icon's tooltip now shows in the toolbar's own dynamic hint row instead of a native browser tooltip, changing live with hover/selection state. Undo/redo icons rotated to read as directional arrows; velocity lane icon is a static white/amber toggle with no blink/nudge.

### Note Editor — visual language for unsaved edits
Selected/dragged notes get a white 2-3px outline (was a 1px red border flush against the note). Notes that were moved/resized/repitched/velocity-changed keep pulsing that same border even after being deselected, so an edit stays visible at a glance. Brand-new (not yet saved) notes render outline-only with no fill at all, instead of a colored note with a border on top. All three reset to normal on Save & Reload.

### Note Editor — interaction bugs
- A plain click on a note silently nudged its pitch/time by a tick — the note-drag math ran on every pointermove between mouse-down and up, including a click's few pixels of incidental jitter, and separately, `snapTick()` was being applied unconditionally even when nothing actually moved, which shifted any note that wasn't already perfectly grid-aligned (i.e. almost any real performance recording). Both fixed — a drag now only "counts" past a 3px threshold, and the snap-and-compare step is skipped entirely below it.
- Cursor could get stuck showing the pencil icon after a Select-tool drag ended.
- Grab-to-pan read the wrong mouse axis (this piano roll's time axis is vertical, not horizontal) — panning was barely responsive and could read as either direction.
- Plain click on empty space now deselects (previously only right-click did).
- A vibraphone/mallet-instrument track sharing a file with a real piano track was miscounted as "piano-family" in two places: the hand-assignment note pool (wrongly forced its notes into the LH/RH split) and the piano-family color palette slot (could coincidentally collide with the fixed hand-color hex, making the piano track's own default color look identical to "assigned right hand"). Both narrowed from `KEYBOARD_GROUPS` to a piano+organ-only `HAND_ASSIGN_GROUPS`.
- A toolbar history-change listener's cleanup compared against the wrong closure reference and could never actually clear a stale handler, leaving the Undo icon stuck disabled after some interactions (Ctrl+Z and the context menu's Undo were unaffected — they read history state fresh each time).

### New feature — save tempo/key changes to file (opt-in)
BPM and transpose were session-only display preferences. A new toggle in Settings → MIDI Files & Library ("Save tempo/key changes", off by default) unlocks a **Save changes** button in the header next to the Key/Tempo controls whenever either has been changed from the loaded file's own values. Saving bakes both into a genuinely new versioned copy: BPM scales every existing tempo event by the same ratio (preserves rubato shape rather than flattening to one constant tempo), and transpose shifts every note's actual pitch (skipping drum tracks — a drum note's pitch selects which drum sound plays, not a musical pitch). Logged to File Info as e.g. "Changed BPM from 144 to 78" / "Changed key from F to Eb". Wired into every place that can discard the current file — opening a new one, dragging a file in, closing the app, and Reset — each prompting Save/Discard/Cancel if dirty.

### Fixed — key signature always showing "—"
Found while testing the feature above: `@tonejs/midi` (the version in use) returns a file's key signature as a note-name **string** ("F", "Bb"...), never the raw numeric sharps/flats count the app's parser assumed — so `key % 12` silently produced `NaN` for every file with a genuine key signature, permanently stuck the Key display at a dash. Affected any file with real key metadata, not just ones without it. Fixed to map the string directly to a semitone.

Separately, `@tonejs/midi`'s own key-signature *encoder* has a bug that silently drops the value on any re-save regardless — verified directly that even round-tripping a file with zero changes through its encoder loses the key signature. Worked around with a custom `ORFEO_KEY` text meta event (same pattern already used for track names/colors), written by the tempo/key save and read back with priority over the native field.

### Fixed — critical: save could silently overwrite an earlier version instead of creating a new one
`nextOrfeoVersion()` computed the next `_ORFEO_vN` number purely from the *currently loaded file's own filename* — correct only if you always keep editing the freshly-reloaded save result. Reopening the plain original later (exactly what Library Favorites does — it points at the original, not the latest version) computed "_ORFEO_v1" again even if v1/v2/v3 already existed on disk from earlier sessions, and the save had no existence check: **it silently overwrote the old v1 with today's completely different edits.** Affected all three save tools that share this versioning rule (Playback Editor, Mixer, Note Editor). Fixed with a helper that scans the actual output folder for existing versions and always takes the real max + 1.

### Track Panel
- Show/hide-in-roll eye icon recolored: green when visible, red when hidden (was white/blue).
- Drag-to-reorder no longer shows the OS "not allowed" cursor badge for the whole drag — the drag handlers never populated `dataTransfer`, which is unrelated to how the reorder itself works (pure React state) but is what Chromium uses to decide which cursor to show.

**New:** `src/utils/tempoKeySave.ts`, `NES.editedNotes` (`src/utils/noteEditorState.ts`), `HAND_ASSIGN_GROUPS` (`src/utils/keyboardGroups.ts`), `nextAvailableOrfeoPath()` (`electron/main.ts`), `tempoKey:save` IPC handler, `ORFEO_KEY` meta convention. **Changed:** `src/components/NoteEditor/NoteEditorToolbar.tsx` (largely rebuilt), `src/components/PianoRoll/PianoRoll.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/components/Transport/TopBar.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/store/index.ts`, `src/utils/keyDetection.ts`, `src/utils/midiParser.ts`, `src/utils/keyboardGroups.ts`, `src/utils/orfeoVersioning.ts` usage, `src/App.tsx`, `src/hooks/useMidiFile.ts`, `electron/main.ts`, `electron/preload.ts`.

---

## [1.5.2-pre] — 9. 8. 2026 — Note Editor: silent audio during live edits, fixed for real

Follow-up to the "no audio while the toolbar is open" fix — that fix (gating playback on `NES.dirty` so it only reroutes to the edit buffer once a real edit exists) stopped the false-positive case, but audio still stayed silent with a genuine edit in place; only a full Save+reload restored it.

### Root cause
`NES.editMidi` — the separate live `@tonejs/midi` copy Note Editor mutates during editing, kept apart from the store's `midi` so edits stay staged until Save — is built via `new Midi(rawBuffer)`, a stock `@tonejs/midi` parse. Its `Track` objects have no `index` field; that's not part of the library. The store's `midi.tracks`, by contrast, are plain objects `midiParser.ts` builds itself with a custom `.index` assigned in parse order. Both audio engines (`useAudioEngine.ts` GM, `useSamplesEngine.ts` Samples) resolve a track's mute/solo/program state via `tracks.find(t => t.index === track.index)` — against the edit buffer, `track.index` was always `undefined`, so the lookup failed for every track, so every track was silently skipped: no program changes sent, no notes scheduled. The transport clock kept advancing regardless (it reads the JZZ player's own position independently), which is why the timeline still visibly scrolled with zero sound — nothing was actually wrong with playback *timing*, nothing was ever being played at all.

Fixed at the single creation point both engines' edit buffer comes from: `midiToEditableCopy()` (`src/utils/noteEditorCommands.ts`) now stamps `.index` on each track by array position immediately after parsing, matching how `midiParser.ts` assigns it — parse order is guaranteed identical since both come from the same `_raw` bytes and note edits never reorder or add/remove tracks.

Also hardened while investigating: `useAudioEngine.ts`'s `buildPlayer()` computed its raw SMF bytes (`editableCopyToBuffer(NES.editMidi)` when dirty) *before* entering its own try/catch, so a re-encode failure there would silently abort the whole rebuild with no player ever built and no error surfaced beyond a generic upstream `.catch(console.error)`. Moved inside the try block, with an explicit warning logged if no bytes are available at all.

**Changed:** `src/utils/noteEditorCommands.ts`, `src/hooks/useAudioEngine.ts`.

---

## [1.5.1-pre] — 8. 8. 2026 — Foreign-format import fixes, per-edit changelog coverage

Bug-hunting round covering the whole gp3/gp4/MusicXML import pipeline plus File Info changelog gaps found while testing it.

### Foreign-format import — save/edit chain was targeting the wrong file
Once a dropped `.gp3`/`.gp4`/`.musicxml`/`.mxl` file was converted and cached to an `_IMPORTED.mid`, the app's loaded `midi._filePath` (and `.fileName`) stayed pinned to the original foreign-format source forever — `resolveAndTrackImport()` returned only the converted bytes, never the resolved on-disk path. Every downstream editing tool (Playback Editor's Save & Reload, Note Editor) kept reading/writing against the foreign source instead of the real cached `.mid`, which is why saves either failed outright (`@tonejs/midi` can't parse Guitar Pro/MusicXML binary) or silently applied edits to the wrong file. `resolveAndTrackImport()` now returns `{ base64, filePath, fileName }` reflecting wherever the real `.mid` actually lives (cache hit, freshly-saved cache, or the original for native `.mid`/`.kar`), threaded through all three load entry points (drag-drop, Ctrl+O, Library click) and the pre-edit gate. The title bar under playback controls now correctly flips to the `_IMPORTED` name the moment the conversion is saved, instead of showing the foreign extension indefinitely.

### Playback Editor — instrument reassignment didn't update name or color
Reassigning a track's instrument only ever touched its GM program number. The track's display name (still whatever the source file called it) and color (still whatever it was assigned before reassignment) never followed, so a guitar reassigned to piano kept showing its old guitar name and color everywhere (Tracks panel, Piano Roll, Keyboard) even though playback correctly changed. Reassignment now also updates the name (to the new instrument's GM name) and color (to the deterministic piano-family blue/pink/amber slot) — but only when neither was ever manually customized, so a real custom name/color a user picked is left alone. Extracted `PIANO_FAMILY_COLORS` into `src/utils/colors.ts` as a shared constant so `midiParser.ts` (initial load) and `MidiEditor.tsx` (live reassignment) compute the identical slot instead of duplicating the rule.

### Also fixed
- `_rawMidiTracks[t.index]` in `MidiEditor.tsx` indexed the raw unfiltered track array with an already note-filtered, compacted index — landed on the wrong track whenever an earlier raw track had 0 notes, showing a bogus "0 notes"/wrong-channel badge in the editor's track list.
- `buildSaveSummary()` (Playback Editor) never diffed `newProgram`, so a save that only reassigned an instrument fell back to a bare "Saved" changelog entry with no detail.

### File Info changelog — several edit paths logged nothing or just "Saved"
- **Note Editor saves logged nothing at all.** Now logs a real tally (`added N notes`, `removed N notes`, `moved N notes`, `repitched N notes`, `resized N notes`, `changed velocity on N notes`), built from the undo stack's own command descriptions (`NoteEditorHistory.appliedDescriptions()`).
- **Note Editor save also wrote to the wrong folder.** It relied on a client-computed Orfeo-subfolder path handed to a native save dialog as `defaultPath` — a folder that often doesn't exist yet, which Electron's dialog can silently ignore, falling back to wherever it last had a folder open (e.g. Downloads) and writing the versioned file there instead. Removed the dialog entirely: `noteEditor:save` now takes the source `filePath` and computes/creates the output path itself via `getOrfeoOutputDir()`/`nextOrfeoBaseName()` and logs its own changelog entry server-side — the same silent-auto-version convention `editor:save`/`mixer:save` already use, so it's no longer possible for the logged path and the actual written path to diverge.
- Foreign-format import cache writes (`fs:writeCachedImport`) wrote to disk with zero changelog entry — now logs "Imported and converted to MIDI".

**New:** `PIANO_FAMILY_COLORS` (`src/utils/colors.ts`), `NoteEditorHistory.appliedDescriptions()` (`src/utils/noteEditorHistory.ts`), `buildNoteEditSummary()` (`src/utils/noteEditorState.ts`). **Changed:** `src/utils/foreignFormatImport.ts`, `src/App.tsx`, `src/hooks/useMidiFile.ts`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/utils/midiParser.ts`, `electron/main.ts` (`noteEditor:save` rewritten, `fs:writeCachedImport` logging).

---

## [1.5.0-pre] — 8. 8. 2026 — Library: show/restore hidden files

"Hide from library" (right-click) had no way back — a hidden file stayed excluded forever, with no unhide affordance anywhere in the UI.

Added a toggle button next to "New folder" in the Library panel (`ChevronsDownUp` icon — lucide-react has no `ListChevronsDownUp` in any published version, this was the closest real icon) that reveals hidden files back into the list instead of hard-excluding them. Revealed files render in a dedicated dim-amber shade (new `--text-amber-dimmest` token, ~40% amber — not a generic opacity fade, so they still read as "library color," not disabled) so they're visually distinct from normal files while shown. Right-click on a revealed file now offers "Unhide" in place of "Hide from library". Toggle state persists across restarts via `orfeo-prefs.json`, same mechanism as favourites/hidden-list itself. `All`/`★` filter tabs tightened slightly (padding/font-size) to make room for the third toolbar button.

**New:** `store.unhideLibraryFile`, `store.showHiddenLibraryFiles`/`setShowHiddenLibraryFiles` (`src/store/index.ts`), `--text-amber-dimmest` (`src/index.css`). **Changed:** `src/components/SettingsPanel/SettingsPanel.tsx` (toolbar button, list filtering, row dimming, context menu).

---

## [1.4.1-pre] — 8. 8. 2026 — Piano/keys track color consistency, Playback Editor color bugs, split/merge UI polish

Piano and keys tracks were rendering a different, arbitrary color every load — root-caused to two disconnected color sources and a per-load-order assignment with no instrument awareness. Fixed alongside two related Playback Editor color bugs found during investigation, plus two small split/merge UI fixes.

### Piano/keys tracks: deterministic color on every load
`src/utils/midiParser.ts` had its own bespoke 12-color array, separate from the 10-color `TRACK_COLOR_PALETTE` shown in the Playback Editor's color picker (`src/utils/colors.ts`) — and assigned colors by raw note-track encounter order, with no idea which tracks were piano vs. anything else. Whichever color landed on a given file's piano track was pure chance based on how many other tracks preceded it. Unified onto one palette and made piano-family tracks (`KEYBOARD_GROUPS`: piano/chromatic/organ) deterministic: 1st piano/keys track always gets the same blue as the Left Hand split color, 2nd always gets the same pink as Right Hand, 3rd+ gets Orfeo amber. Non-piano tracks keep round-robining the rest of the palette. Purely a default-assignment change at parse time — no file writes, no versioning. TrackPanel, Piano Roll, and Keyboard already shared one `store.tracks[i].color`, so once the assigned value is consistent, all three render it consistently.

### Bugfix — Cancel in Playback Editor kept a picked color
Picking a color swatch wrote straight into the live global store immediately (so Track Panel/Keyboard could preview it live) instead of staying staged like every other edit in the editor. Clicking Cancel (or the × close button) discarded the editor's local staged state but never reverted that already-committed store write — the new color stuck around even though nothing was saved. Added an open-time color/colorSource snapshot and a `handleCancel` that reverts any track whose color drifted from it before closing.

### Bugfix — Piano Roll ignored a saved custom track color
Piano Roll had its own inline reimplementation of hand-aware note coloring instead of using the shared `resolveHandAwareColor()` (`utils/handColors.ts`) that Keyboard correctly calls — and its fallback branch was hardcoded to the LH hand color instead of the track's own color. Since `editor:save` hand-tags every keyboard-group track on every save (not just explicit splits), this meant Piano Roll could never show a custom-picked color for any piano track again after a single save — only Track Panel and Keyboard reflected the change. Fixed the fallback to use the track's real color, matching Keyboard's behavior.

### Playback Editor — split/merge UI polish
Split preview's small Cancel button (next to the hand-split stats) renamed to "Don't split" for clarity against the footer's own Cancel, and now ambers on hover like the rest of the editor's secondary actions. Merge-selected row highlight was a dark mustard/olive tint (`#1a1a08`) that read as an error state — changed to the same blue family as the Unmerge button/badge (`--unmerge-bg`); the merge-toggle icon itself now also tints to that blue on hover.

**Changed:** `src/utils/colors.ts`, `src/utils/midiParser.ts`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/PianoRoll/PianoRoll.tsx`, `src/index.css`.

---

## [1.4.0-pre] — 8. 8. 2026 — Mixer Console: save per-channel settings to file

Console Mixer channel strips (volume, pan, reverb, chorus) were previously session-only — re-seeded from the file's CC data on every load, discarded on close. Brainstormed and built end to end: values now persist to disk on request.

Volume/pan/chorus/reverb moved from `ChannelStrip`'s local `useState` into the store (`TrackState.chorus`/`.reverb` joined the existing `.volume`/`.pan`), with a `mixerBaseline` snapshot captured on file load. Closing the mixer (Escape or the × button) diffs live values against that baseline; if any channel changed, a Save/Discard/Cancel dialog appears. **Save** writes a new `_ORFEO_vN.mid` (same versioning `editor:save` uses — never overwrites) via a new `mixer:save` IPC handler, which flattens each channel's CC7/CC10/CC91/CC93 to a single static value at time 0 (the mixer UI only ever represented one static value, so any pre-existing automation on those controllers is replaced, not preserved) and logs one entry to the file's Orfeo History. The app then reloads onto the new version. **Discard** closes without writing; **Cancel** leaves the mixer open. Master strip and everything else on the channel strip (mute/solo/etc.) stay session-only — out of scope.

**New:** `mixer:save` IPC (`electron/main.ts`, `electron/preload.ts`, `src/types/index.ts`). **Changed:** `src/store/index.ts` (`mixerBaseline`, `TrackState.chorus`/`.reverb`), `src/components/Mixer/ChannelStrip.tsx`, `src/components/Mixer/MixerConsole.tsx`.

---

## [1.3.0-pre] — 7. 8. 2026 — File info popup (metadata, change log, version chain)

New right-click "File info" popup for any library file — brainstormed then built in four phases, plus a real bug fix uncovered during testing that affected file organization generally, not just this feature.

### File info popup
Read-only-by-default metadata table — Artist, Song (parsed from the `Artist - Song.mid` filename convention), Key, BPM, Time signature, Tracks, Copyright (newly extracted; `@tonejs/midi`'s `Header` silently drops copyright meta events, so it's read via the lower-level `midi-file` parser directly, added as an explicit dependency). Missing fields show a dimmed "—". Works on any file, not just the one currently loaded — reads it fresh over IPC.

Artist/Song are editable: double-click to rename, same interaction as track renaming in the Playback Editor (amber-on-hover label, pencil cursor, "Double-click to rename" tooltip, `bg-row`/amber-border input on activation). Edits stage locally; nothing touches disk until **Save changes**, which fires one real file rename. A swap icon swaps the two staged values, not an immediate rename. "Show in folder" (outline style, same size as Save) sits beside it.

**Orfeo History** — a change log local to the app (not written into the .mid file): every Playback Editor save now records a terse summary against the saved file's path ("merged 2 tracks into 1, changed color of 1 track, changed roll visibility of 1 track"), and renames/moves log themselves automatically. Persisted in a sidecar JSON (`userData/orfeo-file-log.json`, keyed by path) with remap hooks in every rename/move IPC handler so entries follow the file instead of orphaning. Fixed-height (~2 entries), scrolls instead of growing the popup.

Version dropdown next to the filename — appears when siblings exist (`Original`, `v1`, `v2`, ...), derived by scanning for files sharing the stripped base name (no separate storage). Hover a version for its saved date/time. Navigates the popup only, never loads the file into the app; no delete.

Popup itself: draggable (same pattern as the Playback Editor's modals), filename marquee-scrolls on hover if it overflows, `en-GB` locale pinned for all timestamps (a system locale otherwise renders "Aug" as e.g. "avg.").

**New:** `src/components/FileInfoModal.tsx`, `src/utils/midiMetadata.ts`, `fs:renameLibraryFile` / `fileinfo:getLog` / `fileinfo:logEvent` / `fileinfo:listVersions` IPC (`electron/main.ts`, `electron/preload.ts`, `src/types/index.ts`). **Changed:** `src/components/SettingsPanel/SettingsPanel.tsx` (new context-menu item), `src/components/MidiEditor/MidiEditor.tsx` (save-summary logging).

### Bug fix — file organize actions blocked for every saved version
`isProtectedFolderName` (guards the reserved `Demo`/`Orfeo` library folders from rename/delete) was also being used to gate file-level rename and move — but `Orfeo` isn't one well-known folder: every saved version lands in a folder literally named `Orfeo` next to its source file. That made the check true for nearly every file a user might want to rename or move, not just the two reserved top-level folders. Split into two checks: folder-level operations (renaming/deleting the reserved folders themselves) still block both `Demo` and `Orfeo`; file-level operations (rename, move) now only block `Demo` (genuinely read-only bundled content). Fixed in both `electron/main.ts` and the equivalent renderer-side guard in `SettingsPanel.tsx`, which had the same bug independently.

**Changed:** `electron/main.ts`, `src/components/SettingsPanel/SettingsPanel.tsx`.

---

## [1.2.0-pre] — 7. 8. 2026 — MIDI Playback Editor save-pipeline rework, Library sticky/pinned browsing

Driven by live bug reports and iterative UI feedback across the session — the Playback Editor's split/save flow had a real data-loss bug (every split silently discarded whatever else was staged in the same session), and the Library sidebar needed real design work to stay usable at 500+ files.

### Playback Editor — split and save unified into one disk write
Previously "Split into two tracks" wrote its own file and reloaded the whole editor immediately — which wiped every other staged edit in progress (include/exclude, merges, colors, renames) because the reload rebuilt the row list from scratch. Split is now a purely local staging operation (no IPC, no disk write); the actual note-splitting happens once, inside Save & Reload's single write. A session's edits — however many — now always produce exactly one `_ORFEO_vN`, never two-plus.

Undo moved to where it belongs: "Undo split" now sits with the split-staging banner (reverts the staged split locally, before anything is written), not after a successful save. Once Save & Reload actually commits, the footer collapses to a single **OK** button — Cancel/Save & Reload disappear, so a second click can no longer mint v2, v3, etc. in the same modal session. A failed save leaves Cancel/Save & Reload in place to retry.

Fixed two related bugs surfaced by this rework: staged split output was inheriting the source track's color for both halves (both looked identical) — now uses the fixed LH/RH hex tokens (`#6270A5`/`#CB636C`, matching the piano roll). Split output was also named "Acoustic Grand Piano LH/RH" instead of "Piano LH/RH" when the source track had no real name — restored the "Piano" fallback.

**Changed:** `electron/main.ts` (`editor:save` now handles split+merge+color+name+instrument in one write; standalone `editor:split` handler removed), `electron/preload.ts`, `src/types/index.ts`, `src/components/MidiEditor/MidiEditor.tsx`.

### Playback Editor — persisted Roll/Keyboard columns
Two new columns (Piano roll visibility, Keyboard-lit) let a save persist what the TrackPanel's matching icons only ever did for the current session. Written as `ORFEO_TRACK_VISIBLE`/`ORFEO_TRACK_KEYBOARD` text meta-events on save (same convention as track name/color), restored as defaults on reimport.

**Changed:** `src/utils/midiParser.ts`, `src/store/index.ts`, `electron/main.ts`, `src/components/MidiEditor/MidiEditor.tsx`.

### Playback Editor — layout pass
Columns reordered (Include, Track, Merge, Split, Color, Piano roll, Keyboard, Assign Instrument) with every header carrying a tooltip. Fixed a real column-misalignment bug (not a styling nit): the header row's `gap` didn't match the track rows' `gap`, and the scrollable track list's own scrollbar was shrinking its `1fr` Track column relative to the (non-scrollable) header's — both together shifted every column after Track by a growing, track-count-dependent amount. Synced the gaps and reserved a stable scrollbar gutter on both sides. Select all/Clear all restyled with a bordered, amber-hover pill; footer rows consolidated (info text + action buttons share one row instead of two, buttons sized to content instead of stretching half-width); post-save footer shows the real saved path with a "Show in folder" button instead of a duplicate green banner. Instrument picker family headers and instrument rows now both get an amber hover (previously only instruments did, and in gray).

**Changed:** `src/components/MidiEditor/MidiEditor.tsx`.

### Library — pinned active file, collapsible Folders section
The loaded file now gets its own always-visible bar pinned above the list — CSS `position: sticky` alone can't pull a row out of a collapsed folder or up from its alphabetical position, so this is a real pin, not a scroll trick. It still renders at its normal spot in its folder too, so a folder's contents never look incomplete just because one of them is loaded.

All folders now collapse under one "Folders" row (amber chevron) instead of each needing its own; individual folder headers lost their per-folder chevron (clicking the header still expands/collapses it). Right-click menu gained "Show in folder" (Explorer, file pre-selected via `shell.showItemInFolder`) and a multi-select fix: "New folder from selection"/"Move to folder" were hidden if *any* selected file was in a protected folder (Demo/Orfeo) — now only hidden if *all* of them are, since the move backend already skips protected files individually.

**New:** `shell:showItemInFolder` IPC (`electron/main.ts`, `electron/preload.ts`, `src/types/index.ts`). **Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

---

## [1.1.0-pre] — 6. 8. 2026 — Left/Right Hand rework: algorithm overhaul, workflow fixes, external-review-driven improvements

A full rework of the hand-assignment engine driven by real bar-by-bar testing feedback plus three independent external code reviews (Codex, DeepSeek, and a rejected Gemini pass — see `docs/LR Hand rework/review.md` and `Reviews/`, gitignored). Root-caused and fixed several real bugs along the way, not just algorithm tuning — including two workflow regressions introduced and then fixed within this same session. Full technical writeup and testing guide in `docs/LR Hand rework/SESSION_HANDOFF.md` (gitignored, local).

### Hand-assignment engine — four real algorithm bugs found and fixed
1. **Register-identity tie-break bug**: the very first note's L/R label was an arbitrary coin-flip with nothing tying "L" to physically-lower pitch, which could invert a whole piece's hand coloring from note one. Fixed by seeding each hand's never-played fallback anchor from its own register half (low/high) instead of one shared piece-wide mean.
2. **Anchor-decay**: a hand's last-known position stayed a full-strength attractor forever, even after many seconds of silence — a new passage starting near that stale position got wrongly pulled toward it. Fixed with `ANCHOR_DECAY_WINDOW_SEC`, decaying a silent hand's carried position toward the register fallback.
3. **Movement cost rebuilt from a centroid to a reach range**: replaced "mean pitch of everything a hand is currently playing" with each hand's actual `[lo, hi]` span, decaying toward the fallback the longer it's been silent. A follow-up note landing anywhere inside a hand's recent reach now costs nothing, instead of the old mean-pitch model overstating distance to either edge of a wide chord. Exposed and fixed a second bug in the process: `identityInversionCost` was comparing **undecayed** raw positions, letting a many-seconds-stale position outrank the other hand's genuinely fresh, correct one — this was the actual root cause of a comping-figure passage flip-flopping on nearly every note.
4. **Harmonic prior via `tonal.js`**: a short run of notes that collectively spell a recognizable chord (tonal's `Chord.detect()`) now resists being split across hands mid-gesture — scoped to a 0.6s window, soft bias only, never overrides span/finger feasibility.

**New:** `noteRange()`, `decayedRange()`, `rangeGap()`, `detectHarmonicLinks()`, `cleanupIsolatedFlips()` (all `src/utils/handAssignment.ts`). **Changed:** `src/utils/handAssignment.ts` (`HAND_ENGINE_VERSION` 3→7 across these + workflow fixes below).

### Post-DP cleanup pass — confidence-gated, not blind
Isolated single-cluster hand flips (a cluster's hand disagreeing with both neighbors, which agree with each other) now get smoothed to match neighbors — but *only* when the DP's own confidence at that cluster was already low. Verified against real data before shipping: a sparse single-note bass ostinato surrounded by continuous treble activity produces the exact same "isolated" shape but scores confidently (0.6–0.8+); the genuine near-tie mistakes this targets score low (<0.5). Confidence-gating, not "isolated alone," is what makes this safe — an earlier, ungated approach (scaling switch-cost by run length) was built, found to break the ostinato pattern, and reverted within the same session rather than shipped.

**Changed:** `src/utils/handAssignment.ts`.

### Confidence-flag consistency fix
The split-preview panel showed real confidence flags on a freshly-loaded file but silently showed zero flags on that *same* file reopened after one save — not flaky, a genuine bug: hint-restored notes hardcoded `handConfidence = 1` regardless of what the engine actually computed. Now uses a `RESTORED_CONFIDENCE` sentinel so the UI can honestly say "confidence not re-evaluated" instead of fabricating certainty. Added a permanent disclaimer ("automated — a guideline, not a verified transcription") to both the split-preview panel and the Settings Left/Right Hand description, independent of whether anything happens to be flagged this session.

**New:** `hasKnownConfidence()`, `confidenceUnknown` stat (`src/utils/handPreview.ts`). **Changed:** `src/utils/handMetadata.ts`, `src/utils/handPreview.ts`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`.

### Two workflow regressions — introduced and fixed within this session
A dirty-flag gate on the MidiEditor's Save button (meant to skip a redundant re-save immediately after a split with zero further changes) had a real failure mode: once dirty reset to false after any reload, the button silently became an inert Close — no IPC call, no file write, "saving" appeared to just stop working. Fully reverted; Save always performs a real save now, accepting the occasional harmless duplicate version rather than risk another silent no-op.

**Changed:** `src/components/MidiEditor/MidiEditor.tsx`.

### Split-output track renaming — actually reaches the UI now
"Split into two tracks" renamed the underlying MIDI track-name field correctly, but the UI's displayed track name is a separate field (`trackName` in the store) that only reads an `ORFEO_TRACK_NAME` hint — never the plain track-name field — so the rename was invisible in the app. Split now injects that hint for both output tracks. Also handles the common real-world case of a blank source track name (falls back to "Piano" so output reads "Piano LH"/"Piano RH" instead of a bare " LH"/" RH").

**Changed:** `electron/main.ts`, `src/utils/handMetadata.ts`.

### Hand-assignment configuration — user-facing controls
New Settings sub-section ("Playback & Practice," inside Left/Right Hand, before Mode): independent RH/LH max-fingers controls (4 or 5 each), feeding a hard cap on how many notes of a wide chord one hand can take, with an even-split fallback beyond combined capacity. Threaded through every call site: `midiParser.ts` auto-tag, `editor:split`/`editor:save` IPC payloads, `MidiEditor.tsx`.

**New:** `rhMaxFingers`/`lhMaxFingers` store state + persistence (`src/store/index.ts`). **Changed:** `src/utils/handAssignment.ts`, `src/utils/midiParser.ts`, `electron/main.ts`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`.

### Hand color system — one consistent set of colors, everywhere
Fixed LH (`#6270A5`) / RH (`#CB636C`) tokens now used uniformly across the piano roll, both audio engines' keyboard key-lighting, and the split-preview timeline — replacing an ad-hoc mix of a blue/amber pair and whatever a track's palette color happened to be. Split-mode tracks (homogeneous hand per track) always show the fixed colors; a single mixed-hand track only does in Left/Right Hand mode, otherwise stays blue. Removed the redundant amber keyboard-strip marking on RH notes now that key glow itself carries the signal — kept only for live hardware MIDI input, which has no other visual channel.

**New:** `src/utils/handColors.ts`. **Changed:** `src/index.css`, `src/components/PianoRoll/PianoRoll.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/hooks/useAudioEngine.ts`, `src/hooks/useSamplesEngine.ts`.

### Chord/Scale Explorer modal — grows upward, not downward
When a pattern-loaded row appears (e.g. after loading a chord pattern), the modal previously grew downward from a fixed top position, drifting away from its deliberate anchor point. New `useAnchorBottomOnResize` hook (ResizeObserver-based) keeps the bottom edge fixed and grows/shrinks from there instead.

**New:** `src/hooks/useAnchorBottomOnResize.ts`. **Changed:** `src/components/ChordExplorer.tsx`, `src/components/ScaleExplorer.tsx`.

### Process safety nets
Version-bump automation (`npm run check:hand-engine`, wired into `dev`/`build`/`dist`) hashes `handAssignment.ts` and fails loudly if it changed without a matching `HAND_ENGINE_VERSION` bump in `handMetadata.ts` — catches the exact mistake made twice earlier in this same session, where a real algorithm fix had zero visible effect until the version bump landed separately. Fast-path re-validation: a file that looks like a clean already-split 2-track export now gets cross-checked against a real full DP run before being trusted outright, catching a file whose actual content doesn't match the current engine (e.g. split by an older, buggier version) — calibrated against measured data, not a guess (a genuinely well-split file only agrees ~79% with an independent full re-run, since track membership and a coarse whole-track-average re-derivation are different sources of truth by design).

**New:** `scripts/check-hand-engine-version.mjs`, `src/utils/handAssignment.hash.json`. **Changed:** `package.json`, `src/utils/handAssignment.ts`.

---

## [1.0.0-pre] — 6. 8. 2026 — Final polish for public release: TopBar/Settings restyle, bugfixes, Scales & Chords Explorer overhaul

A full pass across the app driven by a comprehensive pre-release review, done in four phases (styling/layout, bugfixes, Scales Explorer, Chords Explorer) plus an extended round of live pixel-level feedback on both explorers. Tagged as the first public pre-release.

### TopBar restyle
BPM/Key chevrons render amber whenever a file is loaded (was hover-only, with a color-swap-on-hover bug). Volume relocated from the left section to the right, icon-only (no label), vertically centered against the left-section items. Separator heights unified to the right side's value. Transport controls are now absolutely centered on the TopBar's true midpoint, independent of left/right content width.

**Changed:** `src/components/Transport/TopBar.tsx`, `src/components/VolumeKnob.tsx`.

### Settings panel restyle
Transcript icon blinks on the currently-loaded file's row when chord transcription is on. Chord Prompter's description has the actual bracket-corner icon inlined mid-sentence. Sound Fonts and Effect Pattern native `<select>`s — unstylable Windows-native popups — replaced with a custom `SettingsDropdown` popover. Disabled `<Sparkles />` "Coming soon — practice mode" icon added to the TrackPanel rail.

**New:** `SettingsDropdown` component (`SettingsPanel.tsx`). **Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/TrackPanel/TrackPanel.tsx`.

### Console icon redraw
ChannelStrip/MasterStrip mini-piano icon redrawn with 3 black keys (was 4), scaled down to match the M/S/Eye icons beside it.

**Changed:** `src/components/Mixer/ChannelStrip.tsx`, `src/components/Mixer/MasterStrip.tsx`.

### Foreign-format import — real root-cause fix
Found a third, previously unaudited load path: `useMidiFile.ts`'s `openFile()` (Ctrl+O / the Open button) whose file-picker filter allows `.mxl`/`.gp*` but skipped foreign-format conversion entirely. All three load paths (Open dialog, drag-drop, library click) now funnel through one shared `resolveAndTrackImport()`, which also fixes the save prompt firing on the *next* file switch instead of immediately on load. Deleted a dead, broken `loadLibraryFile` store action that duplicated this without any foreign-format handling.

**New:** `resolveAndTrackImport()` (`src/utils/foreignFormatImport.ts`). **Changed:** `src/App.tsx`, `src/hooks/useMidiFile.ts`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/store/index.ts`.

### Library refresh blink + unsaved-changes guard
New `libraryNeedsRefresh` store flag blinks the Library refresh icon after any resave (foreign-import save, MidiEditor save, Note Editor save), clears on click. Extracted a shared `confirmDiscardDirtyNoteEdits()` and wired it into every place that changes/discards the loaded file — TopBar logo reset, drag-drop load, Ctrl+O/Open dialog, and library click (previously only library click had this guard).

**New:** `confirmDiscardDirtyNoteEdits()` (`src/utils/noteEditorState.ts`). **Changed:** `src/store/index.ts`, `src/components/Transport/TopBar.tsx`, `src/App.tsx`, `src/hooks/useMidiFile.ts`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`.

### Track drag-reorder fix
`App.tsx`'s file-import overlay now gates on `e.dataTransfer.types.includes('Files')`, so an internal track-row drag never triggers the app-wide amber import highlight. `dropEffect = 'move'` set in the row's dragover handler (was showing the OS no-drop cursor). Reordering now reflows live during dragover instead of only committing on drop.

**Changed:** `src/App.tsx`, `src/components/TrackPanel/TrackPanel.tsx`.

### Glissando and rapid chord/inversion highlight lag — two real bugs
Glissando's keyboard light was timer-based (ring-and-fade), so a fast mouse sweep still overlapped several keys' fade windows — replaced with an instant single-key swap tied directly to mouse position, no timer at all (`lightGlissandoKey`/`clearGlissandoKey` in `Keyboard.tsx`). Separately — and worse — every chord/inversion click in both Explorers and the Locked Chord modal already had a correct instant-replace highlight (`setExplorerKeys`/`setLockedKeys`) but *also* independently lit the same notes via the old timer-based path, so rapid clicks stacked up several still-decaying highlights (600–1200ms each) on top of the current chord. `playNote()` gained a 5th `visual` param (default `true`); all ~10 explorer/locked-chord call sites now pass `visual: false` since their own state already drives the highlight.

**Changed:** `src/hooks/useAudioEngine.ts`, `src/hooks/useSamplesEngine.ts`, `src/components/Keyboard/Keyboard.tsx`, `src/components/ChordExplorer.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/LockedChordModal.tsx`.

### Scale Explorer — full restyle
Minimize button removed (X only). Circle of Fifths + note-names row moved to the right side (50px from the modal's right border), note-names row centered under the CoF and pushed down between it and the chord tiles, with a trailing octave-root repeat and sequential amber highlight during scale playback. Modal opens pre-selected to C major so it's at full height immediately instead of an empty placeholder state. "Chords in the Scale" row: bigger label, dimmed instruction text, new auto-play-sequence button. Progression speed control rebuilt with genuine open-chevron icons (was a closed teardrop path that read as solid triangles at small size). "KEY OF [root]" reordered with a fixed-width root slot. Spacebar plays/pauses the progression. Progression selector restyled to a compact "None ▾" dropdown trigger. Fixed: chord-tile/inversion clicks now use uniform highlighting (the amber-root/blue-rest split is reserved for actual progression playback); the octave tile no longer keeps a stale highlight after a progression starts stepping through other tiles.

**Changed:** `src/components/ScaleExplorer.tsx`, `src/components/SpeedControl.tsx`.

### Chords Explorer — full restyle, built on Scales Explorer's results
Minimize button removed. Modal width matched exactly to Scale Explorer (720px). Filter row: tooltips added throughout. Progressions row regrouped: Progressions/Style/Inversions together on the left, playback controls (chevron play icon + chevron speed control, matching Scale Explorer) in the right corner. Genre voicing row rebuilt as a CSS Grid row (three equal `minmax(0,1fr)` columns — not flex, and not `1fr auto 1fr`, which lets unequal-content side columns drag an `auto`-sized center off true center) showing, left to right: roman-numeral progression display, a SEQUENCE/NOTES legend, and the currently-sounding chord's notes in real order. Chord-tile playback indicator moved from a third row inside the tile to a corner overlay, sized up, no tile resize. Footer restyled to match Scale Explorer's exact icon/font treatment.

**Changed:** `src/components/ChordExplorer.tsx`.

### Docs & versioning
New `docs/INSTALLATION.md` — full vs. portable build comparison for end users, linked from the README. `docs/ROADMAP.md` created (gitignored) noting Console CC persistence as deferred, non-trivial future scope. Tagged `v1.0.0-pre` as the first public pre-release.

---

## [0.19.1] — 3. 8. 2026 — Design-audit follow-up: Settings overhaul, save versioning, modal positioning, auto-update, note-editor velocity lane

### Icon swap + pen cursor in note editing
The Playback Editor open button (TrackPanel) uses a pencil-sparkles icon (inlined — not present in the installed lucide-react version). Piano Roll canvas now shows the same pen cursor as the Playback Editor's track-rename field while in note-edit mode and idle over empty space (previously `crosshair`). *Superseded below*: the note-edit-mode toggle itself has since moved from TopBar into the Tracks panel, with its own custom icon — see "Note-edit toggle moved to Tracks panel".

**Changed:** `src/components/Transport/TopBar.tsx`, `src/components/TrackPanel/TrackPanel.tsx`, `src/components/PianoRoll/PianoRoll.tsx`.

---

### Settings overhaul, save versioning, modal positioning

A single long session working directly on `dev` (no worktree/PR — by request), driven by a self-audit the user did of the Settings drawer and general app UX. Grouped by theme; commits `179205b..3507f93`.

### Settings panel — global consistency sweep
All `OptionRow` labels now render uppercase; eye/EyeOff feature toggles replaced everywhere with a `ToggleLeft`/`ToggleRight` icon pair (amber when on, dim when off) matching the pattern already used by Effect Scope & Color; every green "success"-tinted control (`OptionBtn`'s active state, the soundfont/Effect-Pattern dropdowns) recolored to the amber accent tokens — green is now reserved for track colors/Console only. Description/hint text uses a darker `--text-faint` color (was `--text-dimmest`) to read as visually subordinate to the (now uppercase) row labels above it, font kept as Inter after a brief detour through JetBrains Mono.

**New:** `labelSmall` and `hintCenter` props on `OptionRow` (`SettingsPanel.tsx`) for subgroup-style rows (smaller, muted) and centered hint text.
**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

### Settings panel — per-section rework
- **Notation**: section icon swapped `Type` → `Music2`; description text added under "Display system".
- **Accidentals**: flat/sharp buttons replaced with a borderless "♭ Flats / toggle / Sharps ♯" layout, labels 20px off the toggle icon and centered as a unit; the ♭/♯ glyphs themselves render 50% larger than the label text; hint text dropped its redundant "e.g." prefix and centers under the row.
- **Keyboard**: "Labels" (containing Show octaves/Show note names) promoted to full row-label weight since it's a real subgroup heading, not a thin divider; the two rows under it use `labelSmall` instead. Left/Right Hand section (plus its Mode/sensitivity sub-controls) moved out of Keyboard into Playback & Practice, below Loop region. New **Close panels on playback** toggle: auto-hides the Tracks *and* Settings/Library panels while playing, restores whichever were actually open on pause/stop/new-file-load (`autoCollapseDrawers` in the store, debounced 150ms against the brief real playbackState blips seek operations cause — see below).
- **Piano Roll**: loupe+ icon → `Columns3`; description added under "Bar numbers & grid lines"; the "Visual Effects" subsection (Effect Scope & Color / Effect Pattern / Intensity / Spread / Threshold) uses `labelSmall` throughout; the three bloom sliders got a custom `.orfeo-slider-amber` CSS class (transparent-amber fill over a gray track via WebKit track/thumb pseudo-elements) replacing `accentColor`, which couldn't give the fill its own opacity independent of the solid thumb, and dropped the stray default track border.
- **Appearance**: Warm theme button dimmed/disabled, relabeled "Coming soon"; "Background" label renamed to "Theme"; About icon replaced with the real `OrfeoMark` SVG logo (clickable → opens the GitHub repo); **version string is now injected at build time from `package.json`** via Vite's `define` (`electron.vite.config.ts` → `__APP_VERSION__`, declared in `src/jzz.d.ts`) instead of being hand-typed and drifting; footer reads "by SquareBow" (no link, styled identically to the version line — same font/color/size, including the preceding dot); the northeast-arrow icon detached from the User Manual button into its own `CloudDownload` button ("Check for updates" tooltip, opens the GitHub releases page — full auto-update-checking wasn't built, just the manual fallback); User Manual label switched to JetBrains Mono to match.

**New:** `src/components/NoteEditorIcon.tsx`. **Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`, `src/store/index.ts`, `electron.vite.config.ts`, `src/jzz.d.ts`.

### Note-edit toggle moved to Tracks panel
The enter/exit-note-edit-mode control moved out of TopBar into TrackPanel, under the MIDI Playback Editor icon (both collapsed and expanded drawer states) — same enable/visibility gating as before (only shown when the Note Editor setting is on and a file is loaded). Icon swapped from lucide `SquarePen` to a custom stylized piano-roll icon (`src/components/NoteEditorIcon.tsx`, ported from a user-supplied `public/midi-editor.svg` with `currentColor` so it themes like every other icon), later bumped 18→22 / 16→20 since the thinner custom glyph read visually smaller than its lucide neighbors at the same numeric size. Track rows now also show their note count in the channel/program line (`<n> notes`).

**Changed:** `src/components/TrackPanel/TrackPanel.tsx`, `src/components/Transport/TopBar.tsx`.

### `_ORFEO_vN` save-versioning unification
Three editing tools each hand-rolled their own save-suffix logic and disagreed: MidiEditor's merge/instrument-reassign save always overwrote the same `_ORFEO`/`_ORFEO_MERGED` file (no versioning at all), split always overwrote `_ORFEO_SPLIT`, and only the note editor incremented at all — using uppercase `_ORFEO_V2` and skipping straight past a `_v1`. Unified into `src/utils/orfeoVersioning.ts`, shared by `electron/main.ts` (`editor:save` and `editor:split`) and `NoteEditorToolbar.tsx`: every edit now produces the next `_ORFEO_v{N}`; legacy suffixes (`_ORFEO`, `_ORFEO_MERGED`, `_ORFEO_SPLIT`, `_ORFEO_V2`, `_ORFEO_IMPORTED`) are recognized and stripped so re-saving an old-scheme file starts a clean v1 instead of stacking. Also added `confirmPendingImportBeforeEdit` (`src/utils/foreignFormatImport.ts`) — opening the MIDI Playback Editor or Note Editor on a foreign-format file (MusicXML/Guitar Pro) still only in memory now prompts to save it as a real `.mid` first.

**New:** `src/utils/orfeoVersioning.ts`. **Changed:** `electron/main.ts`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/utils/foreignFormatImport.ts`.

### Modal/popup default-position overhaul
Every floating modal used to default-position against the whole window, independent of the layout around it. New shared anchors (`src/utils/modalAnchors.ts`), read from the DOM once at open time via `data-piano-roll-area` (`App.tsx`) and `data-keyboard-header` (`Keyboard.tsx`'s chord/scale bar): ChordExplorer, ScaleExplorer, MixerConsole, and LockedChordModal bottom-align to the keyboard header and horizontally center on the piano roll; FloatingKeyboard bottom-aligns to the fixed-ratio playbar line (doesn't move when the playbar is hidden) and horizontally centers on the piano roll; MidiEditor centers on the whole screen with a fixed 220px top offset (simplified after the piano-roll-relative version kept landing partially off-screen); NoteEditorToolbar horizontally centers on the piano roll and always recomputes on open rather than persisting a dragged position across app restarts (it used to, which meant any test-drag got permanently "stuck" and reappeared in what looked like a random spot on the next launch), and is re-clamped into the viewport on mount/resize so a position saved at a larger window size can't render half off-screen after the window shrinks. Undocking the keyboard is now blocked (dimmed, explanatory tooltip) while any of those bottom-anchored modals except LockedChordModal is open — they share the same anchor, floating the keyboard out from under them would look broken; re-docking is always allowed. ConfirmDialog is now screen-centered *and* has the amber `orfeo-modal-glow` it was missing (as does LockedChordModal, which had its own bespoke, dimmer glow implementation that never actually matched the others — now uses the shared class, and the two now-dead `--accent-amber-glow-outer/inner` tokens that fed it were removed).

**New:** `src/utils/modalAnchors.ts`. **Changed:** `src/App.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/Keyboard/FloatingKeyboard.tsx`, `src/components/Keyboard/KeyboardControls.tsx`, `src/components/ChordExplorer.tsx`, `src/components/ScaleExplorer.tsx`, `src/components/Mixer/MixerConsole.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/LockedChordModal.tsx`, `src/components/ConfirmDialog.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/index.css`.

### Playback: skip-while-playing actually seeks now
`seekAndPlay()` (TopBar's ±5s skip buttons, and scrub-release while playing) set `playbackState` straight to `'playing'` even when it was already `'playing'` — a no-op transition. `useAudioEngine` only rebuilds/repositions the real player on an actual transition *into* `'playing'`, so the store's `currentTime` jumped visually but the real player kept going from its old position, silently undoing the skip. Now forces the same brief `playing→paused→playing` blip that PianoRoll's wheel-scrub handler already relied on internally (the only reason wheel-scrub-while-playing worked at all) — both are "the same playback function" now, as intended. That blip legitimately toggles `playbackState` away from `'playing'` for ~20ms, which the new auto-collapse-drawers feature (above) treated as a real pause and briefly re-opened the panels for; its restore now debounces 150ms and bails if playback is already back to `'playing'` by then.

**Changed:** `src/hooks/usePlayback.ts`, `src/store/index.ts`.

### Note editor: solo-for-edit auto-seeks to the track's first note
Soloing a track for note editing now seeks playback to 2s before that track's first note. Previously, soloing a track whose notes started much later than the current playhead (or sat in a pitch range not currently visible) showed an apparently-empty piano roll until playback caught up on its own.

**Changed:** `src/store/index.ts` (`soloTrackForEdit`).

### MAJOR: Piano Roll bar-number grid lines were drawing over falling notes
The horizontal bar-line was drawn on the 2D overlay canvas, which sits above the entire Pixi canvas — so it always rendered on top of falling notes, making them look split by a dark line. Moved to a dedicated Pixi `Graphics` layer inserted behind the notes layer; the number pills stay on the overlay.

**Changed:** `src/components/PianoRoll/PianoRoll.tsx`.

### Library: single-click selection no longer shows the multi-select styling
Single-click file selection now only highlights the icon and filename in amber. The bordered/background-tinted cell treatment is reserved for actual multi-select (2+ files, the drag/create-folder gesture) — previously applied to every selected row regardless of count.

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

### Dev-session fix: HMR-safe store subscriptions
`store/index.ts`'s module-scope `useStore.subscribe()` calls now dispose on hot-reload (`import.meta.hot.dispose`). Repeated edits to this file during a dev session were leaving old subscriber closures alive alongside new ones — each with its own stale tracking state, fighting each other and visibly flickering the Tracks/Settings panels during playback. Not a `dev`-branch runtime bug (only affects an active `npm run dev` session across many edits), but worth knowing about if panel state ever looks haunted mid-session — restart clears it regardless.

**Changed:** `src/store/index.ts`.

### Playback: skip-while-playing actually seeks now
`seekAndPlay()` (TopBar's ±5s skip buttons, and scrub-release while playing) set `playbackState` straight to `'playing'` even when it was already `'playing'` — a no-op transition, so `useAudioEngine` (which only rebuilds the real player on an actual transition *into* `'playing'`) never picked up the new position: the store's `currentTime` jumped visually but the real player kept going from where it was. Now forces the same brief `playing→paused→playing` blip PianoRoll's wheel-scrub handler already relied on internally (the only reason wheel-scrub-while-playing worked at all) — both are "the same playback function" now. That blip legitimately toggles `playbackState` away from `'playing'` for ~20ms, which the new auto-collapse-drawers feature above treated as a real pause and briefly re-opened the panels for; its restore now debounces 150ms and bails if playback is already back to `'playing'` by then.

**Changed:** `src/hooks/usePlayback.ts`, `src/store/index.ts`.

### Loop region: Alt+drag tooltip
The cursor-following "Alt+drag · set loop region" tooltip was gated on the Loop region *setting*, even though the underlying Alt+drag gesture itself isn't — that setting only toggles the separate strip UI in TopBar, the gesture works regardless. Un-gating it from the setting initially introduced a regression where the tooltip could show with no file loaded and Alt not held; fixed to require both a loaded file and Alt actually held down, otherwise it's a plain pointer with no persistent hint.

**Changed:** `src/components/PianoRoll/PianoRoll.tsx`.

### Auto-update (Windows) + CONTRIBUTING.md
Orfeo can now check GitHub Releases for updates and install them in-app, via `electron-updater` — Windows only, by design. Checks silently 5s after launch (nothing shows unless a real update is found) and on demand via Settings' `CloudDownload` icon, which now reflects live state (checking / downloading with a blinking dot / ready-to-install, amber / error) instead of always just opening the releases page; clicking it re-checks, and shows "Orfeo is up to date" briefly if there's nothing new. macOS/Linux builds are community-contributed and never go through Orfeo's own release pipeline, so pointing the updater at the official feed for them would be wrong regardless of whether the app is packaged — those platforms (and portable Windows builds, and dev) fall back to opening the releases page manually. `CONTRIBUTING.md` was referenced from `README.md` but never existed; added it with build commands per platform and a "Releases & auto-update" section spelling out the policy above — what maintainers do to cut a real Windows release (`GH_TOKEN` + `npm run dist`, why the `latest.yml` manifest matters), and what community macOS/Linux builders should do instead. Caveat: the app isn't code-signed, so the downloaded installer still trips Windows SmartScreen — unrelated to auto-update itself, same warning a manual download already got. Untested end-to-end pending a real tagged release.

**New:** `CONTRIBUTING.md`. **Changed:** `package.json` (`build.publish`, new `electron-updater` dependency), `electron/main.ts`, `electron/preload.ts`, `src/types/index.ts`, `src/components/SettingsPanel/SettingsPanel.tsx`.

### Note editor: velocity lane
New advanced editing technique, opened on demand: while a track is soloed for note editing, a toolbar icon blinks (amber) to indicate it's available; clicking it opens a lane covering the whole piano-roll area below the playhead, showing one thin (5px) bar per note of the soloed track — aligned to the *same* X/pitch position as the falling notes and keyboard below it (one continuous vertical line: keyboard key → note → velocity bar), rather than a horizontal-time-axis lane like a typical DAW. That's a deliberate fit to Orfeo's own vertical-scrolling roll (Y=time, X=pitch) instead of porting Signal/Ableton/Logic's exact layout, which assumes a horizontal-scrolling roll Orfeo doesn't have. Drag a bar vertically to change that note's velocity (0–127 MIDI range, real note-on velocity — persists as actual MIDI data on save, playable in any app/DAW), with a live numeric readout while dragging, undo/redo support, grab/grabbing cursor, and five subtle reference gridlines (0/32/64/96/127) with edge value markers. Scoped to one soloed track at a time — editing velocity across a whole orchestration with many tracks and thousands of notes isn't practically usable any other way. Two upgrades flagged, not built: no independent pan/zoom to browse a soloed track's full note list while paused (bars only reflect the same live time-window the falling view already computes); the lane overlays the bottom of the falling-notes canvas rather than reserving real space for it (shrinking the roll safely touches pervasive height-based math across the file).

**New:** velocity lane rendering + interaction in `src/components/PianoRoll/PianoRoll.tsx` (reuses the already-existing `cmdSetNoteVelocity`/`cmdSetRangeVelocity` command layer, previously unused outside a round-trip test), `velocityPanelOpen` in `src/store/index.ts`. **Changed:** `src/components/NoteEditor/NoteEditorToolbar.tsx` (toggle icon).

---

## [0.19.0] — 1. 8. 2026 — Note Hit Effects: track scope toggle + global color override

### Effect scope — keyboard tracks only, or every track in the file
New "Effect Scope & Color" row in Note Hit Effects (Piano Roll settings). A compact icon toggle (`ToggleLeft`/`ToggleRight`, amber, no button chrome) switches between the existing behavior — effects only for tracks currently shown/lit on the keyboard — and a new "all tracks" mode that spawns effects for every track in the file, even ones not mapped to the keyboard. Purely visual: doesn't change which notes actually sound, and doesn't light keys for tracks that aren't shown on the keyboard, only spawns the particle flourish at their note's key position.

**Changed:** `src/hooks/useAudioEngine.ts` (both `updateMutedChannels` and `buildPlayer` — the track-level `showOnKeyboard` skip now only gates the key-light call, not the whole scheduling loop, so non-keyboard tracks can still queue a hit effect when scope is `'all'`), `src/hooks/useSamplesEngine.ts` (same split in `buildSamplesPlayer`), `src/store/index.ts` (`hitEffectScope`, persisted).

### Effect color override — particles only, independent of track/note color
New color swatch next to the scope toggle overrides the hit-effect particle color for every track at once, leaving the falling-note color and the key glow (separate render paths) untouched — applied at the single point effects are actually spawned in `PianoRoll.tsx`, not at the trigger/queue level, so nothing else in the per-track color pipeline needed to change. Built as a self-contained in-app popover (palette grid + hex input) rather than a native `<input type="color">` — the native OS color dialog was blurring the Electron window and closing the whole Settings drawer out from under it.

**New:** `HitEffectColorSwatch` component (`SettingsPanel.tsx`). **Changed:** `src/components/PianoRoll/PianoRoll.tsx` (color override applied at `hitEffects.spawn()`), `src/store/index.ts` (`hitEffectColor`, persisted), `src/components/SettingsPanel/SettingsPanel.tsx`.

### Effect Pattern dropdown — active-selection styling
Matches the Sound Fonts Library selector introduced in 0.18.0: green border/background/text for the active pattern, instead of the previous neutral dropdown styling.

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

---

## [0.18.0] — 1. 8. 2026 — Audio settings rework: dynamic status, dropdown library, SF2/SF3 import

### Sound engine status — dynamic, no longer hardcoded
The "loaded" status line under Sound engine always printed `GeneralUser-GS.sf2 · 30.8 MB`, regardless of which soundfont was actually active — switching to FluidR3 GM (or any other library) left the status silently wrong. Both the `ready` and `idle` status lines now look up the actually-selected soundfont and print its real name/size; styling unchanged.

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

### Sound Fonts Library — dropdown selector, aligned metadata, dimmed under GM
- Description moved above the list (was rendered below it via `OptionRow`'s trailing hint slot).
- Selection is now a single `<select>` dropdown (green border/background, same "active" look as before) instead of one pill-button per library — several library names didn't fit the old fixed-width buttons. The full catalog, including not-yet-downloaded entries, still renders below as a per-item list (size, bundled/download-with-progress/remove), now column-aligned via CSS grid regardless of name length.
- The whole section dims to 40% opacity and goes inert (`pointer-events: none`) whenever GM Synth is the active engine, since none of it does anything until you switch to Samples — hovering anywhere in the section (including the label) shows "Switch to Samples engine for better audio quality".

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

### Import your own SF2/SF3
New "Import your own .sf2 / .sf3" button (tooltip warns to only import soundfonts you have the rights to use). Native file picker → collision-safe copy into the same `userData/soundfonts/` directory and load path already used by the catalog downloads — imported fonts show up in both the dropdown and the metadata list exactly like a downloaded catalog entry, with a "remove" action. `SoundfontId` widened from a fixed 3-value union to `string` to allow the dynamic `custom:<filename>` ids this needs.

**New:** `soundfont:import` IPC (`electron/main.ts`), `window.electronAPI.importSoundfont` (`electron/preload.ts`). **Changed:** `electron/main.ts` (`soundfont:list/delete/read` now resolve custom ids, with a path-traversal guard), `src/types/index.ts` (`SoundfontId`, `SoundfontInfo.custom`), `src/components/SettingsPanel/SettingsPanel.tsx`.

---

## [0.17.0] — 1. 8. 2026 — Library folder management, sidebar fixes, i18n scaffolding

### Library folder management — create, rename, delete, move, undo
The library sidebar now supports organizing MIDI files into subfolders entirely from within Orfeo, mirrored live on disk under the library root:

- **Create** via the `<Folders/>` icon (filter-tabs row) or right-click a file selection → "New folder from selection" (creates + moves in one step). Both auto-enter inline rename.
- **Move** by dragging a selection onto a folder row (or the library-root drop zone that appears while dragging), or via the right-click "Move to folder ▸" submenu / a folder's "Move N selected files here". Standard Explorer multi-select: click / Ctrl-click / Shift-range.
- **Rename** inline (row label swaps for a text input); **delete** only when empty (blocked + tooltipped otherwise).
- **`Demo` and `Orfeo` are protected**: never renamed/deleted, never a drop target, their files aren't draggable — enforced in both the renderer and the IPC handlers.
- **Per-session undo** (until the app closes, not persisted): an Undo icon appears on any moved file and on any folder that received a move (covers drag-in and "New folder from selection" alike), reversing that specific move. Renaming a folder remaps its undo records to the new name rather than orphaning them; deleting a folder purges undo records that pointed at it.
- **Bulk favourite**: a ★ on each folder header stars/unstars every file inside at once. The "starred" filter tab is now a flat cross-folder list (files never move on disk just from starring — only the star lights up in place); the library root itself stays plain alphabetical regardless of favourite status (previously starred-first).
- Drag-over feedback: target folder gets an amber border + "Move to `<name>`" badge; `Demo`/`Orfeo` show a red border + "Can't move to system folder" instead of silently rejecting.
- Selected rows get an amber box around the whole contiguous selection (not per-row outlines); right-click menus and hover states carry explanatory tooltips throughout.

**New:** `src/utils/i18n.ts`. **Changed:** `electron/main.ts` (`fs:createLibraryFolder/renameLibraryFolder/deleteLibraryFolder/moveLibraryFiles/listLibraryFolders`), `electron/preload.ts`, `src/types/index.ts`, `src/store/index.ts` (`lastFolderOf`, `foldersWithUndo`, `setFavourites`, `remapLibraryPaths`), `src/components/SettingsPanel/SettingsPanel.tsx`.

### Library folder-picker icon — behavior fix
The folder icon next to the search bar had silently drifted into two different-looking buttons doing two different things (one opened the folder in Explorer, one opened the change-folder dialog). Consolidated: the icon changes the library folder; the path text underneath it opens that folder in Explorer (where files are actually visible — Windows' native folder-picker dialog never shows files, by OS design).

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`.

### i18n — new-code convention (no user-facing change yet)
Added a no-op `t()` placeholder (mirrors `ttag`'s tagged-template API) so new UI strings can be wrapped in translation-ready form as they're written, without installing real translation tooling yet. Existing strings are untouched — the full PO/MO wrapping pass is deferred until the app is feature-frozen (see `docs/I18N_PLAN.md`, gitignored/local-only).

**New:** `src/utils/i18n.ts`.

---

## [0.16.0] — 31. 7. 2026 — Note-hit VFX rewrite, downloadable soundfonts, track reorder, playback polish

### Downloadable extra soundfonts (Samples engine)
Settings → Audio → "Sound library": FluidR3 GM (142MB) and MuseScore General (38MB), both MIT-licensed GM soundfonts, one-click download + select. Neither is bundled in the build (would bloat the installer by hundreds of MB) — downloaded on demand into `userData/soundfonts/` (portable build: `<exeDir>/Orfeo-Data/soundfonts/`). Selecting a downloaded soundfont layers it over the always-bundled GeneralUser GS via `soundBankManager.addSoundBank` + `priorityOrder` (GeneralUser GS stays loaded as fallback for any preset the extra bank doesn't cover); switching back unloads it. Selection persists across restarts. Two well-known premium libraries (Timbres of Heaven, Arachno) were researched and rejected — both are "all rights reserved, no redistribution without permission," so only MIT-licensed alternatives were integrated.

**New/changed:** `electron/main.ts` (soundfont catalog + `soundfont:list/download/delete/read` IPC, redirect-following HTTPS downloader), `electron/preload.ts`, `src/hooks/useSamplesEngine.ts` (`loadSelectedSoundfont`), `src/store/index.ts` (`selectedSoundfont`), `src/types/index.ts` (`SoundfontId`, `SoundfontInfo`), `src/components/SettingsPanel/SettingsPanel.tsx`.

### Note-hit visual effects — GSAP + pixi-filters rewrite
Replaced the original hand-rolled per-frame effect update loop with GSAP-driven tweens and a shared `AdvancedBloomFilter` (pixi-filters) on the effects layer. Grew from 3 to 7 selectable patterns: Glow Bloom, Ripple Ring, Particle Burst, Smoke Plume, Color Aura, Starburst Nova, Comet Trail — each with a tooltip description. Effect pattern picker converted from buttons to a dropdown (names were too long). Bloom controls (Intensity/Spread/Threshold sliders) apply globally since all patterns share one filtered container — labels de-duplicated ("Bloom" removed, kept only in the Threshold hint text).

**New:** `src/components/PianoRoll/HitEffects.ts` (full rewrite), `src/utils/hitEffectQueue.ts`. **Changed:** `src/components/PianoRoll/PianoRoll.tsx`, `src/hooks/useAudioEngine.ts` (GM engine now also pushes hit effects), `src/store/index.ts`, `src/types/index.ts` (`HitEffectPattern`), `package.json` (+`gsap`, +`pixi-filters`).

### Library drawer search + folder-open fix
Fuzzy search box (Fuse.js, same config as Chord Explorer) added to the library drawer between the MIDI icon and refresh icon. Folder-name button regained its lost tooltip and now opens the folder in the OS file explorer (`shell:openFolder` IPC, previously not implemented at all).

**Changed:** `src/components/SettingsPanel/SettingsPanel.tsx`, `electron/main.ts`, `electron/preload.ts`, `src/types/index.ts` (`openFolderInExplorer`).

### Glissando "amber blob" fix (mouse-drag) + GM-engine audio/visual sync fix
Drag-glissando on the keyboard now short-rings each crossed key (60ms) instead of the full 500ms click duration — fixes many keys lighting simultaneously during a fast drag. Separately, the GM engine's light-timers were being scheduled *before* `player.play()`/`jumpMS()` anchor JZZ's internal clock, coupling visual sync to however long SMF parsing took; audio setup now runs first.

**Changed:** `src/components/Keyboard/Keyboard.tsx`, `src/hooks/useAudioEngine.ts`.

### Chord display legibility fix
Two independent bugs fixed: fast passages with closely-spaced distinct chords flickered faster than readable (no minimum display floor); slow passages could silently swap chord name with zero visual cue. Added a 450ms minimum hold + a 350ms text-glow flash on genuine change. Fixed-width chord name box was also clipping longer names (e.g. "F#dim7/A") — now intrinsic-width with neighboring boxes yielding space.

**Changed:** `src/components/Keyboard/Keyboard.tsx`.

### Phase 1 — hidable playbar
Playbar can be hidden; when hidden, the piano roll tracks the keyboard's live top-edge Y (rAF poll, zero overhead when playbar is visible — the default) so the piano roll's hit-line still lines up with the physical keyboard position, docked or floating.

**New:** `src/hooks/useKeyboardHitLine.ts`. **Changed:** `src/store/index.ts` (`playbarVisible`, `keyboardTopY`), `src/components/Keyboard/Keyboard.tsx`.

### Track panel — drag-to-reorder + collapsed-group legend
Groups and individual tracks within a group can be drag-reordered (session-only, never written to file). Piano/keys group is pinned first and not draggable. Collapsed groups now show a small colored-square legend per track.

**Changed:** `src/components/TrackPanel/TrackPanel.tsx`.

### Track color file-persistence fix
Track colors picked in the color popover only ever lived in the Zustand store — any save+reload silently discarded them back to the palette default. Colors are now written to a `ORFEO_TRACK_COLOR:N:#hex` header meta-event (same convention as `ORFEO_TRACK_NAME`) on save and restored on parse.

**Changed:** `src/utils/midiParser.ts`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/Mixer/ChannelStrip.tsx`.

---

## [0.15.0] — 31. 7. 2026 — Hand-Split Engine (beta)

### 31. 7. 2026 — Unified L/R hand-assignment engine, split/merge/color rewire, indicator rewire

**New files:** `src/utils/handAssignment.ts`, `src/utils/handAssignmentTest.ts`, `src/utils/handMetadata.ts`, `src/utils/handMetadataTest.ts`, `src/utils/handPreview.ts`, `src/utils/keyboardGroups.ts`, `docs/LR Hand rework/` (analysis + implementation-summary docs, two reference MIDI files)

**Files changed:** `electron/main.ts`, `src/App.tsx`, `src/components/Keyboard/Keyboard.tsx`, `src/components/Keyboard/KeyboardControls.tsx`, `src/components/MidiEditor/MidiEditor.tsx`, `src/components/PianoRoll/PianoRoll.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/store/index.ts`, `src/types/index.ts`, `src/utils/handBoundaries.ts`, `src/utils/midiParser.ts`

Replaces three previously-separate, duplicated implementations (crude pitch-threshold split in `electron/main.ts`, naive note-concat merge, live per-frame pitch-gap-guessing L/R keyboard indicator) with one shared engine.

**Engine (`assignHands()`):**
- Fast path for already-split 2-track/2-channel input (avg-pitch gap + unison-collision check).
- Real path: onset clustering + Viterbi DP over per-cluster L/R partitions. Strict mode (default) restricts partitions to pitch-sorted prefix splits — structural "hands never cross." Cost function: quadratic span-violation penalty, hand-movement cost (charged from the piece-wide mean when a hand's never played yet — closes a "free first activation" loophole), a flat penalty for splitting a cluster across hands when it already fits in one hand's reach, and a flat penalty for switching hands between consecutive monophonic clusters.
- Per-cluster confidence (DP cost margin, best vs. runner-up).

**Persistence:** `hand`/`handConfidence` sidecar fields on `ParsedNote`. Portable export hint — name-suffix for homogeneous (split) tracks, `ORFEO_HAND_MAP:<version>:<trackIndex>:<RLE>` text meta for mixed (colored) tracks. Explicitly not real MIDI clef data (SMF has no clef event). Versioned (`HAND_ENGINE_VERSION`) so an algorithm fix doesn't get masked forever by a previously-saved file's stale hint.

**UI:** `MidiEditor.tsx` split action now runs `assignHands()` instead of a pitch-threshold; merge and plain save now hand-tag every surviving keyboard-group track. New hand-split preview panel: colored timeline, low-confidence passages flagged with a red band, two output choices ("Split into two tracks" / "Keep one track, hand-colored" — disabled with a tooltip when the Left/Right Hand setting is off). One-slot undo (snapshot-before-apply, since split/merge never touch the original file). `PianoRoll.tsx` colors notes by hand tag when Left/Right Hand is on. `Keyboard.tsx` shows a per-active-key hand stripe in Performance mode (reads the tag; falls back to live gap-inference only for hardware MIDI input, which has no backing file note). `KeyboardControls.tsx` Practice mode shows a moving split line — sliding-window average of real tags, replacing both the old static-heuristic line and the old live-guessing ribbon.

**Known issues** (see `docs/LR Hand rework/Implementation Summary & Known Issues.md`): hand-label identity can drift/swap across a long single-hand passage; Practice-mode line can linger a couple seconds into a brief solo passage before the window clears. Both pending a proper ground-truth-annotated test corpus (in progress) before further tuning.

---

## [0.14.0] — 30. 7. 2026 — Track Color Editor

### 30. 7. 2026 — Color Editor in MIDI Playback Editor (Phase 2) + pencil cursor

**New files:** `src/utils/colors.ts`

**Files changed:** `src/types/index.ts`, `src/store/index.ts`, `src/utils/cursors.ts`, `src/components/MidiEditor/MidiEditor.tsx`, `docs/Track Color System.md`

**Pencil cursor on track name (Task 1):**
- `src/utils/cursors.ts`: new module with `PENCIL_CURSOR` — amber SVG cursor built from exact Lucide 0.503.0 Pencil paths, encoded as a CSS `url(data:image/svg+xml,...)`. Hotspot (2, 18) places click point at the pencil tip. Fallback: `text`.
- `MidiEditor.tsx`: track name span switches from `cursor: 'text'` to `cursor: PENCIL_CURSOR` when not in inline-edit mode. Title text updated to "Double-click to rename".

**COLOR column in MIDI Playback Editor (Task 2):**
- `ROW_COLS` updated from 5 to 6 columns: `'44px 1fr 44px 44px 44px 220px'` (Include | Track | Color | Merge | Split | Assign Instrument).
- Column header added: `'Color'`.
- Existing 4×32px color bar in Track cell (Col 2) gains `onClick`, `cursor: pointer`, and title "Click to change track color".
- New Col 3 button: 24×24 Palette icon, same style as Merge/Split buttons. Hover: icon and border tint to the track's current color. Every track gets this column (no conditional).
- Both triggers call `openColorPopover(trackIndex, anchorRect)`.

**Track color popover — Phase 2 (Task 3):**
- `src/utils/colors.ts`: `TRACK_COLOR_PALETTE` — 10 muted/desaturated colors (Amber, Teal, Slate Violet, Rose, Sky Blue, Sage Green, Coral, Mauve, Steel Blue, Warm Gold). Typed `as const`.
- `TrackState` in `src/types/index.ts`: added `colorSource: 'default' | 'palette' | 'custom'`.
- `makeTrackState` in `src/store/index.ts`: initialises `colorSource: 'default'`.
- `EditorTrack` interface and `buildRows()` in `MidiEditor.tsx`: include `colorSource`.
- `ColorPopover` component (portal at `zIndex: 60000`): 10-swatch 5-col grid + HSV rainbow picker + hex input. Position: anchored below trigger; auto-flips above near bottom viewport edge. Selecting a palette color sets `colorSource: 'palette'`; valid hex or picker selection sets `'custom'`.
- `handleApplyColor` in `MidiEditor`: calls `updateTrack` on the store (propagates to PianoRoll + Mixer via `t.color` — single source of truth) and mirrors the color into local `EditorTrack` state for immediate row swatch update.
- `docs/Track Color System.md`: Phase 2 trigger section updated to document MidiEditor as the anchor point.

### 30. 7. 2026 — Color editor refinements

**Files changed:** `src/components/MidiEditor/MidiEditor.tsx`

- **Track name hover:** span transitions to `var(--text-amber)` on mouseover (0.12s transition) — makes the rename affordance visible before double-clicking.
- **SwatchBook icon:** replaced `Palette` with `SwatchBook` (Lucide 0.503.0; paths verified from `node_modules`) in the COLOR column button.
- **HSV rainbow picker in ColorPopover:** `HsvPicker` component — 120px SV gradient square (CSS overlay gradients: `hsl(H, 100%, 50%)` base + white→transparent horizontal + transparent→black vertical) and a 14px hue rainbow slider. Both support click-and-drag via `window` `mousemove`/`mouseup`. `lastEmitted` ref guards the `useEffect` sync to prevent the color prop feedback loop. `hexToHsv` / `hsvToHex` utilities inline (no new dependencies, no canvas). Picker sits between palette grid and hex input; hex input and palette both sync the picker via the `color` prop effect. `POP_W`: 204 → 220px, `POP_H`: 170 → 330px.

### 30. 7. 2026 — Custom Confirm Dialogs + Empty State copy update

**New files:** `src/utils/confirmController.ts`, `src/components/ConfirmDialog.tsx`

**Files changed:** `electron/main.ts`, `src/App.tsx`, `src/components/EmptyState.tsx`, `src/components/NoteEditor/NoteEditorToolbar.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/utils/foreignFormatImport.ts`

**Architecture — ConfirmDialog system:**
- `confirmController.ts`: imperative singleton, same pattern family as `noteEditorState.ts`. `confirmDialog(options)` returns a `Promise<number>` resolving to the clicked button index (or `buttons.length - 1` for Escape / backdrop click). Notifies `subscribeConfirm` listeners.
- `ConfirmDialog.tsx`: exports `<ConfirmDialogHost />` — always-mounted portal at `zIndex: 99999`. Styled with `--bg-modal`, `--border2`, `--radius-lg`, `--text-amber` title; JetBrains Mono header. Backdrop `mousedown` and `keydown` Escape both resolve to safe index. `destructiveIndex` prop renders a button in `#c05050`.

**Architecture — main.ts is now a thin dispatcher:**
- `win.on('close')` reduced to 3 lines: if `allowClose` (module-level flag), let through; else `e.preventDefault()` + send `app:save-before-close` to renderer.
- `ipcMain.handle('app:confirm-close')` sets `allowClose = true` then calls `mainWin?.close()` (fires the event again; passes through).
- `dialog.showMessageBox` removed from `main.ts` entirely. `executeJavaScript` dirty probe and `__orfeoNoteEditorDirty` / `__orfeoPendingImportedFile` globals removed.

**Renderer close handler (`App.tsx`) is now the single authority:**
Resolves in sequence: (1) NES dirty check → Save / Discard / Cancel; (2) pending imported file → Save as MID / Don't Save / Cancel. Calls `confirmClose()` only after both pass. Cancelling either leaves the app open with all state intact.

**Native dialogs replaced:**
- `window.confirm` in NoteEditorToolbar Reset button → `confirmDialog`
- `window.electronAPI.showMessageBox` in `SettingsPanel.handleLoadFile` (NES dirty guard) → `confirmDialog`
- `window.electronAPI.showMessageBox` in `App.enterPresentationMode` (NES dirty guard) → `confirmDialog`
- `window.electronAPI.showMessageBox` in `foreignFormatImport.confirmPendingImportBeforeSwitch` → `confirmDialog`
- Inline drag-drop confirm modal in `App.tsx` (60-line JSX + `dropConfirmPath` state) → `confirmDialog`; `dropConfirmPath` state removed entirely.

**EmptyState copy:** subtitle now mentions `.kar`, `.musicxml`, `.mxl`, and Guitar Pro formats in a second line.

---

### 29. 7. 2026 — Foreign Format Import (MusicXML / KAR / Guitar Pro)

**Files changed:** `electron/main.ts`, `electron/preload.ts`, `src/types/index.ts`, `src/App.tsx`, `src/components/SettingsPanel/SettingsPanel.tsx`, `src/utils/foreignFormatImport.ts`, package.json dependency

**New dependency:** `@coderline/alphaTab` v1.8.4 — used import-only (no renderer, no audio engine); loaded lazily via dynamic `import()` to keep startup bundle lean (~1.1 MB).

**New IPC channels:** `fs:getCachedImport`, `fs:writeCachedImport`

**Architecture:**
- Foreign formats converted to SMF bytes at load time via `alphaTab.importer.ScoreLoader` + `MidiFileGenerator` + `AlphaSynthMidiFileHandler`.
- Converted bytes cached as `<stem>_ORFEO_IMPORTED.mid` alongside source in `Orfeo/` subfolder. Cache invalidated when source `mtime` is newer than cache `mtime`.
- KAR pass-through: zero conversion, extension whitelist only. `@tonejs/midi` silently ignores lyric meta-events.
- `_filePath` on `ParsedMidi` is always the original source path, not the cache path — library amber-highlight logic is unaffected.
- Critical fix: `NoteBendEvent` filter required before `midiFile.toBinary()`. alphaTab 1.8.4 emits neutral MIDI 2.0 per-note pitch bend events even when there is no actual pitch bend; SMF 1.0 export cannot represent these. The filter is safe: genuine pitch-bend expression from GP files is encoded as `PitchBendEvent` (SMF 1.0 compatible), not `NoteBendEvent`.

**Extension whitelist added to:** `dialog:openMidi` filter, `fs:scanMidiFolder` regex, demo folder filter, `isSupportedFile()` in App.tsx, library drop handler in SettingsPanel.tsx.

**Error handling:** Corrupt/unsupported files surface via existing `showDropError()` toast. Empty conversion results load as zero-note MIDI without crashing (handled by existing `parseMidiBuffer` empty-track skip).

**Converted file prompt on switch/close:** pending import bytes held in memory as `pendingImportedFile` store field (session-only, not persisted). User prompted "Save as MID / Don't Save / Cancel" when loading a different file or closing the app with unsaved converted bytes. Save writes to `Orfeo/` subfolder with mkdirSync. Same-file reload skips prompt.

**Known limitations:** Very large orchestral MusicXML scores may be slow to convert (no special handling). MIDI Editor split/merge/instrument assign not tested on imported files.

---

### 27. 7. 2026 — Note Editor tooltip fixes + SpeedControl icon redesign

**`src/components/PianoRoll/PianoRoll.tsx`:**
- Fixed tooltip never appearing on small notes (drums etc.): `updateHoverState` and `onEditDown` now guard resize-zone detection with `canResize = noteH >= RESIZE_ZONE_PX * 2` (12px). Notes shorter than this — `MIN_NOTE_H = 4` for drum notes — were always matching `atEnd || atStart` and landing in the resize branch which called `setEditTooltip(null)`.
- Tooltip now strips trailing octave digit (`.replace(/\d+$/, '')`) to match inline canvas text style.
- Tooltip now gated on `NES.showNoteNamesRef.current` — hidden when the Note names toggle is off.

**`src/components/Transport/TopBar.tsx`:**
- Fixed note-names icon showing active on re-entry while names were not drawn: `NES.reset()` is now called *before* `setNoteEditorActive(true)`. The previous order (activate → reset) caused Zustand's synchronous subscriber to mount the toolbar and read the stale `showNoteNamesRef = true` from the prior session before the reset ran.

**`src/components/SpeedControl.tsx`:**
- Full redesign: replaced SVG track-and-circle selector (three filled nodes on a horizontal line) with three play-chevron icon buttons (1×, 2×, 3× forward arrows) sourced from `Slow.svg` / `Medium.svg` / `Fast.svg` assets.
- All three icons share viewBox height = 26, rendered at H = 13px — identical stroke weight across all speeds.
- Active icon renders in `--text-amber` with `drop-shadow` glow; inactive icons are muted at 0.65 opacity.
- "SPEED" label removed. Gap = 8px between buttons.
- Props interface, `value`/`onChange` contract, `title`/`aria-label`/`aria-pressed` accessibility attributes all unchanged.

---

### 26. 7. 2026 — Note Editor: single-tool redesign, live hint line, track solo, axis-free drag

**`src/components/NoteEditor/NoteEditorToolbar.tsx`:**
- Removed Pencil/Select tool buttons and `toolMode` local state. The editor now uses one context-sensitive tool — no mode switching.
- Added `hintText` state subscribed to `NES.onHintChange`: renders a dim italic hint line below the icon row showing context-sensitive instructions from PianoRoll hover.
- Added `showCloseConfirm` state: clicking ✕ when `NES.dirty` reveals an inline strip with Save & Exit / Discard / Cancel buttons instead of closing immediately.
- `doClose` is now an `async useCallback` defined before the early return (`if (!noteEditorActive) return null`) so it obeys hook rules. Calls `unsoloTrackForEdit()` before `setNoteEditorActive(false)`.
- Added Reset button (RotateCcw icon): clears history + `NES.dirty` + `editMidi` via `NES.onResetRequest?.()`. Used `window.confirm` when dirty (replaced by `confirmDialog()` on 30.7.2026).
- Added Velocity placeholder button (Activity icon, `opacity: 0.3`, disabled, `pointerEvents: none`) before Save — marks velocity editing as coming soon.
- Added Info placeholder button (Info icon, `opacity: 0.2`, disabled) before Close.
- Toolbar outer div changed from fixed-height flex row to `flexDirection: column` with icon row (38px) + optional confirm strip + optional hint line below.

**`src/utils/noteEditorState.ts`:** (done in prior session)
- Removed `toolModeRef` / `NETool` type. Added `hoverHint`, `defaultHint`, `onHintChange`, `onResetRequest`. Updated `reset()`.

**`src/components/PianoRoll/PianoRoll.tsx`:**
- `updateHoverCursor` renamed to `updateHoverState`: same cursor logic + sets `NES.hoverHint` + fires `NES.onHintChange`. Hint strings: note body (new) → "Drag to move · Right-click to delete", note body (saved) → "Drag to move · Select + Delete key to remove", note edge → "Drag to resize", empty space → "Alt+click to add note · Drag to select".
- `onEditDown`: unified single-tool handler replacing the old pencil/select branch. Click note edge → resize; Shift+click note → toggle selection; click note in multi-selection → selection-move; click note solo → select + note-move; Alt+click empty → add note; click empty → marquee + clear selection.
- `onEditMove`: removed axis locking entirely. `note-move` and `selection-move` now update both pitch (x) and time (y) simultaneously every frame.
- `onEditUp` note-move: single combined undo command capturing both `timeChanged` and `pitchChanged` booleans. Revert restores both tick and midi.
- `onEditUp` selection-move: single combined command with `anyTimeMoved || anyPitchMoved` guard; revert restores both `origTicks` and `origMidi` for all selected notes.
- `onEditContext`: removed `toolModeRef` guard. Right-click on a note only deletes if `editNewNotes.has(note) || e.altKey`. Right-click empty space clears selection.
- Registered `NES.onResetRequest`: rebuilds `NES.editMidi` from `_raw`, clears history/dirty/newNotes, sets `needsFlatRebuild`, fires both `onHistoryChange` and `onHintChange`.
- Registered `onCanvasLeave` (mouseleave): resets `NES.hoverHint` to `NES.defaultHint` and fires `onHintChange`.
- Cleanup: added `NES.onResetRequest = null` to the return cleanup function.

**`src/components/TrackPanel/TrackPanel.tsx`:**
- Added `noteEditorActive`, `noteEditorSoloTrackIndex`, `soloTrackForEdit` selectors from store.
- `IBtn` click handler now calls `e.stopPropagation()` before delegating to `onClick` — prevents M/S/V/K button clicks from bubbling to the new row-level solo handler.
- `TrackRow`: accepts `onSoloForEdit?` and `isSoloedForEdit?` props. Row div gains `onClick={onSoloForEdit}`, pointer cursor, hover tint, and amber left-border + background when soloed for edit.
- Parent passes `onSoloForEdit={noteEditorActive ? () => soloTrackForEdit(track.index) : undefined}` and `isSoloedForEdit={noteEditorSoloTrackIndex === track.index}` to each row.

**`src/App.tsx`:**
- Added `useStore.subscribe` effect that calls `unsoloTrackForEdit()` on the false-transition of `noteEditorActive` — cleans up track visibility whenever the editor closes for any reason.

**`src/store/index.ts`:** (done in prior session + additions this session)
- Added `noteEditorWalkthroughSeen` / `setNoteEditorWalkthroughSeen` to the prefs persist subscribe block (sentinel init + change detection + `setPrefs` payload + `restoreLibraryPrefs` restore).
- Added `soloTrackForEdit`, `unsoloTrackForEdit`, `noteEditorSoloTrackIndex`, `preSoloTrackVisibility` in interface and store body.

**`src/utils/noteEditorCommands.ts`:** (done in prior session)
- Added `insertSorted` helper. Fixed `cmdAddNote`, `cmdRemoveNote`, `cmdRemoveNotes` to preserve Note object references across undo/redo cycles.

---

### 26. 7. 2026 — Presentation Mode (distraction-free fullscreen)

**New feature: Presentation Mode — fullscreen, distraction-free view for live playing and screen recording.**

**`electron/main.ts`:**
- Added `window:setFullScreen` IPC handler (`ipcMain.handle`) — calls `mainWin.setFullScreen(value)`.

**`electron/preload.ts`:**
- Exposed `setFullScreen(value: boolean)` on `window.electronAPI`.

**`src/types/index.ts`:**
- Added `setFullScreen` to the `Window.electronAPI` interface.

**`src/store/index.ts`:**
- Added `presentationMode: boolean` + `setPresentationMode(v)` to `OrfeoStore` interface and store body. Initialized `false`, not persisted.

**`src/App.tsx`:**
- Added `presentationMode` selector from store.
- Added `headerVisible: boolean` local state and `hideHeaderTimerRef` for hover-reveal debounce.
- Added `enterPresentationMode()` async callback: guards against unsaved Note Editor edits (Save/Discard/Cancel dialog, mirrors `SettingsPanel.handleLoadFile`), then calls `setPresentationMode(true)`.
- Added `useEffect` on `presentationMode`: calls `window.electronAPI.setFullScreen`, hides header on enter, force-exits Note Editor via `setNoteEditorActive(false)`.
- `handleKeyDown`: added `F11` → toggle PM (with dirty-check guard on enter); `Escape` → exit PM first (before existing Escape handlers).
- JSX: in PM, `<TopBar />` rendered in a `position: fixed` wrapper with CSS `transform: translateY()` slide animation. An 8px invisible hover zone at `top: 0` reveals the header on hover; a 400ms debounce hides it again when the cursor leaves. In normal mode, `<TopBar />` and the separator render in-flow as before.
- `<SettingsPanel />` and `<TrackPanel />` skipped when `presentationMode`.

**`src/components/Keyboard/Keyboard.tsx`:**
- Added `presentationMode` selector.
- Chord bar div (34/36px, containing CHORDS/chord name/SCALES row) wrapped in `{!presentationMode && ...}` — collapses to zero height, no empty stripe.

**`src/components/Keyboard/KeyboardControls.tsx`:**
- Added `presentationMode` and `setPresentationMode` selectors.
- Key-range selector (61/73/88): always shown in PM regardless of `performanceHideControls` state.
- Dock/Float button: hidden in PM (`{!presentationMode && <button ...>}`).
- Flex-1 spacer: hidden in PM.
- Hand-label visualization: hidden in PM (beta, needs rework).
- Note counter: hidden in PM.
- New PM toggle button at far right: amber Lucide Expand icon (enter PM) / Lucide Shrink icon (exit PM), `marginLeft: 'auto'` in PM to push to right edge; `opacity: 0.65` with hover to `1`. Shows tooltip with key hint (F11 / Esc).

---

### 26. 7. 2026 — Loop region tooltip + right-click, TopBar centering fix, keyboard label toggles wired

**`src/components/PianoRoll/PianoRoll.tsx` — LoopOverlay:**
- Added `mousePos` state; global `mousemove` handler now tracks cursor position inside the overlay rect.
- Cursor-following tooltip renders via `position: fixed` when `loopRegionEnabled` is true, Alt is not held, and the cursor is over the piano roll. Shows "Alt+drag · set loop region" always; adds "Right-click · clear" line when a region exists.
- Added `window` `contextmenu` listener: right-click inside the overlay bounds calls `clearLoopRegion()` with `preventDefault()` — works regardless of whether Alt is held.
- Removed per-handle `title` attributes (superseded by the cursor tooltip).

**`src/components/Transport/TopBar.tsx`:**
- Note editor slot changed from conditional render (`{noteEditorEnabled && <div>}`) to always-rendered `<div>` with `visibility: noteEditorEnabled ? 'visible' : 'hidden'`. The slot always occupies `var(--button-height)` (28 px) in the flex row, so the center section width never changes regardless of feature enable state — eliminates the leftward shift of transport controls when the note editor is enabled.

**`src/components/Keyboard/Keyboard.tsx`:**
- Added `showOctaveLabels` and `showNoteNamesOnKeyboard` selectors from store.
- White key label logic: octave label (C4, C5…) now gated by `showOctaveLabels`; active-key note name gated by `showNoteNamesOnKeyboard`.
- Black key note name span: gated by `showNoteNamesOnKeyboard` in addition to existing `noteNaming !== 'hidden'` check.
- Both Settings toggles (Keyboard Labels → Show Octaves / Note Names on Keyboard) now take effect immediately.

---

### 25. 7. 2026 — Note Editor: instrument audio fix, alt+click mapping, selection pitch drag, UI polish

**Root cause — instrument audio (both engines):** clicking a note in the editor before ever pressing Play always sounded like piano on all tracks. Two separate bugs, one per engine:

- **Samples engine (`useSamplesEngine.ts`):** `__orfeoPlayNoteSamples` called `_synth.noteOn(ch, ...)` without ever sending `_synth.programChange()` first. SpessaSynth defaults all channels to program 0 (piano). `programChange` was only called inside `buildSamplesPlayer` (playback start). Fix: module-level `_samplesChanInit: Set<number>` — on first `noteOn` for a channel (when ch ≠ 15), look up the track's `program` from the store and call `_synth.programChange(ch, program)` before `noteOn`. `buildSamplesPlayer` clears this set and repopulates it as part of its own program-change loop.
- **GM engine (`useAudioEngine.ts`):** `_port.send([0xC0|ch, program])` is silently discarded before any JZZ player has been connected to `_port` — the synthesizer's internal event pipeline isn't activated until `player.connect(port)` is first called (inside `buildPlayer`). Fix: `warmupEditChannels()` — creates a temporary JZZ SMF player, connects it to `_port`, plays the raw MIDI through a filter that blocks all note events but passes program changes and bank-select CCs. After 150 ms (ample for tick-0 events), the player is stopped. `_warmupPromise` stores the in-flight promise; `playNote` awaits it if the user clicks before 150 ms elapses. Called from PianoRoll on edit mode enter via `window.__orfeoWarmupEditChannels`.

**Root cause — alt+click recolors all notes (fourth unpatched position-based mapping path):** in `onEditDown` (alt+click), `editMidi.tracks.find((_t, i) => parsedMidi.tracks[i].index ...)` used raw track array position without the non-empty filter. Adding a note to the wrong track made the set of non-empty tracks change, shifting all `trackIndex` assignments in the next `needsFlatRebuild` and recoloring everything. Fix: filter `editMidi.tracks` to non-empty first (`nonEmptyForAdd`) before `.find()`, matching `buildEditFlatNotes` and the `needsFlatRebuild` block.

**`src/hooks/useSamplesEngine.ts`:**
- Added module-level `const _samplesChanInit = new Set<number>()`.
- `__orfeoPlayNoteSamples`: lazy programChange on first use of each non-preview channel.
- `buildSamplesPlayer`: clears `_samplesChanInit`, then re-populates as it sends programChanges.

**`src/hooks/useAudioEngine.ts`:**
- Added module-level `let _warmupPromise: Promise<void> | null = null`.
- `destroyPlayer`: resets `_warmupPromise = null` so next edit-mode entry re-warms.
- Added `warmupEditChannels()`: temporary filtered SMF player primes GM channels.
- Registered `window.__orfeoWarmupEditChannels` (GM only) in the playNote useEffect.
- `playNote`: removed failed lazy-init attempt; awaits `_warmupPromise` if channel is specified and warmup is in flight.

**`src/components/PianoRoll/PianoRoll.tsx`:**
- Edit mode enter now calls `window.__orfeoWarmupEditChannels?.()`.
- **alt+click fix:** `nonEmptyForAdd` filter applied before track `.find()`.
- **New-note dashed border:** `drawDashedRect` color changed from `0xdddddd` to `0xdd2244` (red, matching selected-note color family).
- **Selection-move pitch axis:** `axis` starts `null` instead of `'time'`; axis is determined by gesture (first crossing `DRAG_THRESHOLD`). Horizontal drag shifts all selected notes by the same pitch delta relative to `origMidi`. Commit: pitch repitch logged to history via `description: 'Repitch N notes'`.
- `EditDragState.selectionSnapshot` type: added `origMidi: number` per entry.
- Snapshot creation: `[...editSelectedNotes].map(n => ({ ..., origMidi: n.midi }))`.
- `onEditUp` selection-move: branches on `axis === 'pitch'` vs time; pitch path logs finalMidis to history.

**`src/components/NoteEditor/NoteEditorToolbar.tsx`:**
- Save icon replaced with exact Lucide SavePlus SVG (5-path, `viewBox="0 0 24 24"`, 15×15, stroke hardcoded to `var(--text-amber)`).
- Close (✕) button: amber color on hover via `onMouseEnter`/`onMouseLeave`.

---

### 25. 7. 2026 — Note Editor: selection highlight, save flow, unsaved-change guards, TopBar fix, amber glow

**`src/components/PianoRoll/PianoRoll.tsx`:**
- `SEL_COLOR` split into `SEL_NOTE_COLOR = 0xdd2244` (red, selected notes) and `SEL_MARQUEE_COLOR = 0x7788aa` (neutral, drag-select rect).
- Selection border pulsates via `0.55 + 0.30 * Math.sin(Date.now() / 250)` applied to stroke alpha each rAF frame — zero extra state.

**`src/utils/noteEditorState.ts`:**
- Added `onSaveRequest: (() => Promise<boolean>) | null` — registered by NoteEditorToolbar so SettingsPanel and the close handler can trigger a save without importing the toolbar.

**`src/components/NoteEditor/NoteEditorToolbar.tsx`:**
- Added `IconSave` SVG and `computeSavePath()` (versioned `_ORFEO` / `_ORFEO_V2` / `_ORFEO_V3...` suffix, placed in `Orfeo/` subfolder).
- `handleSave()` — shows `saveFileDialog`, encodes `NES.editMidi` via `editableCopyToBuffer`, calls `noteEditor:save` IPC, reloads file into store on success, clears `NES.dirty`.
- Save button inserted after Select (marquee) icon.
- Registers `NES.onSaveRequest = handleSave` on mount (cleared on unmount).
- Added amber glow via `className="orfeo-modal-glow"`, removed inline `boxShadow`.

**`src/components/Transport/TopBar.tsx`:**
- Removed permanent divider between filename area and pencil slot.
- Pencil slot now renders whenever `noteEditorEnabled` (not also gated on `midi`): `opacity: 0; pointerEvents: none` when no file is loaded — slot always occupies `var(--button-height)` width, eliminating all layout shifts.

**`src/components/SettingsPanel/SettingsPanel.tsx`:**
- Imported `NES` from `noteEditorState`.
- `handleLoadFile` wrapped in `useCallback`; checks `NES.dirty` first — shows `showMessageBox` native dialog (Save/Discard/Cancel); Save calls `NES.onSaveRequest?.()`, Discard clears dirty and loads, Cancel returns.

**`src/App.tsx`:**
- Imported `NES`.
- `useEffect` registers `window.__orfeoNoteEditorDirty = () => NES.dirty` and subscribes to `app:save-before-close` IPC — calls `NES.onSaveRequest?.()` then `electronAPI.confirmClose()`.

**`electron/main.ts`:**
- `mainWin` module-level ref to `BrowserWindow`.
- `win.on('close')` — checks dirty via `executeJavaScript`, shows native dialog if dirty; Discard → `win.destroy()`; Save → `win.webContents.send('app:save-before-close')`.
- New `ipcMain.handle('noteEditor:save')` — writes base64 buffer, returns file data for renderer reload.
- New `ipcMain.handle('dialog:messageBox')` — wraps `dialog.showMessageBox` for renderer confirm dialogs.
- New `ipcMain.handle('app:confirm-close')` — destroys `mainWin` after renderer save completes.

**`electron/preload.ts`:** Added `saveNoteEditor`, `showMessageBox`, `confirmClose`, `onSaveBeforeClose`, `offSaveBeforeClose`.

**`src/types/index.ts`:** Typed all five new IPC methods.

---

### 25. 7. 2026 — Note Editor: track-order fix + toolbar persistence + UI polish

**Root cause diagnosed and fixed (issues 3, 4, 6):** `buildEditFlatNotes` and the `needsFlatRebuild` block both used a position-based mapping `NES.editMidi.tracks[i] ↔ parsedMidi.tracks[i]`. `midiToEditableCopy` returns a raw `@tonejs/midi Midi` with ALL tracks including empty tempo/marker tracks; `parseMidiBuffer` filters them via `if (track.notes.length === 0) return`. For any MIDI file with empty leading tracks the indices diverged, causing wrong colors, wrong instrument channels, and notes silently dropped from `editFlatNotes` (no hit-test, no label, no audio).

**`src/components/PianoRoll/PianoRoll.tsx`:**
- Fixed `buildEditFlatNotes`: filter `editMidi.tracks` to non-empty before the position loop (`nonEmptyEditTracks`).
- Fixed `needsFlatRebuild` block: same filter applied to `nonEmpty` before building `flatNotesRef`.
- Note name labels now strip the octave digit (`.replace(/\d+$/, '')`) — shows `F`, `G#`, `Bb` instead of `F4`, `G#5`.

**`src/components/NoteEditor/NoteEditorToolbar.tsx`:**
- Toolbar initial position now reads from `noteEditorToolbarX/Y` store (instead of hardcoded 24/80).
- Added `posRef` to track current position without stale-closure in `onMouseUp`.
- `onMouseUp` now calls `setNoteEditorToolbarPos` to persist final drag position.
- Added `useEffect` on `noteEditorEnabled`: when the Settings toggle goes false while edit mode is active, calls `setNoteEditorActive(false)` + `NES.reset()` immediately.

**`src/components/Transport/TopBar.tsx`:**
- Pencil icon wrapped in a fixed-width container (`width: var(--button-height)`) so toggling the icon on/off never shifts the playback controls. Removed the extra divider that was sitting to its left.

**`src/store/index.ts`:**
- Added `noteEditorToolbarX: number`, `noteEditorToolbarY: number`, `setNoteEditorToolbarPos` to interface, store body, `_prev` sentinels, change-detection, save, and restore — persisted to `orfeo-prefs.json` on drag-end.

**`CLAUDE.md`:** Added Note Editor Architecture section; updated track-mapping note to document the empty-track filter requirement.

---

### 24. 7. 2026 — Note Editor Phase 2.5: NES.editMidi + bug fixes

**Root cause fixed: undo/redo, ticks, and add-note were all silently broken** because the edit system was targeting `ParsedNote[]` (plain copied objects with no `ticks`/`durationTicks`, no `addNote()`, no `header`) instead of real `@tonejs/midi` Note/Track instances.

**`src/utils/noteEditorState.ts`:**
- Added `editMidi: ReturnType<typeof midiToEditableCopy> | null` — a proper `@tonejs/midi Midi` instance. Created via `midiToEditableCopy((parsedMidi as any)._raw)` when entering edit mode; nulled on exit. All edit operations route through `editMidi.tracks` instead of `parsedMidi.tracks`.
- `reset()` now clears `editMidi`.

**`src/components/PianoRoll/PianoRoll.tsx`:**
- Added `prevNoteEditorActive` tracking in PixiJS closure. On enter: creates `NES.editMidi`, sets `needsFlatRebuild`. On exit: nulls `NES.editMidi`, forces `lastMidiRef.current = null` to restore ParsedMidi display.
- `NES.needsFlatRebuild` handler: rebuilds `flatNotesRef` directly from `NES.editMidi.tracks` (position-based index mapping `editMidi.tracks[i]` ↔ `parsedMidi.tracks[i]`) instead of setting `lastMidiRef.current = null`.
- `snapTick()`, `syncNoteTimes()`: now use `(NES.editMidi as any)?.header` — `ParsedMidi` has no `header`, so these were silently no-ops before.
- `buildEditFlatNotes()`: dropped `midi` param; iterates `NES.editMidi.tracks` with position-based `parsedIdx` lookup for visibility/color.
- `drawEditOverlay()`: dropped `midi` param; guards on `NES.editMidi` presence.
- Alt+click add note: uses `NES.editMidi.tracks` (real Track with `addNote()`).
- `onEditUp` `header`: uses `(NES.editMidi as any)?.header`.
- `selection-move` closures: `editDrag!.track` → `track` (captured local) — fixes stale-closure null crash on undo/redo.
- Added `editDragActiveRef` (component-level `useRef`) shared between wheel handler and PixiJS closure. Wheel now only blocks during active drag (`editDragActiveRef.current`), not entire edit mode.
- Added `editDragActiveRef.current = true/false` on drag start/end.
- `EditDragState.trackIndex`: new field (parsedTrack.index) for per-channel audio preview.
- `getTrackChannel()` helper: looks up `parsedTrack.channel` by `trackIndex` for note preview calls.
- All `__orfeoPlayNote?.(note.midi)` calls in edit handlers now pass the track's MIDI channel.
- Note names (Issue 4): at bottom of `drawFrame`, when `noteEditorActive && NES.showNoteNamesRef.current`, draws note labels via Canvas2D overlay using `getNoteLabel()`.

**`src/hooks/useAudioEngine.ts`:**
- `playNote()` 4th param `channel?: number` (default 14). Passes `channel` to `__orfeoPlayNoteSamples`; GM path uses `0x90 | ch` / `0x80 | ch`.

**`src/hooks/useSamplesEngine.ts`:**
- `__orfeoPlayNoteSamples` 4th param `channel?: number` (default 15). Uses `ch` instead of hardcoded 15.

**`src/components/SettingsPanel/SettingsPanel.tsx`:**
- Moved Note Editor OptionRow from "Playback & Practice" to "MIDI Files & Library" section (after Chord Transcription).

**`src/App.tsx`:**
- Removed `|| noteEditorActive` from spacebar block — spacebar play/pause works in edit mode.
- Removed Ctrl+Shift+N dev shortcut entirely — entry is now Settings toggle + TopBar pencil icon.
- Removed `noteEditorActive`, `setNoteEditorActive`, and `NES` imports from App.tsx (no longer needed here).

---

### 24. 7. 2026 — Note Editor Phase 2: in-place editing on live PianoRoll canvas

**Architecture reset** — scrapped the standalone `NoteEditorCanvas.tsx`/`NoteEditorOverlay.tsx` approach (duplicate renderer, drifting geometry). All editing now happens directly on the live `PianoRoll.tsx` PixiJS canvas.

**Deleted:**
- `src/components/NoteEditor/NoteEditorCanvas.tsx`
- `src/components/NoteEditor/NoteEditorOverlay.tsx`

**`src/utils/noteEditorState.ts`** (new):
- Module-level singleton `NES` bridging `NoteEditorToolbar` ↔ `PianoRoll` without prop threading.
- Fields: `toolModeRef`, `snapRef`, `quantizeDivisorRef`, `showNoteNamesRef`, `history`, `dirty`, `newNotes` Set, `needsFlatRebuild` flag, `onHistoryChange` callback.
- `reset()` clears all ephemeral state — called on edit mode enter/exit.

**`src/components/NoteEditor/NoteEditorToolbar.tsx`** (new):
- Floating draggable toolbar, `position: fixed`, appears only when `noteEditorActive`.
- Drag handle (3-dot grip), `EDIT ●` dirty indicator, Pencil/Select tool buttons, Snap toggle, Quantize dropdown (1/4–1/32), Undo/Redo, Note names toggle, Close button.
- Subscribes to `NES.onHistoryChange` for re-renders via `useReducer` force-update.
- Reads/writes `NES.*` refs directly; no prop threading.

**`src/store/index.ts`:**
- Added `noteEditorEnabled: boolean` (default `false`, persisted).
- Added `noteEditorActive: boolean` (default `false`, NOT persisted — ephemeral edit session state).
- Both have setters (`setNoteEditorEnabled`, `setNoteEditorActive`).
- `restoreLibraryPrefs` restores `noteEditorEnabled` from prefs.

**`src/components/PianoRoll/PianoRoll.tsx`** — major additions:
- New interfaces: `EditFlatNote`, `EditDragState` (with `origMidi` field), `EditMarqueeState`.
- New helpers in PixiJS closure: `snapTick()`, `syncNoteTimes()`, `buildEditFlatNotes()`, `editHitTest()`, `drawDashedRect()`, `drawEditOverlay()`, `history_push()`.
- `editG: Graphics` overlay layer added to stage (rendered on top of notes and playhead).
- `drawFrame()` extended: checks `NES.needsFlatRebuild` to force `lastMidiRef.current = null` (triggers flatNotes rebuild); calls `drawEditOverlay()` every frame.
- `LoopOverlay` returns `null` in edit mode to pass pointer events through to PixiJS canvas.
- Wheel scrub disabled in edit mode.
- Pointer handlers on `app.canvas`: `onEditDown`, `onEditMove`, `onEditUp`, `onEditContext`.
- Window `keydown` capture handler: Ctrl+Z/Y undo/redo, Delete to remove selected notes.
- Edit mode gate: all handlers early-return when `noteEditorActive` is false.
- Pencil tool: click to move/resize (RESIZE_ZONE_PX=6 at top/bottom edges), Alt+click to add, right-click to delete.
- Select tool: click to select, Shift+click additive, drag to marquee, selection-move drag.
- New notes (unsaved) get dashed white border via `drawDashedRect()`.
- Selection highlighted with blue stroke (SEL_COLOR=0x4488ee).
- `syncNoteTimes()` is called after every ticks mutation — @tonejs/midi fields are NOT auto-linked.

**`src/components/SettingsPanel/SettingsPanel.tsx`:**
- Added `noteEditorEnabled` / `setNoteEditorEnabled` selectors.
- Added `OptionRow` eye-toggle for "Note Editor" in the Playback & Practice section.

**`src/components/Transport/TopBar.tsx`:**
- Added `Pencil` import from lucide-react; `NES` import from noteEditorState.
- Added `noteEditorEnabled`, `noteEditorActive`, `setNoteEditorActive` selectors.
- Pencil button rendered between volume knob VSep and TIME/METRONOME/MIDI group, gated on `noteEditorEnabled && midi`.
- Active state: amber fill + border. Clicking toggles edit mode; entering pauses playback.

**`src/App.tsx`:**
- Removed `NoteEditorOverlay` import/render; removed `noteEditorOpen` state.
- Added `NoteEditorToolbar` import/render (always mounted; returns `null` when inactive).
- Added `NES` import.
- `noteEditorActive` now comes from store, not local state.
- Spacebar blocks on `noteEditorActive` (same guard as chordExplorer/scaleExplorer).
- Ctrl+Shift+N dev shortcut now toggles `noteEditorActive` via store + `NES.reset()`, pausing playback on enter.

---

### 24. 7. 2026 — Key-layout unification + background stripe alignment + spacebar listener leak fix

**`src/utils/keyLayout.ts`** — rewritten:
- Added `buildKeyLayoutRatios(midiMin, midiMax): KeyLayout[]` — the **canonical formula**, extracted verbatim from `Keyboard.tsx`'s inline CSS math. Returns positions as 0–1 fractions of container width. White keys: `x = wi/n, width = 1/n`. Black keys: `x = (wi−0.30)/n, width = 0.60/n` (mirrors Keyboard.tsx `((whiteIdx + 0.70) / n) * 100%`).
- `buildKeyLayout(W, midiMin, midiMax)` now delegates to `buildKeyLayoutRatios` and multiplies by W — thin wrapper; formula lives in one place only.
- Removed the `// must stay in sync with Keyboard.tsx` comment on `PIANO_RANGES` — Keyboard.tsx now imports `PIANO_RANGES` from here, making drift impossible.

**`src/components/Keyboard/Keyboard.tsx`:**
- Removed local `RANGES` constant — now imports `PIANO_RANGES as RANGES` from `keyLayout.ts`.
- Black key positions computed from `buildKeyLayoutRatios(min, max)` via a `keyRatios` useMemo; `ratio.x * 100` and `ratio.width * 100` replace the previous inline `((whiteIdx + 0.70) / n) * 100` / `(0.6 / n) * 100` calculation. The `whiteIdx = whiteKeys.findIndex(w => w.midi > k.midi) - 1` lookup is gone.
- All three consumers (Keyboard.tsx, PianoRoll.tsx, NoteEditorCanvas.tsx) now run the identical formula path.

**`src/components/PianoRoll/PianoRoll.tsx` — `drawGrid`:**
- Background column fill now mirrors Keyboard.tsx draw order: white key fills (`0x171720`) at full `ww` width drawn first, then black key fills (`0x0d0d10`) at exact `buildKeyLayout` positions overlaid on top. C-note octave dividers unchanged.
- Previously had no column fills (uniform dark canvas background).

**`src/components/NoteEditor/NoteEditorCanvas.tsx` — `redraw` grid section:**
- Same column fill change as PianoRoll.tsx.
- **Spacebar listener leak fix**: added `let unmounted = false` before `app.init()`. The `.then()` callback now checks `if (unmounted) return` as its first statement — if the component unmounted while PixiJS was still initialising (guaranteed in React StrictMode dev, possible in production if init is slow), the async callback exits immediately without registering any event listeners. The cleanup `return () => { ... }` sets `unmounted = true` before calling `cleanupListeners?.()`. Root cause: async Promise callbacks can't be cancelled; without this guard, `window.addEventListener('keydown', onKey, { capture: true })` was registered after cleanup already ran, permanently blocking spacebar globally.

---

### 23. 7. 2026 — Note Editor Phase 1.5 bug pass: selection color, note names, spacebar, draw order

**`src/App.tsx`:**
- Spacebar no longer triggers playback when the Note Editor is open — `noteEditorOpen` added to the guard condition alongside `chordExplorerOpen`/`scaleExplorerOpen`; `noteEditorOpen` added to `useEffect` deps

**`src/components/NoteEditor/NoteEditorCanvas.tsx` — second pass:**
- **Selection color**: changed from amber `0xe8a027` to blue `0x4488ee` for both selection outlines and marquee rectangle; amber was overloaded with hover/drag highlight
- **Selection rect bounds**: tightened to match note body exactly (`key.x + 1`, `key.width - 2`) — was 1px wider on all sides, producing visible overflow into adjacent key columns
- **Note draw order**: white key notes drawn first, black key notes on top — matches physical piano key layering; prevents black key note bodies from rendering underneath adjacent white notes
- **Note alpha**: raised from 0.85 to 0.9
- **Note names — switched from Canvas2D overlay to PixiJS Text pool**: Canvas2D rendered immediately while PixiJS updates on next ticker tick, causing a one-frame stale-label flash after undo. New approach: 512 `Text` objects in a `noteNamesContainer` (added between `selectG` and `barNumsContainer`); same pipeline, no desync. Labels centered via `anchor.set(0.5, 0.5)` at `key.x + key.width/2, topY + noteH/2`; color `#111008` (dark, readable on amber note bodies)
- **Spacebar blocked at canvas level**: `onKey` registered with `{ capture: true }` + `e.stopImmediatePropagation()` for spacebar — fires before App-level bubble listener regardless of listener registration order
- Removed Canvas2D `<canvas>` overlay element from JSX (no longer needed)

**`src/components/NoteEditor/NoteEditorOverlay.tsx`:**
- "Note names" button: label changed from `A4` → `Note names`; title tooltip simplified to `"Show note names"`
- Tool button titles simplified: `"Pencil tool"`, `"Select tool"` (removed verbose implementation detail)
- Hint bar: added `justifyContent: 'center'` — hints now centered in the row

---

### 23. 7. 2026 — Note Editor Phase 1.5: toolbar redesign, tool modes, snap, bar numbers

**`src/utils/noteEditorCommands.ts`:**
- Added `cmdRemoveNotes(track, notes[])` — proper batch delete command; captures specs of all N notes before removal; `revert()` re-adds all via `track.addNote()`; a single undo step regardless of selection size

**`src/components/NoteEditor/NoteEditorCanvas.tsx` — major rewrite:**
- New props (all refs, no PixiJS restart on change): `toolModeRef`, `snapRef`, `quantizeDivisorRef`, `redrawRef`
- `redrawRef.current` set to `redraw` after PixiJS init; overlay undo/redo buttons call `redrawRef.current?.()` to sync the canvas — fixes Phase 1 bug where toolbar undo/redo did not trigger a canvas redraw
- Extended `DragState` with `mode: 'note-move' | 'note-resize' | 'selection-move'` and `selectionSnapshot` for multi-note moves
- Added `MarqueeState` for selection rectangle
- Added `selectG` Graphics layer (selection amber outlines) and `barNumsContainer` Container above `notesG`
- **Bar numbers**: pool of 64 `Text` objects (JetBrains Mono 10px `#505570`) positioned at each bar line y; labels show bar index (1-based); hidden/reused on scroll via visibility toggle — no Text creation per frame
- **Snap**: `snapTick(t) = round(t / (ppq / divisor)) * (ppq / divisor)` when snap on; applied to Alt+click add, note-move time axis, note-resize end-tick, selection-move
- **Pencil mode**: bare click on empty does nothing; Alt+click → add note (snapped); hover bottom 6px of note → `ns-resize` cursor → drag → `note-resize` mode calling `cmdResizeNote` shape; right-click note → remove; Delete while hovering → remove
- **Select mode**: click note → select (amber `selectG` outline), Shift+click → add to selection; click empty → clear + start marquee; drag marquee → `updateMarqueeSelection()` live during move + on up; drag selected note → `selection-move` (time axis, snapped), pushes multi-note batch command on up; Delete → `cmdRemoveNotes` on entire selection, single undo step
- `updateHoverCursor()` helper manages cursor shape per tool + hover position

**`src/components/NoteEditor/NoteEditorOverlay.tsx` — toolbar redesign:**
- Added state + paired refs for `toolMode`, `snapEnabled`, `quantizeDivisor`; setter functions keep state (re-render) and ref (canvas reads) in sync without restarting the PixiJS effect
- Toolbar layout (left→right): [✏] [⬚] | [⌇ SNAP] [1/8▾] | [↺] [↻] | Note Editor · track · (N) — [spacer] — [✕ Close]
- Tool buttons: amber border + background when active; SVG icons (pencil, dashed marquee rect)
- SNAP button: amber icon + text when enabled, muted when disabled; `title` tooltip
- Quantize dropdown: `position: fixed`, positioned from `getBoundingClientRect()` on open; `onMouseDown stopPropagation` inside dropdown prevents outside-click handler from closing it before item click; closes on outside mousedown via `useEffect` document listener
- Undo (↺) and Redo (↻) icon buttons: 28×26px, disabled+dimmed at 0.45 opacity when unavailable; `title` shows keyboard shortcut; call `redrawRef.current?.()` before `handleHistoryChange()` — canvas redraws correctly from toolbar buttons
- Hint bar: dynamic per tool mode — 6 pencil hints vs 5 select hints; updates instantly on tool switch
- Inline SVG icons: `IconPencil`, `IconMarquee`, `IconSnap` defined as React components at file top

---

### 21. 7. 2026 — Note Editor Phase 1: dev overlay + single-track editing canvas

**New directory: `src/components/NoteEditor/`**

`NoteEditorCanvas.tsx`:
- Standalone PixiJS 8 Application (separate from PianoRoll — no shared state)
- Frozen time layout: time = 0 at top of canvas, increases downward (chronological reading order)
- Renders note rectangles using the same `buildKeyLayout` + pitch→pixel mapping as PianoRoll; black key column shading, C-note octave dividers, horizontal bar lines per time signature
- Notes drawn in track colour at 85% alpha; hovered and dragged notes at 100% alpha with amber halo (1px hover, 2px drag)
- White highlight stripe at note top — matches PianoRoll visual style
- `redrawRef` pattern: latest `redraw()` function held in a ref so all event handlers always call the current version without stale closures
- **Add note**: click empty canvas space → pitch from X (`xToMidi` with black-key priority), start tick from Y + scroll offset, default 1-beat duration + 0.8 velocity
- **Retime drag**: pointerdown on note → axis locks to 'time' when |dy| ≥ |dx| > 4px threshold; note.ticks updated live during drag + array re-sorted; single `NoteCommand` pushed to history on pointerup with original/final ticks
- **Repitch drag**: axis locks to 'pitch' when |dx| > |dy|; note.midi derived from `xToMidi(origNoteX + dx, ...)` so drag snaps to actual key layout
- **Delete**: right-click or Delete/Backspace while note is hovered
- `setPointerCapture` / `releasePointerCapture` ensures drag events continue even when cursor leaves canvas
- Mouse-wheel scroll: vertical, clamped to content height
- Keyboard: Ctrl+Z undo, Ctrl+Y / Ctrl+Shift+Z redo (in addition to toolbar buttons)

`NoteEditorOverlay.tsx`:
- Full-screen `position: fixed` overlay, `zIndex: 9600`, dark backdrop
- `buildSession(rawBuffer)` creates fresh `Midi` copy + `NoteEditorHistory` each open; session is discarded on close — not persisted to store
- `useReducer` force-update pattern for undo/redo button state (Undo/Redo disabled when `canUndo`/`canRedo` is false)
- Toolbar: "Note Editor" label · track name (gmName fallback) · note count · Undo · Redo · Close
- Hint bar: five one-line interaction reminders below toolbar
- `onKeyDown` stopPropagation on overlay root prevents global shortcuts (Space, Escape, Ctrl+O) from firing while editing
- Track colour borrowed from `store.tracks[0].color` (first non-empty parsed track)
- Phase 1: hardcoded to first `@tonejs/midi` track with notes; track selector deferred to Phase 4

**Modified files:**

`src/App.tsx`:
- Added `NoteEditorOverlay` import
- Added `noteEditorOpen` useState flag
- Added `case 'n'/'N'` to keydown handler: Ctrl+Shift+N toggles the overlay (same pattern as Ctrl+Shift+M for Mixer)
- Mounted `<NoteEditorOverlay open={noteEditorOpen} onClose={...} />` alongside MixerConsole and MidiEditor

**v1 CC list confirmed:** CC11 (expression), CC7 (volume), CC64 (sustain) — for Phase 3 CC lane implementation.

---

### 21. 7. 2026 — Note Editor Phase 0: groundwork

Internal groundwork only — no user-visible changes. Establishes the command and history layers that Note Editor phases 1–5 will build on.

**Architecture decision recorded:** Dropped `@signal-app/core` + `midifile-ts` in favour of building directly on `@tonejs/midi` (already installed). No new runtime dependencies required. `@tonejs/midi`'s `Midi` class is parsed fresh when the editor opens (dual-parse strategy: the existing parse for playback is untouched), mutated via the command system, and re-encoded via `midi.toArray()`.

**New files:**

`src/utils/noteEditorCommands.ts`:
- `NoteCommand` interface — `apply()`, `revert()`, `description`; all `cmd*` functions return this
- `NoteSpec` interface — tick-based spec for creating a note (midi, ticks, durationTicks, velocity)
- `ToneNote` type alias — `Track['notes'][number]` without a non-barrel import
- `cmdAddNote(track, spec)` — inserts in tick-sorted order via `track.addNote()`, captures the inserted `Note` instance by set-difference for clean undo
- `cmdRemoveNote(track, note)` — splices out, undo re-inserts via `track.addNote()` restoring sort order
- `cmdMoveNote(track, note, newTicks)` — sets `note.ticks` directly then re-sorts `track.notes[]`; undo restores and re-sorts
- `cmdRepitchNote(note, newMidi)` — direct assignment, undo restores
- `cmdResizeNote(note, newDurationTicks)` — direct assignment, undo restores
- `cmdSetNoteVelocity(note, newVelocity)` — clamped to [0, 1], undo restores
- `cmdSetRangeVelocity(notes[], newVelocity)` — batch velocity, stores originals per-note for undo
- `midiToEditableCopy(rawBuffer)` — `new Midi(rawBuffer)`; creates an independent mutable copy from `_raw`
- `editableCopyToBuffer(midi)` — `midi.toArray()` → `ArrayBuffer` via `.slice()` (safe for non-zero byteOffset)

`src/utils/noteEditorHistory.ts`:
- `NoteEditorHistory` interface — `push`, `undo`, `redo`, `canUndo`, `canRedo`, `clear`, `debugStack`
- `createNoteEditorHistory(maxSize?)` — array + cursor undo stack; push discards redo branch; oldest entries trimmed at maxSize; `debugStack()` returns labelled entries with cursor marker

`src/utils/noteEditorRoundTripTest.ts`:
- `runNoteEditorRoundTripTest()` — Phase 0 proof-of-concept: reads `midi._raw` from store, parses fresh `Midi` instance, applies velocity + addNote commands, encodes to buffer, re-parses and verifies track/note counts and velocity round-trip, confirms `parseMidiBuffer()` accepts the output, exercises full undo + redo chain

`THIRD_PARTY_LICENSES.md` — created; credits `@tonejs/midi` (MIT, Yotam Mann) with full license text.

**Modified files:**

`src/App.tsx`:
- Added import of `runNoteEditorRoundTripTest`
- Added `useEffect` (runs once on mount) that exposes `window.__orfeoNoteEditorRoundTripTest` in dev mode only

`tsconfig.json`:
- Added `"types": ["vite/client"]` — required for `import.meta.env.DEV` typecheck in dev-only guards

---

### 21. 7. 2026 — Loop icon blink + tooltip fix for waterfall Alt+drag selections

**`src/components/Transport/TopBar.tsx`:**
- `nudgeLoop`: removed `loopRegionEnabled` gate — loop icon now blinks amber whenever a region is selected (`loopStart !== null`) and loop is not yet active, regardless of whether the Loop Region strip is visible in Settings.
- `loopTooltip`: branching now leads with `loopStart !== null` check instead of `loopRegionEnabled`, so bar numbers always appear when a selection exists. No-selection fallback when strip is hidden now reads "Alt+drag on the waterfall to select a section" instead of directing the user to Settings.

---

### 21. 7. 2026 — Track rename in MIDI Playback Editor

**New: user-editable track names (`TrackState.trackName`)**

**`src/types/index.ts`:**
- Added `trackName: string` to `TrackState` interface — user-visible label, independent from `gmName` (GM resolution) and `name` (raw MIDI name). Never affects audio.
- Added `trackNames?: Record<number, string>` to `saveMidiEditor` payload type.

**`src/utils/midiParser.ts`:**
- Added ORFEO_TRACK_NAME parsing block before building `result`: reads `midi.header.meta[]` for type-0x01 text events matching `ORFEO_TRACK_NAME:N:name` format. Parsing splits on first two colons so names containing colons survive. Result stored as `result._orfeoTrackNames: Record<number,string> | undefined`.

**`src/store/index.ts`:**
- `makeTrackState`: added `trackName: track.gmName` — defaults to GM instrument name on load.
- `setMidi`: reads `(midi as any)._orfeoTrackNames` and applies overrides after `makeTrackState` — so files previously saved through Orfeo restore their custom names.

**`src/components/MidiEditor/MidiEditor.tsx`:**
- `EditorTrack` interface: added `trackName: string`.
- `buildRows()`: passes `trackName: t.trackName` from store track state.
- `handleMerge`: merged row inherits `trackName: first.trackName`.
- `handleSave`: builds `trackNames: Record<number, string>` from all included rows (merged rows keyed by `mergedFromIndices[0]`); passes in `saveMidiEditor` payload.
- `TrackRow` component: added `onRename: (name: string) => void` prop; inline rename via `editingName` state + `<input>` on double-click; commits on Enter/blur, cancels on Escape; amber border while editing.
- Parent `<TrackRow>` render: wires `onRename` to call both `update(track.index, { trackName })` (editor state) and `useStore.getState().updateTrack(track.index, { trackName })` (live store — updates Tracks panel and Mixer Console immediately).

**`electron/main.ts`:**
- `editor:save` handler: added `trackNames?: Record<number, string>` to payload type.
- After merge step: builds `rawIdxToName` (raw MIDI index → name) from `payload.trackNames` + `noteTrackIndices`; computes `includedInOrder`; strips old `ORFEO_TRACK_NAME:*` events from `midi.header.meta`; pushes new `{ type: 'text', text: 'ORFEO_TRACK_NAME:N:name', ticks: 0 }` entries in output-track order. Format round-trips cleanly through `@tonejs/midi`'s `toArray()`.

**`src/components/Mixer/ChannelStrip.tsx` and `src/components/TrackPanel/TrackPanel.tsx`:**
- Both already updated in a prior session to read `track.trackName` — confirmed in place.

**Storage format:**
- `ORFEO_TRACK_NAME:N:name` stored as type-0x01 text meta-event in `midi.header.meta` at ticks=0, one per output track. N is 0-based output track index (matching parser's track array). Standard DAWs ignore type-0x01 header events; Orfeo recognises the prefix on load.

---

### 21. 7. 2026 — Loop region overhaul: waterfall overlay, Alt+drag, draggable boundaries, tooltips

**Bar counter fix (`TopBar.tsx`):**
- `currentBar` span: added `minWidth: '3ch'` + `display: 'inline-block'` + `textAlign: 'right'` — reserves space for 3 digits at all times so the counter growing from 1→2→3 digits no longer shifts the playback controls.

**Loop region bar-range popup (`LoopRegionStrip.tsx`):**
- Added `LongPressChevron` component (identical pattern to `LongPressArrow` in TopBar): mousedown fires once immediately, hold for 400ms starts an accelerating repeat interval (120ms → 40ms). Wired to all four chevrons in the From/To popup — no longer requires repeated individual clicks.

**Alt+drag free selection in the loop region strip (`LoopRegionStrip.tsx`):**
- Added `freeSnap: boolean` field to `DragState`. Set from `e.altKey` on `handleMouseDown`.
- In `onUp`: when `drag.freeSnap` is true, skips `snapToBar()` and commits raw times — allows sub-bar / beat-level precision. Normal drag still snaps to bar boundaries.

**Waterfall overlay (`PianoRoll.tsx`):**
- New `LoopOverlay` component rendered as an HTML `div` with `position: absolute; inset: 0; pointer-events: none` inside the PianoRoll container. Never touches PixiJS internals.
- Time→Y mapping: `timeToPct(t) = PLAYHEAD_RATIO * 100 − ((t − currentTime) / visibleSecs) * (PLAYHEAD_RATIO * 100)` — mirrors the PixiJS render formula.
- Renders: amber tinted band + two 2px amber boundary lines (loopEnd at top, loopStart at bottom). Fill and line opacity increase when `loopRegionActive` is true.
- Boundary lines: wrapped in a 12px hit-area div (`transform: translateY(-6px)`) with `cursor: ns-resize`. `onMouseDown` sets `draggingRef.current` to `'end'` or `'start'`. Global `mousemove`/`mouseup` handlers (registered once in `useEffect`) read live values from `useStore.getState()` and call `setLoopRegion()` on each frame.
- **Alt+drag to draw new region**: tracks `altDown` state via `keydown`/`keyup` listeners. When `altDown`, root overlay switches to `pointer-events: auto` + `cursor: crosshair`. `onMouseDown` seeds `newDragRef.current = { anchorTime }`. `onMove` updates the region live from anchor to current mouse position. `onUp` clears the drag.
- Boundary handle `onMouseDown` calls `e.stopPropagation()` — takes priority over the new-region handler even when Alt is held.

**Playhead color (`PianoRoll.tsx`):**
- PixiJS playhead fill changed from `0xe8a027` (amber) to `0xc6c8c8` (`--text-default`, light grey) to visually distinguish the playhead line from the amber loop region boundaries.

**Loop activation behaviour (`TopBar.tsx`):**
- Loop icon `onClick`: when toggling loop ON and `loopStart !== null`, calls `seek(loopStart)` — positions the playhead at the start of the selection without forcing playback. Space / play button still controls play/pause.

**Tooltips and double-click reset:**
- `LoopRegionStrip.tsx` canvas: dynamic `title` — "Click outside selection to reset · Drag handles to adjust" when a selection exists; "Drag to select a bar range · Alt+drag on waterfall for precise timing" otherwise. `onDoubleClick` calls `clearLoopRegion()`.
- `LoopOverlay` root div: `title="Drag to select loop region · Double-click to reset"` when `altDown`. `onDoubleClick` calls `clearLoopRegion()`.
- Both boundary handle divs: `title="Drag to adjust · Double-click to reset"` + `onDoubleClick` → `clearLoopRegion()`. These always have `pointer-events: auto` so double-click reset works without holding Alt.

---

### 19. 7. 2026 — MIDI Editor column rework, modal header unification, z-index focus

**MIDI Editor — column layout:**
- `MidiEditor.tsx`: introduced shared constant `ROW_COLS = '44px 1fr 44px 44px 220px'` used by both the header row and every `TrackRow`, so columns are always pixel-perfectly aligned.
- New column order: **Include | Track | Merge | Split | Assign Instrument** (previously Include | Merge | color-bar spacer | Track | Assign Instrument).
- Split button moved out of the Track name row and into its own dedicated grid column. It is now a `24×24` square button with the same border/color/hover style as the Merge button. Tracks that cannot be split (drums, merged, already split) render an empty `<div />` placeholder to keep grid alignment.
- Color bar (4×32px) moved from its own 8px spacer column into the Track cell as a flex child to the left of the name text.
- `track.name` (raw MIDI name) replaced with `track.gmName` (resolved GM instrument name) in TrackRow display — same fix as MixerConsole's `ChannelStrip`.

**Modal header unification (`MidiEditor.tsx`, `MixerConsole.tsx`):**
- `MidiEditor.tsx` header: `OrfeoMark height={16}` → `height={22}` (matches Console). Title: `fontWeight: 700`, `letterSpacing: '0.14em'`, `textTransform: 'uppercase'` (matches Console style). Close button: replaced 20×20 bordered ghost button (`X size={12} strokeWidth={1.8}`, hover to `#c05050`) with Console's borderless style (`X size={16}`, `color: #505068`, hover to `var(--text-default)`).
- `MixerConsole.tsx` title: `fontSize: 10` → `fontSize: 'var(--text-sm)'` (12px) — matches MidiEditor title size.

**Click-to-front z-index (`src/utils/modalFocus.ts`):**
- New utility module: module-level counter `_nextZ = 9900`; `bringToFront()` increments and returns the new value.
- Both `MidiEditor` and `MixerConsole` hold local `zIndex` state initialised to `MODAL_BASE_Z = 9900`. Each modal's outer container has `onMouseDown={() => setZIndex(bringToFront())}`. Whichever modal is clicked last gets the highest z-index and renders on top.
- `InstrumentPicker` dropdown z-index raised from `9999` to `50000` to always clear the floating modals regardless of click count.

**Followup fixes (same session):**
- `TopBar.tsx`: VSep separator before TIME/METRONOME/MIDI section — removed `alignSelf: 'flex-end', marginBottom: 12` so it inherits the TopBar root's `alignItems: 'center'` and sits vertically centred.
- `MixerConsole.tsx`: width formula corrected by `+2` (1px left + 1px right `border: 1px solid` with `border-box` sizing was eating 2px from content area, causing the 5th/7th strip to overflow and trigger the horizontal scrollbar).
- `MidiEditor.tsx`: Split icon size corrected to `size={11}` (same as Merge) — previously bumped to 16 which made the button rect-shaped.

---

### 19. 7. 2026 — Bug fixes: TopBar, Mixer Console, MIDI Editor

**TopBar:**
- `VolumeKnob.tsx`: replaced dot-arc SVG (filled circles around the ring + dark dot notch) with line ticks + triangle notch — now identical rendering to `MixerKnob`. Constants: TICK_INR=14.5, TICK_LONG=4.0, STROKE_TICK=0.5, TRI_TIP_R/TRI_BASE_R/TRI_HW matching MixerKnob. Drag logic and outer layout unchanged.
- `TopBar.tsx`: replaced `<VSep />` (44px, full row height) before the TIME/METRONOME/MIDI section with an inline div matching the three neighbouring separators (`height: var(--button-height), alignSelf: flex-end, marginBottom: 12`). All separators in that section are now bottom-aligned at uniform height.

**Mixer Console:**
- `MixerConsole.tsx`: removed hardcoded `VISIBLE_STRIPS = 8` / `MODAL_W = 1216`. Modal width now computed reactively as `BODY_PAD * 2 + n * STRIP_W + (n−1) * STRIP_GAP + STRIP_GAP + MASTER_W` where `n = Math.min(tracks.length, MAX_STRIPS)`. Width shrinks for files with fewer than 8 tracks and caps at 8.
- `MixerConsole.tsx`: `sortedTracks` previously sorted by `a.index - b.index` (raw file order). Now sorted by GROUP_ORDER — same array as TrackPanel — with index as tiebreaker. Piano/keyboard groups appear first, drums last.
- `ChannelStrip.tsx`: `trackName` previously resolved to `parsedTrack?.name` (raw MIDI track name). Now resolves to `track?.gmName` (resolved GM instrument name from store), matching what TrackPanel displays.

**Audio engine — visibility/audio decoupled:**
- `useAudioEngine.ts` (lines in `updateMutedChannels` and `buildPlayer`): removed `!ts.visible` from all four audio-gate conditions. Hiding a track in the waterfall no longer silences it.
- `useSamplesEngine.ts` (lines in `scheduleTracks`): removed `!ts.visible` from both audio-gate conditions. Same fix.
- The eye button and MasterStrip's global hide-all now only affect piano roll visibility, not audio playback. Mute button remains the only audio gate.

**MIDI Editor:**
- `MidiEditor.tsx`: added `title` to Include button (`"Include or exclude this track from the saved file"`) and Merge button (`"Select two or more tracks to merge them into one"`). Changed `<Split size={10} />` to `size={11}` to match Merge icon size.

---

### 19. 7. 2026 — MIDI Playback Editor — rebuilt as floating modal

**Motivation:** The editor was a separate `BrowserWindow`, which caused it to appear as a distinct OS window in the Windows taskbar and made it impossible to apply the amber outer glow used by all other Orfeo panels (CSS `box-shadow` is clipped at the OS window boundary).

**Architecture change — removed:**
- `editorWin: BrowserWindow` and `_editorData` module-level variable in `electron/main.ts`
- `ipcMain.handle('editor:open', ...)` — created the BrowserWindow
- `ipcMain.handle('editor:getData', ...)` — returned `_editorData` to the renderer
- `ipcMain.handle('editor:close', ...)` — closed the window
- `editor:closed` IPC event (sent to main window on BrowserWindow close)
- `midi:reloadFile` IPC event send from `editor:save` and `editor:split` — renderer now reloads inline
- `electron/preload.ts`: removed `openMidiEditor`, `getMidiEditorData`, `closeMidiEditor`, `onMidiReload`, `onEditorClosed`
- `src/types/index.ts`: removed those five from `window.electronAPI`
- `src/App.tsx`: removed `if (window.location.hash === '#/editor') return <MidiEditor />` hash route; removed `onMidiReload` listener useEffect
- `src/components/TrackPanel/TrackPanel.tsx`: removed `editorOpen` local state, `onEditorClosed` listener, and the full IPC-based `handleOpenEditor` function

**Architecture change — adapted:**
- `ipcMain.handle('editor:save', ...)`: now reads `filePath` from payload (not `_editorData`); returns `{ ok, message, filePath, fileName, base64 }` instead of sending `midi:reloadFile`
- `ipcMain.handle('editor:split', ...)`: same pattern — `filePath` from payload; returns file data on success
- `src/types/index.ts`: updated `saveMidiEditor` and `splitMidiEditor` return types to include optional `filePath`, `fileName`, `base64`

**New floating modal — `src/components/MidiEditor/MidiEditor.tsx`:**
- Full rewrite. Same architecture as `ChordExplorer` / `MixerConsole` / `FloatingKeyboard`
- `position: fixed`, `760 × 620px`, draggable title bar, `.orfeo-modal-glow` class
- Reads `midi`, `tracks`, and all `splitBreakpoint*` values from Zustand store — no IPC data fetch on mount
- `buildRows()` helper constructs `EditorTrack[]` from store state; called on open and on unmerge
- Re-initialises state on every open (`useEffect` on `midiEditorOpen`) so track list always reflects current file
- Centred on first open; position persists across closes within the session
- `handleUnmerge`: rebuilds from store state (replaces async `getMidiEditorData()` call)
- `handleSave`: passes `filePath: state.filePath` in payload; on success calls `reloadFile(base64, fileName, filePath)` inline then `setMidiEditorOpen(false)` after 1.2s
- `handleSplitRequest` / `handleSplitConfirm`: two-step split — clicking the split icon arms a confirmation toolbar; confirming executes; modal stays open after split so user can review the result
- Cancel button and title-bar X both call `setMidiEditorOpen(false)`
- `reloadFile()` mirrors `loadFileIntoPlayer` in App.tsx: `parseMidiBuffer` → `setMidi` → key detection → `setDetectedKey`
- `InstrumentPicker` dropdown unchanged; uses `position: fixed` to escape `overflow: hidden`

**Store — `src/store/index.ts`:**
- Added `midiEditorOpen: boolean` / `setMidiEditorOpen: (open: boolean) => void` to interface and implementation

**TrackPanel — `src/components/TrackPanel/TrackPanel.tsx`:**
- `handleOpenEditor` now calls `useStore.getState().setMidiEditorOpen(true)` — zero serialisation, zero IPC
- Buttons reference `midiEditorOpen` from store instead of local `editorOpen` state for amber highlight and cursor
- Removed `useState`, `useEffect` imports that were only used for editor state

**App.tsx:**
- `<MidiEditor />` rendered permanently alongside `<MixerConsole />` (hooks run even when returning null, so state re-initialises correctly on open)
- `parseMidiBuffer`, `detectKeyFromTracks`, `parseKeySignature` imports retained — still used by `loadFileIntoPlayer`

---

### 19. 7. 2026 — Mixer channel VU — solid-color segmented bars per track

**`src/components/Mixer/ChannelStrip.tsx`**
- Reverted wave/breathing display in favour of segmented bars, now rendered in the track's accent colour.
- `drawVU(canvas, level, color, segs, canvasH)` replaces `drawWave`. Active segments fill solid at `globalAlpha 1`; inactive at `0.08`. No glow, no breathing, no zone gradient.
- Removed refs: `breathPhase`, `breathAmp`. Removed breathing block from rAF loop.
- Restored `vuSegs = Math.max(5, Math.floor(vuCanvasH / SEG_UNIT))`.
- rAF deps: `[vuSegs, vuCanvasH]` (was `[vuCanvasH]`).
- Constants `SEG_H = 4`, `SEG_GAP = 2`, `SEG_UNIT = 6`, `VU_W = 16` retained at top of file.
- Level decay (`−0.013/frame`) and velocity-driven `vuLevel` subscribe logic unchanged.

**`src/components/Mixer/MasterStrip.tsx`**
- VU toggle label corrected from `'FFT'` → `'Bars/FFT'`; toggle `title` attrs capitalised.
- Wave display on MasterStrip left untouched.

---

### 19. 7. 2026 — Mixer channel-strip CC wiring — chorus, reverb, pan, volume

**Root cause:** ChannelStrip knobs (chorus, reverb, pan) and the volume fader were wired to plain React `useState` setters only — no audio engine calls. Deferred from the original visual-shell pass and now completed.

**`src/hooks/useSamplesEngine.ts`**
- Added `setChannelChorus(ch, value)` → CC93 on a single MIDI channel
- Added `setChannelReverb(ch, value)` → CC91 on a single MIDI channel
- Added `setChannelPan(ch, value)` → CC10 on a single MIDI channel; value −1…+1 bipolar → 0–127 (64 = center), matching the master pan formula
- Added `setChannelVolume(ch, value)` → CC7 on a single MIDI channel; value 0…1 → 0–127
- All four guard on `!_synth || !_synthReady` and wrap the call in try/catch, matching the master function pattern
- `ch` is the MIDI channel from the parsed track (`track.channel`, 0-based from the file) — NOT `trackIndex`

**`src/components/Mixer/ChannelStrip.tsx`**
- Imports the four new functions from `useSamplesEngine`
- Derives `midiChannel = (parsedTrack as any)?.channel ?? 0` alongside existing `trackName`/`trackColor`
- Renamed `setChorus/setReverb/setPan` state setters to `setChorusState/setReverbState/setPanState` to avoid name collisions
- Added `handleChorus`, `handleReverb`, `handlePan` callbacks (each calls the state setter + the engine function, with `midiChannel` in deps)
- Volume fader `onMove`: now calls `setChannelVolume(midiChannel, v)` alongside `setVolume(v)`
- Knob `onChange` props updated: `setChorus/setReverb/setPan` → `handleChorus/handleReverb/handlePan`

---

### 19. 7. 2026 — Mixer wave VU polish — glow, peak-hold, track color, idle breathing

**`src/components/Mixer/ChannelStrip.tsx`**
- Replaced segmented bars VU (`drawVU`) with smooth wave fill (`drawWave`). Canvas renders a single filled shape from the bottom to the current level — no segments.
- Removed: `SEG_H`, `SEG_GAP`, `SEG_UNIT`, `METER_GREEN/YELLOW/ORANGE/RED` constants; `segColor` helper; `vuAttack` ref; `vuSegs` derived value.
- **Track color fill**: gradient from `trackColor` at top to `rgba(0,0,0,0.08)` at bottom. `trackColor` comes from `parsedTrack.color ?? track.color ?? '#808080'`, kept current via `colorRef` + `useEffect` so the rAF closure sees color changes without restarting the loop.
- **Glow**: `ctx.shadowColor = trackColor; ctx.shadowBlur = 10 * dpr` set before `ctx.fill()`, cleared immediately after — contained within canvas pixel buffer.
- **Peak-hold line**: `vuPeak` ref, decays at `−0.003/frame` (≈5.5s from 1→0 at 60fps, independent of and slower than `vuLevel`'s `−0.013/frame`). Drawn as a 2px bright line at `H * (1 − peak)` using the track color at `globalAlpha 0.9`.
- **Idle breathing**: `breathPhase` increments `+0.018/frame` (~5.8s/cycle); `breathAmp` lerps toward `0.018` when `vuLevel < 0.04` and toward `0` when active (fade rate `0.02/frame` → ~1.7s engagement lag). `Math.sin(breathPhase) × breathAmp` added to displayed level each frame.
- Subscribe: removed `vuAttack` assignment; added `vuPeak` update when `maxVel > vuPeak.current`.
- rAF deps reduced from `[vuSegs, vuCanvasH]` to `[vuCanvasH]`.

**`src/components/Mixer/MasterStrip.tsx`**
- `drawWave` signature extended: `(canvas, levels, peaks, breathOffsets, canvasH, canvasW)`.
- **Glow**: `ctx.shadowColor = METER_RED; ctx.shadowBlur = 14 * dpr` set before `ctx.fill()`, cleared after — peaks bloom red.
- **Peak-hold lines**: `wavePeaks` ref (8 values), set in subscribe when `targets[i] > wavePeaks.current[i]`, decayed at `−0.003/frame` in rAF. Drawn as 2px white (`globalAlpha 0.72`) lines centered at each band's `pts[i].x` position, `BAR_COL_W` wide.
- **Idle breathing**: same pattern as ChannelStrip but per-band — `breathOffsets[i] = sin(breathPhase + i × 0.5) × breathAmp` creates a rolling undulation across the 8 bands when signal is absent, rather than all bands pulsing in sync.
- **Breathing offsets applied before computing `pts`** — bezier smoothing then follows the offset shape naturally.
- New refs: `wavePeaks`, `breathPhase`, `breathAmp` (all initialized to 0).

---

### 19. 7. 2026 — Mixer Console polish — window-shade minimize, VU label rename

**`src/components/Mixer/MixerConsole.tsx`**
- Window-shade minimize: outer div is now always `display: mixerOpen ? 'flex' : 'none'`; only the body div gets `display: mixerMinimized ? 'none' : 'flex'`. Header bar stays visible and draggable at its current screen position when minimized — matching standard floating-window UX.
- Header `onDoubleClick`: calls `setMixerMinimized(false)` when minimized — restores without needing to find the icon.
- Header `borderBottom`: suppressed (`none`) while minimized so the header floats cleanly.
- (–) button changed from `setMixerMinimized(true)` to `setMixerMinimized(!mixerMinimized)` — acts as a toggle (Minimize / Restore). `title` is dynamic: `'Restore'` when minimized, `'Minimize'` otherwise.

**`src/components/Mixer/MasterStrip.tsx`**
- VU toggle label is now dynamic: renders `'Wave'` or `'FFT'` (bars mode renamed from `'Bars'`) in amber bold (`color: 'var(--text-amber)'`, `fontWeight: 700`). Uppercase via `textTransform: 'uppercase'`.
- Toggle track stays always-dark (`background: '#303048'`) — no color flip on click.
- Toggle dot stays always amber (`background: 'var(--text-amber)'`) — only `left` transitions (`transition: 'left 0.15s'`). Visual state communicated by dot position alone, not color.
- `vuDisplayMode === 'bars'` branch label updated from `'Bars'` to `'FFT'`; tooltip updated to `'Switch to bars/FFT'`.

---

### 19. 7. 2026 — Mixer Console Round 2 — VU fixes, wave mode, real minimize

**`src/store/index.ts`**
- Added `mixerMinimized` / `setMixerMinimized`, `chordExplorerMinimized` / `setChordExplorerMinimized`, `scaleExplorerMinimized` / `setScaleExplorerMinimized` to `OrfeoStore` interface and body.
- Added `vuDisplayMode: 'bars' | 'wave'` / `setVuDisplayMode` (global, shared by MasterStrip).
- Modified `setMixerOpen`, `setChordExplorerOpen`, `setScaleExplorerOpen`: when called with `true`, also clears the corresponding minimized flag — ensures re-open via icon always restores from minimized state without a stale-state race.

**`src/App.tsx`**
- Ctrl+Shift+M toggle is now 3-way: minimized → restore (`setMixerMinimized(false)`); open → close (`setMixerOpen(false)`); closed → open (`setMixerOpen(true)`).

**`src/components/Mixer/MixerConsole.tsx`**
- Removed muted-first sort: strips now always render in stable `track.index` order — muting never causes reflow.
- Minimize (–) button now calls `setMixerMinimized(true)` instead of `setMixerOpen(false)`. Console stays mounted with all state intact (position, knobs, scroll). Display guard: `mixerOpen && !mixerMinimized`.
- Close (×) still calls `setMixerOpen(false)` which clears minimized via the modified action.

**`src/components/Mixer/ChannelStrip.tsx`**
- **VU attack color fix**: replaced `rgb(180+75t, 220+35t, 100+80t)` formula with `segColor(i, segs)` at `alpha = 0.5 + 0.5 * attack`. Top segments now flash the correct zone color (red) instead of white/yellow.
- **Full-strip mute overlay**: added `position: 'relative'` to root div. When `muted`, an absolute `rgba(0,0,0,0.45)` overlay covers the entire strip with `pointerEvents: 'none'`. M/S/Eye/Kbd row raised to `zIndex: 2` — M button stays fully bright and clickable above the overlay.

**`src/components/Mixer/MasterStrip.tsx`** (VU refactor)
- Removed `drawMono` and `drawSpectro`. Added `drawBars` (aggregate pitch-band columns, same column geometry as old spectro) and `drawWave` (smooth bezier-filled gradient wave).
- Removed per-track column mapping (`SPEC_COLS = 8` slot-by-track). Replaced with `BAND_COUNT = 8` pitch bands covering MIDI 21–108 in 11-semitone steps. Subscribe now scans ALL non-muted tracks' notes, maps each sounding note by pitch to its band, and takes the max velocity per band. Works correctly for any track count.
- Attack color bug fixed in `drawBars`: same `segColor` flash fix as ChannelStrip.
- Wave mode: separate `waveTargets` and `waveLevels` refs. Subscribe sets `waveTargets` on peak; rAF loop decays `waveTargets` and lerps `waveLevels` toward them at 0.12/frame — produces fluid eased motion without audio FFT.
- `vuDisplayMode` read from store (global); toggle updates store. Local `vuMode` state removed.
- Removed channel-number label row below VU (labels 1–8 no longer meaningful in aggregate mode); `labelReserve` eliminated, giving canvas ~16px extra height.

**`src/components/ChordExplorer.tsx`**
- Added `Minus` import from lucide-react.
- Added `chordExplorerMinimized` / `setChordExplorerMinimized` store reads.
- Added (–) minimize button in header, left of close ×. Calls `setChordExplorerMinimized(true)`.
- Root div: `display: chordExplorerMinimized ? 'none' : 'flex'` — component stays mounted with all state (search, selected chord, progression) when minimized. Early `return null` still fires on real close (`chordExplorerOpen = false`).

**`src/components/ScaleExplorer.tsx`**
- Same minimize pattern as ChordExplorer: `Minus` import, `scaleExplorerMinimized` store reads, (–) button, `display: none` when minimized.

---

### 19. 7. 2026 — Mixer Console Stage 5 — draggable modal, real trigger, global controls

**`src/store/index.ts`**
- Added `mixerOpen: boolean` + `setMixerOpen: (open: boolean) => void` to `OrfeoStore` interface and store body (same pattern as `chordExplorerOpen`). Not reset on file load — console stays open across MIDI swaps.

**`src/App.tsx`**
- Removed `showMixerDev` local state.
- `Ctrl+Shift+M` handler now reads/writes `mixerOpen` directly via `useStore.getState()`.
- `<MixerConsole />` is now always rendered with no props — reads state from store.

**`src/components/TrackPanel/TrackPanel.tsx`**
- Both "coming soon" `SlidersVertical` buttons (collapsed icon strip + open icon strip) are now wired: `onClick={() => useStore.getState().setMixerOpen(true)}`, title "Console", amber hover, normal opacity/cursor.

**`src/components/Mixer/MixerConsole.tsx`** (major rework)
- Props removed — reads `mixerOpen`/`setMixerOpen` from store.
- `everOpened` state: component never mounts until first open (avoids rAF cost at startup); never unmounts after that — internal state (knob values, scroll position, drag pos) is fully preserved across open/close cycles.
- **No `minimized` state**: both Minimize (`<Minus>`) and Close (`<X>`) buttons call `setMixerOpen(false)`. `everOpened` keeps the component mounted. Re-opening calls `setMixerOpen(true)` which flips `display` back to `flex` — no stale state risk.
- Removed backdrop overlay — modal is now a free-floating `position: fixed` window.
- `pos` state `{x, y}` initialized to viewport center; `startDrag` header mousedown handler (window mousemove/mouseup pattern from LockedChordModal).
- Button group has `onMouseDown={e.stopPropagation()}` to prevent accidental header drag when clicking minimize/close.
- Fixed `width: 1216px` — derived: `2×16 (body-pad) + 8×120 (strips) + 7×8 (inter-strip gaps) + 8 (body-gap) + 160 (master) = 1216`. Exactly 8 channel strips visible before horizontal scroll.
- Title: "Console". `<OrfeoMark height={22} />` added to header left corner.
- Escape key calls `setMixerOpen(false)`.

**`src/components/Mixer/MasterStrip.tsx`** (two new rows, height 574px)
- Added **global icons row** (36px, between VU toggle and global-icons): three `IBtn` buttons — Mute All (`VolumeX`/`Volume2`, red active), Show/Hide Waterfall All (`Eye`/`EyeClosed`, amber active), Show/Hide Keyboard All (mini piano SVG, amber active). Each is an all-or-nothing toggle. Calls `updateTrack` for every loaded track.
- Added **mute-filter toggle row** (34px): clone of the amber "All tracks / Selection" button from TrackPanel header. Reads `autoMuteNonKeyboard`, `setTrackMuteFilter`, computes `isCurrentlyFiltered` identically to TrackPanel. Shown only when `autoMuteNonKeyboard` is true.
- Added `EyeClosed`, `PianoIcon`, `IBtn` helpers (matching ChannelStrip implementations exactly).
- Layout fixed rows (top→bottom): Header 30 + Spacer 8 + VU toggle 28 + Spacer 8 + Icons 36 + Mute-filter 34 + marginBottom 8 + FX 56 + Tone 44 = 252px fixed. Remaining 322px shared: VU `flex: 1.3` (~127px, 16 segments) + MV `flex: 2` (~195px).
- VU section `flex: 1.3` (up from `flex: 1`): gives canvas ~99px → 16 segments (was 13, +3). MV tick ring fully visible — ring top at SVG_y 28.8px, clip reaches only SVG_y 2.8px.

---

### 18. 7. 2026 — Mixer Console Stage 4 — full modal shell

**`src/components/Mixer/MixerConsole.tsx`** (new)
- Full modal component: `{ open: boolean; onClose: () => void }` props.
- Backdrop: `position: fixed, inset: 0, rgba(0,0,0,0.85), zIndex: 9990`. Click backdrop to close; Escape key also closes.
- Modal: `width: min(90vw, 1400px)`, `--bg-modal`, `1px solid --border2`, borderRadius 10, drop shadow.
- Header (40px): `--bg-modal-header`, `borderBottom 1px --border`. Left: "MIXER CONSOLE" amber JetBrains Mono label. Right: `<X size={16} />` close button. Matches ChordExplorer/ScaleExplorer header convention.
- Body: 16px padding all sides, flex row, `gap: 8px`.
- **Scrollable channel strip area**: `flex: 1`, `overflowX: auto`, flex row with `gap: 8px`. Tracks sorted via `useMemo`: unmuted first (stable by `index`), muted at end. Empty state message when no MIDI loaded.
- **Drag-to-pan**: `onMouseDown` records `dragStartX` + `scrollLeft`; `mousemove`/`mouseup` attached to `document` during pan so pointer can leave the row. Cursor switches `grab` ↔ `grabbing` via `useState`. Vertical mouse wheel mapped to `scrollLeft` for horizontal scroll.
- **Master strip**: `flexShrink: 0` wrapper, always visible at the fixed right end — does not participate in horizontal scroll.
- Scrollbar: `.mixer-scroll` class — 4px height, transparent track, `--border2` thumb.

**`src/App.tsx`**
- Replaced direct `ChannelStrip` + `MasterStrip` imports and inline dev overlay with `import MixerConsole` + `<MixerConsole open={showMixerDev} onClose={…} />`.
- `showMixerDev` state and Ctrl+Shift+M shortcut unchanged.

**`src/index.css`**
- Added `.mixer-scroll` scrollbar rules (4px, thin, dark theme, hover brightens thumb).

---

### 18. 7. 2026 — Mixer Console — ChannelStrip + MasterStrip

**`src/components/Mixer/MixerKnob.tsx`** — geometry redesign + new props
- Replaced dot-circle tick marks with radial line ticks. All ticks share `TICK_INR = 14.5` (inner edge, bottom-aligned); length distinguishes major from minor (`TICK_LONG = 4.0`, `TICK_SHORT = 1.8`). `STROKE_TICK = 0.5` hairline stroke.
- Replaced circle notch indicator with filled triangle. Tip/base computed from `NOTCH_R` with perpendicular geometry; fills with `var(--bg-deep)` against the amber knob body.
- **`dotCount?: number`** (default 7) — number of tick marks around the arc.
- **`tickMajorEvery?: number`** (default 0 = all same) — every Nth tick renders at `TICK_LONG`; others at `TICK_SHORT`.
- **`tickScale?: number`** (default 1) — multiplies both `TICK_LONG` and `TICK_SHORT`. Used on master volume (0.5) to halve tick height at large render size without affecting other knobs.
- **`triScale?: number`** (default 1) — scales triangle indicator toward `NOTCH_R` axis. `tip_r = NOTCH_R + (TRI_TIP_R - NOTCH_R) × triScale`; similarly for base and half-width. Master volume uses `triScale={0.5}`.
- **`label?: string`** — renders a dim uppercase 9px JetBrains Mono label below the SVG.

**`src/components/Mixer/ChannelStrip.tsx`** — full implementation
- Dimensions: `120 × 574 px`. Layout (top → bottom): track name bar (30px) → Chorus (66px) → Reverb (66px) → Pan (66px) → M/S/Eye/Kbd row (46px) → fader section (flex:1 ≈ 250px) → VOLUME label (24px) → track pill (26px).
- **Props**: `{ trackIndex: number }` — reads all state from store via `useStore` selectors. Derives `track` (TrackState) and `parsedTrack` from `trackIndex`.
- **Knob wiring**: Chorus/Reverb/Pan knobs are local state only (audio engine wiring deferred). Pan is bipolar. Volume knob seeded from `track.volume` (CC7), pan from `track.pan` (CC10).
- **M/S/Eye/Kbd row**: `IBtn` component — `26 × 26 px` rounded-square with static `background: var(--bg-deep)`. Icon/font stays 14px; background never changes color. Gap 3px between buttons, row uses `justifyContent: center`. Eye icon: always `active={true}`, amber (`--text-amber`) when visible, red (`--status-error`) when hidden. M = red on mute, S = amber on solo, piano = amber when lit on keyboard.
- **Fader**: `HANDLE_W = 46`, `HANDLE_H = 20`, `FADER_TOP_PAD = 24` (reserves space for dB pill). Handle is an amber pill (`--text-amber`) with 3 grip score lines; greys to `--state-disabled` when muted. `FADER_TICK_COUNT = 13`, major every 4th. CSS `top` transition disabled during drag (instant response); re-enabled on mouseup.
- **dB pill**: `position: absolute, top: 0, zIndex: 1` above fader track, updates from `20 × log10(volume)`. Handle has `zIndex: 2`.
- **VOLUME label**: mirrors fader row flex structure (same `padding: 0 8px`, `VU_W` spacer, `gap: 6`, `flex:1 center`) so "Volume" text is geometrically centered on the fader track's vertical line, not the strip centerline.
- **VU meter**: `VU_W = 16 px` canvas, MIDI-event driven via `useStore.subscribe`. Scans `midi.tracks[trackIndex].notes` at `currentTime`; fires attack on level increase. rAF decay loop: level −0.013/frame, attack −0.06/frame. 4-zone color (green/yellow/orange/red). Canvas sized to `sectionH - 8` (8px top padding, 0 bottom).
- **CC-seeded defaults**: `chorus`/`reverb` init from `parsedTrack._cc93/_cc91`; `pan`/`volume` from `track.pan/track.volume` (seeded by store from `_cc10/_cc7`).

**`src/components/Mixer/MasterStrip.tsx`** (new file)
- Dimensions: `160 × 574 px`. Layout: header "MASTER" (30px) → VU flex:1 → VU display toggle (28px) → spacer (34px) → FX row Chorus+Reverb (72px) → Tone EQ (60px) → Master Volume (230px).
- **VU — spectrogram mode** (default): 8 columns × 14px wide, MIDI-event driven, same subscribe pattern as ChannelStrip. Column labels 1–8 below canvas. Toggle switches to mono (single centered column, max of all 8 levels).
- **VU toggle**: iOS-style amber pill (26×13px) with sliding white dot. Label "VU DISPLAY" below.
- **FX row**: Chorus + Reverb knobs side by side (size=52), "FX" micro-label centered between them. Both greyed on GM engine.
- **Tone EQ**: size=52 bipolar knob, label "Tone". Greyed on GM.
- **Master Volume**: size=200, `dotCount=36`, `tickMajorEvery=6`, `tickScale=0.5`, `triScale=0.5`. SVG extends 20px beyond strip on each side (clipped by `overflow:hidden`); the clipped region is pure empty SVG margin — tick ring fully visible with ~16px visual clearance. Label "MASTER VOLUME" below.

**`src/hooks/useSamplesEngine.ts`**
- Added `_filterNode: BiquadFilterNode | null` singleton. Created in `initSamplesEngine` as `highshelf` at 3000 Hz, gain=0 (flat). Audio chain: `_synth → _gainNode → _filterNode → _ctx.destination`.
- **`setMasterChorus(v)`**: broadcasts CC93 = `round(v × 127)` to all 16 channels.
- **`setMasterReverb(v)`**: broadcasts CC91 = `round(v × 127)` to all 16 channels.
- **`setMasterPan(v)`**: broadcasts CC10 = `round((v+1)/2 × 127)` to all 16 channels. Bipolar −1…+1 → 0–127 (64=center).
- **`setMasterTone(v)`**: sets `_filterNode.gain.value = v × 12` (±12 dB highshelf). Samples engine only.

**`src/utils/midiParser.ts`**
- Added `parseCC(n)` helper inside `forEach`: reads first occurrence of CC7/CC10/CC91/CC93 from `track.controlChanges[n]`. Attaches `_cc7/_cc10/_cc91/_cc93` as private fields on each parsed track. Values are @tonejs/midi normalized (0–1). CC10 center = 0.5.

**`src/store/index.ts`**
- `makeTrackState`: `volume` seeds from `(track as any)._cc7 ?? 1`; `pan` seeds from `((track as any)._cc10 - 0.5) * 2` when present, else 0.

**`src/index.css`**
- Added `--knob-tone: #5ba0c8` (steel-blue, distinct from `--knob-chorus` teal and `--knob-reverb` purple).

**`src/App.tsx`**
- Added `import MasterStrip`. Dev overlay (Ctrl+Shift+M) renders `<ChannelStrip trackIndex={0} />` + `<MasterStrip />` side by side with 8px gap. Guard changed to `showMixerDev && midi !== null`.

---

### 18. 7. 2026 — Loop Region strip fixes

**`src/components/LoopRegionStrip.tsx`**
- **Tick color** — corrected density tick fill from `#404058` (near-invisible against dark bg) to `#b5b7bc`.
- **Ticks blank after re-toggle** — `loopRegionEnabled` toggle fully unmounts/remounts `LoopRegionStrip`. The density `useStore.subscribe` callback only fires on future state changes, so on remount with no midi change `densityRef` stayed `[]` and no ticks were drawn. Fix: extracted subscriber body into `computeDensity`, call it immediately via `useStore.getState()` on mount, then subscribe for future changes.
- **Bar range popup position** — changed popup anchor from `right: 0` to `left: 0` so the popup drops below and to the right of the icon instead of leftward over the region strip.

---

### 13. 7. 2026 — Locked Chord modal: clear button no longer dismisses modal

**`src/components/LockedChordModal.tsx`**
- Added `modalOpen` local state (default `false`); a `useEffect` sets it `true` whenever `lockedKeys.size > 0`, replacing the old derived `isOpen = lockedKeys.size > 0` guard.
- Split the single `handleClose` into two callbacks: `handleClose` (X button — clears keys + sets `modalOpen false`) and `handleClear` (RotateCcw button — clears keys only, modal stays open showing `— — —`).
- Re-opening after clear: next Shift+click re-locks keys, `useEffect` fires, modal reopens at its last dragged position.

---

### 13. 7. 2026 — Replace EyeOff icon globally with custom EyeClosed SVG

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Removed `EyeOff` from lucide-react import.
- Added inline `EyeClosed` component (custom SVG — 5-path eye-closed design).
- Replaced both `<EyeOff>` usages: eye-toggle in `OptionRow` (size 14) and "Hide" button in Notation's display system (size 11).

**`src/components/TrackPanel/TrackPanel.tsx`**
- Removed `EyeOff` from lucide-react import.
- Added same inline `EyeClosed` component.
- Replaced `<EyeOff size={12} />` in track visibility toggle.

---

### 13. 7. 2026 — Fix EU chord root display for pitch class 10 (Bb → "B" not "H")

**`src/utils/chordDetection.ts`**
- Bug: `localizeChord()` ran two sequential `.replace()` calls for Central European naming — first `Bb → B`, then `B(?!b) → H`. The second call caught the `B` produced by the first, turning every Bb-rooted chord name (e.g. "Bbm") into "Hm" instead of the correct "Bm".
- Fix: replaced both calls with a single atomic pass `result.replace(/Bb|B/g, m => m === 'Bb' ? 'B' : 'H')`. The alternation tries `Bb` first at every position, so the newly-produced `B` is never revisited. Affects all display paths that go through `localizeChord()`: Locked Chord modal, playback chord bar, Chord Explorer, Scale Explorer.

---

### 13. 7. 2026 — Selective Tracks Playback reframe + Settings group persistence

**`src/store/index.ts`**
- `makeTrackState`: removed `autoMute` parameter — all tracks start unmuted on file load; selective filtering is user-initiated via the Track Panel button.
- `setMidi`: updated call to `makeTrackState(t)` (no second arg).
- `autoMuteNonKeyboard` default changed `false` → `true`; repurposed from "auto-mute on load" to "show/hide selective playback button in Track Panel". Comment updated.
- Added `settingsGroupsCollapsed: Record<string, boolean>` to `OrfeoStore` interface and store body; default: `midi-files-library` expanded, all other groups collapsed.
- Added `setSettingsGroupCollapsed(id, collapsed)` action.
- Full persistence wiring for `settingsGroupsCollapsed`: `_prevSettingsGroupsCollapsed` null-sentinel (JSON-stringified for comparison), subscriber diff/update/`setPrefs` payload, `restoreLibraryPrefs` (merges saved values onto defaults so new groups always have a fallback).

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- `CollapsibleSection`: added optional `collapsed?: boolean` and `onToggle?: () => void` props; controlled when provided, falls back to internal `useState` when not.
- Added `settingsGroupsCollapsed` / `setSettingsGroupCollapsed` selectors.
- All 7 `CollapsibleSection` instances now pass `collapsed` + `onToggle` from store.
- Renamed eye-toggle from "Piano, Bass & Drums Only" → "Selective Tracks Playback"; updated description to "When active, select if you want to hear all MIDI tracks or only Piano, Bass & Drums. Can be overridden manually."

**`src/components/TrackPanel/TrackPanel.tsx`**
- Added `autoMuteNonKeyboard` selector.
- Wrapped All Tracks / Selection amber button in `{autoMuteNonKeyboard && ...}` — button only renders when the Settings toggle is on.

---

### 13. 7. 2026 — Auto-mute setting + Track Panel filter toggle

**`src/store/index.ts`**
- Exported `DEFAULT_MUTED_GROUPS` so TrackPanel can read it without duplicating the set.
- Added `autoMuteNonKeyboard: boolean` (default `false`) to `OrfeoStore` interface and store body, with `setAutoMuteNonKeyboard` setter and `setTrackMuteFilter(filtered: boolean)` batch action.
- `makeTrackState` now takes a second `autoMute: boolean` argument; when `false` (the new default), all tracks start unmuted on file load.
- `setMidi` passes `get().autoMuteNonKeyboard` to `makeTrackState`.
- `setTrackMuteFilter`: single `set()` call mapping all tracks — `filtered` mode mutes every non-drum `DEFAULT_MUTED_GROUPS` track, `false` unmutes all.
- Full persistence wiring: `_prevAutoMuteNonKeyboard` null-sentinel, subscriber diff/update/`setPrefs` payload, `restoreLibraryPrefs`.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `autoMuteNonKeyboard` / `setAutoMuteNonKeyboard` selectors.
- New eye-toggle `OptionRow` at the bottom of the Audio section — label "Piano, Bass & Drums Only", description "Automatically mutes all other instrument tracks when a file loads." Default off (EyeOff/red), matching the `false` default.

**`src/components/TrackPanel/TrackPanel.tsx`**
- Imports `DEFAULT_MUTED_GROUPS` from store.
- Reads `setTrackMuteFilter` from store.
- `isCurrentlyFiltered` useMemo: `true` when every filterable (non-drum `DEFAULT_MUTED_GROUPS`) track has `muted === true` and at least one such track exists.
- Amber quick-toggle button in the Track Panel header (visible when a file is loaded): text "Selection" when filtered / "All tracks" when unfiltered; ▶ icon prepended in both states. Tooltip describes the action that clicking will take, not the current state. Clicking calls `setTrackMuteFilter(!isCurrentlyFiltered)`.

**`src/hooks/useAudioEngine.ts`**
- Promoted `_mutedCh` from a local variable inside `buildPlayer` to module scope; the JZZ player filter now reads the live module-level set.
- Added `updateMutedChannels()`: repopulates `_mutedCh` from current store state and rebuilds the key-lighting schedule from `currentTime` — no player rebuild, no audio gap, instant effect.
- Subscriber `tracksChanged` branch during playback: now calls `updateMutedChannels()` instead of `buildPlayer`. BPM and transpose changes still trigger a full `buildPlayer` rebuild (required for tempo/pitch timing). This is the "real-time JZZ filter callback" approach noted in CLAUDE.md.

---

### 13. 7. 2026 — Library amber highlight + right-click Remove from Library

**`src/store/index.ts`**
- Added `hiddenLibraryFiles: string[]` (default `[]`) and `hideLibraryFile(path)` to the store body. `hideLibraryFile` appends the path to the exclusion list (idempotent — no-op if already present). Follows the same undeclared-field convention as all other library state.
- Extended the `_favTimer` subscriber to also persist `hiddenLibraryFiles` alongside `libraryFavourites` in the same debounced `setPrefs` call.
- `restoreLibraryPrefs`: restores `hiddenLibraryFiles` via `useStore.setState` when found in prefs.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `FILENAME_SPAN_DEFAULT` / `FILENAME_SPAN_ACTIVE` constants above `LibraryPanel` — amber + weight 500 for the active row.
- `LibraryPanel` — new store reads: `midi` (for `_filePath`), `hiddenLibraryFiles`, `hideLibraryFile`.
- Derived `loadedFilePath = (midi as any)?._filePath` — full path comparison (normalised backslash → forward-slash) detects the currently loaded file independent of play/pause state.
- New state: `contextMenu: { path, x, y } | null` and `menuRef`.
- `useEffect` — attaches `mousedown` (outside-click) and `keydown` (Escape) listeners to `window` when context menu is open; cleans up on close.
- `handleContextMenu(e, filePath)` — `e.preventDefault()` + sets context menu position.
- `grouped` useMemo — filters `hiddenLibraryFiles` via `Set` lookup before grouping; `hiddenLibraryFiles` added to deps.
- All file rows (grouped library + demo): `isLoaded` comparison drives amber background (`var(--accent-amber-medium)`), amber `MarqueeText` span style, amber `FileMusic` icon, and `onContextMenu` handler.
- Context menu: `position: fixed` div with `ref={menuRef}` — escapes panel `overflow: hidden`; single "Remove from Library" button with amber hover; calls `hideLibraryFile` + closes.
- File list div: `onScroll={() => setContextMenu(null)}` closes context menu on scroll.
- **Scope note:** No un-hide UI yet — a "Show hidden files" toggle in Settings is the planned follow-up.

---

### 13. 7. 2026 — Drag & Drop onto Library sidebar (add-only)

**`src/components/SettingsPanel/SettingsPanel.tsx`** — all changes inside `LibraryPanel`:
- Added `isDragOver`, `dropError`, `dropErrorTimer` state/ref.
- `showDropError(msg)` — timed error display (2.5 s), cancels previous timer before setting a new one.
- `handleDragOver` — `e.preventDefault()` + `e.stopPropagation()` + sets `isDragOver`.
- `handleDragLeave` — `contains(relatedTarget)` guard to avoid flicker from child elements.
- `handleDrop` — validates `.mid`/`.midi` extension; rejects with inline message if no library folder configured; calls `getPathForFile` (preload `webUtils` bridge) for real OS path; normalised path check (case-insensitive, backslash-normalised) to detect inside/outside library; if outside: `copyMidiToLibrary` IPC (same channel as main-area drop, collision-safe); always rescans with `scanMidiFolder` → `setLibraryFiles`. Zero playback state touched.
- File list `<div>` gains `position: relative`, `onDragOver`, `onDragLeave`, `onDrop`.
- Amber border + tint overlay (`position: absolute, inset: 0, pointer-events: none`) shown while `isDragOver`.
- Error toast pinned `position: absolute, bottom: 8` inside the panel — does not escape the sidebar.

---

### 13. 7. 2026 — Drag & Drop MIDI files anywhere in the app

**`electron/main.ts`**
- Added `fs:copyMidiToLibrary` IPC handler — takes `(sourcePath, libraryFolder)`, copies the file into the library root with collision-safe numeric-suffix renaming (`Song.mid` → `Song (2).mid`), never moves or overwrites, returns the final destination path.
- Added `extname` to `path` import.

**`electron/preload.ts`**
- Added `webUtils` to Electron import.
- Exposed two new methods via `contextBridge`: `getPathForFile(file)` (calls `webUtils.getPathForFile` — returns the real OS path for a browser `File` object) and `copyMidiToLibrary(sourcePath, libraryFolder)`.

**`src/types/index.ts`**
- Added `getPathForFile: (file: File) => string` and `copyMidiToLibrary: (sourcePath: string, libraryFolder: string) => Promise<string>` to the `Window.electronAPI` interface.

**`src/App.tsx`**
- Added `useState`, `useCallback`, `useRef` imports.
- Three new state values: `isDragOver` (amber highlight overlay), `dropConfirmPath` (path held while confirm modal is open), `dropError` (ephemeral toast message).
- `showDropError(msg)` — shows error toast for 2.5 s, clears previous timer before setting a new one.
- `loadDroppedFilePath(filePath)` — calls `stop()`, reads `libraryFolder` from store, normalises paths (backslash → forward-slash, case-insensitive) to determine inside/outside library, copies if external, rescans library (`scanMidiFolder` → `setLibraryFiles`), loads via `store.loadLibraryFile(path)`. No auto-play.
- `handleDragOver` — `e.preventDefault()` + `e.stopPropagation()` + sets `isDragOver = true`.
- `handleDragLeave` — only clears `isDragOver` when pointer leaves the container entirely (guards with `e.currentTarget.contains(e.relatedTarget)`).
- `handleDrop` — validates `.mid`/`.midi` extension, gets OS path via `getPathForFile`, either shows confirm modal (if a file is loaded) or calls `loadDroppedFilePath` directly.
- Drop zone: the outer flex row (SettingsPanel + centre column + TrackPanel) gains `onDragOver`, `onDragLeave`, `onDrop`, `position: relative`.
- Amber border + subtle tint overlay rendered as `position: absolute, inset: 0, pointer-events: none` child of the drop zone while `isDragOver` is true.
- Error toast rendered `position: fixed, bottom: 32` — auto-dismissed, pointer-events: none.
- Confirm modal — dark panel, amber "Load File" button, ghost "Cancel" button; click outside = cancel.

---

### 10. 7. 2026 — Settings panel redesign: collapsible groups, eye-toggles, amber headers + v0.10.4

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `OptionRow` eye-toggle variant — name + Eye/EyeOff icon share one flex row (`justifyContent: space-between`); description sits below at `maxWidth: 85%` to keep breathing room from the icon. Green Eye = feature on, red EyeOff = feature off.
- Added `CollapsibleSection` component replacing all static `SectionHeader` instances. Click anywhere on the header row to expand/collapse; state is local `useState`; all groups default to expanded.
- Group header icon, label text, and chevron changed from `--text-inactive`/`--text-dimmest` → `var(--text-amber)` (applied once at the component level, affects all 7 groups).
- `OptionBtn` active-state color changed from amber → green (`var(--status-success)` border+text, `rgba(74, 144, 96, 0.13)` tint background). Added `activeColor?: 'success' | 'error'` prop for the Display / Hide button, which correctly stays red when active.
- Settings groups reorganised into 7 `CollapsibleSection`s in new order: MIDI Files & Library, Notation, Keyboard, Playback & Practice, Audio, Piano Roll, Appearance.
- Eye-toggle applied to: Demo folder, Chord Transcription, Show octave labels, Show note names on keyboard, Left / Right Hand, Chord Prompter, Loop region, Bar numbers.
- Added Keyboard Labels sub-divider within the Keyboard group separating range controls from label toggles.
- Description/hint prose normalised panel-wide: JetBrains Mono → Inter, raw pixel sizes (`9`, `10`) → `var(--text-xs)`, name color → `var(--text-default)`, description color → `var(--text-dimmest)`.

**`src/store/index.ts`**
- Added `showOctaveLabels: boolean` (default `true`) and `showNoteNamesOnKeyboard: boolean` (default `true`) to `OrfeoStore` interface and implementation.
- Both fields persisted via the existing null-sentinel subscribe callback; `restoreLibraryPrefs` restores both on cold start.

**Version:** `0.10.3` → `0.10.4`

---

### 9. 7. 2026 — Track Panel: full instrument names + marquee + guitar auto-mute + v0.10.3

**`src/components/MarqueeText.tsx`** *(new)* — shared `MarqueeText` component extracted from `SettingsPanel`'s local `MarqueeFilename`. Uses `ResizeObserver` to measure overflow; on hover, CSS-transitions the inner span by `translateX(-scrollAmt)` with duration `Math.max(1.5, scrollAmt / 40)` seconds. `spanStyle` prop lets callers control font/color while scroll mechanics are shared.

**`src/components/SettingsPanel/SettingsPanel.tsx`** — removed 30-line local `MarqueeFilename` function; replaced with a 3-line `MarqueeFilename` alias that delegates to `MarqueeText` with the same `text-xs / text-muted` style. Both library list call sites unchanged.

**`src/components/TrackPanel/TrackPanel.tsx`**
- `TrackRow` restructured from a single flex row to a three-row block layout:
  - **Row 1** — color bar + `MarqueeText` with `flex: 1`; instrument name has the full track content width (~192 px) to itself with no competing elements.
  - **Row 2** — `justifyContent: space-between`: track number on the left, M/S/👁/🎹 controls always visible on the right.
  - **Row 3** — MIDI channel + program info. Rows 2 and 3 indented 11 px (`paddingLeft: 11` = 3 px color bar + 8 px gap) to align with the name above.
- Instrument names now display in full for all standard GM names; marquee scroll-on-hover is a fallback only for names that genuinely overflow.
- Removed `rowHovered` state (hover-reveal controls experiment — reverted; controls are always visible in their own row).

**`src/store/index.ts`** — added `'guitar'` to `DEFAULT_MUTED_GROUPS`. Guitar (GM programs 24–31) was an original omission; it is now muted by default on file load alongside the other non-keyboard families. Unmuted by default: `piano`, `chromatic`, `organ`, `bass`, `drums` only.

**Version:** `0.10.2` → `0.10.3`

---

### 9. 7. 2026 — CSS Variable Rollout: Closing Pass + v0.10.2

**`src/index.css`** — 3 new tokens added to `:root`:
- `--text-dim-control: #606078` — dim control labels, inactive action icons
- `--border-row: #181822` — row separator borders within panels and editors
- `--bg-deep: #111116` — deepest floor layer, below `--bg-modal`

**Files updated — ~40 substitutions across 10 components:**

- **`ChordExplorer.tsx`** — `#2a2a3a`→`--state-hover-bg`, `#1a1a26`→`--bg-tile`, `#13131c`→`--bg-modal`, `#404055`→`--text-muted`, `#9090a8`→`--text-muted` (consolidation), `#606078`→`--text-dim-control`; border string `'1px solid #2a2a3a'` handled separately from standalone `'#2a2a3a'`
- **`ScaleExplorer.tsx`** — `#9090a8`→`--text-muted` in DOM spans and event handlers; Circle of Fifths SVG `stroke`/`setAttribute` calls excluded
- **`FloatingKeyboard.tsx`** — border string `#2a2a3a`→`--state-hover-bg`
- **`TopBar.tsx`** — `#111116`→`--bg-deep` (drag-region container), `#1a1a26`→`--bg-tile` (3 occurrences: search bg, bar-counter indicators)
- **`KeyboardControls.tsx`** — `#404055`→`--text-muted` (silent-zone divider line background)
- **`Keyboard.tsx`** — `#9090a8`→`--text-muted` (past/future chord spans in chord bar), `#111116`→`--bg-deep` (piano key container floor); `#2a2a35` border left intact (distinct value)
- **`LoopRegionStrip.tsx`** — `#9090a8`→`--text-muted` (icon button hover, popup header label)
- **`MidiEditor.tsx`** — `#9090a8`→`--text-muted`, `#181822`→`--border-row` (track row separators), `#606078`→`--text-dim-control` (merge button, split button, Cancel button)
- **`SettingsPanel.tsx`** — `#9090a8`→`--text-muted`, `#606078`→`--text-dim-control` (pick-folder button), `#181822`→`--border-row` (OptionRow, file row separators)
- **`TrackPanel.tsx`** — `#181822`→`--border-row`, `#9090a8`→`--text-muted`

**Intentional exclusions (SVG context, `var()` not supported):**
- `VolumeKnob.tsx` — `fill="#111116"` on SVG notch dot
- `ScaleExplorer.tsx` — `stroke="#2a2a3a"` on Circle of Fifths wedge rings and inner circle; `setAttribute('fill', '#2a2a3a')` on SVGPathElement hover

**Docs committed:** `docs/CSS_FINAL_SCAN.md`, `docs/CSS_TOKEN_CHEATSHEET.md` (scan results and token cheatsheet generated during rollout)

**Version:** `0.10.1` → `0.10.2`

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 8 — EmptyState + LockedChordModal

**`src/components/EmptyState.tsx`** — 5 substitutions (font colors + sizes only; layout/positioning/button structure intentionally excluded)

- **Color tokens:** `'#707088'` → `var(--text-dimmest)` (heading "No file open"); `'#404055'` → `var(--text-muted)` (subtitle)
- **Typography:** `fontSize: 13` → `var(--text-base)`, `fontSize: 12` → `var(--text-sm)` (subtitle), `fontSize: 11` → `var(--text-xs)` (Ctrl+O hint)
- **Kept as literals (Group C):** `fontSize: 15` (between `--text-base` 13px and `--text-lg` 16px — intentional size); `color: '#0f0f12'` (dark text on amber button — no dark-on-amber token); `color: '#2a2a38'` (ultra-dim hint, darker than all text tokens)

**`src/components/LockedChordModal.tsx`** — ~22 substitutions across layout, colors, event handlers

- **Color tokens (replace_all):** `'#e8a027'` → `var(--text-amber)` (JSX color props); `'#707088'` → `var(--text-dimmest)` (ordinal text, dim icon); `'#505068'` → `var(--text-inactive)` (close/clear buttons, play border)
- **Surfaces + structure:** `background: '#13131c'` → `var(--bg-modal)`; `border: '1px solid #2a2a3a'` → `var(--state-hover-bg)`; `borderRadius: 8` → `var(--radius-lg)`; `borderBottom: '1px solid #1e1e28'` → `var(--border)`; `border: '1px solid #505068'` → `var(--text-inactive)` (Play button); `borderRadius: 3` → `var(--radius-sm)`
- **Spacing:** `gap: 8` → `var(--space-2)`; `gap: 4` → `var(--space-1)` (controls row)
- **Event handler style mutations (replace_all):** `.style.color = '#e8a027'` → `'var(--text-amber)'`; `.style.color = '#707088'` → `'var(--text-dimmest)'`; `.style.color = '#505068'` → `'var(--text-inactive)'`; `.style.borderColor = '#e8a027'` → `'var(--text-amber)'`; `.style.borderColor = '#505068'` → `'var(--text-inactive)'`; targeted no-comma color in inversion ordinal span
- **Code comment:** `// ── Position state` added before `const [pos, setPos] = useState(...)`
- **Kept as literals (Group C):** `newColors.set(k, '#e8a027')` (functional keyboard key lighting — excluded per rollout rules); `boxShadow` rgba values (complex amber glow, no token); mixed padding values (10/6/2px — no tokens); font sizes 7/9/10/20; `gap: 5`

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 7 — VolumeKnob + LoopRegionStrip

**`src/components/VolumeKnob.tsx`** — 2 substitutions

- `LABEL_COL = '#707088'` → `'var(--text-dimmest)'` (module-level constant; inline `color: LABEL_COL` auto-updated via constant)
- `padding: '0 12px'` → `'0 var(--space-3)'` (outer wrapper)
- **Code comments:** `// ──` added before `VolumeKnob` export and `handleMouseDown` callback
- **Kept as literals (Group C):** `AMBER = '#e8a027'` + `AMBER_DIM = '#e8a02738'` (SVG `fill` presentation attrs — `var()` not supported; also functional state excluded per rollout rules); `fill="#111116"` notch dot (SVG attr); `gap: 5` / `gap: 1` / `fontSize: 8` (no matching tokens)

**`src/components/LoopRegionStrip.tsx`** — 13 substitutions across icon button, bars label, popup, inputs, chevrons, Apply button

- **Text/color (replace_all):** `'#e8a027'` (JSX color only, 6 occurrences) → `var(--text-amber)`; `'#707088'` → `var(--text-dimmest)` (From/To labels); `'#b0b0cc'` → `var(--text-dim)` (input text); `'#505068'` → `var(--text-inactive)` (icon btn inactive + leave handler)
- **Backgrounds (replace_all + targeted):** `'#0e0e18'` → `var(--bg-row)` (input fields, Δ2 Group B); `'#1a1a24'` → `var(--bg-tile)` (popup bg, Δ2 Group B)
- **Typography:** `fontSize: 12` → `var(--text-sm)` (inputs); `fontSize: 11` → `var(--text-xs)` (Apply button)
- **Border:** `'1px solid #e8a02750'` → `var(--accent-amber-strong)` (Apply button border, Δ5 alpha, imperceptible)
- **Code comment:** `// ──` added before `LoopRegionStrip` export
- **Kept as literals (Group C):** All canvas `ctx.fillStyle` values (canvas can't resolve CSS vars; density ticks, loop overlay, handles, playhead all excluded per rollout rules); `'#9090a8'` hover grey (no token); `'#2e2e42'` popup/input borders (sits between `--border2` and `--state-hover-border`, neither is an exact semantic fit); `'#e8a02718'`/`'#e8a02732'` Apply btn bg (custom 9%/20% alpha, between tiers); `borderRadius: 4/6`, `gap: 6/10`, font sizes 9/10 (no tokens)

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 6 — SettingsPanel + TrackPanel

**`src/components/SettingsPanel/SettingsPanel.tsx`** — ~60 substitutions across BetaBadge, SectionHeader, OptionRow, OptionBtn, LibraryPanel, SettingsPanel, ZoomStepBtn, AppBgBtn

- **Color tokens (replace_all):** `'#0e0e16'` → `var(--bg-row)`, `'#1a1a26'` → `var(--bg-tile)`, `'#13131c'` → `var(--bg-modal)`, `'#2a2a3a'` → `var(--state-hover-bg)`, `'#303048'` → `var(--state-disabled)`, `'#505068'` → `var(--text-inactive)`, `'#707088'` → `var(--text-dimmest)`, `'#b0b0cc'` → `var(--text-dim)`, `'#e8a027'` → `var(--text-amber)`, `'#e8a02755'` → `var(--accent-amber-strong)`, `'#e8a02722'` → `var(--accent-amber-medium)`, `'#c0392b'` → `var(--status-error)`
- **Border strings (embedded):** `'1px solid #1e1e28'` → `var(--border)`, `'1px solid #252530'` → `var(--border2)`, `'1px solid #1a1a26'` → `var(--bg-tile)`, `'1px dashed #303048'` → `var(--state-disabled)`, `'1px solid #e8a02755'` → `var(--accent-amber-strong)`, `'2px solid #e8a027'` → `var(--text-amber)`
- **Typography:** `fontSize: 11` → `var(--text-xs)`, `fontSize: 12` → `var(--text-sm)`, `fontSize: 13` → `var(--text-base)` (split note display), `fontSize: 16` → `var(--text-lg)` (ZoomStepBtn ±)
- **Spacing:** `gap: 4` → `var(--space-1)` (all 16 occurrences), `gap: 8` → `var(--space-2)` (2 occurrences), `paddingLeft: 12` → `var(--space-3)` (tab bar)
- **Border radius:** `borderRadius: 5` → `var(--radius-md)` (pick folder button), `borderRadius: 3` → `var(--radius-sm)` (AppBgBtn color swatch)
- **Code comments:** `// ──` header comments added to SectionHeader, OptionRow, OptionBtn, handlePickFolder, handleRefresh, handleLoadFile, grouped useMemo, init useEffect, auto-init useEffect, ZoomStepBtn, AppBgBtn
- **Confirmed:** BetaBadge already uses `var(--status-error)` for color and border — no change needed
- **Kept as literals (Group C):** `#9090a8` (file/folder text, mid-grey); `#606078` (pick folder button); `#8080a0` (subfolder names); `#111120` (folder header hover); `#707060` (un-starred hover); `#35354a` (about legal text); `#4caf50`/`#f44336` (TranscriptIcon status — different from `--status-success/error`); font sizes 9/10 (below token minimum); `borderRadius: 4` (between token values); gap: 5/6 (between token values); SVG presentation attributes (`stroke="#e8a027"`)

**`src/components/TrackPanel/TrackPanel.tsx`** — ~25 substitutions across TrackPanel, TrackRow, IBtn

- **Color tokens (replace_all):** `'#0e0e16'` → `var(--bg-row)`, `'#1a1a26'` → `var(--bg-tile)`, `'#13131c'` → `var(--bg-modal)`, `'#252530'` → `var(--border2)`, `'#1e1e28'` → `var(--border)`, `'#505068'` → `var(--text-inactive)`, `'#707088'` → `var(--text-dimmest)`, `'#e8a027'` → `var(--text-amber)`, `'#303048'` → `var(--state-disabled)`
- **Typography:** `fontSize: 11` → `var(--text-xs)`, `fontSize: 12` → `var(--text-sm)`
- **Spacing:** `gap: 4` → `var(--space-1)`, `gap: 8` → `var(--space-2)` (both header and TrackRow outer div)
- **Targeted:** `activeColor="#d04040"` (Mute button) → `activeColor="var(--status-error)"`; Solo button `activeColor="#e8a027"` (already as literal — already replaced by color pass)
- **Code comments:** `// ──` header comments added to TrackPanel, handleOpenEditor, grouped useMemo, toggleGroupCollapse, isGroupMuted, editor-closed useEffect, TrackRow, IBtn
- **Kept as literals (Group C):** `#35354a` (empty state text); `#40404e` (group track count); `#9090a8` (instrument name); `#454560` (channel/prog labels); `#404058` / `#808098` (IBtn inactive/hover); font sizes 9/10; gap 6; `borderRadius: 4`; per-track color swatches (`track.color`) — intentionally excluded

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 5 — MidiEditor + new token groups

**`src/index.css`** — 3 new token groups added to `:root`
- **Modal surfaces:** `--bg-modal`, `--bg-modal-header`, `--bg-tile`
- **Interaction states:** `--state-hover-bg`, `--state-hover-border`, `--state-active-bg`, `--state-selected-bg`, `--state-disabled`, `--accent-amber-hover`, `--text-inactive`
- **Amber alpha tiers:** `--accent-amber-strong` (#e8a02755), `--accent-amber-medium` (#e8a02722), `--accent-amber-subtle` (#e8a02708)
- **Status banners:** `--status-success-bg/border/text`, `--status-error-banner-bg/border/text` (6 vars)

**`src/components/MidiEditor/MidiEditor.tsx`** — ~80 substitutions across InstrumentPicker, TrackRow, and main render

- **Text/color (replace_all):** `'#e8a027'` → `var(--text-amber)`, `'#505068'` → `var(--text-inactive)`, `'#404055'` → `var(--text-muted)`, `'#707088'` → `var(--text-dimmest)`, `'#b0b0cc'` → `var(--text-dim)`
- **Borders (embedded string replace):** `'1px solid #252535'` → `var(--border2)`, `'1px solid #1e1e28/1e1e2c'` → `var(--border)`, `'1px solid #1a1a26'` → `var(--bg-tile)`, `'1px solid #2a2a3a'` → `var(--state-hover-bg)`, `'1px solid #e8a02755'` → `var(--accent-amber-strong)`, `'2px solid #e8a027'` → `var(--text-amber)`
- **Amber alpha (standalone):** `'#e8a02755'` → `var(--accent-amber-strong)`, `'#e8a02714'` → `var(--accent-amber-medium)`, `'#e8a02710/08'` → `var(--accent-amber-subtle)`
- **Backgrounds:** `'#0f0f12'/'#111116'/'#0d0d12'/'#0d0d16'` → `var(--bg-modal-header)`, `'#13131e'` → `var(--bg-modal)`, `'#0e0e16'` → `var(--bg-row)`, `'#1a1a24'/'#1a1a26'` → `var(--bg-tile)`
- **Status banners:** all 6 banner bg/border/text values replaced with new tokens
- **Typography:** `fontSize: 11/12` → `var(--text-xs/sm)`
- **Border radius:** `borderRadius: 3/5` → `var(--radius-sm/md)`
- **Spacing:** `gap: 4/8` → `var(--space-1/2)`, title bar `padding: '0 16px 0 16px'` → `'0 var(--space-4)'`
- **Group B near-match alignments applied:** `#0f0f12` → bg-modal-header, `#111116` → bg-modal-header, `#13131e` → bg-modal, `#0d0d16` → bg-modal-header, `#1a1a24` → bg-tile, `#252535` → border2, `#1e1e2c` → border

**Kept as literals (Group C):** `#9090a8` (cool-blue grey, between tokens); `#606078` (between text-inactive and text-dimmest); `#0a0a0a` (near-black on amber save button); `#0a0a10` (very dark search/output bg); `#181822` (track row border — intentionally darker than `--border`); `#3a7a3a`/`#0d200d`/`#50c050`/`#353540` (include checkbox green/grey states); `#4040a0`/`#10102a`/`#8080cc`/`#20204a` (unmerge button + merged badge, custom blue-purple); `#101020`/`#1a1a08` (merged row bg variants); `#606078` (cancel text, split btn color); font sizes 9/10 (below token minimum); `borderRadius: 4/6/2` (between token values); padding/gap values with no token equivalents

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 4 — ScaleExplorer

**`src/components/ScaleExplorer.tsx`** — ~55 substitutions

- **Global replace_alls (9 passes):** `'#505068'` → `var(--text-inactive)`, `'#707088'` → `var(--text-dimmest)`, `'#303048'` → `var(--state-disabled)`, `'#ffb84d'` → `var(--accent-amber-hover)`, `'#b0b0cc'` → `var(--text-dim)`, `'#0d0d12'` → `var(--bg-modal-header)`, `padding: '0 12px'` → `'0 var(--space-3)'`, `'1px solid #1e1e2a'` → `'1px solid var(--border)'`, `.style.color = '#e8a027'` → `var(--text-amber)`
- **Modal container** (prior session): `background: var(--bg-modal)`, `border: 1px solid var(--state-hover-bg)`
- **Header:** `background: '#0f0f18'` → `var(--bg-modal-header)`, title `color: '#e8a027'` → `var(--text-amber)`
- **CoF section:** `background: '#0f0f18'` → `var(--bg-modal-header)`, `gap: 8` → `var(--space-2)`
- **Scale type buttons:** selected `color` and border template `'#e8a027'` → `var(--text-amber)`
- **CoF info overlay:** root name `color: '#e8a027'` → `var(--text-amber)`
- **Chord tile area:** outer `padding: '4px 12px'` → `var(--space-1) var(--space-3)`, empty-state `'#404055'` → `var(--text-muted)`, container `gap: 4` → `var(--space-1)`
- **Chord tiles (regular + octave, both):** tile bg `'#1a1a28'` → `var(--bg-tile)`, border template `'#2a2a3a'` → `var(--state-hover-bg)`, `paddingTop/Bottom: 8` → `var(--space-2)`, tile gap `4` → `var(--space-1)`, leave borderColor `'#2a2a3a'` → `var(--state-hover-bg)`, chord name `fontSize: 13` → `var(--text-base)` (replace_all hits both tiles)
- **Info row:** active step `'#e8a027'` → `var(--text-amber)`, note names `fontSize: 16` → `var(--text-lg)`, key name `color: '#e8a027'` + `fontSize: 12` → `var(--text-sm)`, left/right group `gap: 4` → `var(--space-1)`
- **Progressions row:** prog trigger bg `'#1a1a28'` → `var(--bg-tile)`, border `'#2a2a3a'` → `var(--state-hover-bg)`, selected color `'#e8a027'` → `var(--text-amber)`; all 3 inversion mode buttons (off/sequential/random): active color + leave ternary `'#e8a027'` → `var(--text-amber)`
- **Footer:** accidentals `fontSize: 16` → `var(--text-lg)`, selected color `'#e8a027'` → `var(--text-amber)`, `gap: 4` → `var(--space-1)`; inversion prev/next initial + leave `'#e8a027'` → `var(--text-amber)` (both buttons, replace_all)
- **Dropdown:** bg `'#1a1a26'` → `var(--bg-tile)`, border `'#2a2a3a'` → `var(--state-hover-bg)`, selected/hover bg `'#2a2a3a'` → `var(--state-hover-bg)`, color `'#e8a027'` → `var(--text-amber)` (enter + leave ternary)

**Kept as literals:** SVG `fill` attributes (CoF wedge colours, ring labels, key-sig symbols, centre labels); `colors.set(m, '#e8a027')` key-lighting calls (×6, functional state not UI chrome); semi-transparent variants `#e8a02722`/`#e8a02799` (alpha channel, no CSS var equivalent); selected tile bg `#1e2a3a` + note accent `#6080d0` (musical selection colours, no token); hover border `#3a3a5a` (blue-shifted variant, no exact token); `#9090a8` / `#c0c0d8` (no token); SVG `setAttribute('fill', ...)` calls for CoF ring hover (presentation attributes can't use CSS variables).

---

### 6. 7. 2026 — CSS Variable Rollout: Batch 3 — ChordExplorer + SpeedControl

**`src/components/ChordExplorer.tsx`**
- `ROW_LABEL.color`: `#707088` → `var(--text-dimmest)` — consistent with TopBar batch; comment updated to `// ──` style
- `ROW.borderBottom`: `#1e1e2a` → `var(--border)` — same semantic token applied to all 4 section borders (`borderBottom` on ROW, header bottom, progressions outer div, footer `borderTop`; `borderTop` on genre sub-row)
- `btnBase`: `borderRadius: 3` → `var(--radius-sm)` + `color: active ? '#e8a027'` → `var(--text-amber)`; added `// ──` comment
- All `minHeight: 44` (4 occurrences across root row, filter row, sub-row 1, footer) → `var(--row-height)`
- Header `padding: '0 12px'` → `'0 var(--space-3)'`; footer same
- "Chord Explorer" title `color: '#e8a027'` → `var(--text-amber)`
- Search scope active pill text `'#e8a027'` → `var(--text-amber)`; button `borderRadius: 3` → `var(--radius-sm)`
- Search input: `color: '#b0b0cc'` → `var(--text-dim)`, `caretColor: '#e8a027'` → `var(--text-amber)`
- Search icon: `'#707088'` → `var(--text-dimmest)`, `'#e8a027'` hover → `var(--text-amber)` (both enter/leave)
- Close button (×): `fontSize: 16` → `var(--text-lg)`, amber hover → `var(--text-amber)`
- Root row: `gap: 4` → `var(--space-1)`; root btn selected `background: '#e8a027'` → `var(--text-amber)`, text `'#12121c'` → `var(--bg)`, `fontSize: 11` → `var(--text-xs)`
- Filter row: `gap: 8` → `var(--space-2)`; tier container `borderRadius: 5` → `var(--radius-md)`
- Results grid: `padding: '8px 12px'` → `'var(--space-2) var(--space-3)'`
- Progressions dropdown trigger + clear-prog button: amber hovers → `var(--text-amber)`
- Inversion mode buttons (CircleOff/ListOrdered/Shuffle): active/hover `'#e8a027'` → `var(--text-amber)` (6 occurrences)
- Chord and power chord tiles: `border` template literal amber → `var(--text-amber)` (replace_all, 2 tiles); chord name `fontSize: 12` → `var(--text-sm)`, selected color `'#e8a027'` → `var(--text-amber)`, unselected `'#b0b0cc'` → `var(--text-dim)` (both tile types)
- Chord tile roman numeral label: `color: '#e8a027'` → `var(--text-amber)`
- Footer "Show as" label: `'#707088'` → `var(--text-dimmest)`
- Accidentals button: selected `'#e8a027'` → `var(--text-amber)`, `fontSize: 16` → `var(--text-lg)`
- Inversion prev/next buttons: active `'#e8a027'` → `var(--text-amber)` (4 occurrences across both buttons)
- Clear selection button: hover `'#e8a027'` → `var(--text-amber)`
- Scale Explorer → button: hover `'#e8a027'` → `var(--text-amber)`
- Progression dropdown: `baseColor` selected branch `'#e8a027'` → `var(--text-amber)`; mouseEnter `'#e8a027'` → `var(--text-amber)`

**Kept as literals (no matching token):** `#13131c` (modal bg), `#0d0d12` (header/footer deep bg), `#1a1a26` (pill/tile/dropdown surface), `#2a2a3a` (active pill bg, borders), `#505068` (inactive icons), `#404055` (sub-labels), `#9090a8` / `#c0c0d4` / `#8080a0` / `#3a3a4a` / `#303048` / `#ffb84d` / `#606078` / `#1f1a0e` (no token equivalents). Font sizes 8/9/10 and border-radius 4/6/10 also left as literals (below or between token values). `AMBER`/`DIM` JS constants in SpeedControl left as hex — SVG `fill`/`stroke`/`floodColor` attributes, not CSS properties.

**`src/components/SpeedControl.tsx`**
- "Speed" label `color: '#707088'` → `var(--text-dimmest)`

---

### 6. 7. 2026 — Types: electronAPI interface completed

**`src/types/index.ts`**
- Added 8 missing method signatures to the `electronAPI` interface in `declare global { interface Window }`:
  - `openMidiEditor(data: any): Promise<void>` — opens the MIDI editor window with source data
  - `getMidiEditorData(): Promise<any>` — returns `_editorData` set by `editor:open` handler
  - `closeMidiEditor(): Promise<void>` — destroys the editor BrowserWindow
  - `saveFileDialog(opts): Promise<string | null>` — `dialog.showSaveDialog` wrapper; opts: `{ defaultPath, filters }`
  - `saveMidiEditor(payload): Promise<{ ok: boolean; message: string }>` — writes the edited MIDI to disk; payload: `{ outputPath, includedTracks: { index, newProgram }[], mergeGroups: number[][] }`
  - `onMidiReload(cb): void` — `ipcRenderer.on('midi:reloadFile', ...)` listener; cb receives `MidiFileResult`
  - `onEditorClosed(cb): void` — `ipcRenderer.on('editor:closed', ...)` listener
  - `openExternal(url): Promise<void>` — `shell.openExternal` wrapper
- All 8 methods were present in `electron/preload.ts` and had corresponding handlers in `electron/main.ts`; only the TypeScript declaration was missing.
- Fixes three reported TS2339 errors (`onMidiReload`, `getMidiEditorData`, `saveMidiEditor`); five additional methods discovered during full audit.

---

### 5. 7. 2026 — Piano Roll: Defensive size-sync fix

**Root cause:** Two perpetual `requestAnimationFrame` loops added in `KeyboardControls` (v0.9.0 performance ribbon) fire `setState` at 60 fps, causing sibling-component re-renders. Under certain timing conditions these re-renders produce transient DOM layout changes that diverge `app.screen.width/height` from `el.clientWidth/height` between `ResizeObserver` callbacks — resulting in the PixiJS renderer drawing to a canvas smaller than its CSS container. Visible symptoms: missing grid on the right portion, playhead not spanning full width, notes fragmenting near the playhead.

**`src/components/PianoRoll/PianoRoll.tsx`**
- Added defensive size-sync block at the top of `drawFrame`: reads `el.clientWidth/clientHeight` each tick and compares against `app.screen.width/height`. If they diverge and both container dimensions are > 0, calls `app.renderer.resize`, `drawGrid`, and updates the overlay canvas width/height, then returns early so the next frame renders at the correct size. The check costs two property reads + two comparisons per frame when dimensions are already correct (the common case).

---

### 5. 7. 2026 — Settings: BETA badges on Chord Transcription + Hand Labels (v0.10.1 continued)

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `BetaBadge` function component: small outlined red pill (`var(--status-error)` border + text, `var(--radius-sm)`, 8px Inter uppercase, 0.85 opacity). Placed in the shared sub-components block.
- Extended `OptionRow` with an optional `badge?: React.ReactNode` prop. Label div changed to `display: flex; align-items: center; gap: 6` so the badge sits inline after the label text without disrupting existing rows (no badge = no visual change).
- Applied `badge={<BetaBadge />}` to exactly two settings: **Chord Transcription** (Library section) and **Left/Right Hand Labels** (Keyboard section). No other settings receive the badge.

---

### 5. 7. 2026 — CSS Variable Rollout: Stage 1 + Stage 2 (v0.10.1 continued)

Replaced hardcoded hex colors and raw pixel values with design-system CSS variables across four components. Functional colors (piano key lighting, note highlight state, hand boundary visuals) are intentionally left as literals.

**`src/components/Transport/TopBar.tsx`**
- `C` constant object updated: all four values (`default`, `active`, `muted`, `amber`) now reference `var(--text-*)` tokens instead of old hex values. `C.default` / `C.active` / `C.muted` are semantically brighter as part of the design system upgrade.
- `paddingRight: 12` → `var(--space-3)` on logo section; `padding: '0 12px'` → `'0 var(--space-3)'` on BPM, KEY, and BAR sections (3 places).
- Open-file button: `width: 28, height: 28` → `var(--button-height)`; `borderRadius: 5` → `var(--radius-md)`.
- `VSep` height: `44` → `var(--row-height)`; background `#1e1e28` → `var(--border)`.
- Three inline column dividers (bar counter, time sig, metronome): `height: 28` → `var(--button-height)`; background `#1e1e28` → `var(--border)`.
- Bar counter font sizes: `fontSize: 12` → `var(--text-sm)` ×2.
- Time signature font sizes: `fontSize: 13` → `var(--text-base)` ×2.
- Filename label: `fontSize: 11` → `var(--text-xs)`.
- Nudge span: inline `#e8a027` → `C.amber`.
- `LongPressArrow`, `ArrowBtn`: `borderRadius: 3` → `var(--radius-sm)`; `onMouseEnter` amber → `var(--text-amber)`.
- `TBtn`: idle/active color `#e8a027`/`#707088` → `var(--text-amber)`/`var(--text-default)` in all three color references.

**`src/components/Keyboard/Keyboard.tsx`** (chord bar chrome only — piano key rendering untouched)
- Chord bar `borderTop: '#1e1e28'` → `var(--border)`.
- Center container: `gap: 8` → `var(--space-2)`; `padding: '0 12px'` → `'0 var(--space-3)'`.
- CHORDS/SCALES labels (×4, replace_all): color `#e8a027` → `var(--text-amber)`.
- Prompter toggle (simple mode): conditional color `#e8a027`/`#707088` → `var(--text-amber)`/`var(--text-default)`.
- Prompter toggle (extended mode): `#e8a027` → `var(--text-amber)`.
- Explorer chord display and sequence chord names (×3): `fontSize: 14` → `var(--text-md)`; color `#e8a027` → `var(--text-amber)`.
- `‹›` separators (×2): `fontSize: 14` → `var(--text-md)`.
- Ordinal inv label: `#707088` → `var(--text-default)`.
- Slash bass note span: `fontSize: 11` → `var(--text-xs)`; `#b0b0cc` → `var(--text-active)`.
- Hint text (×2, replace_all): `#707088` → `var(--text-default)`.
- Extended mode status text: `fontSize: 11` → `var(--text-xs)`; `#404055` → `var(--text-muted)`.
- Past/next chord name spans (×2, replace_all): `fontSize: 11` → `var(--text-xs)`.
- Right groups: `gap: 8` → `var(--space-2)` ×2.

**`src/components/Keyboard/KeyboardControls.tsx`**
- Container: `padding: '0 16px'` → `'0 var(--space-4)'`; `gap: 12` → `var(--space-3)`.
- Key size button group: `gap: 4` → `var(--space-1)`.
- Key size buttons: `padding: '2px 8px'` → `'2px var(--space-2)'`; `fontSize: 12` → `var(--text-sm)`; active `#e8a027` → `var(--text-amber)`; idle `#404055` → `var(--text-muted)` (including mouseLeave handler).
- Column divider: `#1e1e28` → `var(--border)`.
- Dock/float toggle: `fontSize: 11` → `var(--text-xs)`; colors `#404055`/`#e8a027` → `var(--text-muted)`/`var(--text-amber)` (including hover handlers).
- Practice mode labels: `paddingLeft: 8` → `var(--space-2)` ×2 (replace_all).

**`src/components/Keyboard/FloatingKeyboard.tsx`**
- All `'#404055'` → `'var(--text-muted)'` (×5, replace_all): title label, pin/close button initial colors, and both mouseLeave handlers.
- `'#e8a027'` → `'var(--text-amber)'` on pin button mouseEnter.
- Both button `borderRadius: 3` → `'var(--radius-sm)'` (replace_all).
- Button container `gap: 4` → `'var(--space-1)'`.

---

### 5. 7. 2026 — Design System Tokens + Explorer UI Polish (v0.10.1 continued)

**`src/index.css`**
- Added spacing scale: `--space-1` through `--space-6` (rem-based, 4 px increments).
- Added typography scale: `--text-xs` (11 px) through `--text-lg` (16 px).
- Added border-radius scale: `--radius-sm` (3 px), `--radius-md` (5 px), `--radius-lg` (8 px).
- Added layout tokens: `--row-height: 44px`, `--button-height: 28px`.
- Added utility classes: `.orfeo-row`, `.orfeo-label`, `.orfeo-button`, `.orfeo-value` — scoped inside `:root {}` so they resolve as `:root .orfeo-*` via CSS nesting (effective for all descendants).

**`src/components/ChordExplorer.tsx`**
- Progression Play/Stop button: ready state changed from amber (`#e8a027`) to green (`var(--status-success)`); stop state now uses `var(--status-error)` instead of hardcoded `#c0392b` — both states fully token-driven.
- Row height consistency pass: Root row, Filter row, Progressions sub-row 1, Style sub-row 2, and Footer all given explicit `minHeight` values (`44` / `32`) matching Scale Explorer's established pattern. Root row unified to `{ ...ROW, minHeight: 44 }` (was `padding: '7px 12px'`, no height). Footer fixed from `height: 40` to `minHeight: 44`.

**`src/components/ScaleExplorer.tsx`**
- Progression Play/Stop button: same token swap as ChordExplorer — green ready, red stop, fully token-driven.

**`CLAUDE.md`**
- Design Tokens section expanded: added CSS variable names alongside hex values, full spacing/typography/radius/layout token tables, utility class reference, guidance to prefer `var()` in new code.

---

### 5. 7. 2026 — UI Polish: Logo Mark, EmptyState, Separator, MidiIcon (v0.10.1)

**`src/components/OrfeoMark.tsx`** (new)
- Extracted the Orfeo logo mark SVG into a shared reusable component (`height` + `style` props); aspect ratio 133.39/150 maintained via `Math.round(height * 133.39 / 150)`.

**`src/components/EmptyState.tsx`**
- Replaced inline `OrfeoMark` function definition with import from shared `OrfeoMark.tsx`.
- Centering rewritten: outer div uses `position: absolute; inset: 0`; content wrapper uses `position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%)` — pins to true viewport centre regardless of drawer state.
- Watermark size increased to 320px height; gap between watermark and text block set to 64px.

**`src/components/ChordExplorer.tsx`**
- Header title area now renders `<OrfeoMark height={14} />` + "Chord Explorer" label in a flex row (gap 7px), replacing the bare span.

**`src/components/ScaleExplorer.tsx`**
- Same pattern: `<OrfeoMark height={14} />` + "Scale Explorer" label in header flex row.

**`src/components/MidiEditor/MidiEditor.tsx`**
- Removed hand-drawn circle+lines icon SVG from title bar; replaced with `<OrfeoMark height={18} />`. Existing `gap: 10` on the title bar div provides spacing to the label.

**`src/components/MidiIcon.tsx`**
- viewBox trimmed from `0 0 1000 455` to `137 0 712 455` (glyph bounds) to eliminate ~13.7% empty whitespace on the left, making the SVG element's left edge flush with the M glyph's visual left edge for correct alignment with labels.

**`src/components/Transport/TopBar.tsx`**
- MIDI section `alignItems` changed to `flex-start`; padding adjusted to `0 14px`.
- `borderBottom` removed from TopBar (separator moved to App.tsx sibling div).

**`src/App.tsx`**
- Added full-width 1px separator div as sibling of `<TopBar />` so it spans all columns (SettingsPanel, content, TrackPanel) reliably.

**`electron/main.ts`**
- `titleBarOverlay.height` reduced from 100 to 40 — the 100px tray background was painting over the separator line at y=96px (bottom of TopBar) in the top-right corner of the window.

---

### 5. 7. 2026 — Chord Explorer: Power Chord Tier (v0.10.0)

**`src/components/ChordExplorer.tsx`**
- Tier state type extended: `'common' | 'extended'` → `'common' | 'extended' | 'power'`.
- New state: `selectedPowerRoot: number | null` — tracks which of the 12 tiles is active.
- New derived: `isPowerMode = tier === 'power'`.
- New `playPowerChord(pitchClass)` callback — computes root MIDI at oct 4, builds `[rootMidi, rootMidi+7]` (P5), calls `setExplorerKeys`/`setExplorerChordDisplay`/`__orfeoPlayNote`. Chord display shows e.g. `C5`.
- Tier toggle now renders `['common', 'power', 'extended']` with Power positioned between the two existing options.
- When `isPowerMode`:
  - Results grid switches to 12 power chord tiles in a `repeat(4, 1fr)` layout; each tile shows root name + "5" heading and root+fifth note names; selected tile gets amber border.
  - Hand filter, Notes filter, and Search button greyed out (`opacity: 0.35, pointerEvents: 'none'`).
  - Entire Progressions section (both sub-rows, covering Progressions + Play + Inversions + Style) greyed out the same way.
  - Play Inversion centre div in footer also greyed out.
- Tier-change effect: on entry to Power mode, additionally clears `selectedKey`, `explorerKeys`, and `explorerChordDisplay` so previously selected chord tiles don't leave stale highlights.
- Open-modal reset: `setSelectedPowerRoot(null)` added to the chordExplorerOpen reset block.

---

### 5. 7. 2026 — Scale Explorer: Octave-Completion Chord Tile

**`src/components/ScaleExplorer.tsx`**
- New state: `octaveTileSelected: boolean` — tracks whether the 8th tile is active.
- New `playOctaveDegree` callback — takes the tonic chord from `diatonicChords[0]`, shifts all MIDI notes `+12`, plays them, lights the keyboard in the same colour scheme as regular degree tiles (root amber, others blue), displays chord name with no suffix change.
- Info row label shows `{tonic.roman}⁸` (Unicode superscript 8, U+2078).
- The 8th tile renders after the `diatonicChords.map` block, guarded by `diatonicChords[0]`. Roman numeral shown as `{tonic.roman}⁸`; note names computed at `+12` using existing `getNoteName` calls.
- `currentBaseMidi` useMemo extended: when `octaveTileSelected && diatonicChords[0]`, returns tonic MIDI notes shifted `+12`. This keeps the inversion buttons enabled and pointing at the correct octave when the 8th tile is active.
- Selecting any other degree tile sets `octaveTileSelected` to false via each tile's existing `setSelectedDegree` → the 8th tile deselects automatically.

---

### 5. 7. 2026 — Chord Explorer: Genre/Style Voicing System

**`src/utils/genreVoicing.ts`** (new file)
- `Genre` union type: `'classic' | 'coltrane' | 'cinematic' | 'roadhouse' | 'ipanema' | 'carnival' | 'velvet'`.
- `GENRE_LABELS` record for display names.
- `parseRomanLabel(label)` — strips `b`/`#` prefix and `°` suffix; classifies by case: uppercase=major, lowercase=minor, `°`=diminished.
- `getGenreVoicing(genre, romanLabel, baseKey)` — Classic resolves to plain 'major'/'minor'/'dim' from Roman case (no chord type extension). All other genres look up `(degree, quality)` in their DegreeMap and fall back to `baseKey` when no override exists.
- Style maps and their design intent:
  - `COLTRANE_MAP` — maj9/m9/m7b5 on I; dom13 on V; maj7/m7/m7b5 elsewhere.
  - `CINEMATIC_MAP` — Madd9/madd9 on I; Madd9/m7 on II–IV; 9sus4/m7 on V; Madd9/madd9 on VI. VII/dim fall through to Classic.
  - `ROADHOUSE_MAP` — dom7 on I/IV/V for all qualities (intentional blues override).
  - `IPANEMA_MAP` — maj9/m9 on I; m11 on minor II/IV; maj7#11 on major IV (Lydian lift); dom13 on V; VII gets maj7/m7b5.
  - `CARNIVAL_MAP` — maj7/m7 on I–IV/VI; dom7/m7 on V; maj7/m7b5 on VII.
  - `VELVET_MAP` — maj13/m13 on I/VI; maj9/m11 on II/III; maj9#11/m11 on IV; 7b9b13/m11 on V (altered dominant); maj7/m9b5 on VII.
- All chord type strings verified against tonal 6.4.3 `ChordType.all()`.

**`src/components/ChordExplorer.tsx`**
- Imports `getGenreVoicing`, `GENRE_LABELS`, `Genre` from `genreVoicing.ts`.
- `progGenre: Genre` state (default `'classic'`).
- `playProgStepAt` applies `getGenreVoicing(genre, prog.labels[step], chordKey)` to derive `effectiveKey` before looking up the chord info. Falls back to the user's selected chord type when no genre override exists for that degree/quality.
- `playProgStepAt` also calls `setExplorerChordDisplay` after MIDI notes are determined — previously the chord display above the keyboard stayed frozen on "C" during progression playback. Deps array updated to include `setExplorerChordDisplay` and `rootLabels` to fix the stale closure.
- Standalone Genre row removed; replaced with two-sub-row Progressions container:
  - Sub-row 1: three-column layout (Progressions dropdown + Play/Stop + SpeedControl + Inversions).
  - Sub-row 2: Style buttons, dimmed (`opacity: 0.35, pointerEvents: 'none'`) when no progression is selected.
- Style tooltips: each button has a `title` attribute describing the voicing character.
- `PROGRESSIONS` array reordered into four family groups: Pop cluster → Rock/Blues cluster → Jazz cluster → Exotic/named progressions.
- Rotation deduplication: `buildAllProgressions()` uses a Set of offset-sequence strings to deduplicate cyclic equivalents across different base progressions (e.g. Pop/Rock Inv. is a rotation of Pop — emitted zero extra rotations).
- Bug fix — Classic style regression: previously `if (genre === 'classic') return baseKey` bypassed `parseRomanLabel` entirely, causing `vi` to play as a major chord. Fixed to return `'minor'`/`'dim'`/`'major'` based on Roman numeral case.

---

### 4. 7. 2026 — Performance mode: ribbon rest state — full hide + midline + dimmed labels

**`src/components/Keyboard/KeyboardControls.tsx`**
- Added `isSilent` derived boolean: `activeKeys.size === 0`.
- Added four refs for frozen last-known positions, mutated during render (no hook):
  `hadBoundaryRef` (bool), `lastRibbonPctRef` (default 50%), `lastClusterLeftPctRef`, `lastClusterRightPctRef`. Updated whenever their source values are non-null.
- Performance mode guard changed: `if (ribbonPct === null) return null` → `if (!isSilent && ribbonPct === null) return null`. Silent state now proceeds to render; only single-hand/no-boundary-while-active hides everything.
- Gradient fill: switched from fixed `opacity: e6` to `opacity: isSilent ? 0 : 1` with `transition: 'opacity 0.25s ease'`. Position computed from `ribbonPct ?? lastRibbonPctRef.current` so it does not jump on silence entry.
- Added resting midline: 1px `#404055` vertical line at `activePct`, `zIndex: 2`, rendered only when `isSilent`.
- Labels now rendered from `clusterLeftPct ?? lastClusterLeftPctRef.current` and equivalent right — holds frozen cluster position during silence. `opacity: isSilent ? 0.55 : 1` with `transition: 'opacity 0.25s ease'`. Labels remain hidden if cluster position is null and no frozen position exists yet.

---

### 4. 7. 2026 — Performance mode: ribbon contrast fix + cluster-anchored stable labels

**`src/utils/handBoundaries.ts`**
- Added internal helper `computeClusterCenters(pitches, boundary)` — computes mean MIDI pitch of notes strictly below (left) and at/above (right) the boundary; returns null when either side is empty.
- Added exported `computeClusterCenterCurve(midi, minGapSt)` — same sliding 2-second window scan as `computeHandBoundaryCurve`; at each sample stores `{ leftCenter, rightCenter }` instead of a midpoint; returns null entries when boundary is absent.
- Added exported `lookupClusterAtTime(curve, t)` — binary-search nearest-past entry (not interpolated); returns `{ leftCenter: null, rightCenter: null }` when curve is empty.

**`src/components/Keyboard/KeyboardControls.tsx`**
- `useSmoothedBoundary` simplified: removed Tier 2 entirely (committed value, `committedRef`, `candidateRef`, `COMMIT_DELTA_ST`, `COMMIT_DELAY_MS`). Now returns `number | null` directly instead of `{ ribbonPct, committed }`.
- Added constant `CLUSTER_SMOOTHING = 0.04`; removed `COMMIT_DELTA_ST` and `COMMIT_DELAY_MS`.
- Added local hook `useSmoothedClusterCenters(rawLeftPct, rawRightPct)` — two independent long-lived rAF expo-smoothers at `CLUSTER_SMOOTHING`; snap-to-null on null input; snap-immediate on first non-null. Returns `{ clusterLeftPct, clusterRightPct }`.
- Added `clusterCurve` local state (`useState`).
- Extended `useEffect([midi, performanceSplitSensitivity])` to also call `computeClusterCenterCurve` and store result; sets `clusterCurve` to `[]` on null midi.
- Raw cluster centers computed inline — hardware path: split `activeKeys` at `performanceBoundary` and take means; file path: `lookupClusterAtTime(clusterCurve, currentTime)`.
- Cluster centers converted to pct via `noteToLeftPct(Math.round(center), whiteKeys)` then passed to `useSmoothedClusterCenters`.
- Ribbon gradient opacity: `28` (15.7%) → `e6` (90.2%). Both SLATE and AMBER sides.
- Dock/Float button: added `position: 'relative', zIndex: 3` so it renders above the absolute-positioned gradient ribbon (zIndex 1).
- Performance mode labels: replaced centered-in-region model with `left: ${clusterPct}%; transform: translateX(-50%)` anchored at cluster mean; color changed from per-hand tint to `#ffffff` white; each label conditionally rendered — hidden when its cluster pct is null (e.g. single-hand texture or sparse region).

---

### 4. 7. 2026 — Performance mode: sensitivity range fix + two-tier jitter smoothing

**`src/store/index.ts`**
- `performanceSplitSensitivity` default lowered: `14` → `8`; clamp changed from `[8, 24]` to `[2, 16]`. The previous range was calibrated for 12-tone chromatic gaps; the tighter range better reflects real piano inter-hand spacings (perfect 2nd at 2 st through a minor 10th at 16 st).

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Slider `min`/`max` updated to `2`/`16`; end labels updated accordingly.

**`src/components/Keyboard/KeyboardControls.tsx`**
- Added constants `SMOOTHING_FACTOR = 0.18`, `COMMIT_DELTA_ST = 3`, `COMMIT_DELAY_MS = 400`.
- Added local hook `useSmoothedBoundary(rawBoundary, whiteKeys)` — applied once to the merged `performanceBoundary` (both file-curve and live-hardware paths converge there; no per-source duplication).
  - **Tier 1 ribbon pct** — exponential smoothing in pct space (not MIDI space, to keep motion visually uniform across black/white key geometry). `SMOOTHING_FACTOR = 0.18` reaches ~90% of a new target in ~175ms at 60fps. Null raw snaps to null immediately — no phantom ease-out.
  - **Tier 2 committed** — hysteresis in MIDI-note space. Tracks a pending `candidate { value, since }`. Commits only when `|raw − committed| > 3 st` AND candidate has held for ≥ 400ms without itself jumping > 3 st. Null raw immediately clears committed and cancels any pending candidate.
  - Single long-lived rAF loop; all reactive values accessed via refs so raw changes never restart the loop.
- Performance mode render updated: line uses `ribbonPct`, labels use `noteToLeftPct(committed, whiteKeys)` with a `ribbonPct` fallback for the first ~400ms before first commit.

---

### 4. 7. 2026 — Performance mode: adjustable split sensitivity (v0.9.0)

**`src/utils/handBoundaries.ts`**
- `PERF_MIN_NOTES` lowered from 4 to 2. A single note has no measurable gap; 2+ notes always go through the gap check. The gap threshold alone handles false positives for small chords.
- Removed module-level constant `PERF_MIN_GAP_ST`; threshold is now a live parameter on both functions.
- `detectPerformanceBoundary(pitches, minGapSt)` — added `minGapSt: number` parameter; read fresh from the store on every call.
- `computeHandBoundaryCurve(midi, minGapSt)` — added `minGapSt: number` parameter; passes it through to each `detectPerformanceBoundary` call inside the window loop.

**`src/store/index.ts`**
- `performanceSplitSensitivity: number` — new field; default 14 semitones; setter clamps to [8, 24]; persisted via the standard 5-point sentinel pattern (interface, store body with clamp, `_prevPerformanceSplitSensitivity` sentinel variable, subscriber comparison+update, `setPrefs` payload, `restoreLibraryPrefs`).

**`src/components/Keyboard/KeyboardControls.tsx`**
- Reads `performanceSplitSensitivity` from store via primitive selector.
- Curve `useEffect` deps extended to `[midi, performanceSplitSensitivity]`; passes sensitivity to `computeHandBoundaryCurve`.
- Live boundary `useEffect` deps extended to `[activeKeys, handLabelMode, performanceSplitSensitivity]`; passes sensitivity to `detectPerformanceBoundary`.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Reads `performanceSplitSensitivity` / `setPerformanceSplitSensitivity` from store.
- Performance mode section: description-only div replaced with a slider `OptionRow` (`Split Sensitivity — N semitones`, range 8–24, `accentColor: #e8a027`) plus a description div below it.

---

### 4. 7. 2026 — Performance mode: correct gap threshold (7 st, was 14)

**`src/utils/handBoundaries.ts`**
- `PERF_MIN_GAP_ST` lowered from 14 to 7. The 14-semitone (major 9th) threshold was too conservative: in a 2-second window with both hands present, the largest consecutive gap between the highest bass note and lowest treble note is typically 5–12 semitones, causing the entire curve to be null and the line to never appear. The original 3-note false-positive (C–E–G) is already blocked by `PERF_MIN_NOTES = 4`; common 4-note single-hand chords top out at 5-semitone consecutive gaps, so 7 (perfect 5th) is the correct threshold.

---

### 4. 7. 2026 — Performance mode: fix false hand-split on single-hand chords

**`src/utils/handBoundaries.ts`**
- Added constants `PERF_MIN_NOTES = 4` and `PERF_MIN_GAP_ST = 14` (major 9th).
- Added `detectPerformanceBoundary(pitches: number[]): number | null` — shared function used by both the file-curve precomputation and the live hardware-input path. Returns null when fewer than 4 unique pitches are present, or when the largest consecutive pitch gap is < 14 semitones; returns the gap midpoint otherwise. Fixes the root cause: previously both call sites always emitted a split even for tight single-hand clusters (C–E–G = 4 st gap → false split).
- `computeHandBoundaryCurve` return type changed to `{ time: number; boundary: number | null }[]`. Removed the `lastBoundary` carry-forward logic (each sample is now self-contained). Replaced 8-line inline gap loop with a single call to `detectPerformanceBoundary`. Empty or thin windows now produce null entries rather than carrying stale data.
- `interpolateCurve` input type updated to match; added null-neighbor guard — returns null immediately if either surrounding curve point is null, preventing a phantom line from interpolating across a no-boundary segment.

**`src/store/index.ts`**
- `handBoundaryCurve` interface and setter type updated to `{ time: number; boundary: number | null }[]`.

**`src/components/Keyboard/KeyboardControls.tsx`**
- Imported `detectPerformanceBoundary`.
- Live hardware `useEffect`: replaced inline 8-line gap loop with `detectPerformanceBoundary(pitches)`; removed early-return on thin pitch list — state is always updated (null or number) so tight single-hand clusters actively hide the line rather than holding a stale boundary.
- `performanceBoundary` derivation simplified to `hasHardwareKeys ? lastLiveBoundary : curveBoundary` — removed `?? lastLiveBoundary` fallback so hardware-present null (tight cluster) correctly hides the line instead of falling back to the file curve.

---

### 4. 7. 2026 — Hand Labels: Performance mode (dynamic boundary)

**`src/utils/handBoundaries.ts`**
- `computeHandBoundaryCurve(midi)` — new export; slides a 2-second lookback window across the piece's keyboard-track notes, sampled every 250 ms; finds the largest pitch gap per window and returns the midpoint as a `{ time, boundary }[]` array. Used by Performance mode for file playback.
- `interpolateCurve(curve, t)` — new export; binary-searches the curve for surrounding points and linearly interpolates. Returns `null` when the curve is empty.

**`src/store/index.ts`**
- `handLabelMode: 'practice' | 'performance'` — new store field; default `'practice'`; persisted via the existing 5-point sentinel pattern (sentinel var, subscriber init, comparison, update, setPrefs payload, restoreLibraryPrefs).
- `handBoundaryCurve: { time, boundary }[]` — new store field; not persisted; reset to `[]` by the `useEffect` in `KeyboardControls` on every file change.

**`src/components/Keyboard/KeyboardControls.tsx`**
- Complete rewrite to add Performance mode rendering alongside Practice mode.
- `useEffect([midi])` — computes and stores `handBoundaryCurve` via `computeHandBoundaryCurve` whenever the loaded file changes; clears to `[]` on null.
- `useState(lastLiveBoundary)` + `useEffect([activeKeys, handLabelMode])` — tracks live boundary from currently held notes using the same largest-gap midpoint algorithm; holds last computed value when no notes are held.
- Hardware key detection: `[...activeKeyColors.values()].some(c => c === '#e8a027')` — identifies hardware MIDI notes by their fixed amber color, taking priority over curve boundary when present.
- Performance mode renders a single moving amber line; Practice mode is byte-for-byte unchanged.
- `performanceHideControls` flag: when Performance is active and playing or hardware notes present, hides key-size selector and NoteCounter; dock/float button moves to far right via `marginLeft: 'auto'`.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Reads `handLabelMode` / `setHandLabelMode` from store.
- Adds "Mode" row (Practice / Performance toggle) below the Hand Labels on/off toggle, visible only when labels are on.
- Practice: existing split zone controls shown unchanged.
- Performance: split zone hidden; short description shown in its place.

---

### 4. 7. 2026 — Loop nudge blink, MIDI wordmark icon, label polish

**`src/components/Transport/TopBar.tsx`**
- `nudgeLoop` derived: `loopRegionEnabled && !!midi && loopStart !== null && loopEnd !== null && !loopRegionActive` — true when a region is selected but the user hasn't activated looping yet
- Repeat (↺) button passes `blink={nudgeLoop}` to `TBtn`; when blinking, colour is forced amber and `loop-nudge-blink` CSS class applied; `transition: 'color 0.1s'` suppressed so the animation runs uncontested
- "click to loop" span (9px Inter, 0.04em spacing, 85% opacity) rendered in the transport flex row to the right of the Repeat button when `nudgeLoop`; disappears on activation or region clear
- `TBtn` extended with `blink?: boolean` prop; `isAmber = active || accent || blink`; `onMouseLeave` also uses `isAmber` so hover-out restores amber when blinking
- MIDI icon: replaced stroke-based circle-dot SVG in `MidiIcon.tsx` with official MIDI wordmark (MIDI_LOGO.svg, viewBox `0 0 1000 455`); `height={size}`, `width={Math.round(size * (1000/455))}` (~53px at size 24) so height exactly matches the metronome SVG; `fill={color}` — all existing connection/colour logic in TopBar unchanged
- MIDI label: `'NO MIDI'` → `'CONNECT A KEYBOARD'`; font-size drops to 7 (from 8) when not connected; letter-spacing tightens to `0.05em` (from `0.08em`); `whiteSpace: 'nowrap'` added; container padding reduced `'0 14px'` → `'0 8px'`

**`src/index.css`**
- `@keyframes orfeo-loop-blink`: `filter: brightness(1)` at 0%/100%, `filter: brightness(0.3)` at 50%; 1.4s ease-in-out infinite
- `.loop-nudge-blink` applies the animation
- `filter` chosen over `opacity`/`color` so inline React styles cannot override the keyframe

**`src/components/MidiIcon.tsx`**
- Full rewrite: four `<path>`/`<rect>` elements from MIDI_LOGO.svg; `fill={color}`, no stroke; props (`size`, `color`) unchanged

---

### 3. 7. 2026 — Loop Region Strip (v0.8.0)

**`src/components/LoopRegionStrip.tsx`** (NEW)
- Canvas-based 24px interactive strip rendered between the scrub bar and the filename in TopBar when `loopRegionEnabled` is true
- Note density visualisation: note times bucketed into 2px columns, normalised height 4–12px, colour `#404058`
- Drag-to-create: `handleMouseDown` classifies as `'new'` | `'left'` | `'right'` handle drag; `previewRef` holds live drag state separate from committed store state
- Bar snapping: `snapToBar()` picks nearest bar boundary from `barStarts + duration` on mouseup; `displayEndBar()` subtracts 1 from raw bar index when `loopEnd` lands exactly on a bar start (avoids "bars 8–13" when user selected 8–12)
- Handle geometry: `HANDLE_VIS_W = 4` (drawn), `HANDLE_HIT_W = 8` (mouse hit target)
- Playhead: white 2px rect + amber downward triangle tracking `currentTime`
- Global `mousemove`/`mouseup` in single `useEffect([], [])` — never re-registered on re-render; state via refs only
- Icon button (ArrowUp01 SVG): amber when selection exists or popup open; tooltip "Select bar range manually"
- Popup: "BAR RANGE" header; From/To rows with 48px `type="text"` inputs + amber `ChevronUp`/`ChevronDown` steppers (no background); amber Apply button; closes on click-outside
- `applyBarRange()`: `startTime = barStarts[from-1]`, `endTime = to < totalBars ? barStarts[to] : midi.duration`
- Bars DOM label: `bars {startBar}–{endBar}` in amber, right of the icon, only when selection exists; derived in render body from primitive selectors — not a `useStore` object selector (which breaks `useSyncExternalStore` snapshot invariant → renderer crash)
- `draggable={false}` + `onDragStart={e => e.preventDefault()}` on canvas — blocks native HTML5 drag reaching Electron's file handler
- Fragment return: canvas fills the shared 400px TopBar wrapper; icon+popup are `position: absolute, left: calc(100% + 8px)` anchored outside the wrapper's right edge

**`src/components/Transport/TopBar.tsx`**
- Scrub bar and strip share a `width: min(100%, 400px), position: relative` flex column wrapper — both have identical visual width (34+6+320+6+34 = 400px); `position: relative` is the containing block for the strip's absolutely-placed icon
- TopBar height: `loopRegionEnabled ? 120 : 96`
- Loop button now toggles `loopRegionActive`; tooltip is context-aware (shows bar range when region set, generic hint otherwise)

**`src/hooks/usePlayback.ts`**
- JZZ path: `loopRegionActive && secs >= loopEnd` → `player.play(); player.jumpMS(Math.floor(loopStart * 1000))` — in-place seek, no player rebuild
- JZZ path: `loopRegionActive` + no region → seeks to 0 on end-of-file instead of stopping
- Fallback/samples path: same logic via `playbackState: 'paused'` → `Promise.resolve().then(() => 'playing')` to trigger samples engine rebuild at new `currentTime`

**`src/store/index.ts`**
- New fields: `loopStart: number | null`, `loopEnd: number | null`, `loopRegionEnabled: boolean`, `loopRegionActive: boolean`
- New actions: `setLoopRegionEnabled` (clears region when disabling), `setLoopRegionActive`, `setLoopRegion`, `clearLoopRegion`
- `setMidi` (both branches) and `resetAll` reset loop state to null/false
- `loopRegionEnabled` persisted via `_prevLoopRegionEnabled` sentinel; `loopStart`/`loopEnd`/`loopRegionActive` intentionally NOT persisted

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- "Loop Region strip" On/Off toggle under Playback section

**Bug fixed — native drag opens file dialog:** `draggable={false}` + `onDragStart` on the canvas stops the OS drag-and-drop event from surfacing to Electron's file handler mid-selection.

**Bug fixed — renderer crash on selection commit:** `loopBarRange` selector was returning `{ startBar, endBar }` — a new object reference on every call. Zustand v4 / `useSyncExternalStore` calls `getSnapshot` multiple times and requires referential stability; always-new object → snapshot inconsistency → immediate renderer crash. Fixed: use three primitive selectors (`loopStartLabel`, `loopEndLabel`, `barStartsLabel`) and compute derived values in render body.

---

### 3. 7. 2026 — Web MIDI hardware input capture (verified)

**`src/hooks/useMidiInput.ts`** (NEW)
- `useMidiInput()` — requests `navigator.requestMIDIAccess()` on mount (skipped gracefully if API unavailable in the Electron context); attaches `midimessage` listener to every connected input port (all devices merged into one stream)
- `pressNote(midiNum, vel)` — writes directly to `activeKeys` / `activeKeyColors` (amber `#e8a027`, no timer), then routes audio to `__orfeoNoteOnSamples` or `__orfeoNoteOn` based on current engine
- `releaseNote(midiNum)` — removes from `activeKeys` / `activeKeyColors`, routes to `__orfeoNoteOffSamples` or `__orfeoNoteOff`
- `syncInputs()` — re-enumerates on `onstatechange`; updates `setMidiDevice(connected, name)` — the topbar MIDI indicator is now live
- Cleanup removes all per-port listeners and nulls `onstatechange` on unmount
- Verified: key lighting, true sustain (note-off stops sound immediately), polyphony all confirmed via console test helper (helper removed before commit)

**`src/hooks/useAudioEngine.ts`**
- Added `_hwChannelReady` flag + `ensureHardwareChannel()` — sends program 0 on channel 15 (`[0xCF, 0]`) once; same sentinel pattern as `ensureClickChannel`
- Added `window.__orfeoNoteOn(midiNum, vel)` — async, awaits `initJZZ()`, calls `ensureHardwareChannel()`, sends `[0x9F, midiNum, vel]` (ch 15); no timer
- Added `window.__orfeoNoteOff(midiNum)` — sync, sends `[0x8F, midiNum, 0]`; immediate
- Both registered/unregistered alongside `__orfeoPlayNote` in the same `useEffect`
- Comment: channel 15 collision risk with MIDI files using channel 16 — accepted tradeoff

**`src/hooks/useSamplesEngine.ts`**
- Added `_hwChannelReady` flag + `ensureHwChannel()` — sends `programChange(15, 0)` + `controllerChange(15, 7, 127)` once on first hardware note-on
- `__orfeoPlayNoteSamples` now calls `ensureHwChannel()` instead of inline `programChange`/`controllerChange` on every invocation
- Added `window.__orfeoNoteOnSamples(midiNum, vel)` — calls `ensureHwChannel()`, then `_synth.noteOn(15, midiNum, vel)`; no timer
- Added `window.__orfeoNoteOffSamples(midiNum)` — calls `_synth.noteOff(15, midiNum)` immediately
- Same comment re channel 15 collision risk

**`src/App.tsx`**
- `useMidiInput()` mounted alongside `useAudioEngine()`

---

### 3. 7. 2026 — Left/Right Hand Labels: settings reorder + split zone conditional visibility

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Moved "Left/Right Hand Labels" On/Off toggle to appear directly below "Key range", before the Split zone controls
- Wrapped the entire Split zone section (mode selector + note/range steppers) in `{showHandLabels && (...)}` — collapses from view when Labels is OFF
- Updated Labels hint to: "Shows amber hand boundary lines and labels in the keyboard footer."

---

### 3. 7. 2026 — Left/Right Hand Labels: footer redesign + settings relocation

**`src/components/Keyboard/Keyboard.tsx`**
- Removed the vertical separator line overlays from the piano key area entirely; visual layer now belongs exclusively to the footer bar

**`src/components/Keyboard/KeyboardControls.tsx`**
- Replaced dim centered labels with a full amber visual layer:
  - Range mode: two 2px amber lines (`box-shadow: 0 0 7px 2px #e8a02788` glow), shaded mixed-zone fill (`#e8a02718`) between them, "LEFT HAND" right-aligned to the left line with 6px padding, "RIGHT HAND" left-aligned from the right line with 8px padding
  - Single mode: one amber glowing line, same label placement, no zone fill
  - All overlays: `zIndex: 2`, `pointerEvents: none` so controls remain clickable

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Moved the Split zone / Split note controls from the MIDI Editor section into the Keyboard section, positioned between "Key range" and "Left/Right Hand Labels"
- Removed the now-empty MIDI Editor section header and `Scissors` import
- Updated "Split mode" label to "Split zone" and rewrote hint text to reflect its role as a visual keyboard boundary rather than an editor operation hint
- Updated range hint: "Notes inside the shaded zone may come from either hand."
- Updated "Left/Right Hand Labels" hint: "Displays LEFT HAND / RIGHT HAND labels on the keyboard using the split zone above."

---

### 3. 7. 2026 — Left/Right Hand Labels on keyboard

**`src/utils/handBoundaries.ts`** (NEW)
- `getWhiteKeys(keyboardSize)` — derives white-key list from RANGES, matching Keyboard.tsx constants exactly
- `noteToLeftPct(note, whiteKeys)` — converts a MIDI note to a left-edge % position; white keys use their index directly, black keys use the `(lowerWhiteIdx + 0.40) / len` formula matching the existing black-key geometry in Keyboard.tsx
- `detectHandBoundaries(midi, bpType, bpNote, bpStart, bpEnd)` — returns `null | { type:'single', note } | { type:'range', start, end }`:
  - Two-track case: finds a ≥85%-bass / ≥85%-treble keyboard track pair; derives boundary from their note ranges (touching → single, gap or overlap → range)
  - Single-track case (or no qualifying pair): checks ≥15% notes in each register (split-eligible threshold); if yes, uses the global split breakpoint settings to produce a single or range result

**`src/store/index.ts`**
- Added `showHandLabels: boolean` (default `false`) and `setShowHandLabels` to `OrfeoStore`
- Wired into null-sentinel subscriber: `_prevShowHandLabels` sentinel, change-detection condition, `setPrefs` payload
- Wired into `restoreLibraryPrefs`: `if (typeof prefs.showHandLabels === 'boolean') store.setShowHandLabels(...)`

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `showHandLabels` / `setShowHandLabels` selectors
- Added `OptionRow` "Left/Right Hand Labels" with On/Off buttons under the Keyboard section (below Key range)

**`src/components/Keyboard/Keyboard.tsx`**
- Added imports: `detectHandBoundaries`, `noteToLeftPct` from `handBoundaries.ts`
- Added store selectors: `showHandLabels`, `splitBreakpointType`, `splitBreakpointNote`, `splitBreakpointRangeStart`, `splitBreakpointRangeEnd`
- Added `handBoundaries` useMemo (depends on `midi` + breakpoint settings)
- Inside the piano key container div: renders 1 or 2 `position: absolute, zIndex: 3` thin vertical lines at the computed `left: N%` positions when `showHandLabels && handBoundaries`

**`src/components/Keyboard/KeyboardControls.tsx`**
- Added imports: `React`, `useMemo`, `getWhiteKeys`, `noteToLeftPct`, `detectHandBoundaries`
- Added store selectors: `showHandLabels`, `midi`, all four breakpoint fields
- Added `whiteKeys` and `handBoundaries` useMemos
- Renders LEFT HAND and RIGHT HAND labels as `position: absolute, zIndex: 0` overlays centered in their respective keyboard half-regions; `pointer-events: none`; dim `#404055` color
- Works for both docked and floating keyboard modes (FloatingKeyboard renders the same two components)

---

### 3. 7. 2026 — Drawer icons, layout & styling unification

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Removed single `ListMusic` toggle button; replaced with a conditional:
  - Closed: full-height flex column — `Library` (→ library tab), `Settings` (→ settings tab), flex spacer, `Info` pinned at bottom ("Coming soon" tooltip, `opacity: 0.5`, `cursor: default`). All functional buttons: `#707088` default / `#e8a027` hover.
  - Open: `ChevronLeft` only (no more dual-icon toggle); tooltip is now dynamic — `'Close Library'` or `'Close Settings'` based on `activeTab`.
- Tab bar: icons swapped `Music → Library`, `Settings2 → Settings`; `justifyContent: 'center'` → `justifyContent: 'flex-start'` + `paddingLeft: 12` to left-align icon+label flush with panel content below (folder bar / filter buttons at 12px).
- Imports: removed `Settings2`, `ListMusic`, `Music` (latter was the tab icon, not the Playback section header — `Music` is kept for that). Added `Library`, `Settings`, `Info`.

**`src/components/TrackPanel/TrackPanel.tsx`**
- Removed single `SlidersHorizontal` toggle button; replaced with conditional:
  - Closed: full-height flex column — `AudioLines size={18}` (opens panel), `SlidersVertical size={18}` (coming soon, `opacity: 0.5`), `PencilSparkles size={18}` (MIDI editor; dim `#303042` when no midi, amber when editor open).
  - Open: outer div restructured from flex-column to flex-row:
    - Left icon strip (32px, `borderRight: '1px solid #1a1a26'`, `paddingTop: 10`): `ChevronRight` close button (styled with `background: '#1a1a24'`, `border: '1px solid #252535'`, `borderRight: 'none'`, `borderRadius: '0 4px 4px 0'`) + `SlidersVertical size={16}` coming soon + `PencilSparkles size={16}` MIDI editor.
    - Content div (`flex: 1`, `flexDirection: 'column'`): header (`padding: '0 14px'`, previously `'0 14px 0 36px'`) + track list — both unchanged in content.
- Soundfont placeholder button (SVG, color `#30303e`) removed from open header.
- Header icon `Music2 size={14}` → `AudioLines size={14}`.
- `PencilLine` → `PencilSparkles` throughout (both states, closed column and open strip). `PencilSparkles` is defined as an inline SVG component at file top (not yet shipped in the installed `lucide-react` version); uses the path data from the official Lucide `pencil-sparkles` icon.
- Imports: removed `ChevronLeft` (was unused), `Pencil`, `SlidersHorizontal`, `Music2`, `PencilLine`. Added `AudioLines`, `SlidersVertical`. `PencilSparkles` is a local SVG component.

---

### 3. 7. 2026 — Split breakpoint: Single Note vs Range mode

**`src/store/index.ts`**
- Replaced `globalSplitBreakpoint: number` / `setGlobalSplitBreakpoint` with four new fields:
  - `splitBreakpointType: 'single' | 'range'` (default `'single'`)
  - `splitBreakpointNote: number` (default 60, clamped 48–60)
  - `splitBreakpointRangeStart: number` (default 52/E3, clamped 48 to rangeEnd–1)
  - `splitBreakpointRangeEnd: number` (default 60/C4, clamped rangeStart+1 to 60)
- `setSplitBreakpointRangeStart` / `setSplitBreakpointRangeEnd` use `set(s => ...)` to read the opposing bound and enforce no-crossing invariant.
- Null-sentinel subscriber updated: 4 new `_prev*` vars replace old `_prevGlobalSplitBreakpoint`; all 4 fields included in change-detection condition and `setPrefs` payload.
- `restoreLibraryPrefs` restores all 4 new fields from prefs (old `globalSplitBreakpoint` key silently dropped; default 60 is valid for both old and new).

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- MIDI Editor section split into two `OptionRow`s:
  - Row 1 "Split mode": `[Single] [Range]` toggle buttons; hint explains the ≥15% register threshold.
  - Row 2 (conditional): Single → one `− note +` stepper (range 48–60); Range → two side-by-side steppers ("Lower" / "Upper") with UI-level disabled guards that prevent the bounds from crossing.
- All 8 new store fields wired to the UI.

**`src/components/MidiEditor/MidiEditor.tsx`**
- Replaced single `splitBreakpoint` local state with 4 local vars matching the store fields.
- `getPrefs()` on mount now reads all 4 new pref keys.
- `handleSplit` sends `{ trackIndex, breakpointType, breakpoint, rangeStart, rangeEnd }` to `splitMidiEditor` IPC.

**`src/types/index.ts`**
- Updated `Window.electronAPI.splitMidiEditor` payload type to include `breakpointType`, `rangeStart`, `rangeEnd`.

**`electron/main.ts`**
- `editor:split` handler payload type updated; note-assignment logic branches on `breakpointType`:
  - Single: unchanged (notes < breakpoint → LH, ≥ → RH).
  - Range: notes < rangeStart → LH; notes > rangeEnd → RH; notes in zone → assigned by proximity (`|note – rangeStart| ≤ |note – rangeEnd|` → LH, else RH; ties go to LH).
- ≥15% gate still applied after assignment in both modes.

---

### 3. 7. 2026 — Locked Chord modal: draggable float + hint text + visual polish

**`src/components/LockedChordModal.tsx`** (new)
- Draggable floating modal replaces inline locked chord display in the chord bar and the locked chord controls in `KeyboardControls.tsx`.
- All existing locked chord logic migrated verbatim: `nextInversion` / `prevInversion`, `applyInversion`, `playLockedChord`, `clearLockedKeys`, `formatInversionDisplay` / `ordinalSuffix` display. Behaviour is unchanged.
- Layout: amber drag-handle header ("LOCKED CHORD" in amber) with × close button; large amber chord name + inversion ordinal; ‹ / PLAY / › / RotateCcw control row.
- Control icons default to `#707088`; amber on hover. Play button border follows same pattern.
- Border: amber outer ring + diffuse glow via `boxShadow` (`0 0 0 1px rgba(232,160,39,0.25), 0 0 18px rgba(232,160,39,0.12)`).
- Default open position: centered on screen (resets on every fresh lock).
- Drag pattern matches `ChordExplorer` exactly.
- Auto-pause on open intentionally removed: it triggered `clearSchedule() → _synth.stopAll(true)` in the Samples engine, which can suspend the AudioContext and introduce noteOn latency. The old `KeyboardControls` locked chord controls never paused playback. Residual tiny delay observed under RDP — likely network overhead; flagged for local testing.

**`src/components/Keyboard/Keyboard.tsx`**
- Removed `lockedDisplay` useMemo and the `lockedDisplay ?` priority branch from the chord bar centre (simple mode) and `centreChord` in extended mode. Locked chord now displays exclusively in the modal.
- Part 1: Shift+Click hint text moved from `KeyboardControls` into the chord bar right group, immediately left of the SCALES label — present in both simple and extended modes.
- Fixed stale `<Maximize2>` reference in extended prompter mode (was left unreplaced in the previous session); replaced with the same inline SVG used in simple mode.

**`src/components/Keyboard/KeyboardControls.tsx`**
- Removed: `nextInversion`, `prevInversion`, `applyInversion`, `playLockedChord`, `isLocked`, the entire centre `position:absolute` group (hint text + locked chord controls), `Play` / `RotateCcw` lucide imports, `useCallback`, `lockedKeys` / `lockedColors` / `setLockedKeys` / `clearLockedKeys` store reads.
- File now contains only: key size selector, dock/float toggle, NoteCounter.

**`src/App.tsx`**
- Added `<LockedChordModal />` import and render alongside `<ChordExplorer />` / `<ScaleExplorer />`.

---

### 3. 7. 2026 — Library UX: transcript trigger on FileMusic icon, marquee filenames, fullscreen chord prompter icon

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- `TranscriptIcon` component updated: icon changed from `FileText` to `FileMusic`; idle color `#707088`, amber hover `#e8a027`, IDLE_TOOLTIP constant for tooltip text. Spin animation keyframe injection moved here from `Keyboard.tsx`.
- `MarqueeFilename` component added: `ResizeObserver` measures overflow between FileMusic icon and star button; on hover, CSS `transition: transform` scrolls the name left at 40 px/s with a 0.5 s delay; mouse-out smoothly snaps back. Duration computed as `max(1.5, scrollAmt / 40)` seconds.
- Both demo file rows and library grouped file rows updated: when `chordTranscriptionEnabled` is off, shows a plain dim `<FileMusic>` icon; when on, mounts `<TranscriptIcon>` in place of it — no separate right-side column. `<MarqueeFilename>` replaces the plain filename `<span>`.
- `FileText` removed from lucide-react imports; separate `TranscriptIcon` instances that were appended to the right of the row removed entirely.

**`src/components/Keyboard/Keyboard.tsx`**
- Chord prompter toggle icon: `Maximize2` (lucide-react) replaced by custom inline SVG (`lucide-fullscreen` path data, `width/height="13"`, `viewBox="0 0 24 24"`). `Maximize2` import removed.
- Applied to both simple-mode (34 px chord bar) and extended-mode (36 px chord bar) toggle buttons.

---

### 2. 7. 2026 — MIDI Editor polish: track sort + icon contrast + LH/RH split guard

**`src/components/MidiEditor/MidiEditor.tsx`**
- Track list now sorted on load: keyboard group (piano / chromatic / organ) at the top, drums at the bottom, original MIDI order preserved within each group. Within the keyboard group, "Left Hand" is pinned before "Right Hand" for split files.
- Merge icon and Split icon color when inactive: `#353540` / `#505068` → `#606078` — both icons are now distinctly visible against the dark row background.
- Split button is suppressed on tracks named "Left Hand" or "Right Hand" — a track that is already the result of a split does not need a split trigger.

---

### 2. 7. 2026 — Split Track + icon updates + portable build filename (v0.7.0)

**`electron/main.ts`**
- Added `editor:split` IPC handler: reads source MIDI via `_editorData.filePath`, finds the track by note-bearing index, splits notes into Left Hand (< breakpoint) and Right Hand (≥ breakpoint). Qualifies the split by requiring ≥15% notes in each register — returns a descriptive error if the track is too one-sided. Mutates the source track in-place (becomes LH), adds a new RH track via `midi.addTrack()`. Copies instrument program from source. Output path: `{baseName}_ORFEO_SPLIT.mid` in the Orfeo subfolder via `getOrfeoOutputDir()`. Strips `_(ORFEO_MERGED|ORFEO_SPLIT|ORFEO)` from basename before appending suffix. Sends `midi:reloadFile` to main window on success.
- `editor:split` basename stripping: regex `_(ORFEO_MERGED|ORFEO_SPLIT|ORFEO)` — order matters, ORFEO_SPLIT must come before ORFEO or the shorter suffix matches first.

**`electron/preload.ts`**
- Added `splitMidiEditor: (payload) => ipcRenderer.invoke('editor:split', payload)`.

**`src/types/index.ts`**
- Added `splitMidiEditor: (payload: { trackIndex: number; breakpoint: number }) => Promise<{ ok: boolean; message: string }>` to `window.electronAPI` type.

**`src/store/index.ts`**
- Added `globalSplitBreakpoint: number` (default 60 — C4, middle C) + `setGlobalSplitBreakpoint` to `OrfeoStore`.
- Setter clamps to 21–107 (A0–B7).
- Restored in `restoreLibraryPrefs` from `prefs.globalSplitBreakpoint`.
- Persisted in null-sentinel subscribe callback; `_prevGlobalSplitBreakpoint` added as sentinel variable.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added `Scissors` to lucide-react import.
- Added `SPLIT_NOTE_NAMES` constant for MIDI-note-to-name conversion.
- Reads `globalSplitBreakpoint` / `setGlobalSplitBreakpoint` from store.
- New **MIDI Editor** section (between Playback and Appearance): shows current breakpoint note name (e.g. "C4") with − / + buttons to change by semitone. Hint explains the 15% detection threshold.
- Version bumped to v0.7.0.

**`src/components/MidiEditor/MidiEditor.tsx`**
- Added `Split` to lucide-react import.
- `TrackRow`: added `onSplit?: () => void` prop.
- Merge toggle button: replaced `'+'` / `'✓'` text with `<Merge size={11} />` icon (Part 2).
- Split button: appears inside the track name row for piano/chromatic/organ tracks (not merged rows). Amber hover, `<Split size={10} />` icon, tooltip "Split into Left Hand / Right Hand".
- `MidiEditor` component: added `splitBreakpoint` state (loaded from prefs in `useEffect`), `splitResult` state.
- Added `handleSplit(trackIndex)` — calls `window.electronAPI.splitMidiEditor`, sets result, closes editor on success after 1200ms.
- Track list: passes `onSplit` to qualifying tracks (`['piano','chromatic','organ'].includes(group) && !isMerged`).
- Footer: `splitResult` banner rendered above `saveResult` banner (same style).

**`package.json`**
- Added `"portable": { "artifactName": "${productName}-${version}-portable.${ext}" }` to `build` config. Portable exe will now be named `Orfeo-0.7.0-portable.exe` instead of the default `Orfeo 0.7.0.exe`.
- Version bumped to `0.7.0`.

---

### 2. 7. 2026 — Demo folder + Orfeo subfolder for generated files

**`electron/main.ts`**
- Added `ensureDemoFolder()`: on first launch, copies bundled demo MIDI files from `public/demo/` (dev) or `app.asar.unpacked/public/demo/` (packaged) into `libraryFolder/Demo/`. Writes `.demo-installed` flag to userData so the copy runs exactly once. Safe-copy: skips files that already exist. Falls back to `userData/Demo/` if no library folder is configured yet. Called from `app.whenReady()` before `createWindow()`, wrapped in try/catch so a missing demo dir never blocks launch.
- Added `getOrfeoOutputDir(sourceFilePath)` helper: resolves and auto-creates an `Orfeo/` subfolder next to the source file. If the source is already inside an `Orfeo/` subfolder, steps up to its parent — prevents `Orfeo/Orfeo/` nesting.
- `editor:save` IPC handler: output path now computed from `_editorData.filePath` via `getOrfeoOutputDir()` instead of using `payload.outputPath` from the renderer. `writeFileSync`, the `midi:reloadFile` notification, and the return message all use the new local `outputPath`. Fixes bug where the Orfeo/ folder was created (by `getOrfeoOutputDir`) but files were written next to the source (because `payload.outputPath` was still referenced). Re-saving an already-generated `_ORFEO.mid` strips the suffix before appending a new one — prevents `_ORFEO_ORFEO` doubling.
- `transcript:generate` IPC handler: output path moved into `Orfeo/` subfolder via `getOrfeoOutputDir()`. `songName` variable reused for the filename.
- Expanded `fs/promises` import: added `access`, `copyFile`, `readdir`, `writeFile` alongside existing `mkdir`.

**`package.json`**
- `files` array: added `public/demo/**/*` and `public/spessasynth_processor.min.js`; removed stale `package.json` entry.
- `asarUnpack`: added `public/demo/**/*` so demo files are accessible to `fs.copyFile` in packaged builds.

**`src/store/index.ts`**
- Added `hideDemoFolder: boolean` (default `false`) + `setHideDemoFolder` to `OrfeoStore`.
- Restored from prefs in `restoreLibraryPrefs`.
- Persisted in the null-sentinel subscribe callback alongside other display settings.

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- `LibraryPanel`: `Demo` folder (case-insensitive) is sorted to position 0 in the folder list, pinned above `Orfeo/` and all user subfolders. When `hideDemoFolder` is true, the Demo group is filtered from the render — files remain on disk.
- Settings tab: new **Library** section at the top with a Demo folder Show/Hide toggle.

**`public/demo/`**
- Bundled: Mozart - Rondo Alla Turca, Scott Joplin - Entertainer, Vivaldi 4 stagioni - Estate.

---

### 2. 7. 2026 — Portable build target

**`package.json`**
- Added `"portable"` to `build.win.target` alongside `"nsis"`. Running `npm run dist` now produces both `Orfeo Setup x.x.x.exe` (NSIS installer) and `Orfeo x.x.x.exe` (portable single-file exe) in `release/`.
- Added `dist:portable` script: same as `dist` but passes `--win portable` to electron-builder — builds the portable exe only, without the installer (faster iteration).

**`electron/main.ts`**
- Added portable userData redirect before `app.whenReady()`: when `PORTABLE_EXECUTABLE_DIR` is set (injected by electron-builder portable target at runtime), `app.setPath('userData', ...)` points to `Orfeo-Data/` next to the exe. This makes prefs (`orfeo-prefs.json`) and any cached files travel with the exe when copied to another machine. Has no effect on the NSIS installer build.

---

### 2. 7. 2026 — Build fixes — editor window, samples engine, keyboard alignment

**`electron/main.ts`**
- `editor:open` handler: `loadFile({ hash: 'editor' })` → `{ hash: '/editor' }`. `hash: 'editor'` produces `#editor` in the URL; `App.tsx` checks `window.location.hash === '#/editor'`, so the check always failed in packaged builds, causing the editor window to render the full main app instead of `<MidiEditor />`.

**`src/hooks/useSamplesEngine.ts`**
- Worklet URL: `new URL('/spessasynth_processor.min.js', location.href)` → `new URL('./spessasynth_processor.min.js', location.href)`. Leading `/` resolves to `file:///spessasynth_processor.min.js` (filesystem root) in packaged mode; `./` correctly resolves relative to `index.html` in the same directory.
- SF2 URL: `fetch('/GeneralUser-GS.sf2')` → `fetch(new URL('./GeneralUser-GS.sf2', location.href).href)` — same root cause and same fix.
- Added `console.log` of the resolved URL before each load and included the URL in the SF2 fetch error message for future debuggability.
- Tightened catch block type to `e: any` so `.message` access compiles cleanly.

**`package.json`**
- Added `"asarUnpack": ["out/renderer/spessasynth_processor.min.js"]`. `AudioWorklet.addModule()` bypasses Electron's asar protocol handler and requires the file on the real filesystem; `fetch()` goes through the handler so the SF2 does not need unpacking.

**`src/components/Keyboard/Keyboard.tsx`**
- Black key left-position constant: `0.65` → `0.70`. PianoRoll's formula places each black key at `(wi − 0.30) × ww` (center at the white-key boundary); Keyboard was placing it at `(whiteIdx + 0.65) × ww = (wi − 0.35) × ww` — a consistent `0.05 × ww` offset per black key. The fix aligns the keyboard DOM element with the PixiJS note columns.

---

### 2. 7. 2026 — Chord Transcript PDF — styling fixes (v4)

**`electron/main.ts`** (`transcript:generate` handler only)

- **Fix 1 — Outer grid borders removed:** replaced `doc.rect()` (which drew all 4 edges) with a conditional `moveTo/lineTo` separator drawn only *between* rows (not above bar 1, not below last bar). Separator is full-bleed (x=0 to pageW), 0.15pt, `#c8c8d8`.
- **Fix 2 — Chord name concatenation:** chords in each beat cell are now sorted by `xFrac` before placement. Added `prevDrawX`/`prevTW` tracking to detect x-overlap with the previous chord in the same cell. If `newX < prevX + prevTW + 3`: pushed right; if still overlapping after hard-clamp to `cellRight − tw − 2`: `forceStack = true` applies diagonal offset (`prevDrawX + 5`, `midY − ci*9`). Prevents `Dsus24CMadd9`-style visual concatenation.
- **Fix 3 — Legend inversion collapsing:** step 8 now normalises each chord key explicitly with `pdfStripMajor(gc.chordEn.split('/')[0])` before inserting into the dedup set, rather than relying on `gc.chordEn` already being stripped. Makes the normalization self-contained and guards against future changes to step 6.

---

### 1. 7. 2026 — Chord Transcript PDF — layout & detection fixes (v3)

**`public/fonts/`** — new directory; four font files added:
- `Inter-Regular.ttf`, `Inter-Bold.ttf`, `Inter-Italic.ttf` — Inter v4.0 (rsms/inter GitHub release)
- `JetBrainsMono-Regular.ttf` — JetBrains Mono v2.304 (JetBrains GitHub release)

**`package.json`**
- Added `extraResources: [{ from: "public/fonts", to: "fonts" }]` to electron-builder config so fonts are copied outside the asar in packaged builds and accessible via `process.resourcesPath`

**`electron/main.ts`**
- Added `pdfLegendKey(chord)` — `pdfStripMajor(chord.split('/')[0])`; single helper used in both legend dedup and consecutive-dedup in bar progression; collapses `C/E`, `GM/D` etc. to root
- Updated `drawKeyboardThumbnail`: white key fill `#efefef`, stroke `#c0c0c0` 0.2pt; black key fill `#2a2a2a`, width fixed 4.5pt, height fixed 11pt (no longer derived from thumb dimensions); black keys no longer stroked
- In `transcript:generate` IPC handler:
  - Font registration via `doc.registerFont()` for `Inter`, `Inter-Bold`, `Inter-Italic`, `Mono`; resolved from `app.isPackaged ? process.resourcesPath/fonts : appPath/public/fonts`
  - **Chord detection — consecutive dedup** now compares by `pdfLegendKey` (root+quality, ignoring inversion) instead of exact match; `C → C/E → C/G` collapses to one `C` entry
  - **Legend dedup** now uses `pdfLegendKey` as the set key; `chordEn` field on `GridChord` set to the key-normalised value so the legend only holds root-position chords; 50+ legend entries reduced to ~8–15 for typical pop/rock files
  - **`C_LINE`** changed `'#2a2a3a'` → `'#d0d0dc'`; added `C_INFO = '#909090'`; all grid `lineWidth` calls 0.3 → 0.2; header rule stays 0.3pt per spec
  - **Dynamic row height** — fixed pre-computed `rowH` removed; per-bar: `rowH = Math.max(20, barChords.length * 11)`; page-break check uses the current bar's own `rowH`
  - **Chord placement — contained within cell** — `doc.widthOfString()` to measure; font size tries 8 → 7 → 6pt until text fits `BEAT_COL_W - 4`; proportional x clamped to `[cellLeft+2, cellRight−tw−2]`; 3+ chords per cell use adaptive step `min(9, (rowH−14)/(n−1))` with hard ceiling/floor at `rowTop+3` / `rowBottom−3−fontSize`; rendered with `width: cellRight − drawX − 1` to prevent overflow
  - **Fonts applied throughout**: header title `Inter-Bold 13pt`; subtitle `Inter-Italic 8pt`; info line `Inter 7pt`; section label `Inter 7pt C_DIM`; legend chord names `Inter-Bold 7pt`; legend note names `Inter 6pt`; beat header `Inter 6pt`; bar numbers `Mono 7pt`; grid chord names `Mono` 8/7/6pt; footer `Inter 7pt`

---

### 30. 6. 2026 — Chord Transcript PDF generation

**New feature:** Clicking the `FileText` icon in the chord bar (extended mode) generates a PDF chord transcript of the loaded MIDI file and saves it next to the source file as `<filename>_CHORD_TRANSCRIPT.pdf`.

**`npm install pdfkit @types/pdfkit`** — PDF generation dependency, main process only.

**`src/types/index.ts`**
- Added `TranscriptEntry { midiPath, transcriptPath, date }` interface
- Added `transcriptGenerate(midiPath): Promise<{ success, path?, error? }>` to `Window.electronAPI` global declaration

**`electron/preload.ts`**
- Added `transcriptGenerate` IPC bridge for `transcript:generate`

**`src/store/index.ts`**
- Added `transcriptHistory: TranscriptEntry[]` and `addTranscriptEntry(entry)` — capped at 20 entries (newest first, oldest dropped); persists immediately to `orfeo-prefs.json` via direct `setPrefs` call inside the action
- Restored `transcriptHistory` from prefs in `restoreLibraryPrefs`

**`electron/main.ts`**
- Added imports: `basename`, `createWriteStream`, `Chord`/`Note` from tonal, `PDFDocument` from pdfkit
- Added `pdfStripMajor()`, `pdfPickBest()`, `pdfDetectChord()` — minimal chord detection duplicated from renderer-side `chordDetection.ts` (cannot import renderer code into main process); uses tonal.js `Chord.detect()` + shortest non-slash root-position name
- Added `drawKeyboardThumbnail(doc, x, y, chordName)` — draws a C4–B4 one-octave keyboard using pdfkit vector rects (8 white keys, 5 black keys); chord tones filled amber, others grey/off-white
- Added `formatTranscriptDate()` — date string in project format
- `transcript:generate` IPC handler:
  1. Parses MIDI with `@tonejs/midi`; collects notes from all non-percussion tracks
  2. 80ms cluster window → `pdfDetectChord()` per cluster → filter `< 2` notes
  3. Bar number from `Math.floor(time / secPerBar) + 1` using first tempo + time signature
  4. Dedup consecutive identical chords; group remaining by bar (stack with `→` prefix for multiple chords per bar)
  5. Collect unique chords in order of first appearance for legend
  6. PDF via pdfkit (A4 portrait, 20mm margins): header (filename 18pt, subtitle 12pt grey, tempo/key/bars 10pt dim, rule), chord legend (keyboard thumbnails 5/row, chord name + note names), bar grid (4/row, 52pt cell height, stacked chords), footer (rule + attribution)
  7. Writes to `midiFilePath.replace(/\.midi?$/i, '_CHORD_TRANSCRIPT.pdf')`
  8. Returns `{ success, path }` or `{ success: false, error }`

**`src/components/Keyboard/Keyboard.tsx`**
- Injected `@keyframes orfeo-transcript-spin` style element at module level (guarded by `id` check)
- Added `addTranscriptEntry` subscription
- Added `transcriptState` (`'idle'|'loading'|'success'|'error'`) and `transcriptTooltip` local state; `transcriptRevertRef` for 3-second auto-revert
- Replaced `FileText` no-op placeholder with active icon:
  - Active only when `midi._filePath` is present; otherwise `opacity:0.35, cursor:not-allowed`
  - Loading: spin animation, tooltip "Generating…"
  - Success: green color, tooltip "✓ Saved — filename.pdf" for 3s, calls `addTranscriptEntry`
  - Error: red color, tooltip shows error string for 3s
  - Auto-reverts to idle state and default tooltip after 3s

---

### 30. 6. 2026 — Chord Prompter embedded in chord bar

**`src/components/ChordPrompter.tsx`** — deleted; all display is now handled inline in `Keyboard.tsx`

**`src/App.tsx`**
- Removed `ChordPrompter` import and render

**`src/components/Keyboard/Keyboard.tsx`**
- Added `resolveCurrentIndex()` — binary search for `lastEvent.time <= currentTime`; same algorithm that was in the old floating panel
- Added `frozenIndexRef` — freezes at last known chord index on pause/stop; resets to `-1` on file change via `useEffect([midi])`
- Added store subscriptions: `midi`, `chordSequence`, `chordPrompterOpen`, `currentTime`
- Removed playback chord detection from the live `activeKeys` effect; that effect now returns early when `playbackState === 'playing'` — playback chord display is now sourced entirely from the pre-computed `chordSequence`
- Manual chord detection (Shift+click lock mode, mouse play when not playing) is unchanged
- Chord bar is now dual-mode with a fluid `height: 0.2s ease` transition:
  - **Simple** (`chordPrompterOpen === false`, 30 px): unchanged layout; chord name priority chain updated to `locked → explorer → sequenceChord → displayedChord → empty`; `sequenceChord` is used instead of the old live-detected `displayedChord` during playback
  - **Extended** (`chordPrompterOpen === true`, 56 px): three-column teleprompter — 4 past chords (Inter 11px `#9090a8`) | `‹` | current chord (JetBrains Mono 20px bold amber) | `›` | 2 next chords; bottom 14px sub-row holds CHORDS / SCALES triggers; empty states: "Open a MIDI file" / "No chords detected" / "Press play"

**`src/components/Transport/TopBar.tsx`**
- Added `FileText` to Lucide imports
- Added `FileText` placeholder icon immediately after the `ScrollText` button; only visible when `chordPrompterOpen === true`; `cursor:not-allowed`, `opacity:0.4`, `color:#505068`, tooltip "Transcribe & Save PDF"; no-op on click

---

### 30. 6. 2026 — Chord bar layout polish

**`src/components/Keyboard/Keyboard.tsx`**
- Extended mode collapsed from two stacked rows (56px total: 42px sequence + 14px CHORDS/SCALES sub-row separated by a border) into a single flat flex row (36px)
- Single-row extended layout: `[CHORDS] [ScrollText toggle] [FileText placeholder]` left-anchored flex group | chord sequence (past `‹` current `›` next) centred flex-1 | `[SCALES]` right-anchored flex item — no separator, no sub-row
- `ScrollText` prompter toggle icon moved from `TopBar` into the chord bar left group (size 13, `strokeWidth 1.5`): amber when `chordPrompterOpen === true`, `#707088` when false; shown only when `chordPrompterEnabled && midi`
- Same toggle icon appears in extended mode left group (always amber, since open)
- Simple mode height increased 30px → 34px for visual consistency with extended 36px
- Added `chordPrompterEnabled`, `setChordPrompterOpen` store subscriptions; added `ScrollText` to Lucide imports

**`src/components/Transport/TopBar.tsx`**
- Removed `ScrollText` from Lucide imports
- Removed `chordPrompterEnabled`, `chordPrompterOpen`, `setChordPrompterOpen` store subscriptions (all moved to `Keyboard.tsx`)
- Removed `ScrollText` transport button entirely — toggle now lives in the chord bar

---

### 29. 6. 2026 — Chord Prompter

**`src/types/index.ts`**
- Added `ChordEvent` interface: `{ time: number; name: string; notes: string[] }` — represents one chord in the pre-computed sequence

**`src/store/index.ts`**
- Added `chordPrompterEnabled: boolean` (default `false`, persisted to `orfeo-prefs.json`)
- Added `chordPrompterOpen: boolean` (default `false`, not persisted) + setter
- Added `chordSequence: ChordEvent[]` (default `[]`, not persisted) + setter
- `setMidi(null)` and `resetAll` now clear `chordSequence` and `chordPrompterOpen`
- `restoreLibraryPrefs` restores `chordPrompterEnabled` from saved prefs

**`src/hooks/useChordSequence.ts`** (new)
- `useChordSequence()` — effect on `[midi, noteNaming, accidentals]`; deferred with `setTimeout(0)` so it doesn't block the render thread
- `computeChordSequence()`: collects non-drum note events, groups by 80ms cluster threshold, detects chord via `detectChord()`, localizes via `localizeChord()` (with `'hidden'` → `'english'` fallback), deduplicates consecutive identical names, builds `notes[]` from unique PCs via `getNoteName()`
- Clears sequence when no MIDI loaded

**`src/components/ChordPrompter.tsx`** (new)
- Floating 500×110px panel; `position:fixed`, `zIndex:402`, default top-right above keyboard
- Draggable via header (same mouse-event pattern as ChordExplorer)
- Three-column layout: past 3 chords (fading left, opacity 0.5/0.3/0.15) | current chord (JetBrains Mono 22px bold amber, notes row below) | next 3 chords (fading right)
- `resolveCurrentIndex()`: binary-search for last event where `event.time <= currentTime`, then enforces 2-second minimum hold by walking back
- Freezes display on pause/stop via `frozenIndexRef` — never clears current chord
- Three empty states: no file, no chords detected, not yet playing
- Footer: disabled placeholder "Transcribe & Save PDF" button (`cursor:not-allowed`, `opacity:0.4`)

**`src/components/Transport/TopBar.tsx`**
- Added `ScrollText` (lucide-react) to imports
- `ScrollText` icon button appears after the Loop button, only when `chordPrompterEnabled && midi !== null`
- Toggles `chordPrompterOpen`; amber when open, `#707088` when closed; tooltip "Chord Prompter"

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Added new **Playback** section (between Audio and Appearance)
- `OptionRow` "Chord Prompter" with On/Off toggle — enables/disables the transport icon and the prompter window

**`src/App.tsx`**
- Calls `useChordSequence()` alongside other lifecycle hooks
- Renders `<ChordPrompter />` after `<ScaleExplorer />`

**Refinements (same session):**
- `resolveCurrentIndex` simplified to a plain binary search — removed 2-second minimum hold so the centre chord advances immediately in sync with the above-keyboard chord display; past chords persist naturally in the history column
- Opacity ramp lifted from `[0.5, 0.3, 0.15]` to `[0.85, 0.55, 0.28]`; font size 11px Inter → 14px JetBrains Mono on side chords
- Dot `·` separators between each chord in both past and next columns
- "CHORD PROMPTER" header label coloured amber

---

### 29. 6. 2026 — Bar numbers, bar counter, metronome fixes

**`src/utils/midiParser.ts`**
- `parseMidiBuffer` now precomputes `_barStarts: number[]` — array of bar start times in seconds, built by walking `_tempoMap` with the time signature numerator; handles mid-song tempo changes correctly
- Single source of truth: PianoRoll and TopBar both read this array, eliminating bar-count drift

**`src/store/index.ts`**
- Added `barStarts: number[]` field (default `[]`, not persisted) — set from `_barStarts` in `setMidi`, cleared in `resetMidi`/`resetAll`
- Added `showBarNumbers: boolean` (default `true`) + `setShowBarNumbers` — persisted alongside other display prefs
- `restoreLibraryPrefs` restores `showBarNumbers` from saved prefs

**`src/components/PianoRoll/PianoRoll.tsx`**
- Full rewrite of bar overlay layer: PixiJS `Text` pool replaced with a Canvas2D overlay (`position:absolute`, `pointer-events:none`) drawn every frame via `clearRect` + `fillRect`/`fillText` — reliable text rendering, no PixiJS texture sizing issues
- Bar start times now read from `storeRef.current.barStarts` (no local recomputation)
- `currentBarIdx` scan fixed: removed `else break` that caused early exit before scanning all events
- Horizontal bar lines drawn in Canvas2D (`rgba(30,30,56,0.5)`) before pills; pills use `ctx.roundRect` with `ctx.rect` fallback
- Container div gets `position: 'relative'` for overlay positioning; overlay resized in `ResizeObserver` callback

**`src/components/Transport/TopBar.tsx`**
- Added `barStarts` from store; replaced simple `Math.floor(currentTime/barDuration)+1` with binary search into `barStarts` — exact sync with PianoRoll
- BAR counter moved inside the `alignItems:'flex-end'` right group div so its bottom aligns with TIME/METRONOME/MIDI labels

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- "Bar numbers & grid lines" Show/Hide toggle added under Piano Roll section

**`src/hooks/useMetronome.ts`** *(complete rewrite — full tempo-map awareness)*
- **Bug fix:** Removed `useStore.setState({ bpm: rawBpm, originalBpm: rawBpm })` — the metronome was overwriting `originalBpm` on every tempo-change event in the MIDI, corrupting the user's tempo ratio and causing visible BPM stutter
- **Bug fix:** Accent beat alignment — changed `Math.floor(elapsedBeats)` to `Math.ceil(elapsedBeats)` for initial `beatNumRef`; `timeToNextBeat` now uses `(ceil - elapsed) * spb` instead of `(1 - frac) * spb`; the old code scheduled beat 0's click one full beat late, causing the accent to land on beat 2 instead of beat 1 of each bar
- **Root fix for rubato files:** `elapsedBeats = currentTime / localSpb` was wrong for files with tempo changes — it divided only by the current-segment BPM without integrating prior tempo events, causing `beatNumRef` to start at the wrong position; replaced with `getElapsedBeats()` which walks the full `_tempoMap`
- Added `getElapsedBeats(tempoMap, time)`: integrates beats across all tempo segments up to `time` seconds (exported for TopBar)
- Added `getSongTimeForBeat(tempoMap, targetBeat)`: inverse function, maps absolute beat number → file seconds; handles mid-file tempo changes exactly
- Scheduler redesign — per-tick beat audio times computed via `audioOffsetRef + getSongTimeForBeat(tempoMap, bt) / ratio` (exact, tempo-aware) instead of accumulating `nextBeat += spb` (drifts across tempo changes); `lastScheduled` ref prevents double-firing; `audioOffsetRef = ctx.currentTime - currentTime/ratio` is a true invariant during uninterrupted playback
- Removed `nextBeatRef`, replaced with per-beat exact computation; removed `beatNumRef` accumulation loop

**`src/components/Transport/TopBar.tsx`** *(additional change)*
- BPM display now shows live tempo from `_tempoMap` at `currentTime` instead of the static `bpm` store value; computed via `reduce` over `rawTempoMap`, scaled by user ratio (`bpm / originalBpm`); updates every frame as the song plays through tempo changes
- `isTempoChanged` flag continues to reflect user tempo adjustment (ratio ≠ 1), not the file's internal tempo changes

---

### 29. 6. 2026 — Audio engine persistence + Chord Explorer search rewrite (v0.6.1)

**`src/store/index.ts`**
- `audioEngine` added to the display-settings prefs subscriber — saved alongside `noteNaming`/`accidentals`/`masterVolume` on every change
- `restoreLibraryPrefs` now restores `audioEngine: 'samples'` from prefs on startup

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- New `useEffect` on `[audioEngine]` — when prefs restore sets engine to `'samples'` and `samplesStatus` is still `'idle'`, auto-calls `initSamplesEngine`; SF2 loads in background on cold start, progress bar visible if Settings tab is open

**`src/components/ChordExplorer.tsx`**
- Replaced broken inline `includes()` filter with Fuse.js fuzzy search (`fuse.js` v7)
- `searchableChords` useMemo builds one record per chord: `display` (root+suffix e.g. `Cm7`), `typeName` (suffix only, root-independent e.g. `m7`), `aliases` (tonal.js), `notes` (note names for selected root), `numerics` (digit substrings e.g. `7 11`)
- `fuseInstance` useMemo — keys vary by `searchScope`: `name` → `['typeName','numerics']`; `notes` → `['notes']`; `both` → `['display','typeName','notes','numerics']`; `threshold: 0.2`, `minMatchCharLength: 1`, `ignoreLocation: true`
- `aliases` excluded from all Fuse keys — tonal.js aliases contain long English words (`'minor'`, `'dominant'`) that caused spurious matches on single letters (n, o, i, u)
- Search scope toggle `[Name | Notes | Both]` added inline to header search bar; `searchScope` state persists for the session, default `'both'`
- `useEffect` on `[tier]` clears search when switching Common ↔ Extended
- Bug: `searchableChords` useMemo initially referenced `rootLabel()` which is declared later in the component — caused ReferenceError (black screen) on first render; fixed by inlining `rootLabels.find()` directly

**`electron.vite.config.ts`**
- `optimizeDeps.include: ['fuse.js']` — pre-bundles fuse.js at dev server start, preventing mid-session dep-optimisation reload (black screen) when ChordExplorer mounts for the first time

**`package.json`**
- `fuse.js` added as dependency; version bumped `0.5.0` → `0.6.1`

**`CLAUDE.md`**
- Full redesign: concise structure, Key Files table, Note Naming section, Non-Obvious Architecture section (ParsedMidi private fields, RANGES sync rule, `#/editor` hash routing, Fuse aliases gotcha), Versioning section with MAJOR/MINOR/PATCH rules; removed resolved Known Issue (Chord Explorer search)

---

### 2026-06-28 — Samples audio engine (spessasynth_lib + GeneralUser GS SF2)

**New hook: `src/hooks/useSamplesEngine.ts`**
- `initSamplesEngine(onProgress)` — creates AudioContext, loads AudioWorklet processor, dynamically imports `WorkletSynthesizer`, fetches `GeneralUser-GS.sf2` (30.8 MB) with streaming progress, adds soundbank, wires GainNode
- `buildSamplesPlayer(startSec)` — schedules noteOn/noteOff for all unmuted tracks via setTimeout; respects mute/solo/transpose/BPM ratio; key lighting for `showOnKeyboard` tracks
- `useSamplesEngine()` hook — three subscribers: playback state (play/pause/stop), engine switching (clears schedule when leaving 'samples'), master volume (updates GainNode gain)
- **Volume normalisation**: `SAMPLES_BOOST = 3.0` constant applied to GainNode (`masterVolume × 3`) plus CC7=127 sent to all 16 channels at init and playback start, matching perceived loudness of the GM Synth
- **Engine switching**: detects `audioEngine` transitions — leaving 'samples' calls `clearSchedule()` + `clearAllKeys()`; arriving at 'samples' while playing calls `buildSamplesPlayer(currentTime)`
- **Recursive crash fix**: all `prev*` closure variables updated *before* the if-condition chain — prevents Zustand's synchronous subscriber re-entry from calling `buildSamplesPlayer` recursively when `clearAllKeys()` triggers `setState`
- WorkletSynthesizer imported dynamically (not at module level) to prevent Vite from triggering a mid-session dep-optimisation page reload on first use

**`src/hooks/useAudioEngine.ts`**
- Engine switching: `prevAudioEngineRef` tracks the previous engine; when leaving 'gm' → `stopAudio()`; when arriving at 'gm' while playing → `buildPlayer(currentTime)`
- Replaces `useSF2Engine` import with `useSamplesEngine`; click dispatcher routes to `__orfeoPlayNoteSamples` when `audioEngine === 'samples'`

**`src/components/SettingsPanel/SettingsPanel.tsx`**
- Audio section: functional GM Synth / Samples buttons; Samples click calls `initSamplesEngine` with inline progress bar and status line ("Loading soundfont… X%" → "GeneralUser-GS.sf2 · 30.8 MB · loaded")
- `samplesStatus` / `samplesProgress` local state; switches engine automatically when loading completes

**`src/store/index.ts`**
- `audioEngine: 'gm' | 'samples'` and `setAudioEngine` added to `OrfeoStore` interface (implementation was already present)

**`electron.vite.config.ts`**
- `optimizeDeps.exclude: ['spessasynth_lib', 'spessasynth_core']` — prevents Vite from pre-bundling these large ESM packages, which was causing a mid-session page reload (black screen) on first engine activation

**`package.json`**
- `copyworklet` script copies `spessasynth_processor.min.js` from node_modules to `public/` before dev/build
- `spessasynth_lib: ^4.3.8` added to dependencies

**Deleted: `src/hooks/useSF2Engine.ts`** — replaced by useSamplesEngine

---

### 2026-06-28 — Volume knob + TopBar reset fixes

**New component: `src/components/VolumeKnob.tsx`**
- Interactive SVG dial: central amber circle with rotating dark notch indicator
- 7 fixed dots in a 270° arc (7:30 → 4:30 clockwise); dots at or below the current level render in amber (`#e8a027`), headroom dots in dim tint (`#e8a02738`)
- Drag-to-rotate: `mousedown` starts, document `mousemove` maps angle to 0–1 volume, `mouseup` ends; snaps immediately on click too
- Label column mirrors BPM/KEY structure (8px spacer + VOLUME text) so the label baseline aligns with TEMPO/TRANSPOSE to its left
- Positioned between KEY/TRANSPOSE and the centre transport section; no separator on the right

**`src/store/index.ts`**
- `masterVolume: number` (default `0.8`) + `setMasterVolume` — clamped to 0–1
- Persisted to `orfeo-prefs.json` via the existing display-settings subscriber; restored on startup alongside `noteNaming`/`accidentals`
- `resetAll` now also resets `bpm: 120`, `originalBpm: 120`, `detectedKey: null`

**`src/hooks/useAudioEngine.ts`**
- `applyMasterVolume(v)` — sends MIDI CC 7 (Main Volume) on all 16 channels via `_port`
- Called in `buildPlayer` before `player.play()` so every new playback session inherits the knob position
- New `useEffect` subscriber fires on every `masterVolume` change during live playback or key-click — no player rebuild needed

**`src/components/Transport/TopBar.tsx`**
- BPM value displays `—` when no MIDI file is loaded (matches KEY behaviour); `isTempoChanged` is always false without a file
- VolumeKnob imported and placed after KEY section with `alignItems: center` parent so it sits on the header's horizontal centreline

---

### 2026-06-28 — Inversion display architecture rework + locked chord seed fix

**`src/store/index.ts`** — new fields:
- `explorerChordDisplay: { name, invCount, noteCount } | null` + setters — single source of truth for chord above keyboard when an explorer is open; replaces the previous pattern where explorers called `setDisplayedChord` on an inverted note set
- `lockedChordNoteCount: number` + setter — enables correct modulo wrapping for locked chord inversion labels; `clearLockedKeys` and `resetAll` reset it

**`src/utils/chordDetection.ts`**:
- `formatInversionDisplay` — added `noteCount` parameter; applies `((invCount % noteCount) + noteCount) % noteCount` so labels loop correctly for all chord sizes (3-note: root→1st→2nd→root…; 4-note: adds 3rd; 5/6+: same logic)
- `stripMajorSuffix` — exported; applied at the end of `localizeChord` as a global safety net so `CM`/`GM` can never reach the UI
- `stripMajorSuffix` now also applied inside the solfege branch of `localizeChord`

**`src/components/Keyboard/Keyboard.tsx`**:
- `handleKeyClick` Shift branch — seeds `lockedInversionCount` from `detectChordWithInversion().ordinal` instead of always 0; locking C-F-A (an F 2nd inv) now immediately shows "F/C 2nd inv" and cycles correctly from that position
- Added `explorerDisplay` useMemo — reads `explorerChordDisplay` from store, calls `formatInversionDisplay` with stored noteCount; renders in chord bar with correct modulo label
- Chord bar priority: locked → explorer → MIDI playback → empty; `Nth inv` ordinal label colour changed from `#c0c0d0` to `#707088` globally
- Detection effect guarded: skips `activeKeys` re-detection while any explorer is open, preventing the active-keys path from overriding `explorerChordDisplay` with a wrong re-detected chord name (e.g. `G6` instead of `Em7/G`)

**`src/components/ChordExplorer.tsx`**:
- Removed local `originalChordName`/`inversionCount` state — replaced by `explorerChordDisplay` in store
- `playChordAt` — calls `setExplorerChordDisplay({ name, invCount: 0, noteCount })` instead of local state
- `handleInversion` — updates `explorerChordDisplay.invCount` in store via `useStore.getState()`
- Footer centre restored to plain grey `PLAY INVERSION` text between two `<Play>` Lucide icons (matching ScaleExplorer); chord display removed from footer entirely

**`src/components/ScaleExplorer.tsx`**:
- Same store migration as ChordExplorer — local `originalChordName`/`inversionCount` removed
- `playDegree`, `handlePrevInversion`, `handleNextInversion`, CoF onClick, RotateCcw, close — all wired to `setExplorerChordDisplay`/`clearExplorerChordDisplay`
- Footer centre restored to same plain grey `PLAY INVERSION` text; added hover states to inversion play buttons

---

### 2026-06-27 — Chord inversion display fix (complete)

Core principle: `Chord.detect()` called once on the root-position note set; original chord identity is preserved across all inversion cycling. Never re-detect on an already-inverted set. `stripMajorSuffix()` applied at every return point — no bare `CM`/`GM` in UI.

**`src/utils/chordDetection.ts`** — rewrote inversion detection and added formatting helpers:
- `detectChordWithInversion(midiNotes)` — always returns root-position name (never slash); inversion number derived from bass pitch class position in `Chord.get().notes` list; returns `{ name, invLabel, ordinal }`
- `formatInversionDisplay(originalChordName, inversionNumber, bassNoteMidi, noteNaming, accidentals, showLabel)` — computes `{ chordLabel, invLabel, ordinal }` from stored original name + count; root position returns empty strings; inverted returns `C/E` slash notation + ordinal number
- `ordinalSuffix(n)` — exported helper returning `'st'`/`'nd'`/`'rd'`/`'th'` for superscript rendering
- `stripMajorSuffix()` applied at every return point in both functions

**`src/store/index.ts`** — added locked-chord identity state:
- `originalLockedChordName: string | null` + `setOriginalLockedChordName`
- `lockedInversionCount: number` + `setLockedInversionCount`
- `clearLockedKeys` resets both; `resetAll` resets both

**`src/components/Keyboard/Keyboard.tsx`** — chord bar inversion display:
- `lockedDisplay` useMemo calls `formatInversionDisplay` with `originalLockedChordName` + `lockedInversionCount` + live bass MIDI
- Chord bar renders: amber `chordLabel` (slash notation when inverted) + ordinal superscript + `inv` label
- `handleKeyClick` Shift branch stores `localizeChord(info.name)` as `originalLockedChordName` and resets `lockedInversionCount` to 0
- Playback `displayedChord` (no inversion count known): root amber 14px + `/bass` lighter 11px, no ordinal

**`src/components/Keyboard/KeyboardControls.tsx`** — inversion count tracking:
- `applyInversion` callback updates `lockedInversionCount` in store (`+1` for next, `-1` for prev) after each voicing rotation

**`src/components/ChordExplorer.tsx`** — inversion display in footer:
- Local `originalChordName` + `inversionCount` state; set when a chord tile is clicked (`playChordAt`), reset on close/RotateCcw
- `handleInversion` increments/decrements `inversionCount` by direction
- Footer centre: `formatInversionDisplay` renders chord/bass label + ordinal superscript + `inv`; falls back to "Play Inversion" text when no chord is active

**`src/components/ScaleExplorer.tsx`** — same inversion display pattern as ChordExplorer:
- Local `originalChordName` + `inversionCount` state
- `playDegree` stores `chord.chordName` as `originalChordName` and resets count to 0
- CoF outer and inner ring onClick handlers reset both on key change
- `handlePrevInversion` decrements count; `handleNextInversion` increments count
- RotateCcw handler resets both alongside all other state
- Footer "PLAY INVERSION" static span replaced with `formatInversionDisplay` dynamic rendering — shows slash notation + ordinal superscript when inverted, falls back to static label otherwise

---

### 2026-06-27 — Manual chord lock mode redesign

**`src/components/Keyboard/Keyboard.tsx`**
- Chord bar now shows the locked chord name + inversion label when a manual lock is active — computed via `detectChordWithInversion` + `useMemo` directly in the component; takes priority over `displayedChord` from playback

**`src/components/Keyboard/KeyboardControls.tsx`**
- Removed chord name / inversion display from the bottom row (moved to chord bar above)
- Bottom row locked state restructured: `LOCKED CHORD` dim label left, then `[◂ Play] [PLAY outlined amber] [Play ▸]` inversion player, then `RotateCcw` clear — styled to match ScaleExplorer footer
- Removed `detectChordWithInversion`, `localizeChord`, `ChevronLeft`, `ChevronRight` imports; added `RotateCcw`

**`src/components/ChordExplorer.tsx`**
- Removed `setKeyboardSize(61)` and prevSizeRef restore — ChordExplorer no longer forces 61-key (61-key is ScaleExplorer-only; default stays at 73)
- RotateCcw reset button now also calls `clearLockedKeys()` when a chord is locked

**`src/components/ScaleExplorer.tsx`**
- RotateCcw reset button now also calls `clearLockedKeys()` when a chord is locked

---

### 2026-06-27 — ScaleExplorer bug fixes

**`src/components/ScaleExplorer.tsx`**

- **Chord keyboard range** — `buildDiatonicChord` octave preference order changed from `[4,3,5,2]` to `[3,4,2,5]`; chord roots now land in C3–B3 (MIDI 48–59) by default, keeping full triads within the C3–C5 range instead of starting at C4 and climbing higher
- **Inversion player** — removed `inversionStep` state and `playInversion` callback; `handlePrevInversion` / `handleNextInversion` now read live `explorerKeys` from the Zustand store and rotate in-place using `prevInversionSet` / `nextInversionSet` module helpers (identical pattern to ChordExplorer's `handleInversion`); voicings now traverse the full keyboard range in both directions indefinitely instead of wrapping after N chord tones

---

### 2026-06-27 — Progressions row redesign + SpeedControl

**New component: `src/components/SpeedControl.tsx`**
- SVG speed selector with three fixed nodes (slow / med / fast)
- Active node: amber fill + drop-shadow glow filter; inactive: stroke-only with `fill="transparent"` for full-disc click area
- Two track segments (slow→med, med→fast) so no line crosses the middle node
- `mix-blend-mode: lighten` on all elements prevents alpha seam at node/track junctions
- "Speed" label right-aligned above the fast node

**ScaleExplorer + ChordExplorer — progressions row (`src/components/ScaleExplorer.tsx`, `src/components/ChordExplorer.tsx`)**
- Three-column layout: left (PROGRESSIONS label + dropdown), centre absolute (PLAY/STOP + SpeedControl), right (INVERSIONS label + icon buttons)
- PLAY/STOP button: outlined style — amber border + glow at rest, red border + glow during playback; `<Play>`/`<Square>` Lucide icons; tooltip "Pick a pattern to play a progression" when disabled
- Inversion mode buttons: `<CircleOff>` / `<ListOrdered>` / `<Shuffle>` icons replace Off/Sequential/Random text buttons
- Chord Quality info row (ScaleExplorer): all progression steps shown as roman numerals on one line; active step amber/bold 12px, inactive dim 11px
- Progressions dropdown: two-column layout — name (minWidth 90px) + roman numerals (JetBrains Mono 9px, opacity 0.65); container minWidth 260px

**ScaleExplorer footer**
- `‹` / `›` chevrons replaced with `<Play size={14}>` / `<Play size={14} scaleX(-1)>` Lucide icons
- RotateCcw reset button: `title="Clear & reset"` tooltip added
- "Chord Explorer" link: uppercased + `<ArrowUpRight>` icon replaces `→`

---

### 2026-06-26 — Scale Explorer layout polish (round 3–4)

All changes in `src/components/ScaleExplorer.tsx`:

- **Guideline text always visible** — removed `selectedRoot === null` condition; the hint text ("Click a key on the circle…") now shows at all times, including when a key is selected alongside the info box
- **CoF section height +30px** — increased bottom padding from 16px to 46px; the "CHORDS IN THE SCALE" label and bottom-circle accidentals are no longer cramped; all four bottom rows shift down
- **Scale column vertical alignment** — added `marginTop: 20` to correct a systematic 20px offset between the scale buttons midpoint and the CoF circle centre (caused by SVG geometry: CY + viewBox offset = 230px vs `alignSelf:center` = 210px in a 420px flex line)
- **Accidental gap uniformity** — replaced uniform-multiplier sigR with a font-size-scaling formula: font shrinks for longer strings (1–3 chars → fs 11, 4–5 → fs 9, 6–7 → fs 8) with matching char-half-width so the inner text edge stays ~8–9px from the ring for all 12 positions; sigR range narrows from 185–215 to 187–201

---

### 2026-06-25 — Scale Explorer layout polish (rounds 1–2)

All changes in `src/components/ScaleExplorer.tsx`:

- Info box moved to absolute overlay (top: 0, centered on CoF axis) — no longer a flex sibling that compressed the SVG wrapper
- Guideline text repositioned to absolute top-left of CoF section
- CoF section changed to `position: relative` to anchor both overlays
- Scale buttons column set to `alignSelf: center`
- "CHORDS IN THE SCALE" label moved to absolute bottom of CoF section
- Chord button padding increased to 8px top/bottom
- Bottom 4 rows reordered: chord tiles → chord/inversion info → progressions/inversions → SHOW AS footer
- All 4 bottom rows: `minHeight: 44`
- Play/Stop button: always red (`#c0392b` bg, `#e74c3c` hover)
- SVG viewBox extended to `"0 -40 380 420"` so top accidentals render fully

---

### 2026-06-24 — Scale Explorer (initial implementation)

- New modal: `src/components/ScaleExplorer.tsx` (~970 lines)
- Zustand store: `scaleExplorerOpen` / `setScaleExplorerOpen`
- Circle of Fifths SVG (12 wedges, outer = major, inner = minor)
- 10 scale types with diatonic chord grid, Roman numeral progressions, inversion cycling
- Footer ‹ PLAY INVERSION › pattern (same as ChordExplorer)
- ChordExplorer ↔ ScaleExplorer switching buttons
- Both explorers force 61-key layout; Keyboard.tsx font conditions updated

---

### 2026-06-23 — Chord Explorer enhancements

- Progressions, inversion modes, layout polish
- `displayedChord` added to Zustand store
- ChordExplorer search (known issue: unreliable across naming systems)

## [0.5.2] — 2026-06 — Scale Explorer
> Session 10 | Branch: dev

### Added
- Scale Explorer modal (`ScaleExplorer.tsx`) — 720px draggable; opens from "Scales" trigger right side of chord bar
- Circle of Fifths SVG — 380×380; outer (major) + inner (relative minor) rings; amber selection; ♯/♭ symbols staggered at alternating radii
- 10 scale types; notes play ascending including octave root note
- Diatonic chord grid — 7 tiles; Roman numeral labels; click to light keyboard and play
- Info row, chord/inversion display row, progressions (20 named), SpeedControl, modal switching
- App launches maximized; both modals default-position above keyboard on open

### Changed
- "Scales" trigger added right side of keyboard chord bar
- Key label font sizes enlarge when either explorer is open
- App.tsx Space/Escape guards check `scaleExplorerOpen`

### Fixed
- Scale replays on every COF click (playTrigger counter)
- Clear button resets all local Scale Explorer state
- Explorers always open fresh via useEffect reset

---

## [0.5.1] — 2026-06 — Chord Explorer
> Session 09 | Branch: dev

### Added
- Chord Explorer modal (`ChordExplorer.tsx`) — 600px draggable; pauses playback on open
- Root selector, Common/Extended chord grid, Hand filter, Note count filter, Search
- Inversion browser — `‹ PLAY INVERSION ›` centred footer; RotateCcw clears
- Accidentals toggle in footer; Chord Progressions (15 named); Logo click reset

### Changed
- All rows: label-left / controls-right; modal width 540px → 600px
- `displayedChord` moved to Zustand store; chord bar label → `Locked Chord`
- PROGRESSIONS + INVERSIONS merged into one row

### Fixed
- CE naming: pitch class 10 always `'B'` (was `'A#'`)
- RotateCcw clears chord bar display; explorer keys excluded from persistence

---

## [0.5.0] — 2026-06 — UI Polish, Tempo Map Metronome, Piano Roll Range Fix
> Session 08 | Branch: dev → main

### Added
- Tempo map metronome — persistent 25ms interval; handles mid-file tempo changes
- MIDI tempo map extraction (`_tempoMap`); BPM display tracks changes
- BPM long-press — hold ▲/▼ to accelerate; `LongPressArrow` component
- Warm theme functional; Zoom wired to PianoRoll renderer
- Piano roll key range respects selected keyboard size (was hardcoded 88)
- User Manual link; Floating keyboard width-only resize

### Changed
- Left drawer width 220px → 260px; Library tab default; opens on launch
- Note naming buttons: UK/US, EU, Hide
- Piano roll grid — black-key shading + C-note dividers; playhead 1px → 2px
- Keyboard height proportional via ResizeObserver; metronome levels/pitch/lookahead tuned
- `package.json` version 0.2.1 → 0.5.0

### Fixed
- Library subfolder `ChevronDown` missing import; chord tooltip direction

---

## [0.3.2] — 2026-06 — Floating Keyboard, Chord Display During Playback, Metronome Alignment
> Session 07 | Branch: dev

### Added
- Floating keyboard (`FloatingKeyboard.tsx`) — draggable; boundary-clamped; pin and × re-dock
- Keyboard size button tooltips

### Changed
- Chord debounce during playback 320ms → 60ms; clears immediately below 3 notes
- `accidentals` added to chord display effect dependency array
- Metronome aligns first click to next grid-aligned beat at current playback position

### Fixed
- Float button toggled store but no floating panel existed — now real

---

## [0.3.1] — 2026-06 — Library Subfolders, MIDI Editor Fixes, Settings Persistence
> Sessions 05/06 | Branch: dev

### Added
- Library subfolder support — recursive scan; collapsible headers; Windows paths normalised
- Full GM instrument list — all 128 programs across 16 families
- Pencil icon turns amber when MIDI editor open; resets via `editor:closed` IPC

### Changed
- `noteNaming` + `accidentals` persisted with null sentinel fix; MIDI editor undo-merge in-place
- Output filename dynamically switches `_ORFEO` / `_ORFEO_MERGED`
- Drums show plain "Standard Drums"; GM family icons 12px → 15px

### Fixed
- Library file click silently failed; first subscriber fire overwrote saved prefs

---

## [0.3.0] — 2026-06 — Left Drawer, Library, MIDI Editor, UI Polish, Build Pipeline
> Session 04 | Branch: dev → main

### Added
- Left settings/library drawer (`SettingsPanel.tsx`) — Settings + Library tabs
- MIDI file library — folder picker, star toggle, persistent, click to load
- Accidentals toggle — `convertAccidentals()` single source of truth
- MIDI Playback Editor (`MidiEditor.tsx`) — separate Electron window; track include/exclude; GM reassignment; track merge; Save & Reload (`_ORFEO.mid`)
- Build pipeline — `electron-builder` + NSIS; real app icon
- SF2 audio engine scaffold; design token system; chord detection rewrite; chord lock

### Changed
- TopBar redesigned; track panel auto-opens on MIDI load; `titleBarStyle: 'hidden'`
- Default keyboard size 73 keys; metronome rewritten (Web Audio API lookahead)

### Fixed
- `showOnKeyboard` flag before key lighting; mouse click uses channel 14 + Grand Piano

---

## [0.2.0] — 2026-06 — MIDI Playback, Audio Engine, Visual Polish
> Sessions 02/03 | Branch: dev

### Added
- MIDI file open dialog; MIDI parser; PixiJS piano roll (falling notes, 60fps)
- Visual clock (rAF + `performance.now()`); Tone.js audio engine (`Tone.Part` + `Tone.Transport`)
- Key lighting — `activeKeys` / `activeKeyColors`; piano-family tracks only

### Fixed
- App freeze on startup (JZZ lazy init); infinite loop in Zustand subscriber
- Transpose not affecting audio; topbar padding cramped by Windows titlebar overlay

---

## [0.1.0] — 2026-06 — Initial Scaffold
> Session 01 | Branch: main

### Added
- Electron + Vite + React + TypeScript scaffold via electron-vite
- PixiJS piano roll (WebGL); Zustand store; `@tonejs/midi` parser; `tonal.js` chord detection
- Note naming: English, Central European (H), Solfège, Hidden
- Virtual keyboard (61/73/88); track panel; amber `#e8a027` theme on `#0f0f12`
- Inter + JetBrains Mono typography; CSS variables; Tailwind
- README, CHANGELOG, ROADMAP, ARCHITECTURE

### Technical Decisions
- PixiJS over Canvas — WebGL for large MIDI files
- Zustand over Redux — simpler boilerplate
- Central European note naming (H = B natural) for Slovenian/German/Croatian users