# Orfeo

**From MIDI to mastery.** Turn any MIDI file into an interactive piano-learning
experience.

[![Version](https://img.shields.io/github/v/release/Squarebow/Orfeo?label=Version&color=blue)](https://github.com/Squarebow/Orfeo/releases/latest) [![License](https://img.shields.io/badge/License-GPLv3-blue)](LICENSE.md) [![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey?logo=windows)](https://github.com/Squarebow/Orfeo/releases)

📖 **User manual: [orfeo.cc/docs](https://orfeo.cc/docs)**

Orfeo is free and always will be. If it helps your playing, you can support it on [Ko-fi](https://ko-fi.com/squarebow) or [GitHub Sponsors](https://github.com/sponsors/Squarebow).

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/X5T32931V0)

![Orfeo mid-playback: falling notes on the keyboard, keys lit in track colours, the live chord name above](.github/images/orfeo-hero.webp)

---

Orfeo is a free, open-source desktop app that turns MIDI files into an
interactive piano lesson: notes fall onto a virtual keyboard in real time, keys
light up as they play, and you can slow down, loop, transpose, and explore any
passage at your own pace. Real-time chord detection, hand-coloured keys,
interactive chord and scale explorers, a full mixer, and per-note editing — with
a piano roll that looks like it was built this decade.

It's not a game — no scoring, no streaks, no subscription. No account, no
telemetry; MIDI files are processed entirely on your device.

## Contents

- [Features](#features)
- [Download](#download)
- [Documentation](#documentation)
- [Building from source](#building-from-source)
- [FAQ](#faq)
- [Why Orfeo](#why-orfeo)
- [License](#license)

---

## Features

### Piano Roll & Playback

- **Import** `.mid` / `.midi`, plus MusicXML, Guitar Pro, Capella, and karaoke
  `.kar` (converted automatically)
- **Falling-note piano roll** onto a 61 / 73 / 88-key keyboard, colour-coded per
  track, pixel-aligned to each key
- **Tempo control** — slow down or speed up without changing pitch; long-press
  the BPM arrows to glide to a target
- **Change key** — transpose the whole piece by semitones
- **Loop region** — draw a loop directly on the waterfall and drill any section
- **Metronome** — follows the file's embedded tempo map through mid-song changes;
  right-click for volume and count-in
- **Count-in** — 1–4 bars of clicks before the music starts, at the song's real
  tempo, leading straight into the first note
- **Skip empty bars** — songs open where the music starts, with silent lead-in
  bars left out (a drum count-in can stay); the file itself is never changed
- **Tap Tempo** — fix songs whose bar lines and metronome don't match the music:
  tap along on Space or a MIDI key, and Orfeo lines your beat up with the song's
  own drums and bass, remembers it for that song, and never touches the file
- **Tempo warnings** — optional marks in the Library and the top bar for songs
  whose bar lines and metronome don't match the music's beat
- **Tracks panel & Console Mixer** — mute, solo, recolour, show/hide tracks
  (hide a part to hear it as accompaniment without seeing it on the roll or keys);
  per-channel volume, pan, chorus, reverb with live VU meters (saved into the
  file on close); master Tone and Compressor
- **Focus Mode** — one click to hear keys, bass and drums but see only the keys;
  click again and every track comes back as it was
- **Export to audio** — save any song as MP3 (320 kbps) or WAV (CD quality):
  as written, keys + bass + drums only, or exactly as you hear it (tempo, key,
  muted parts, Mixer, loop), with the Studio or Native sound
- **Presentation Mode** (`F11`) — distraction-free view of just the roll and
  keyboard

### Interactive Keyboard

- **Click or drag** to play; drag across keys for glissando
- **Docked or floating** — a draggable, resizable panel for multi-window setups
- **Key highlighting** in track colour, with the chord name shown live above
- **Automated hand assignment** — notes colour-code by which hand plays
  them, in Practice (moving split line) or Performance (per-note tags) mode, with
  optional colourblind-friendly L/R badges, and **hand colours** of your choice
  (ready-made pairs, colour-blind friendly ones included, or your own)
- **Hardware MIDI input** — play along on a real keyboard with true sustain and
  multi-device support. A dedicated *MIDI Keyboard* page in Settings lists every
  keyboard by name and sets touch response, pedals and controls, and a double-note
  filter, with a **Delay check** that shows where every millisecond between key and
  speaker goes
- **Step Through** — walk through a song one note or chord at a time with `→` and
  `←`, at your own pace

### Chord & Scale Explorers

- **Chord Explorer** — browse and audition any chord in any key; filter by hand
  span or note count; cycle inversions; play progressions in nine chord
  styles
- **Scale Explorer** — interactive Circle of Fifths; ten scale types, each with
  its diatonic chords and Roman numerals
- **Real-time chord detection** with three tracking modes (Auto, Harmony,
  Follow Instrument)
- **Chord Prompter** — a lead-sheet-style past / current / next readout synced
  to playback
- **Chord Transcription** *(beta)* — generate a printable chord chart PDF for
  any file
- **Lock-a-Chord** — `Shift`+click any 3+ keys to build and lock a chord, then
  cycle inversions

### MIDI Editing

- **MIDI Playback Editor** — exclude, rename, recolour, reassign instrument,
  merge, and split-hands tracks; saves as a new `_ORFEO_vN.mid` without touching
  the original
- **Note Editor** — move, resize, add, delete, and re-velocity individual notes
  on the roll, with marquee / lasso / pen tools and full undo/redo
- **MIDI library** — browse a folder, star favourites, fuzzy-search, auto-refresh
- **Edit history embedded in the file** — travels with the `.mid` anywhere,
  survives reinstalls

### Visual Flourishes

- **Hit effects** — seven optional particle animations where notes strike the
  keyboard (glow bloom, ripple ring, particle burst, smoke plume, colour aura,
  starburst nova, comet trail), with custom colour and a real bloom filter

### Audio

- **Master volume** — a physical-feeling toolbar knob, persists across sessions
- **Three sound engines** — **GM** (General MIDI: instant, no download),
  **Studio** (SpessaSynth + downloadable SF2/SF3 soundfonts, GeneralUser GS by
  default) for far richer sound, and **Native** *(beta)*, which plays the same
  soundfonts straight to your sound card so a MIDI keyboard is heard in under
  10 ms. Native mixes songs like Studio and has two modes: **Shared** (other apps
  keep playing) and **Exclusive** (the shortest latency from keyboard to speaker,
  3-10 ms in average, depending on your sound card). A connected keyboard switches
  it to Exclusive by itself
- **Your own mix, played as written** — both engines follow a song's own volume
  swells and fades, tracks sharing a MIDI channel share its mix, and parts that
  change instrument mid-song switch at the right moment

### Settings

- **Setup** — the everyday switches (sound engine, Focus mode, Tap Tempo, note
  names, key range, zoom…) in the left panel, each with a one-line explanation
- **Settings window** (`Ctrl` `,`) — every setting in nine groups with full
  descriptions, a search box, and a link to the matching page of the online
  manual. Hints can be switched off with the *Tooltips* switch under Appearance

Full walkthrough of every feature: **[orfeo.cc/docs](https://orfeo.cc/docs)**.

---

## Download

Grab the latest build from the [Releases](https://github.com/Squarebow/Orfeo/releases)
page:

<table width="100%">
<colgroup><col width="34%"><col width="66%"></colgroup>
<thead><tr><th>File</th><th>Use</th></tr></thead>
<tbody>
<tr><td><code>Orfeo-Setup-&lt;version&gt;.exe</code></td><td>Standard Windows installer — Start Menu shortcut, automatic updates</td></tr>
<tr><td><code>Orfeo-&lt;version&gt;-portable.exe</code></td><td>Portable — no installation, runs from anywhere, manual updates</td></tr>
</tbody>
</table>

Prefer the Store? Orfeo is also in the
[Microsoft Store](https://apps.microsoft.com/detail/9NJ9Q01P8JQD), which keeps it
up to date for you.

Not sure which, or want to know how they differ (auto-updates, where settings
live)? See **[docs/INSTALLATION.md](docs/INSTALLATION.md)**.

---

## Documentation

<table width="100%">
<colgroup><col width="20%"><col width="80%"></colgroup>
<thead><tr><th>Document</th><th>What's in it</th></tr></thead>
<tbody>
<tr><td><a href="https://orfeo.cc/docs">User manual</a></td><td>The complete guide — Play, Edit, Practice, Manage files, Extras (online at orfeo.cc)</td></tr>
<tr><td><a href="https://orfeo.cc/docs/support/roadmap">Roadmap</a></td><td>What is being built next</td></tr>
<tr><td><a href="docs/SHORTCUTS.md">Shortcuts</a></td><td>Every keyboard and mouse gesture</td></tr>
<tr><td><a href="docs/INSTALLATION.md">Installation</a></td><td>Installer vs. portable, updates, where data lives</td></tr>
<tr><td><a href="docs/ARCHITECTURE.md">Architecture</a></td><td>How Orfeo is built and why</td></tr>
<tr><td><a href="docs/CHANGELOG.md">Changelog</a></td><td>Technical release history</td></tr>
<tr><td><a href="docs/CONTRIBUTING.md">Contributing</a></td><td>Build from source, cut a release</td></tr>
</tbody>
</table>

---

## Building from source

```bash
git clone https://github.com/Squarebow/Orfeo.git
cd Orfeo
npm install
npm run dev
```

Requires [Node.js](https://nodejs.org) 20 LTS or newer. Full build and release
instructions, including macOS/Linux, are in
[docs/CONTRIBUTING.md](docs/CONTRIBUTING.md).

---

## FAQ

<details>
<summary><b>Is Orfeo free?</b></summary>

Yes — completely free and open source. No subscription, no paywalled features,
no account.

</details>

<details>
<summary><b>Does it need an account or an internet connection?</b></summary>

No account, no login, no telemetry — and no internet connection is needed to
play, practise or edit. MIDI files are processed entirely on your device, and
every sound engine works offline: the default sound set (GeneralUser GS)
ships inside the installer.

Orfeo only goes online when you ask it to, or to check for updates:

- **Extra sound sets** (FluidR3 GM ~142 MB, MuseScore General ~38 MB) are not
  in the installer; each is downloaded once, only when you press its download
  button in Settings → Audio, and kept in `%APPDATA%\Orfeo\soundfonts\`
  (your own imported `.sf2` / `.sf3` files go there too).
- **Updates:** the installed version checks GitHub for a new release when it
  starts; the portable version only shows a link, and *Check for updates* in the
  Microsoft Store version opens Orfeo's Store page. Offline, this simply
  doesn't happen.
- **Links** (user manual, GitHub) open in your web browser.

</details>

<details>
<summary><b>What platforms does Orfeo run on?</b></summary>

Windows 10/11 today, with an installer and a portable build. Orfeo is built on
Electron, so macOS and Linux builds are possible and community-buildable — see
[CONTRIBUTING.md](docs/CONTRIBUTING.md) — there just aren't official builds for
those platforms yet.

</details>

<details>
<summary><b>Does Orfeo support Finale, Sibelius, or MuseScore files?</b></summary>

Not their native formats directly — but all three export MusicXML, which Orfeo
imports and converts to MIDI automatically. Guitar Pro, Capella, and karaoke
`.kar` files are supported natively too.

</details>

<details>
<summary><b>What MIDI files work best?</b></summary>

Real, human-performed files with natural rubato and mid-song tempo changes —
Orfeo tracks the tempo map properly instead of assuming a flat click. Cleanly
quantized files work great too. Messy downloads can be cleaned up with the
Playback and Note editors without touching the original.

</details>

---

## Why Orfeo

Before Synthesia there was [Rondo](https://macsim.app/rondo/) — a lovely,
Mac-only MIDI learning app with a scrolling piano roll, tempo slowdown, and
track filtering. Development stopped and it no longer runs on modern macOS. The
alternative that filled the gap became expensive and gamified, and hasn't
meaningfully modernized in years.

Orfeo picks up Rondo's idea, rebuilt from scratch as an actively maintained,
cross-platform-capable app with one goal: **make the music itself — not the app
around it — the focus.** Free forever, no gamification, real rubato support,
open source, and a modern interface.

*Inspired by [Rondo](https://macsim.app/rondo/) (RIP).*

---

## License

GPL-3.0-or-later © [SquareBow](https://github.com/Squarebow) — see
[LICENSE.md](LICENSE.md). Bundles GSAP under a separate additional-permission
grant; see the license file and [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md).
