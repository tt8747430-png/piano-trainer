# Pianooo

[English](README.md) · **Deutsch** · [Français](README.fr.md) · [Español](README.es.md) · 🌐 [Website](https://hoai-droid.github.io/Pianooo/)

**Klavier lernen auf iPad, Mac und Android** – mit fallenden Noten, echtem Notenblatt,
157 Stücken zum Start und Bluetooth-MIDI für dein Digitalpiano (z. B. Kawai ES120).

<p align="center"><img src="site/img/roll.jpg" alt="Pianooo auf dem iPad: fallende Noten über der Tastatur" width="100%"></p>

**📲 Download:**

| 📱 iPad | 💻 Mac | 🤖 Android |
|:---:|:---:|:---:|
| [**Pianooo.ipa**](https://github.com/HOAI-droid/Pianooo/releases/download/ipad-latest/Pianooo.ipa) | [**Pianooo-Mac.zip**](https://github.com/HOAI-droid/Pianooo/releases/download/ipad-latest/Pianooo-Mac.zip) | [**Pianooo.apk**](https://github.com/HOAI-droid/Pianooo/releases/download/android-latest/Pianooo.apk) |
| Sideloadly oder AltStore | Terminal-Befehl | Herunterladen, antippen – fertig |

– Installation: [SIDELOADING.md](SIDELOADING.md)

## 🎯 Üben, das dich besser macht

Pianooo hört auf dein Digitalpiano (Bluetooth- oder USB-MIDI). Tippe bei den fallenden Noten auf **Üben** und wähle:

<p align="center"><img width="100%" src="site/img/practice-wait.jpg" alt="Warte auf mich"></p>

**⏳ Warte auf mich** – Die Noten bleiben an der Linie stehen, bis du die richtigen Tasten drückst. Die gesuchten Tasten leuchten.

<p align="center"><img width="100%" src="site/img/practice-rhythm.jpg" alt="Im Takt"></p>

**⏱️ Im Takt** – Das Stück läuft im Tempo. Jede Note wird bewertet: pünktlich, zu früh, zu spät oder verpasst.

- **Deine Hand:** links, rechts oder beide – die App spielt den Rest (andere Hand, andere Instrumente)
- **Schneller werden:** mit 50 % Tempo starten; mit *Tempo automatisch steigern* gibt es nach jedem Durchgang mit mindestens 90 % richtig 5 % mehr Tempo, bis zum Originaltempo
- **Klavier ohne MIDI?** **Mikrofon** wählen: bei *Warte auf mich* hört die App zu und prüft die erwarteten Töne – auch Akkorde
- **Loop** um eine schwierige Stelle – jeder Durchgang mit eigener Trefferquote und Serie

<p align="center"><img src="site/img/practice-panel.jpg" alt="Üben, das dich besser macht" width="80%"></p>

## Was Pianooo kann

- **Fallende Noten oder Notenblatt** – umschaltbar, jeweils über die ganze Fläche
- **Notenblatt drucken** (AirPrint, DIN A4) und teilen
- **Start-Katalog mit 157 Stücken** in 7 Stufen: Clementis Klavierschule,
  Hanon, Czerny, Burgmüller, Bach, Beethoven, Chopin, Debussy, Joplin … –
  jeweils mit MIDI **und** Noten ([KATALOG.md](KATALOG.md))
- **Bluetooth- und USB-MIDI** – eigenes Piano anschließen, Tasten leuchten mit,
  Anschlag und Pedal werden übernommen
- **Eigene Songs:** MIDI, MusicXML, Guitar Pro, Capella aus Safari, Dateien oder
  AirDrop mit „Teilen › Pianooo“ öffnen; Noten-PDF mit gleichem Namen daneben
  legen, dann erscheint sie im Notenblatt
- Tempo, Transponieren, Loop, Metronom, Hand-Farben, Akkorderkennung, Mixer,
  Noten-Editor – alles aus Orfeo
- **Vier Sprachen:** Deutsch, Englisch, Französisch, Spanisch – startet in der Systemsprache
- Bedienung per Finger: Ziehen, Akkorde mit mehreren Fingern, langes Drücken
  = Kontextmenü

**Handbuch:** [docs/HANDBUCH.md](docs/HANDBUCH.md) – Bedienung, Notenblatt, eigene Songs, alle Einstellungen

Details zur iPad-Version, Bluetooth und zum Selberbauen: [IPAD.md](IPAD.md)

### Notenblatt und Einstellungen

<p align="center"><img width="100%" src="site/img/sheet.jpg" alt="Notenblatt Seite für Seite, druckfertig (A4)"></p>

Notenblatt Seite für Seite, druckfertig (A4)

<p align="center"><img width="100%" src="site/img/settings.jpg" alt="Keyboard verbinden; Klang, Anschlag und Pedale"></p>

Keyboard verbinden; Klang, Anschlag und Pedale

## Herkunft und Lizenz

Pianooo ist eine Weiterentwicklung von **[Orfeo](https://github.com/Squarebow/Orfeo)**
von **SquareBow** – vielen Dank! Die ursprüngliche Beschreibung steht in
[docs/ORFEO-README.md](docs/ORFEO-README.md).

- Code: **GPL-3.0-or-later** – © SquareBow (Orfeo) und Beiträge von HOAI-droid
  (iPad-, Mac- und Android-Version), siehe [LICENSE.md](LICENSE.md) und
  [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md)
- Klavier-Klänge zum Download: Kawai Upright (CC0) und Yamaha Disklavier Grand
  (CC BY 3.0) von [FreePats](https://freepats.zenvoid.org), Kawai ES100 Concert Grand
  (CC BY 3.0) von [GD Craft](https://musical-artifacts.com/artifacts/2922) – Quellen in der
  [Release „soundfonts“](https://github.com/HOAI-droid/Pianooo/releases/tag/soundfonts)
- Katalog: Notensätze und MIDI vom [Mutopia Project](https://www.mutopiaproject.org),
  gemeinfrei bzw. Creative Commons – Quellen in
  [public/Katalog/QUELLEN.md](public/Katalog/QUELLEN.md)
